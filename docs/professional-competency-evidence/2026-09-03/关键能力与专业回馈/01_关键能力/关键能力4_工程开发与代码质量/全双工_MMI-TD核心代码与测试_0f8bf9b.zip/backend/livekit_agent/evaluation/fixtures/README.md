# Evaluation Fixtures

This directory is for local NoiseGate, SpeakerGate, and MMI-FD recording samples.

Recording folders are intentionally ignored by git because they can contain large WAV/log files and session-specific data. Keep local captures here when running scripts from `backend/livekit_agent/evaluation/`.

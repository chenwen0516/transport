"""音频素材生成器

一次性生成测试需要的音频 fixture 文件，便于复用和调试。
当前使用程序化生成（正弦波/噪声/类语音），后续可接入 TTS API 生成真实语音。

使用方法：
    python fixtures/generate_fixtures.py
"""

import sys
from pathlib import Path

# 将 core 加入路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.audio_generator import AudioGenerator


FIXTURES_DIR = Path(__file__).parent / "audio"


def main():
    FIXTURES_DIR.mkdir(parents=True, exist_ok=True)

    print(f"[Fixtures] Generating audio fixtures in {FIXTURES_DIR}")

    # 类语音信号（多个时长）
    for duration_s in [0.5, 1.0, 2.0, 3.0]:
        pcm = AudioGenerator.speech_like(duration_s)
        path = FIXTURES_DIR / f"speech_like_{int(duration_s * 1000)}ms.pcm"
        AudioGenerator.save_pcm(pcm, str(path))
        print(f"  - {path.name} ({len(pcm)} bytes, {duration_s}s)")

    # 静音
    for duration_s in [0.5, 1.0, 2.0, 3.0]:
        pcm = AudioGenerator.silence(duration_s)
        path = FIXTURES_DIR / f"silence_{int(duration_s * 1000)}ms.pcm"
        AudioGenerator.save_pcm(pcm, str(path))
        print(f"  - {path.name}")

    # 白噪声
    pcm = AudioGenerator.white_noise(2.0)
    AudioGenerator.save_pcm(pcm, str(FIXTURES_DIR / "noise_white_2s.pcm"))
    print(f"  - noise_white_2s.pcm")

    # 低音量噪声
    pcm = AudioGenerator.low_amplitude_noise(2.0)
    AudioGenerator.save_pcm(pcm, str(FIXTURES_DIR / "noise_low_amplitude_2s.pcm"))
    print(f"  - noise_low_amplitude_2s.pcm")

    # 正弦波（用作非语音对照）
    pcm = AudioGenerator.sine_wave(2.0, freq=440.0)
    AudioGenerator.save_pcm(pcm, str(FIXTURES_DIR / "sine_440hz_2s.pcm"))
    print(f"  - sine_440hz_2s.pcm")

    print("\n[Fixtures] Done!")
    print("\n提示：如需真实语音素材，可后续调用 TTS API 生成：")
    print("  - 火山引擎 TTS: voice='BV700_V2_streaming'")
    print("  - 华为云 TTS: voice='chinese_xiaoyan_common'")


if __name__ == "__main__":
    main()

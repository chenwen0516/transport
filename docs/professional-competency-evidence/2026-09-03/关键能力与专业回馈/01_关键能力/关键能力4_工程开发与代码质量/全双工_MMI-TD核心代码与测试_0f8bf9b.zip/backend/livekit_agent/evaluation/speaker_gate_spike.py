#!/usr/bin/env python3
"""SpeakerGate 离线标定 / 调试台（CAM++）。

用真实录音离线复现 SpeakerGate 的"自动注册 + 滑窗声纹相似度"判决，
打印 sim 时间线，并在双文件模式下给出建议阈值。**不接 LiveKit、确定性、可重复**。

依赖：numpy + 标准库 wave + audio_filter.CampplusEmbedder（onnxruntime + kaldi-native-fbank）。

用法
----
单文件（看一段录音的 sim 时间线，按当前 theta 看会怎么判）::

    python evaluation/speaker_gate_spike.py \
        --model model/pretrained/campplus_sv_zh-cn_16k-common.onnx \
        --wav recording.wav --enroll-sec 3

双文件（标定阈值：target=目标说话人, bg=背景人声）::

    python evaluation/speaker_gate_spike.py \
        --model model/pretrained/campplus_sv_zh-cn_16k-common.onnx \
        --wav target.wav --bg background.wav

输出
----
- sim 时间线（ASCII sparkline）+ 可选逐窗明细（--verbose）
- 目标/背景 sim 分位数
- 双文件模式：**建议 theta_open / theta_close**（基于分布分离度）
"""

from __future__ import annotations

import argparse
import sys
import wave
from pathlib import Path

import numpy as np

from _bootstrap import ensure_livekit_agent_path

ensure_livekit_agent_path()
from audio_filter import CampplusEmbedder  # noqa: E402

TARGET_SR = 16000


# ----------------------------------------------------------------------
# 音频读取
# ----------------------------------------------------------------------

def read_wav_16k_mono(path: str) -> np.ndarray:
    """读 16-bit PCM wav → int16 数值范围的 float32，单声道、16k。"""
    with wave.open(path, "rb") as w:
        n_ch = w.getnchannels()
        sw = w.getsampwidth()
        sr = w.getframerate()
        frames = w.readframes(w.getnframes())
    if sw != 2:
        raise ValueError(f"{path}: 仅支持 16-bit PCM wav（当前 sampwidth={sw}）")
    data = np.frombuffer(frames, dtype=np.int16).astype(np.float32)
    if n_ch > 1:
        data = data.reshape(-1, n_ch).mean(axis=1)
    if sr != TARGET_SR:  # 简单线性重采样（标定用足够）
        n_out = int(round(len(data) * TARGET_SR / sr))
        data = np.interp(
            np.linspace(0, len(data), n_out, endpoint=False),
            np.arange(len(data)),
            data,
        ).astype(np.float32)
    return data


def rms(x: np.ndarray) -> float:
    return float(np.sqrt(np.mean(x.astype(np.float64) ** 2))) if x.size else 0.0


# ----------------------------------------------------------------------
# 滑窗 embedding
# ----------------------------------------------------------------------

def window_embeddings(
    emb: CampplusEmbedder, wav: np.ndarray, win: int, hop: int, min_energy: float
):
    """产出 (t_sec, rms, embedding) —— 只对能量足的窗算 embedding。"""
    out = []
    for start in range(0, max(1, len(wav) - win + 1), hop):
        w = wav[start : start + win]
        if w.size < win:
            break
        r = rms(w)
        e = emb.embed(w) if r >= min_energy else None
        out.append((start / TARGET_SR, r, e))
    return out


def build_centroid(embs: list[np.ndarray]) -> tuple[np.ndarray | None, float]:
    """质心 = 归一均值；返回 (centroid, 自一致性 min 两两余弦)。"""
    embs = [e for e in embs if e is not None]
    if not embs:
        return None, 0.0
    M = np.stack(embs)
    c = M.mean(axis=0)
    c /= max(float(np.linalg.norm(c)), 1e-8)
    if len(M) == 1:
        return c, 1.0
    sims = M @ M.T
    np.fill_diagonal(sims, 1.0)
    consist = float(sims[np.triu_indices(len(M), k=1)].min())
    return c, consist


def sparkline(values: list[float], lo: float = 0.0, hi: float = 1.0) -> str:
    blocks = "▁▂▃▄▅▆▇█"
    out = []
    for v in values:
        t = max(0.0, min(1.0, (v - lo) / (hi - lo))) if hi > lo else 0.0
        out.append(blocks[min(len(blocks) - 1, int(t * (len(blocks) - 1)))])
    return "".join(out)


def pcts(vals: list[float]) -> str:
    if not vals:
        return "n/a"
    a = np.array(vals)
    return (
        f"p10={np.percentile(a,10):.3f} p50={np.percentile(a,50):.3f} "
        f"p90={np.percentile(a,90):.3f} (n={len(a)})"
    )


# ----------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description="SpeakerGate 离线标定台")
    ap.add_argument("--model", required=True, help="CAM++ .onnx 路径")
    ap.add_argument("--wav", required=True, help="目标说话人录音（单文件模式即全程）")
    ap.add_argument("--bg", help="背景人声录音（双文件标定模式）")
    ap.add_argument("--window", type=float, default=1.5)
    ap.add_argument("--hop", type=float, default=0.25)
    ap.add_argument("--min-energy", type=float, default=50.0)
    ap.add_argument("--enroll-sec", type=float, default=3.0, help="单文件模式：前 N 秒做注册")
    ap.add_argument("--theta-open", type=float, default=0.35)
    ap.add_argument("--theta-close", type=float, default=0.25)
    ap.add_argument("--verbose", action="store_true", help="打印逐窗明细")
    args = ap.parse_args()

    emb = CampplusEmbedder(args.model, TARGET_SR)
    if not emb.ok:
        print("[ERR] embedder 加载失败，检查 --model 是否为有效 .onnx", file=sys.stderr)
        return 2
    print(f"[OK] model loaded dim={emb.dim} in={emb._in_name} out={emb._out_name}")

    win = int(args.window * TARGET_SR)
    hop = int(args.hop * TARGET_SR)
    wav = read_wav_16k_mono(args.wav)
    print(f"[wav] {args.wav}: {len(wav)/TARGET_SR:.1f}s")

    # ---- 注册 ----
    if args.bg:
        enroll_src = wav  # 双文件：用整段 target 注册
    else:
        enroll_src = wav[: int(args.enroll_sec * TARGET_SR)]
    enroll_windows = window_embeddings(emb, enroll_src, win, hop, args.min_energy)
    centroid, consist = build_centroid([e for _, _, e in enroll_windows])
    voiced_enroll = sum(1 for _, _, e in enroll_windows if e is not None)
    if centroid is None:
        print("[ERR] 注册段没有足够能量的语音窗，调低 --min-energy 或换录音", file=sys.stderr)
        return 2
    print(f"[enroll] voiced_windows={voiced_enroll} self_consistency_min={consist:.3f}")
    if consist < 0.5:
        print("  ⚠ 注册自一致性偏低：注册段可能混入了第二个人或噪声，标定结果会不准")

    def score(wav_in: np.ndarray):
        rows = window_embeddings(emb, wav_in, win, hop, args.min_energy)
        sims = []
        for t, r, e in rows:
            s = float(centroid @ e) if e is not None else None
            sims.append((t, r, s))
        return sims

    # ---- 双文件标定模式 ----
    if args.bg:
        bg = read_wav_16k_mono(args.bg)
        print(f"[wav] {args.bg}: {len(bg)/TARGET_SR:.1f}s")
        tgt_sims = [s for _, _, s in score(wav) if s is not None]
        bg_sims = [s for _, _, s in score(bg) if s is not None]
        print("\n=== sim 分布 ===")
        print(f"target : {pcts(tgt_sims)}")
        print(f"bg     : {pcts(bg_sims)}")
        if tgt_sims and bg_sims:
            t_p10 = float(np.percentile(tgt_sims, 10))
            b_p90 = float(np.percentile(bg_sims, 90))
            if t_p10 > b_p90:  # 干净分离
                mid = (t_p10 + b_p90) / 2
                print(f"\n✅ 分离良好（target_p10={t_p10:.3f} > bg_p90={b_p90:.3f}）")
            else:  # 有重叠
                mid = (float(np.median(tgt_sims)) + float(np.median(bg_sims))) / 2
                print(f"\n⚠ 分布有重叠（target_p10={t_p10:.3f} ≤ bg_p90={b_p90:.3f}）"
                      "：会有误杀/漏拦，建议增大 window 或改善录音")
            margin = 0.05
            print(f"建议 SPEAKER_GATE_THETA_OPEN={mid + margin:.2f}")
            print(f"建议 SPEAKER_GATE_THETA_CLOSE={max(0.0, mid - margin):.2f}")
        return 0

    # ---- 单文件时间线模式 ----
    sims = score(wav)
    voiced = [(t, r, s) for t, r, s in sims if s is not None]
    print(f"\n=== sim 时间线（窗={args.window}s hop={args.hop}s）===")
    print("sparkline[0..1]: " + sparkline([s for _, _, s in voiced]))
    print(f"voiced sim: {pcts([s for _, _, s in voiced])}")
    open_n = sum(1 for _, _, s in voiced if s >= args.theta_open)
    close_n = sum(1 for _, _, s in voiced if s < args.theta_close)
    hyst_n = len(voiced) - open_n - close_n
    print(f"按当前 theta {args.theta_open}/{args.theta_close}: "
          f"目标={open_n} 背景={close_n} 滞回保持={hyst_n}（共 {len(voiced)} 个有声窗）")
    if args.verbose:
        print("\n  t(s)   rms     sim   decision")
        for t, r, s in sims:
            d = "—(silent)" if s is None else (
                "TARGET" if s >= args.theta_open else
                "BG" if s < args.theta_close else "hyst")
            print(f"  {t:5.2f} {r:7.1f} {('  -  ' if s is None else f'{s:.3f}')}  {d}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

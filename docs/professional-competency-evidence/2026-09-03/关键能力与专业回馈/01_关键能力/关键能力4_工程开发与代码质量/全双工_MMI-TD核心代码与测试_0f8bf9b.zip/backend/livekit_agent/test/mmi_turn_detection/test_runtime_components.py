from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from types import SimpleNamespace

import pytest

from mmi_turn_detection.context_store import MMITurnContextStore
from mmi_turn_detection.executor import MMITurnExecutor, StaleDecisionError
from mmi_turn_detection.models import (
    MMIConfidenceLevel,
    MMIMode,
    MMITurnAction,
    MMITurnDecision,
)
from mmi_turn_detection.runtime import MMITurnRuntime, resolve_mmi_mode
from mmi_turn_detection.session_options import build_local_turn_handling


@dataclass
class ModeConfig:
    mode: str = "active"
    active_percentage: int = 100
    enabled_pipelines: tuple[str, ...] = ("pipeline", "omni", "realtime_qwen")


class FakeSession:
    def __init__(self, *, fail_commit=False, fail_interrupt=False):
        self.commits = 0
        self.interrupts = 0
        self.interrupt_forces = []
        self.clears = 0
        self.generated_replies = []
        self.fail_commit = fail_commit
        self.fail_interrupt = fail_interrupt

    async def commit_user_turn(self):
        self.commits += 1
        if self.fail_commit:
            raise RuntimeError("commit failed")

    async def interrupt(self, *, force=False):
        self.interrupts += 1
        self.interrupt_forces.append(force)
        if self.fail_interrupt:
            raise RuntimeError("interrupt failed")

    def clear_user_turn(self):
        self.clears += 1

    def generate_reply(self, *, user_input=None, **kwargs):
        self.generated_replies.append(user_input)
        return SimpleNamespace()


class FakeEventSession(FakeSession):
    def __init__(self):
        super().__init__()
        self.handlers = {}

    def on(self, event_name):
        def register(handler):
            self.handlers[event_name] = handler
            return handler

        return register

    def emit(self, event_name, **fields):
        self.handlers[event_name](SimpleNamespace(**fields))


class FakeParticipant:
    def __init__(self):
        self.published_data = []

    def publish_data(self, data, *, reliable=False, topic=None):
        self.published_data.append(
            {
                "data": data,
                "reliable": reliable,
                "topic": topic,
            }
        )


class FakeRoom:
    def __init__(self):
        self.local_participant = FakeParticipant()
        self.handlers = {}

    def on(self, event_name, handler):
        self.handlers[event_name] = handler
        return handler


class StateChangingInterruptSession(FakeEventSession):
    async def interrupt(self, *, force=False):
        await super().interrupt(force=force)
        self.emit("agent_state_changed", new_state="listening")


class DelayedCommitSession(FakeEventSession):
    def __init__(self):
        super().__init__()
        self.commit_futures = []

    def commit_user_turn(self):
        self.commits += 1
        future = asyncio.get_running_loop().create_future()
        self.commit_futures.append(future)
        return future


@dataclass
class RuntimeConfig:
    min_endpointing_delay: float = 0.01
    max_endpointing_delay: float = 0.03
    wait_intent_max_ms: int = 100
    strong_interrupt_min_ms: int = 0
    ordinary_interrupt_min_ms: int = 10
    ordinary_interrupt_min_chars: int = 2
    stt_only_final_interrupt_min_ms: int = 10
    stt_only_final_interrupt_min_chars: int = 2
    observe_ms: int = 10
    max_observe_ms: int = 20
    decision_timeout_ms: int = 100
    eou_timeout_ms: int = 250
    max_consecutive_errors: int = 3
    fail_safe_enabled: bool = True
    fail_safe_interrupt_ms: int = 20
    vad_silence_offset_ms: int = 0
    require_target_speaker: bool = False
    require_explicit_intent_for_overlapping_followup: bool = False
    overlapping_followup_min_gap_ms: int = 2000
    speaker_non_target_sim_max: float = 0.18
    interrupt_target_min_similarity: float = 0.44
    target_latch_max_ms: int = 3000
    fast_path_shadow_enabled: bool = False
    fast_path_deadline_ms: int = 20


class FakeEOUService:
    calls = 0

    def __init__(self, *, timeout_ms):
        self.timeout_ms = timeout_ms

    async def predict(self, session, *, text, locale):
        type(self).calls += 1
        return 0.9, 0.5


def decision(store, action):
    return MMITurnDecision(
        action=action,
        confidence=1.0,
        confidence_level=MMIConfidenceLevel.HIGH,
        reason="test",
        turn_id=store.turn_id,
        based_on_event_id=store.event_id,
    )


def test_mode_resolution_is_stable_and_excludes_aliyun():
    config = ModeConfig(active_percentage=50)
    first = resolve_mmi_mode(config, pipeline="pipeline", session_id="room-1")
    second = resolve_mmi_mode(config, pipeline="pipeline", session_id="room-1")
    assert first == second
    assert resolve_mmi_mode(config, pipeline="realtime_aliyun", session_id="room-1") == MMIMode.OFF


def test_active_mode_falls_back_to_shadow_without_text_signals():
    config = ModeConfig(active_percentage=100)

    assert (
        resolve_mmi_mode(
            config,
            pipeline="realtime_qwen",
            session_id="room-1",
            text_signals_available=False,
        )
        == MMIMode.SHADOW
    )


@pytest.mark.asyncio
async def test_shadow_runtime_publishes_commit_after_native_user_turn(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    room = FakeRoom()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
        room=room,
    )
    runtime.setup()

    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="user",
            text_content="杭州明天天气怎么样？",
        ),
    )
    await asyncio.sleep(0)

    published = [
        json.loads(item["data"].decode("utf-8"))
        for item in room.local_participant.published_data
    ]
    assert [
        (item["type"], item["text"])
        for item in published
        if item["type"] == "transcript_commit"
    ] == [
        ("transcript_commit", "杭州明天天气怎么样？"),
    ]
    runtime.close()


def test_context_store_preserves_pause_but_resets_new_interruption_candidate():
    store = MMITurnContextStore(session_id="test")
    store.on_transcript("上一段", is_final=True)
    store.on_user_listening()

    store.on_user_speaking()
    assert store.final_text == "上一段"

    store.on_user_listening()
    store.on_user_speaking(force_new_turn=True)
    assert store.final_text == ""
    assert store.turn_id == 1


def test_context_store_marks_vad_backed_turn_started_during_agent_thinking():
    store = MMITurnContextStore(session_id="test")
    store.on_transcript("上一轮", is_final=True)
    store.consume_current_turn()
    store.on_agent_state("thinking")

    store.on_user_speaking(force_new_turn=True)

    assert store.turn_id == 1
    assert store.started_during_agent_thinking is True


def test_context_store_marks_stt_only_turn_started_during_agent_thinking():
    store = MMITurnContextStore(session_id="test")
    store.on_transcript("上一轮", is_final=True)
    store.consume_current_turn()
    store.on_agent_state("thinking")

    store.on_transcript("你继续", is_final=True)

    assert store.turn_id == 1
    assert store.started_during_agent_thinking is True
    assert store.transcript_text == "你继续"


def test_context_store_accounts_for_vad_silence_before_listening_event():
    store = MMITurnContextStore(session_id="test")

    store.on_user_listening(silence_offset_ms=800)

    assert store.snapshot().silence_ms >= 800


def test_context_store_initializes_missing_silence_from_final_transcript():
    store = MMITurnContextStore(session_id="test")

    store.ensure_listening_silence(silence_offset_ms=800)

    assert store.snapshot().silence_ms >= 800


def test_context_store_accumulates_final_transcript_segments_without_duplicates():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("我想咨询", is_final=True)
    store.on_transcript("高血压用药", is_final=True)
    store.on_transcript("我想咨询 高血压用药", is_final=True)
    store.on_transcript("需要注意什么", is_final=False)

    assert store.final_text == "我想咨询 高血压用药"
    assert store.transcript_text == "我想咨询 高血压用药 需要注意什么"


def test_context_store_replaces_same_utterance_final_rewrites():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("有冇？", is_final=True)
    store.on_transcript("天气。", is_final=True)
    store.on_transcript("有没有天气？", is_final=True)
    store.on_transcript("有没有天气相关的信息啊？", is_final=True)

    assert store.final_text == "有没有天气相关的信息啊？"
    assert store.transcript_text == "有没有天气相关的信息啊？"


def test_context_store_keeps_distinct_final_segments():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("杭州。", is_final=True)
    store.on_transcript("上海。", is_final=True)
    store.on_transcript("北京。", is_final=True)

    assert store.final_text == "杭州。 上海。 北京。"


def test_context_store_commit_text_uses_only_target_confirmed_segments():
    store = MMITurnContextStore(session_id="test")
    store.on_speaker_gate_status(True)

    store.on_transcript("背景先说。", is_final=True)
    store.on_speaker_verdict(True, similarity=0.72, kind="decide")
    store.on_transcript("讲一下目标问题。", is_final=True)

    assert store.transcript_text == "背景先说。 讲一下目标问题。"
    assert store.target_confirmed_transcript_text == "讲一下目标问题。"
    assert store.commit_transcript_text == "讲一下目标问题。"


def test_context_store_keeps_all_transcripts_from_same_target_speaker_segment():
    store = MMITurnContextStore(session_id="test")
    store.on_speaker_gate_status(True)

    store.on_speaker_verdict(
        None,
        kind=None,
        state=None,
        segment_id=80,
    )
    store.on_transcript("你查一下特朗普这条新闻。", is_final=True)
    store.on_speaker_verdict(
        True,
        similarity=0.62,
        kind="decide",
        state="TARGET_CONFIDENT",
        segment_id=80,
    )
    store.on_transcript("是哪个新闻啊？", is_final=True)

    assert store.transcript_text == "你查一下特朗普这条新闻。 是哪个新闻啊？"
    assert store.commit_transcript_text == store.transcript_text


def test_context_store_excludes_prior_non_target_speaker_segments_by_id():
    store = MMITurnContextStore(session_id="test")
    store.on_speaker_gate_status(True)

    store.on_speaker_verdict(
        None,
        kind=None,
        state=None,
        segment_id=76,
    )
    store.on_transcript("背景电视连续说话。", is_final=True)
    store.on_speaker_verdict(
        False,
        similarity=0.12,
        kind="decide",
        state="NON_TARGET",
        segment_id=76,
    )
    store.on_speaker_verdict(
        None,
        kind=None,
        state=None,
        segment_id=80,
    )
    store.on_transcript("帮我看一下这个东西。", is_final=True)
    store.on_speaker_verdict(
        True,
        similarity=0.63,
        kind="decide",
        state="TARGET_CONFIDENT",
        segment_id=80,
    )

    assert store.transcript_text == "背景电视连续说话。 帮我看一下这个东西。"
    assert store.commit_transcript_text == "帮我看一下这个东西。"


def test_context_store_target_verdict_marks_latest_final_segment():
    store = MMITurnContextStore(session_id="test")
    store.on_speaker_gate_status(True)

    store.on_transcript("背景先说。", is_final=True)
    store.on_transcript("讲一下目标问题。", is_final=True)
    store.on_speaker_verdict(True, similarity=0.72, kind="decide")

    assert store.transcript_text == "背景先说。 讲一下目标问题。"
    assert store.target_confirmed_transcript_text == "讲一下目标问题。"
    assert store.commit_transcript_text == "讲一下目标问题。"


def test_context_store_tracks_latest_transcript_segment_separately():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("等一下，等一下", is_final=True)
    store.on_transcript("海瑞是谁演的", is_final=True)

    assert store.transcript_text == "等一下，等一下 海瑞是谁演的"
    assert store.latest_transcript_text == "海瑞是谁演的"


def test_context_store_keeps_bounded_transcript_hypothesis_history():
    store = MMITurnContextStore(session_id="test")

    for index in range(15):
        store.on_transcript(f"hypothesis {index}", is_final=False)

    assert store.snapshot().transcript_hypotheses == tuple(
        f"hypothesis {index}" for index in range(3, 15)
    )


def test_context_store_clears_hypothesis_history_after_consuming_turn():
    store = MMITurnContextStore(session_id="test")
    store.on_transcript("Laura, can you help?", is_final=False)

    store.consume_current_turn()

    assert store.snapshot().transcript_hypotheses == ()


def test_context_store_extracts_latest_segment_from_cumulative_transcript():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("等一下，等一下", is_final=True)
    store.on_transcript("等一下，等一下 海瑞是谁演的", is_final=True)

    assert store.transcript_text == "等一下，等一下 海瑞是谁演的"
    assert store.latest_transcript_text == "海瑞是谁演的"


def test_context_store_does_not_treat_final_punctuation_as_latest_segment():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("等一下", is_final=False)
    store.on_transcript("等一下。", is_final=True)

    assert store.latest_transcript_text == "等一下。"


def test_transcript_before_vad_speaking_starts_new_turn_without_losing_text():
    store = MMITurnContextStore(session_id="test")
    store.on_transcript("上一轮", is_final=True)
    store.consume_current_turn()

    store.on_transcript("新一轮 partial", is_final=False)
    store.on_user_speaking()

    assert store.turn_id == 1
    assert store.partial_text == "新一轮 partial"
    assert store.final_text == ""


def test_transcript_before_vad_during_agent_speech_is_not_cleared():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("speaking")
    store.on_transcript("我想换一本", is_final=False)
    turn_id = store.turn_id

    store.on_user_speaking(force_new_turn=True)

    assert store.turn_id == turn_id
    assert store.partial_text == "我想换一本"
    assert store.snapshot().transcript_observe_ms >= 0


def test_stt_only_transcript_tracks_observation_duration(monkeypatch):
    now = 100.0
    monkeypatch.setattr(
        "mmi_turn_detection.context_store.time.monotonic",
        lambda: now,
    )
    store = MMITurnContextStore(session_id="test")
    store.on_transcript("我想换一本", is_final=False)

    now = 100.7
    snapshot = store.snapshot()

    assert snapshot.speech_ms == 0
    assert snapshot.transcript_observe_ms == 700


def test_stt_only_new_turn_does_not_inherit_previous_silence():
    store = MMITurnContextStore(session_id="test")
    store.on_transcript("上一轮", is_final=True)
    store.ensure_listening_silence(silence_offset_ms=10_000)
    store.consume_current_turn()

    store.on_transcript("嗯", is_final=True)

    assert store.turn_id == 1
    assert store.snapshot().silence_ms == 0


def test_context_store_consumes_non_interrupting_candidate_before_next_turn():
    store = MMITurnContextStore(session_id="test")
    store.on_user_speaking(force_new_turn=True)
    store.on_transcript("嗯嗯", is_final=True)
    store.on_user_listening()
    store.consume_current_turn()

    store.on_user_speaking()

    assert store.turn_id == 2
    assert store.transcript_text == ""
    assert store.committed is False


def test_context_store_latches_speaker_verdict_only_for_current_turn():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("我想看古装剧", is_final=True)
    store.on_speaker_verdict(True, similarity=0.408, kind="decide")
    snapshot = store.snapshot()

    assert snapshot.user_turn_active is True
    assert snapshot.external_speaker_is_target is True
    assert snapshot.turn_speaker_is_target is True
    assert snapshot.turn_speaker_similarity == 0.408
    assert snapshot.turn_speaker_verdict_kind == "decide"

    store.consume_current_turn()
    next_snapshot = store.snapshot()

    assert next_snapshot.user_turn_active is False
    assert next_snapshot.turn_speaker_is_target is None
    assert next_snapshot.turn_speaker_similarity is None
    assert next_snapshot.turn_speaker_verdict_kind is None


def test_context_store_target_latch_is_not_overwritten_by_later_background_verdict():
    store = MMITurnContextStore(session_id="test")

    store.on_transcript("我想看古装剧", is_final=True)
    store.on_speaker_verdict(True, similarity=0.408, kind="decide")
    store.on_speaker_verdict(False, similarity=0.28, kind="decide")
    snapshot = store.snapshot()

    assert snapshot.external_speaker_is_target is False
    assert snapshot.external_speaker_similarity == 0.28
    assert snapshot.turn_speaker_is_target is True
    assert snapshot.turn_speaker_similarity == 0.408


def test_context_store_decisive_non_target_overwrites_target_latch():
    store = MMITurnContextStore(
        session_id="test",
        speaker_non_target_sim_max=0.35,
    )

    store.on_transcript("我想看古装剧", is_final=True)
    store.on_speaker_verdict(True, similarity=0.52, kind="decide")
    store.on_speaker_verdict(False, similarity=0.18, kind="decide")
    snapshot = store.snapshot()

    assert snapshot.external_speaker_is_target is False
    assert snapshot.external_speaker_similarity == 0.18
    assert snapshot.turn_speaker_is_target is False
    assert snapshot.turn_speaker_state == "NON_TARGET"
    assert snapshot.turn_speaker_similarity == 0.18


def test_context_store_bargein_probe_does_not_overwrite_target_latch():
    store = MMITurnContextStore(
        session_id="test",
        speaker_non_target_sim_max=0.35,
    )

    store.on_transcript("我想看古装剧", is_final=True)
    store.on_speaker_verdict(True, similarity=0.52, kind="decide")
    store.on_speaker_verdict(False, similarity=0.18, kind="bargein")
    snapshot = store.snapshot()

    assert snapshot.external_speaker_is_target is False
    assert snapshot.external_speaker_similarity == 0.18
    assert snapshot.turn_speaker_is_target is True
    assert snapshot.turn_speaker_similarity == 0.52


@pytest.mark.asyncio
async def test_runtime_does_not_endpoint_before_user_activity(monkeypatch):
    FakeEOUService.calls = 0
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert FakeEOUService.calls == 0
    assert runtime._endpointing_task is None
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_commits_completed_user_turn(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="你好", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 1
    assert runtime.store.commit_pending is False
    assert runtime.store.committed is True
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_discards_non_target_turn_before_next_target_speech(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    room = FakeRoom()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
        room=room,
    )
    runtime.setup()
    runtime.store.on_speaker_gate_status(True)

    session.emit("agent_state_changed", new_state="listening")
    session.emit("user_state_changed", new_state="speaking")
    session.emit(
        "user_input_transcribed",
        transcript="啊，没有，昨天晚上唱的。",
        is_final=True,
    )
    runtime.store.on_speaker_verdict(
        False,
        similarity=0.12,
        kind="decide",
        state="NON_TARGET",
    )
    session.emit("user_state_changed", new_state="listening")

    session.emit("user_state_changed", new_state="speaking")
    runtime.store.on_speaker_verdict(
        True,
        similarity=0.60,
        kind="decide",
        state="TARGET_CONFIDENT",
    )
    session.emit("user_input_transcribed", transcript="你好，你好。", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    published = [
        json.loads(item["data"].decode("utf-8"))
        for item in room.local_participant.published_data
    ]
    assert [
        (item["type"], item["text"])
        for item in published
        if item["type"] in {"transcript_retract", "transcript_commit"}
    ] == [
        ("transcript_retract", "啊，没有，昨天晚上唱的。"),
        ("transcript_commit", "你好，你好。"),
    ]
    assert session.commits == 1
    assert session.clears == 1
    assert session.generated_replies == []
    assert runtime.store.commit_requested_text == "你好，你好。"
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_commits_question_after_wait_intent(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="等一下，等一下", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 0
    assert runtime.store.wait_intent_active is True

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="海瑞是谁演的", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 1
    assert runtime.store.committed is True
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_commits_same_turn_question_after_wait_prefix(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="Hold on.", is_final=False)
    runtime.store.consume_wait_intent("hold on")
    assert runtime.store.wait_intent_active is True

    session.emit(
        "user_input_transcribed",
        transcript="Hold on. How do I make a smoothie?",
        is_final=True,
    )
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 1
    assert runtime.store.commit_requested_text == "Hold on. How do I make a smoothie?"
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_commits_wait_turn_after_wait_timeout(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="等一下", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.15)

    assert session.commits == 1
    assert runtime.store.committed is True
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_cancels_pending_reply_for_wait_intent(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = StateChangingInterruptSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="thinking")
    session.emit("user_input_transcribed", transcript="我想一下啊", is_final=True)
    await asyncio.sleep(0.05)

    assert session.interrupt_forces == [True]
    assert session.commits == 0
    assert runtime.store.agent_state == "listening"
    assert runtime.store.wait_intent_active is True
    runtime.close()


@pytest.mark.asyncio
async def test_shadow_runtime_rechecks_late_target_verdict_after_native_interrupt(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(require_target_speaker=True),
    )
    decisions = []
    runtime._log_decision = lambda decision, **fields: decisions.append(
        (decision, fields)
    )
    runtime.setup()
    runtime.on_speaker_gate_status(True)

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit(
        "user_input_transcribed",
        transcript="How do I make a smoothie?",
        is_final=True,
    )
    await asyncio.sleep(0.02)
    session.emit("agent_state_changed", new_state="listening")
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="Pending assistant answer",
            interrupted=True,
        ),
    )

    await asyncio.to_thread(
        runtime.on_speaker_verdict,
        True,
        0.60,
        "bargein",
        "TARGET_CONFIDENT",
    )
    await asyncio.sleep(0.05)

    rechecks = [
        (decision, fields)
        for decision, fields in decisions
        if fields["trigger"] == "speaker_verdict_after_native_interrupt"
    ]
    assert len(rechecks) == 1
    decision, fields = rechecks[0]
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"
    assert fields["executed"] is False
    assert fields["context"].external_speaker_is_target is True
    assert fields["event_processing_latency_ms"] is not None
    runtime.close()


@pytest.mark.asyncio
async def test_shadow_runtime_skips_speaker_verdict_from_previous_turn(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(require_target_speaker=True),
    )
    decisions = []
    runtime._log_decision = lambda decision, **fields: decisions.append(
        (decision, fields)
    )
    runtime.setup()
    runtime.store.on_agent_state("speaking")
    runtime.store.on_user_speaking(force_new_turn=True)
    runtime.store.on_transcript("Old interruption", is_final=True)

    runtime.on_speaker_verdict(
        True,
        0.60,
        "bargein",
        "TARGET_CONFIDENT",
    )
    runtime.store.consume_current_turn()
    runtime.store.on_user_speaking(force_new_turn=True)
    runtime.store.on_transcript("New turn", is_final=True)
    await asyncio.sleep(0.05)

    assert not any(
        fields["trigger"].startswith("speaker_verdict_")
        for _, fields in decisions
    )
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_rechecks_speaker_verdict_for_active_user_turn(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(require_target_speaker=True),
    )
    triggers = []
    runtime._schedule_decision = lambda trigger, **_: triggers.append(trigger)
    runtime.setup()
    runtime.store.on_transcript("How do I make a smoothie?", is_final=True)

    await asyncio.to_thread(
        runtime.on_speaker_verdict,
        True,
        0.60,
        "decide",
        "TARGET_CONFIDENT",
    )
    await asyncio.sleep(0.02)

    assert triggers == ["speaker_verdict_recheck"]
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_ignores_backchannel_during_pending_reply(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="thinking")
    session.emit(
        "user_input_transcribed",
        transcript="uh-huh sure",
        is_final=True,
    )
    await asyncio.sleep(0.05)

    assert session.interrupts == 0
    assert session.commits == 0
    assert session.clears == 1
    assert runtime.store.user_turn_active is False
    assert runtime.store.agent_state == "thinking"
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_supersedes_pending_commit_when_user_resumes(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = DelayedCommitSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="我推荐的是", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 1
    assert runtime.store.commit_pending is True

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="我推荐的是雷霆", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 2
    assert runtime.store.transcript_text == "我推荐的是雷霆"
    assert runtime.store.commit_pending is True
    assert runtime.store.committed is False
    assert runtime.store.turn_id == 1
    assert session.commit_futures[0].cancelled()
    session.commit_futures[1].set_result("我推荐的是雷霆")
    await asyncio.sleep(0)
    assert runtime.store.committed is True
    runtime.close()


def test_active_runtime_ignores_stale_user_item_after_user_continues(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()
    runtime.store.on_transcript("我推荐的是雷霆", is_final=True)

    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(role="user", text_content="我推荐的是"),
    )

    assert runtime.store.committed is False
    assert runtime.store.user_turn_active is True
    assert runtime.store.transcript_text == "我推荐的是雷霆"
    runtime.close()


def test_active_runtime_does_not_use_user_item_as_commit_confirmation(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()
    runtime.store.on_transcript("有效问题", is_final=True)
    runtime.store.commit_pending = True

    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(role="user", text_content="有效问题"),
    )

    assert runtime.store.commit_pending is True
    assert runtime.store.committed is False
    assert runtime.store.user_turn_active is True
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_confirms_commit_when_livekit_future_completes(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = DelayedCommitSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()
    runtime.store.on_transcript("有效问题", is_final=True)
    runtime.store.on_user_listening()

    task = asyncio.create_task(
        runtime.executor.execute(decision(runtime.store, MMITurnAction.START_SPEAKING))
    )
    await asyncio.sleep(0)
    assert runtime.store.commit_pending is True

    session.commit_futures[0].set_result("有效问题")
    assert await task is True

    assert runtime.store.commit_pending is False
    assert runtime.store.committed is True
    assert runtime.store.user_turn_active is False
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_never_retries_same_committed_text(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()
    runtime.store.on_transcript("有效问题", is_final=True)
    runtime.store.on_user_listening()

    assert await runtime.executor.execute(
        decision(runtime.store, MMITurnAction.START_SPEAKING)
    )
    assert session.commits == 1
    assert runtime.store.committed is True

    runtime.store.committed = False
    runtime.store.user_turn_active = True
    assert await runtime.executor.execute(
        decision(runtime.store, MMITurnAction.START_SPEAKING)
    ) is False
    assert session.commits == 1
    runtime.close()


@pytest.mark.asyncio
async def test_runtime_close_cancels_untracked_decision_tasks(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    started = asyncio.Event()
    cancelled = asyncio.Event()

    async def slow_detect(_context):
        started.set()
        try:
            await asyncio.sleep(10)
        except asyncio.CancelledError:
            cancelled.set()
            raise

    runtime.detector.detect = slow_detect
    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    await started.wait()

    assert runtime._background_tasks
    runtime.close()
    await asyncio.sleep(0)

    assert cancelled.is_set()
    assert not runtime._background_tasks


@pytest.mark.asyncio
async def test_active_fail_safe_commits_pending_user_turn(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()
    runtime.store.on_transcript("故障期间的问题", is_final=True)
    runtime.store.on_user_listening()

    runtime._enter_fail_safe("test")
    await asyncio.sleep(0.05)

    assert session.commits == 1
    assert runtime.store.committed is True
    runtime.close()


@pytest.mark.asyncio
async def test_active_fail_safe_interrupts_sustained_user_speech(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()
    runtime.store.on_agent_state("speaking")
    runtime.store.on_user_speaking(force_new_turn=True)

    runtime._enter_fail_safe("test")
    await asyncio.sleep(0.04)

    assert session.interrupts == 1
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_discards_empty_vad_turn_after_max_delay(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 0
    assert runtime.store.committed is True
    assert runtime.store.user_turn_active is False
    assert runtime._endpointing_task is None

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="新的有效问题", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.commits == 1
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_discards_noise_only_turn_without_reply(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_input_transcribed", transcript="哎，嗯。", is_final=True)
    await asyncio.sleep(0.05)

    assert session.commits == 0
    assert runtime.store.committed is True
    assert runtime.store.user_turn_active is False
    assert runtime._endpointing_task is None
    assert session.clears == 1
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_preempts_thinking_for_new_vad_backed_turn(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    runtime.store.committed = True
    session.emit("agent_state_changed", new_state="thinking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="新的有效问题", is_final=True)
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.interrupt_forces == [True]
    assert session.commits == 1
    assert runtime.store.commit_pending is False
    assert runtime.store.committed is True
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_preempts_agent_that_starts_thinking_during_user_turn(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="新的有效问题", is_final=True)
    session.emit("agent_state_changed", new_state="thinking")
    session.emit("user_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert session.interrupt_forces == [True]
    assert session.commits == 1
    assert runtime.store.committed is True
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_interrupts_agent_that_starts_speaking_over_user(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="新的有效问题", is_final=False)
    session.emit("agent_state_changed", new_state="speaking")
    await asyncio.sleep(0.04)

    assert session.interrupts == 1
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_does_not_interrupt_response_started_by_pending_commit(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()
    runtime.store.on_transcript("当前问题", is_final=True)
    runtime.store.commit_pending = True
    runtime.store.commit_requested_text = "当前问题"

    session.emit("agent_state_changed", new_state="speaking")
    await asyncio.sleep(0.04)

    assert session.interrupts == 0
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_preempts_native_reply_for_short_gap_continuation(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(
            require_explicit_intent_for_overlapping_followup=True,
            overlapping_followup_min_gap_ms=2000,
        ),
    )
    runtime.setup()
    runtime.store.turn_id = 1
    runtime.store.user_turn_active = True
    runtime.store.user_state = "speaking"
    runtime.store.turn_started_after_previous_speech_ms = 400

    session.emit("agent_state_changed", new_state="thinking")
    await asyncio.sleep(0.01)

    assert session.interrupt_forces == [True]
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_keeps_native_reply_for_long_gap_overlap(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(
            require_explicit_intent_for_overlapping_followup=True,
            overlapping_followup_min_gap_ms=2000,
        ),
    )
    runtime.setup()
    runtime.store.turn_id = 1
    runtime.store.user_turn_active = True
    runtime.store.user_state = "speaking"
    runtime.store.turn_started_after_previous_speech_ms = 2500

    session.emit("agent_state_changed", new_state="thinking")
    await asyncio.sleep(0.01)

    assert session.interrupt_forces == []
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_ignores_external_user_item_and_owns_commit(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_input_transcribed", transcript="已经提交的问题", is_final=True)
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(role="user", text_content="已经提交的问题"),
    )
    session.emit("agent_state_changed", new_state="thinking")
    session.emit("agent_state_changed", new_state="listening")
    await asyncio.sleep(0.05)

    assert runtime.store.committed is True
    assert runtime.store.user_turn_active is False
    assert session.commits == 1
    runtime.close()


@pytest.mark.asyncio
async def test_shadow_runtime_logs_decision_for_native_commit(monkeypatch, caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("user_input_transcribed", transcript="你好", is_final=True)
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(role="user", text_content="你好"),
    )
    await asyncio.sleep(0.02)

    assert "native_user_turn_committed" in caplog.text
    assert '"user_state": "listening"' in caplog.text
    assert '"final_text_len": 2' in caplog.text
    assert '"context_eou_prob": 0.9' in caplog.text
    assert '"context_eou_unlikely_threshold": 0.5' in caplog.text
    assert session.commits == 0
    assert runtime.store.user_turn_active is False
    assert runtime._endpointing_task is None
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_pending_interruption_decision_is_dropped_when_agent_stops(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="打断候选", is_final=False)
    session.emit("agent_state_changed", new_state="listening")
    await asyncio.sleep(0.04)

    assert "user_transcript_during_agent_speech" not in caplog.text
    assert "interruption_observation_timer" not in caplog.text
    assert "native_assistant_item_interrupted" not in caplog.text
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_shadow_logs_native_interruption_from_interrupted_assistant_item(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="请告诉我城市",
            interrupted=True,
        ),
    )
    await asyncio.sleep(0.02)

    assert '"trigger": "assistant_item_interrupted"' in caplog.text
    assert '"action": "START_LISTENING"' in caplog.text
    assert "native_assistant_item_interrupted" in caplog.text
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_fast_path_shadow_correlates_pending_turn_with_native_stop(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(fast_path_shadow_enabled=True),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    await asyncio.sleep(0.01)
    session.emit("agent_state_changed", new_state="listening")
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="interrupted response",
            interrupted=True,
        ),
    )
    await asyncio.sleep(0.01)

    assert "fast_path_pending" in caplog.text
    assert "fast_path_decision" in caplog.text
    assert "fast_path_native_stop" in caplog.text
    assert '"decision_before_native_stop": false' in caplog.text
    assert session.interrupts == 0
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_fast_path_audio_deadline_decides_without_transcript(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(fast_path_shadow_enabled=True),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    runtime.store.on_voice_confidence(0.9, -20.0)
    session.emit("user_state_changed", new_state="speaking")
    await asyncio.sleep(0.04)

    assert "audio_target_speech_sustained" in caplog.text
    assert '"recommendation": "INTERRUPT"' in caplog.text
    assert session.interrupts == 0
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("transcript", "expected_action"),
    (("等一下", "START_LISTENING"), ("好的，好的。", "CONTINUE_SPEAKING")),
)
async def test_shadow_rechecks_final_transcript_as_if_native_interrupt_had_not_run(
    monkeypatch,
    caplog,
    transcript,
    expected_action,
):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit("agent_state_changed", new_state="listening")
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="请告诉我城市",
            interrupted=True,
        ),
    )
    session.emit("user_input_transcribed", transcript=transcript, is_final=True)
    await asyncio.sleep(0.04)

    payloads = []
    marker = "[MMI-TD] decision "
    for record in caplog.records:
        message = record.getMessage()
        if marker in message:
            payloads.append(json.loads(message.split(marker, 1)[1]))
    comparison = next(
        item
        for item in payloads
        if item.get("trigger") == "shadow_transcript_after_native_interrupt"
    )
    assert comparison["agent_state"] == "speaking"
    assert comparison["tts_playing"] is True
    assert comparison["action"] == expected_action
    assert comparison["executed"] is False
    assert session.interrupts == 0
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_active_warns_when_assistant_is_interrupted_outside_mmi_executor(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.WARNING, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="被意外打断",
            interrupted=True,
        ),
    )

    assert "assistant item interrupted outside MMI executor" in caplog.text
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_active_warns_when_agent_stops_during_unowned_user_input(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.WARNING, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="我想换一本", is_final=False)
    session.emit("agent_state_changed", new_state="listening")

    assert "agent stopped during active user input without MMI START_LISTENING" in caplog.text
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_shadow_deduplicates_native_interruption_sources(monkeypatch, caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit("agent_state_changed", new_state="listening")
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="正在播报",
            interrupted=True,
        ),
    )
    await asyncio.sleep(0.02)

    native_start_messages = {
        record.getMessage()
        for record in caplog.records
        if "[MMI-TD] native_action" in record.getMessage()
        and '"action": "START_LISTENING"' in record.getMessage()
    }
    assert len(native_start_messages) == 1
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_shadow_does_not_mark_natural_stop_as_native_interruption(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.runtime")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit("agent_state_changed", new_state="listening")
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="自然播报完成",
            interrupted=False,
        ),
    )
    await asyncio.sleep(0.02)

    assert '"action": "START_LISTENING"' not in caplog.text
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_active_runtime_interrupts_on_strong_intent(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="等一下", is_final=False)
    await asyncio.sleep(0.03)

    assert session.interrupts == 1
    assert session.interrupt_forces == [True]
    runtime.close()


@pytest.mark.asyncio
async def test_shadow_runtime_never_executes_decision(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="等一下", is_final=False)
    await asyncio.sleep(0.03)

    assert session.interrupts == 0
    runtime.close()


@pytest.mark.asyncio
async def test_partial_interruption_candidate_is_not_consumed_before_final(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="杭州", is_final=False)
    await asyncio.sleep(0.03)

    turn_id = runtime.store.turn_id
    assert runtime.store.partial_text == "杭州"
    assert runtime.store.committed is False

    session.emit("user_input_transcribed", transcript="杭州。", is_final=True)
    await asyncio.sleep(0.03)

    assert runtime.store.turn_id == turn_id
    assert runtime.store.committed is False
    assert runtime.store.final_text == "杭州。"
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_interrupts_stt_only_ordinary_candidate(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="我想换一本", is_final=False)
    await asyncio.sleep(0.04)

    assert session.interrupts == 1
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_observation_interrupt_is_not_self_cancelled(
    monkeypatch,
    caplog,
):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.executor")
    mmi_logger = logging.getLogger("health-agent.mmi")
    mmi_logger.addHandler(caplog.handler)
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = StateChangingInterruptSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(ordinary_interrupt_min_ms=20, observe_ms=10),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="我想换一本", is_final=False)
    await asyncio.sleep(0.05)

    assert session.interrupts == 1
    assert "interrupted agent" in caplog.text
    runtime.close()
    mmi_logger.removeHandler(caplog.handler)


@pytest.mark.asyncio
async def test_active_runtime_preserves_final_stt_only_candidate_until_interrupt(
    monkeypatch,
):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="我想换一本", is_final=True)
    await asyncio.sleep(0.04)

    assert session.interrupts == 1
    assert runtime.store.final_text == "我想换一本"
    assert runtime.store.committed is False
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_ignores_stt_only_backchannel(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="好的，好的。", is_final=True)
    await asyncio.sleep(0.04)

    assert session.interrupts == 0
    assert runtime.store.committed is True
    assert session.clears == 1
    runtime.close()


@pytest.mark.asyncio
async def test_active_runtime_keeps_partial_backchannel_that_can_grow(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    session = FakeEventSession()
    runtime = MMITurnRuntime(
        session=session,
        session_id="test",
        mode=MMIMode.ACTIVE,
        config=RuntimeConfig(),
    )
    runtime.setup()

    session.emit("agent_state_changed", new_state="speaking")
    session.emit("user_input_transcribed", transcript="是的，是的。", is_final=False)
    await asyncio.sleep(0.02)

    assert runtime.store.partial_text == "是的，是的。"
    assert runtime.store.committed is False
    assert session.clears == 0

    session.emit(
        "user_input_transcribed",
        transcript="是的，是的，他现在有多少岁？",
        is_final=False,
    )
    await asyncio.sleep(0.04)

    assert session.interrupts == 1
    assert session.clears == 0
    runtime.close()


def test_runtime_uses_dedicated_eou_timeout(monkeypatch):
    monkeypatch.setattr("mmi_turn_detection.runtime.EOUService", FakeEOUService)
    runtime = MMITurnRuntime(
        session=FakeEventSession(),
        session_id="test",
        mode=MMIMode.SHADOW,
        config=RuntimeConfig(decision_timeout_ms=100, eou_timeout_ms=350),
    )

    assert runtime.eou_service.timeout_ms == 350
    runtime.close()


@pytest.mark.asyncio
async def test_executor_commits_once():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("listening")
    store.on_transcript("有效问题", is_final=True)
    store.on_user_listening()
    session = FakeSession()
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is True
    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is False
    assert session.commits == 1
    assert store.commit_pending is False
    assert store.committed is True


@pytest.mark.asyncio
async def test_executor_generates_reply_with_target_confirmed_commit_text():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("listening")
    store.on_speaker_gate_status(True)
    store.on_transcript("背景先说。", is_final=True)
    store.on_speaker_verdict(True, similarity=0.72, kind="decide")
    store.on_transcript("讲一下目标问题。", is_final=True)
    store.on_user_listening()
    session = FakeSession()
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is True
    assert session.commits == 0
    assert session.clears == 1
    assert session.generated_replies == ["讲一下目标问题。"]
    assert store.commit_requested_text == "讲一下目标问题。"


@pytest.mark.asyncio
async def test_executor_generates_reply_for_agent_speech_interjection():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("speaking")
    store.on_user_speaking(force_new_turn=True)
    store.on_transcript("原名是谁？", is_final=True)
    store.on_agent_state("listening")
    store.on_user_listening()
    session = FakeSession()
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is True
    assert session.commits == 0
    assert session.clears == 1
    assert session.generated_replies == ["原名是谁？"]


@pytest.mark.asyncio
async def test_executor_does_not_repeat_same_text_after_pending_flag_is_lost():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("listening")
    store.on_transcript("有效问题", is_final=True)
    store.on_user_listening()
    session = FakeSession()
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is True
    store.committed = False
    store.commit_pending = False
    store.next_event()

    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is False
    assert session.commits == 1


@pytest.mark.asyncio
async def test_executor_does_not_commit_empty_or_while_agent_is_thinking():
    empty_store = MMITurnContextStore(session_id="empty")
    empty_store.on_agent_state("listening")
    empty_store.on_user_listening()
    empty_session = FakeSession()
    empty_executor = MMITurnExecutor(empty_session, empty_store)

    assert (
        await empty_executor.execute(
            decision(empty_store, MMITurnAction.START_SPEAKING)
        )
        is False
    )
    assert empty_session.commits == 0

    thinking_store = MMITurnContextStore(session_id="thinking")
    thinking_store.on_transcript("有效问题", is_final=True)
    thinking_store.on_agent_state("thinking")
    thinking_store.on_user_listening()
    thinking_session = FakeSession()
    thinking_executor = MMITurnExecutor(thinking_session, thinking_store)

    assert (
        await thinking_executor.execute(
            decision(thinking_store, MMITurnAction.START_SPEAKING)
        )
        is False
    )
    assert thinking_session.commits == 0


@pytest.mark.asyncio
async def test_executor_preempts_pending_reply_for_vad_backed_turn_during_thinking():
    store = MMITurnContextStore(session_id="thinking")
    store.on_transcript("上一轮", is_final=True)
    store.consume_current_turn()
    store.on_agent_state("thinking")
    store.on_user_speaking(force_new_turn=True)
    store.on_transcript("新的有效问题", is_final=True)
    store.on_user_listening()
    session = FakeSession()
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is True
    assert session.interrupt_forces == [True]
    assert session.commits == 1


@pytest.mark.asyncio
async def test_executor_preempts_pending_reply_for_stt_only_turn_during_thinking():
    store = MMITurnContextStore(session_id="thinking")
    store.on_transcript("上一轮", is_final=True)
    store.consume_current_turn()
    store.on_agent_state("thinking")
    store.on_transcript("你继续", is_final=True)
    store.on_user_listening()
    session = FakeSession()
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is True
    assert session.interrupt_forces == [True]
    assert session.commits == 1


@pytest.mark.asyncio
async def test_executor_interrupts_agent_speech_once():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("speaking")
    session = FakeSession()
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_LISTENING)) is True
    assert await executor.execute(decision(store, MMITurnAction.START_LISTENING)) is False
    assert session.interrupts == 1


@pytest.mark.asyncio
async def test_executor_respects_disabled_interruptions():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("speaking")
    session = FakeSession()
    session.options = SimpleNamespace(interruption={"enabled": False})
    executor = MMITurnExecutor(session, store)

    assert await executor.execute(decision(store, MMITurnAction.START_LISTENING)) is False
    assert session.interrupts == 0


@pytest.mark.asyncio
async def test_executor_force_interrupts_when_active_owns_interruption():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("speaking")
    session = FakeSession()
    session.options = SimpleNamespace(interruption={"enabled": False})
    executor = MMITurnExecutor(session, store, force_interruptions=True)

    assert await executor.execute(decision(store, MMITurnAction.START_LISTENING)) is True
    assert session.interrupt_forces == [True]


@pytest.mark.asyncio
async def test_executor_rejects_stale_decision():
    store = MMITurnContextStore(session_id="test")
    session = FakeSession()
    executor = MMITurnExecutor(session, store)
    stale = decision(store, MMITurnAction.START_SPEAKING)
    store.next_event()

    with pytest.raises(StaleDecisionError):
        await executor.execute(stale)


@pytest.mark.asyncio
async def test_executor_allows_retry_after_commit_failure():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("listening")
    store.on_transcript("有效问题", is_final=True)
    store.on_user_listening()
    session = FakeSession(fail_commit=True)
    executor = MMITurnExecutor(session, store)

    with pytest.raises(RuntimeError, match="commit failed"):
        await executor.execute(decision(store, MMITurnAction.START_SPEAKING))

    assert store.committed is False
    session.fail_commit = False
    assert await executor.execute(decision(store, MMITurnAction.START_SPEAKING)) is True


@pytest.mark.asyncio
async def test_executor_allows_retry_after_interrupt_failure():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("speaking")
    session = FakeSession(fail_interrupt=True)
    executor = MMITurnExecutor(session, store)

    with pytest.raises(RuntimeError, match="interrupt failed"):
        await executor.execute(decision(store, MMITurnAction.START_LISTENING))

    assert store.interrupted_agent_speech_id is None
    session.fail_interrupt = False
    assert await executor.execute(decision(store, MMITurnAction.START_LISTENING)) is True


def test_active_session_options_use_manual_turn_detection(monkeypatch):
    class Session:
        endpointing_mode = "dynamic"
        min_endpointing_delay = 0.5
        max_endpointing_delay = 3.0
        allow_interruptions = True
        min_interruption_duration = 1.0
        min_interruption_words = 2

    class Config:
        session = Session()

    class FakeMultilingualModel:
        pass

    monkeypatch.setattr(
        "mmi_turn_detection.session_options.MultilingualModel",
        FakeMultilingualModel,
    )
    active = build_local_turn_handling(Config(), MMIMode.ACTIVE)
    native = build_local_turn_handling(Config(), MMIMode.SHADOW)

    assert active["turn_detection"] == "manual"
    assert active["interruption"]["enabled"] is False
    assert active["interruption"]["resume_false_interruption"] is False
    assert isinstance(native["turn_detection"], FakeMultilingualModel)

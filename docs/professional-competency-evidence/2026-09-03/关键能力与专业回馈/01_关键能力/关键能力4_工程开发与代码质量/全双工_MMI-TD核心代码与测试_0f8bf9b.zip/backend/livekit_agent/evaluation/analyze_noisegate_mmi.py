#!/usr/bin/env python3
"""NoiseGate + MMI-FD session analysis.

Correlates per-session artifacts under ``tmp/``:

  - ``mmi_turn_detection_active_<timestamp>.log``
  - ``audio_recording_*_<timestamp>.json`` plus raw/stt wavs, when present

The recorded WAV is already the audio received by the backend. When frontend
NoiseGate is enabled, this is post-NoiseGate audio, so this script cannot
directly measure the removed pre-gate signal. It instead measures:

  1. client NoiseGate health from forwarded snapshots;
  2. MMI decision outcomes and how external voice confidence affected them;
  3. backend audio energy received by STT;
  4. suspicious cases worth replaying/listening to for threshold tuning.

Usage:
    python evaluation/analyze_noisegate_mmi.py
    python evaluation/analyze_noisegate_mmi.py tmp
    python evaluation/analyze_noisegate_mmi.py tmp --json tmp/noisegate_mmi_report.json
    python evaluation/analyze_noisegate_mmi.py tmp --session health-voice-79-1782109050
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import wave
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from statistics import median
from typing import Any

import numpy as np

TS_RE = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})")
LOG_TS_RE = re.compile(r"mmi_turn_detection_active_(\d{8}_\d{6})\.log$")
DECISION_MARKER = "[MMI-TD] decision "
CLIENT_GATE_MARKER = "[CLIENT-GATE] snapshot session="
SESSION_START_MARKER = "[CLIENT-GATE] session_start session="
DISCARD_MARKER = "[MMI-TD] discarded ignored user turn "
UNCONTROLLED_STOP_MARKER = "agent stopped during active user input without MMI START_LISTENING"
TS_FMT = "%Y-%m-%d %H:%M:%S,%f"

LOW_CONF = 0.4
FRAME_MS = 20
VOICED_RMS = 50.0
LOUD_RMS = 500.0
SILENT_RMS = 5.0


def parse_ts(line: str) -> datetime | None:
    match = TS_RE.match(line)
    if not match:
        return None
    try:
        return datetime.strptime(match.group(1), TS_FMT)
    except ValueError:
        return None


def pct(part: int | float, total: int | float) -> float | None:
    if not total:
        return None
    return round(float(part) / float(total), 3)


def dist(values: list[float]) -> dict[str, Any] | None:
    clean = sorted(v for v in values if isinstance(v, (int, float)) and np.isfinite(v))
    if not clean:
        return None
    n = len(clean)
    return {
        "n": n,
        "min": round(clean[0], 3),
        "p10": round(clean[min(n - 1, int(n * 0.10))], 3),
        "median": round(median(clean), 3),
        "p90": round(clean[min(n - 1, int(n * 0.90))], 3),
        "max": round(clean[-1], 3),
        "mean": round(sum(clean) / n, 3),
    }


def histogram(values: list[float], bins: int = 10) -> list[dict[str, Any]]:
    if not values:
        return []
    out = []
    for i in range(bins):
        lo = i / bins
        hi = (i + 1) / bins
        count = sum(1 for v in values if (lo <= v < hi) or (i == bins - 1 and v == hi))
        out.append({"range": f"[{lo:.1f},{hi:.1f})", "count": count})
    return out


def line_json_after(line: str, marker: str) -> dict[str, Any] | None:
    idx = line.find(marker)
    if idx < 0:
        return None
    try:
        return json.loads(line[idx + len(marker) :].strip())
    except json.JSONDecodeError:
        return None


def resolve_artifact_path(meta_path: str, path: str) -> str:
    if not path:
        return ""
    if os.path.isabs(path):
        return path
    # Metadata is usually under backend/livekit_agent/tmp and stores paths like
    # tmp/audio_raw_input_*.wav. Prefer that exact path relative to the cwd that
    # owns the metadata directory; fall back to basename next to metadata.
    meta_dir = os.path.dirname(meta_path)
    candidate = os.path.join(os.path.dirname(meta_dir), path)
    if os.path.exists(candidate):
        return candidate
    candidate = os.path.join(meta_dir, os.path.basename(path))
    if os.path.exists(candidate):
        return candidate
    return path


def read_wav(path: str) -> tuple[np.ndarray, int] | None:
    if not path or not os.path.exists(path):
        return None
    with wave.open(path, "rb") as reader:
        sr = reader.getframerate()
        ch = reader.getnchannels()
        data = np.frombuffer(reader.readframes(reader.getnframes()), dtype=np.int16)
    if ch > 1:
        data = data.reshape(-1, ch).mean(axis=1).astype(np.int16)
    return data, sr


def frame_rms(samples: np.ndarray, sample_rate: int) -> np.ndarray:
    frame_len = max(1, int(sample_rate * FRAME_MS / 1000))
    n = (len(samples) // frame_len) * frame_len
    if n <= 0:
        return np.empty(0)
    frames = samples[:n].reshape(-1, frame_len).astype(np.float64)
    return np.sqrt(np.mean(frames * frames, axis=1))


def analyze_audio(meta_path: str | None) -> dict[str, Any] | None:
    if not meta_path or not os.path.exists(meta_path):
        return None
    try:
        meta = json.load(open(meta_path, encoding="utf-8"))
    except Exception as exc:
        return {"error": f"metadata read failed: {exc}"}

    raw_path = resolve_artifact_path(meta_path, meta.get("raw_input", {}).get("path", ""))
    stt_path = resolve_artifact_path(meta_path, meta.get("stt_input", {}).get("path", ""))
    raw = read_wav(raw_path)
    stt = read_wav(stt_path)
    if raw is None:
        return {"metadata": meta, "error": "raw wav missing"}

    raw_samples, raw_sr = raw
    raw_rms = frame_rms(raw_samples, raw_sr)
    duration_sec = round(len(raw_samples) / raw_sr, 3) if raw_sr else 0.0
    voiced = raw_rms >= VOICED_RMS
    loud = raw_rms >= LOUD_RMS
    silent = raw_rms < SILENT_RMS

    result: dict[str, Any] = {
        "raw_path": raw_path,
        "stt_path": stt_path if stt is not None else None,
        "sample_rate": raw_sr,
        "duration_sec": duration_sec,
        "frame_ms": FRAME_MS,
        "rms": dist(raw_rms.tolist()),
        "voiced_sec": round(float(voiced.sum()) * FRAME_MS / 1000, 3),
        "voiced_ratio": pct(int(voiced.sum()), len(raw_rms)),
        "loud_sec": round(float(loud.sum()) * FRAME_MS / 1000, 3),
        "silent_sec": round(float(silent.sum()) * FRAME_MS / 1000, 3),
    }

    if stt is not None:
        stt_samples, stt_sr = stt
        n = min(len(raw_samples), len(stt_samples))
        if n > 0 and stt_sr == raw_sr:
            stt_rms = frame_rms(stt_samples[:n], stt_sr)
            raw_rms2 = frame_rms(raw_samples[:n], raw_sr)
            m = min(len(raw_rms2), len(stt_rms))
            if m:
                backend_silenced = (raw_rms2[:m] >= VOICED_RMS) & (stt_rms[:m] < SILENT_RMS)
                result["backend_gate"] = {
                    "raw_stt_diff": bool(np.any(raw_samples[:n] != stt_samples[:n])),
                    "silenced_voiced_sec": round(float(backend_silenced.sum()) * FRAME_MS / 1000, 3),
                    "silenced_ratio_of_voiced": pct(int(backend_silenced.sum()), int((raw_rms2[:m] >= VOICED_RMS).sum())),
                    "stt_rms": dist(stt_rms.tolist()),
                }
    return result


@dataclass
class ParsedLog:
    timestamp: str
    path: str
    session_id: str | None = None
    started_at: datetime | None = None
    ended_at: datetime | None = None
    decisions: list[dict[str, Any]] = field(default_factory=list)
    gate_snapshots: list[dict[str, Any]] = field(default_factory=list)
    gate_session_start: list[dict[str, Any]] = field(default_factory=list)
    discarded_turns: Counter[str] = field(default_factory=Counter)
    uncontrolled_agent_stops: int = 0


def parse_mmi_log(path: str) -> ParsedLog:
    m = LOG_TS_RE.search(os.path.basename(path))
    timestamp = m.group(1) if m else "unknown"
    parsed = ParsedLog(timestamp=timestamp, path=path)

    with open(path, encoding="utf-8") as fh:
        for line in fh:
            ts = parse_ts(line)
            if ts is not None:
                parsed.started_at = parsed.started_at or ts
                parsed.ended_at = ts

            if DECISION_MARKER in line:
                payload = line_json_after(line, DECISION_MARKER)
                if payload is not None:
                    payload["_log_time"] = ts.isoformat(sep=" ") if ts else None
                    parsed.decisions.append(payload)
                    parsed.session_id = parsed.session_id or payload.get("session_id")
                continue

            if CLIENT_GATE_MARKER in line:
                idx = line.find("{")
                if idx >= 0:
                    try:
                        payload = json.loads(line[idx:].strip())
                    except json.JSONDecodeError:
                        payload = None
                    if payload is not None:
                        payload["_log_time"] = ts.isoformat(sep=" ") if ts else None
                        parsed.gate_snapshots.append(payload)
                continue

            if SESSION_START_MARKER in line:
                idx = line.find("mic=")
                # Keep this robust: session_start is less important than snapshots.
                if idx >= 0:
                    parsed.gate_session_start.append({"line": line.strip()})
                continue

            if DISCARD_MARKER in line:
                reason = "unknown"
                match = re.search(r"reason=([A-Za-z0-9_.-]+)", line)
                if match:
                    reason = match.group(1)
                parsed.discarded_turns[reason] += 1

            if UNCONTROLLED_STOP_MARKER in line:
                parsed.uncontrolled_agent_stops += 1

    return parsed


def summarize_gate(snapshots: list[dict[str, Any]]) -> dict[str, Any]:
    if not snapshots:
        return {
            "snapshot_count": 0,
            "note": "No [CLIENT-GATE] snapshots found; check frontend NoiseGate forwarding or MMI data channel.",
        }
    conf = [float(s["confidence"]) for s in snapshots if isinstance(s.get("confidence"), (int, float))]
    energy = [float(s["envelopeDB"]) for s in snapshots if isinstance(s.get("envelopeDB"), (int, float))]
    noise = [float(s["noiseFloorDB"]) for s in snapshots if isinstance(s.get("noiseFloorDB"), (int, float))]
    threshold = [float(s["thresholdDB"]) for s in snapshots if isinstance(s.get("thresholdDB"), (int, float))]
    gain = [float(s["currentGain"]) for s in snapshots if isinstance(s.get("currentGain"), (int, float))]
    gate_open = [bool(s.get("isGateOpen")) for s in snapshots if "isGateOpen" in s]
    zeroed = sum(1 for s in snapshots if s.get("noiseFloorZeroed"))
    states = Counter(str(s.get("agentState", "?")) for s in snapshots)
    engines = Counter(str(s.get("engine", "?")) for s in snapshots)
    gate_versions = Counter(str(s.get("gateVersion", s.get("version", "?"))) for s in snapshots)
    first_trans = snapshots[0].get("gateTransitionCount")
    last_trans = snapshots[-1].get("gateTransitionCount")
    transition_delta = (
        int(last_trans) - int(first_trans)
        if isinstance(first_trans, int) and isinstance(last_trans, int)
        else None
    )
    return {
        "snapshot_count": len(snapshots),
        "engine": dict(engines),
        "version": dict(gate_versions),
        "agent_state_snapshots": dict(states),
        "confidence": dist(conf),
        "confidence_histogram": histogram(conf),
        "low_conf_snapshot_ratio": pct(sum(1 for v in conf if v < LOW_CONF), len(conf)),
        "gate_closed_snapshot_ratio": pct(sum(1 for v in gate_open if not v), len(gate_open)),
        "noise_floor_zeroed_ratio": pct(zeroed, len(snapshots)),
        "energy_db": dist(energy),
        "noise_floor_db": dist(noise),
        "threshold_db": dist(threshold),
        "current_gain": dist(gain),
        "gate_transition_delta": transition_delta,
    }


def summarize_decisions(decisions: list[dict[str, Any]]) -> dict[str, Any]:
    actions = Counter(str(d.get("action", "?")) for d in decisions)
    reasons = Counter(str(d.get("reason", "?")) for d in decisions)
    triggers = Counter(str(d.get("trigger", "?")) for d in decisions)
    executed = sum(1 for d in decisions if d.get("executed") is True)
    ignored = sum(1 for d in decisions if d.get("ignore_input") is True)
    conf_values = [
        float(d["external_voice_confidence"])
        for d in decisions
        if isinstance(d.get("external_voice_confidence"), (int, float))
    ]
    stale = sum(1 for d in decisions if d.get("external_voice_stale") is True)
    missing_conf = len(decisions) - len(conf_values) - stale

    interrupts = [d for d in decisions if d.get("action") == "START_LISTENING"]
    commits = [d for d in decisions if d.get("action") == "START_SPEAKING"]
    suppressions = [
        d
        for d in decisions
        if d.get("reason")
        in {
            "low_voice_confidence_suppressed",
            "low_voice_confidence_observe",
            "invalid_or_noise_low_voice_confidence",
            "non_target_speaker_suppressed",
            "speaker_gate_warmup_suppressed",
            "speaker_gate_target_unconfirmed",
            "non_target_speaker_ignored",
            "agent_speech_unconfirmed_speaker_ignored",
        }
    ]

    suspicious = {
        "low_conf_suppressed_long_text": [
            brief_decision(d)
            for d in decisions
            if d.get("reason") == "low_voice_confidence_suppressed"
            and transcript_len(d) >= 8
        ][:20],
        "interrupt_with_low_confidence": [
            brief_decision(d)
            for d in interrupts
            if isinstance(d.get("external_voice_confidence"), (int, float))
            and float(d["external_voice_confidence"]) < LOW_CONF
        ][:20],
        "commit_with_low_confidence": [
            brief_decision(d)
            for d in commits
            if isinstance(d.get("external_voice_confidence"), (int, float))
            and float(d["external_voice_confidence"]) < LOW_CONF
            and transcript_len(d) >= 4
        ][:20],
        "ignored_but_high_confidence": [
            brief_decision(d)
            for d in decisions
            if d.get("ignore_input") is True
            and isinstance(d.get("external_voice_confidence"), (int, float))
            and float(d["external_voice_confidence"]) >= 0.8
        ][:20],
    }

    return {
        "decision_count": len(decisions),
        "actions": dict(actions),
        "reasons_top": dict(reasons.most_common(20)),
        "triggers": dict(triggers),
        "executed_count": executed,
        "ignore_input_count": ignored,
        "ignore_input_ratio": pct(ignored, len(decisions)),
        "interrupt_count": len(interrupts),
        "commit_count": len(commits),
        "suppression_count": len(suppressions),
        "noisegate_effect_reasons": {
            "low_voice_confidence_suppressed": reasons.get("low_voice_confidence_suppressed", 0),
            "low_voice_confidence_observe": reasons.get("low_voice_confidence_observe", 0),
            "invalid_or_noise_low_voice_confidence": reasons.get("invalid_or_noise_low_voice_confidence", 0),
            "invalid_or_noise_turn_pending": reasons.get("invalid_or_noise_turn_pending", 0),
            "invalid_or_noise_turn_timeout": reasons.get("invalid_or_noise_turn_timeout", 0),
        },
        "voice_confidence": {
            "coverage_ratio": pct(len(conf_values), len(decisions)),
            "stale_count": stale,
            "missing_count": missing_conf,
            "distribution": dist(conf_values),
            "histogram": histogram(conf_values),
            "low_confidence_decision_ratio": pct(sum(1 for v in conf_values if v < LOW_CONF), len(conf_values)),
        },
        "endpointing": {
            "min_delay_commits": reasons.get("min_endpointing_delay_reached", 0),
            "max_delay_commits": reasons.get("max_endpointing_delay_reached", 0),
            "wait_intent": reasons.get("wait_intent", 0),
            "backchannel": reasons.get("backchannel", 0),
        },
        "suspicious": suspicious,
    }


def transcript_len(decision: dict[str, Any]) -> int:
    return int(decision.get("partial_text_len") or 0) + int(decision.get("final_text_len") or 0)


def brief_decision(decision: dict[str, Any]) -> dict[str, Any]:
    return {
        "time": decision.get("_log_time"),
        "turn_id": decision.get("turn_id"),
        "trigger": decision.get("trigger"),
        "action": decision.get("action"),
        "reason": decision.get("reason"),
        "executed": decision.get("executed"),
        "ignore_input": decision.get("ignore_input"),
        "external_voice_confidence": decision.get("external_voice_confidence"),
        "external_voice_energy_db": decision.get("external_voice_energy_db"),
        "partial_text_len": decision.get("partial_text_len"),
        "final_text_len": decision.get("final_text_len"),
        "speech_ms": decision.get("speech_ms"),
        "transcript_observe_ms": decision.get("transcript_observe_ms"),
        "silence_ms": decision.get("silence_ms"),
        "agent_state": decision.get("agent_state"),
        "user_state": decision.get("user_state"),
    }


def find_recording(tmp: str, timestamp: str, session: str | None, log_path: str = "") -> str | None:
    log_dir = os.path.dirname(log_path)
    candidates = []
    if log_dir:
        candidates.extend(glob.glob(os.path.join(log_dir, f"audio_recording_*_{timestamp}.json")))
    candidates.extend(glob.glob(os.path.join(tmp, "**", f"audio_recording_*_{timestamp}.json"), recursive=True))
    candidates = sorted(dict.fromkeys(candidates))
    if session:
        for path in candidates:
            try:
                meta = json.load(open(path, encoding="utf-8"))
            except Exception:
                continue
            if meta.get("session_id") == session:
                return path
    return candidates[0] if candidates else None


def build_session_report(log_path: str, tmp: str) -> dict[str, Any]:
    parsed = parse_mmi_log(log_path)
    rec = find_recording(tmp, parsed.timestamp, parsed.session_id, log_path)
    span_sec = None
    if parsed.started_at and parsed.ended_at:
        span_sec = round((parsed.ended_at - parsed.started_at).total_seconds(), 3)
    return {
        "session_id": parsed.session_id,
        "timestamp": parsed.timestamp,
        "log_path": log_path,
        "recording_metadata": rec,
        "log_span_sec": span_sec,
        "limitation": (
            "recorded raw_input is backend input, not microphone pre-NoiseGate audio; "
            "NoiseGate removal is inferred from client snapshots and MMI confidence, not measured directly"
        ),
        "client_gate": summarize_gate(parsed.gate_snapshots),
        "mmi": summarize_decisions(parsed.decisions),
        "warnings": {
            "discarded_turns": dict(parsed.discarded_turns),
            "agent_stopped_without_mmi_start_listening": parsed.uncontrolled_agent_stops,
        },
        "audio": analyze_audio(rec),
    }


def aggregate(reports: list[dict[str, Any]]) -> dict[str, Any]:
    total_decisions = sum(r["mmi"]["decision_count"] for r in reports)
    total_interrupts = sum(r["mmi"]["interrupt_count"] for r in reports)
    total_commits = sum(r["mmi"]["commit_count"] for r in reports)
    total_suppressions = sum(r["mmi"]["suppression_count"] for r in reports)
    reasons = Counter()
    actions = Counter()
    gate_engines = Counter()
    conf_values: list[float] = []
    gate_conf_values: list[float] = []
    suspicious_counts = Counter()
    discarded = Counter()
    uncontrolled = 0
    voiced_sec = 0.0
    duration_sec = 0.0

    for report in reports:
        reasons.update(report["mmi"]["reasons_top"])
        actions.update(report["mmi"]["actions"])
        gate_engines.update(report["client_gate"].get("engine", {}))
        vc = report["mmi"]["voice_confidence"]["distribution"]
        # Keep aggregate exact enough by re-reading suspicious counts and broad counters.
        for name, examples in report["mmi"]["suspicious"].items():
            suspicious_counts[name] += len(examples)
        discarded.update(report["warnings"]["discarded_turns"])
        uncontrolled += report["warnings"]["agent_stopped_without_mmi_start_listening"]
        audio = report.get("audio")
        if isinstance(audio, dict):
            duration_sec += float(audio.get("duration_sec") or 0.0)
            voiced_sec += float(audio.get("voiced_sec") or 0.0)
        # We do not store raw values in reports to keep JSON compact; collect a
        # representative aggregate from per-session medians.
        if vc and isinstance(vc.get("median"), (int, float)):
            conf_values.append(float(vc["median"]))
        gc = report["client_gate"].get("confidence")
        if gc and isinstance(gc.get("median"), (int, float)):
            gate_conf_values.append(float(gc["median"]))

    return {
        "sessions": len(reports),
        "total_log_span_sec": round(
            sum(float(r.get("log_span_sec") or 0.0) for r in reports), 3
        ),
        "audio_duration_sec": round(duration_sec, 3),
        "audio_voiced_sec": round(voiced_sec, 3),
        "audio_voiced_ratio": pct(voiced_sec, duration_sec),
        "total_decisions": total_decisions,
        "actions": dict(actions),
        "top_reasons": dict(reasons.most_common(20)),
        "interrupt_count": total_interrupts,
        "commit_count": total_commits,
        "suppression_count": total_suppressions,
        "suppression_ratio_of_decisions": pct(total_suppressions, total_decisions),
        "gate_engines": dict(gate_engines),
        "session_median_external_voice_confidence": dist(conf_values),
        "session_median_gate_snapshot_confidence": dist(gate_conf_values),
        "discarded_turns": dict(discarded),
        "agent_stopped_without_mmi_start_listening": uncontrolled,
        "suspicious_example_counts_capped_at_20_per_session": dict(suspicious_counts),
    }


def print_report(report: dict[str, Any]) -> None:
    gate = report["client_gate"]
    mmi = report["mmi"]
    audio = report.get("audio")
    print(f"\n● session {report.get('session_id') or '?'}  ts={report['timestamp']}")
    print(f"  log_span={report.get('log_span_sec')}s  recording={os.path.basename(report['recording_metadata'] or '') or 'missing'}")
    print(
        "  Gate: "
        f"snapshots={gate.get('snapshot_count')} engine={gate.get('engine')} "
        f"conf={gate.get('confidence')} closed_ratio={gate.get('gate_closed_snapshot_ratio')} "
        f"zeroed_noise={gate.get('noise_floor_zeroed_ratio')}"
    )
    print(
        "  MMI : "
        f"decisions={mmi['decision_count']} interrupts={mmi['interrupt_count']} "
        f"commits={mmi['commit_count']} suppressions={mmi['suppression_count']} "
        f"ignore_ratio={mmi['ignore_input_ratio']}"
    )
    print(f"        actions={mmi['actions']}")
    print(f"        NoiseGate reasons={mmi['noisegate_effect_reasons']}")
    print(f"        voice_conf={mmi['voice_confidence']['distribution']} coverage={mmi['voice_confidence']['coverage_ratio']}")
    if isinstance(audio, dict) and not audio.get("error"):
        backend_gate = audio.get("backend_gate", {})
        print(
            "  Audio: "
            f"duration={audio.get('duration_sec')}s voiced={audio.get('voiced_sec')}s "
            f"voiced_ratio={audio.get('voiced_ratio')} rms={audio.get('rms')}"
        )
        if backend_gate:
            print(
                "        backend raw/stt diff="
                f"{backend_gate.get('raw_stt_diff')} silenced_voiced={backend_gate.get('silenced_voiced_sec')}s"
            )
    elif isinstance(audio, dict):
        print(f"  Audio: {audio.get('error')}")
    warn = report["warnings"]
    if warn["discarded_turns"] or warn["agent_stopped_without_mmi_start_listening"]:
        print(
            "  Warn : "
            f"discarded={warn['discarded_turns']} "
            f"uncontrolled_agent_stops={warn['agent_stopped_without_mmi_start_listening']}"
        )
    for name, examples in mmi["suspicious"].items():
        if examples:
            print(f"  Check: {name} -> {len(examples)} example(s), first={examples[0]}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyze NoiseGate + MMI-FD session artifacts")
    parser.add_argument("tmp", nargs="?", default="tmp", help="artifact directory")
    parser.add_argument("--json", dest="json_path", default=None, help="write full JSON report")
    parser.add_argument("--session", default=None, help="filter by session_id")
    parser.add_argument("--latest", type=int, default=0, help="only analyze latest N sessions")
    args = parser.parse_args()

    logs = sorted(
        glob.glob(os.path.join(args.tmp, "mmi_turn_detection_active_*.log"))
        + glob.glob(os.path.join(args.tmp, "**", "mmi_turn_detection_active_*.log"), recursive=True)
    )
    logs = sorted(dict.fromkeys(logs))
    if args.latest > 0:
        logs = logs[-args.latest :]
    reports = [build_session_report(path, args.tmp) for path in logs]
    if args.session:
        reports = [r for r in reports if r.get("session_id") == args.session]

    if not reports:
        print(f"No matching mmi_turn_detection_active_*.log under {args.tmp}")
        return

    print("=" * 86)
    print("NoiseGate + MMI-FD 量化报告")
    print("=" * 86)
    print("限制: raw_input 是后端收到的音频，不是前端 NoiseGate 前的麦克风原始音频；")
    print("      NoiseGate 效果通过 CLIENT-GATE snapshot 与 MMI external_voice_confidence 间接衡量。")

    for report in reports:
        print_report(report)

    agg = aggregate(reports)
    print("\n" + "=" * 86)
    print("汇总")
    print("=" * 86)
    for key, value in agg.items():
        print(f"  {key}: {value}")

    if args.json_path:
        with open(args.json_path, "w", encoding="utf-8") as fh:
            json.dump({"sessions": reports, "aggregate": agg}, fh, ensure_ascii=False, indent=2, default=str)
        print(f"\nJSON 已写入 {args.json_path}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Summarize online semantic-overlay Shadow logs."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

_MARKERS = (
    "semantic_overlay_comparison",
    "semantic_overlay_result",
    "semantic_overlay_dropped",
    "semantic_overlay_error",
)


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * percentile
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return round(
        ordered[lower] * (1 - fraction) + ordered[upper] * fraction,
        3,
    )


def discover_logs(paths: Iterable[Path]) -> list[Path]:
    logs: set[Path] = set()
    for path in paths:
        if path.is_file():
            logs.add(path.resolve())
        elif path.is_dir():
            logs.update(candidate.resolve() for candidate in path.rglob("*.log"))
    return sorted(logs)


def parse_overlay_events(paths: Iterable[Path]) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for path in discover_logs(paths):
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line_number, line in enumerate(handle, start=1):
                for marker in _MARKERS:
                    token = marker + " "
                    position = line.find(token)
                    if position < 0:
                        continue
                    raw = line[position + len(token) :].strip()
                    try:
                        payload = json.loads(raw)
                    except json.JSONDecodeError:
                        events.append(
                            {
                                "event": "parse_error",
                                "file": str(path),
                                "line": line_number,
                                "marker": marker,
                            }
                        )
                        break
                    if isinstance(payload, dict):
                        events.append(
                            {
                                "event": marker,
                                "file": str(path),
                                "line": line_number,
                                **payload,
                            }
                        )
                    break
    return events


def summarize_overlay_events(events: list[dict[str, Any]]) -> dict[str, Any]:
    comparisons = [
        event
        for event in events
        if event.get("event") == "semantic_overlay_comparison"
    ]
    results = [
        event
        for event in events
        if event.get("event") == "semantic_overlay_result"
    ]
    dropped = [
        event
        for event in events
        if event.get("event") == "semantic_overlay_dropped"
    ]
    errors = [
        event
        for event in events
        if event.get("event") == "semantic_overlay_error"
    ]
    parse_errors = [
        event for event in events if event.get("event") == "parse_error"
    ]
    latencies = [
        float(event["latency_ms"])
        for event in results
        if isinstance(event.get("latency_ms"), (int, float))
    ]
    request_total = len(results) + len(dropped) + len(errors)
    within_budget = [
        event
        for event in results
        if event.get("within_effective_budget") is True
    ]
    before_base = [
        event
        for event in comparisons
        if event.get("semantic_arrived_before_base_decision") is True
    ]
    changed_results = [
        event for event in results if event.get("would_change_action") is True
    ]
    changed_comparisons = [
        event
        for event in comparisons
        if event.get("would_change_action") is True
    ]

    return {
        "files": len({event.get("file") for event in events if event.get("file")}),
        "events": len(events),
        "requests": {
            "total": request_total,
            "successful": len(results),
            "dropped": len(dropped),
            "errors": len(errors),
            "success_rate": round(len(results) / request_total, 6)
            if request_total
            else None,
            "drop_rate": round(len(dropped) / request_total, 6)
            if request_total
            else None,
            "error_rate": round(len(errors) / request_total, 6)
            if request_total
            else None,
        },
        "latency_ms": {
            "count": len(latencies),
            "p50": _percentile(latencies, 0.5),
            "p95": _percentile(latencies, 0.95),
            "max": round(max(latencies), 3) if latencies else None,
            "within_effective_budget": len(within_budget),
            "within_effective_budget_rate": round(
                len(within_budget) / len(results),
                6,
            )
            if results
            else None,
            "arrived_before_base_decision": len(before_base),
            "arrived_before_base_decision_rate": round(
                len(before_base) / len(comparisons),
                6,
            )
            if comparisons
            else None,
        },
        "decisions": {
            "comparisons": len(comparisons),
            "comparison_changes": len(changed_comparisons),
            "result_changes": len(changed_results),
            "base_to_overlay": dict(
                sorted(
                    Counter(
                        f"{event.get('base_action')}->{event.get('overlay_action')}"
                        for event in comparisons
                    ).items()
                )
            ),
        },
        "semantic_states": dict(
            sorted(
                Counter(
                    str(event.get("semantic_state") or "UNKNOWN")
                    for event in results
                ).items()
            )
        ),
        "drop_reasons": dict(
            sorted(
                Counter(str(event.get("reason") or "unknown") for event in dropped).items()
            )
        ),
        "error_types": dict(
            sorted(
                Counter(
                    str(event.get("error_type") or "unknown")
                    for event in errors
                ).items()
            )
        ),
        "parse_errors": len(parse_errors),
    }


def _format_percent(value: float | None) -> str:
    return "-" if value is None else f"{value * 100:.2f}%"


def format_text(summary: dict[str, Any]) -> str:
    requests = summary["requests"]
    latency = summary["latency_ms"]
    decisions = summary["decisions"]
    lines = [
        "Online Semantic Overlay Shadow Summary",
        f"files: {summary['files']}",
        (
            "requests: "
            f"{requests['total']} total, {requests['successful']} successful, "
            f"{requests['dropped']} dropped, {requests['errors']} errors"
        ),
        f"success_rate: {_format_percent(requests['success_rate'])}",
        f"drop_rate: {_format_percent(requests['drop_rate'])}",
        (
            "latency_ms: "
            f"p50={latency['p50']} p95={latency['p95']} max={latency['max']}"
        ),
        (
            "within_effective_budget: "
            f"{latency['within_effective_budget']} "
            f"({_format_percent(latency['within_effective_budget_rate'])})"
        ),
        (
            "arrived_before_base_decision: "
            f"{latency['arrived_before_base_decision']} "
            f"({_format_percent(latency['arrived_before_base_decision_rate'])})"
        ),
        (
            "decision_changes: "
            f"{decisions['comparison_changes']}/{decisions['comparisons']} comparisons"
        ),
        f"semantic_states: {json.dumps(summary['semantic_states'], ensure_ascii=False)}",
        f"base_to_overlay: {json.dumps(decisions['base_to_overlay'], ensure_ascii=False)}",
    ]
    if summary["drop_reasons"]:
        lines.append(
            f"drop_reasons: {json.dumps(summary['drop_reasons'], ensure_ascii=False)}"
        )
    if summary["error_types"]:
        lines.append(
            f"error_types: {json.dumps(summary['error_types'], ensure_ascii=False)}"
        )
    if summary["parse_errors"]:
        lines.append(f"parse_errors: {summary['parse_errors']}")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Summarize online semantic-overlay Shadow logs"
    )
    parser.add_argument("paths", type=Path, nargs="+")
    parser.add_argument("--json", dest="json_path", type=Path)
    args = parser.parse_args()

    events = parse_overlay_events(args.paths)
    summary = summarize_overlay_events(events)
    print(format_text(summary))
    if args.json_path is not None:
        args.json_path.parent.mkdir(parents=True, exist_ok=True)
        args.json_path.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()

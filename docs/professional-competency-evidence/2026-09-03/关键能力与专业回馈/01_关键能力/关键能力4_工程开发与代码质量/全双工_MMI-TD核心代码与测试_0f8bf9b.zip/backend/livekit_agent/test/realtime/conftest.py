"""pytest fixtures：WS 客户端、音频工具、指标聚合器"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pytest
import pytest_asyncio
import yaml

from core.ws_test_client import RealtimeTestClient
from core.audio_generator import AudioGenerator
from core.metrics import MetricsAggregator
from core.report import print_terminal_report, save_json_report


# ========== 环境配置 ==========

def get_agent_mode() -> str:
    return os.getenv("AGENT_RUNTIME__AGENT_MODE", os.getenv("AGENT_MODE", "real"))


def get_ws_url() -> str:
    return os.getenv("WS_URL", "wss://api.health.com/v1/realtime?model=health-assistant")


def get_auth_token() -> str:
    return os.getenv("AUTH_TOKEN", "")


# ========== YAML 场景加载 ==========

SCENARIOS_DIR = Path(__file__).parent / "scenarios"


@dataclass
class InterruptionCase:
    name: str
    description: str
    audio_type: str
    audio_duration_s: float
    inject_after_deltas: int
    expect_interrupt: bool


@dataclass
class CompoundInterruptionCase:
    """打断后轮次恢复的复合场景"""
    name: str
    description: str
    inject_after_deltas: int
    barge_audio_type: str
    barge_audio_duration_s: float
    post_silence_s: float
    expect_interrupt: bool
    expect_recovery: bool


@dataclass
class TurnSegment:
    type: str  # "speech" or "silence"
    audio_type: Optional[str] = None
    audio_duration_s: Optional[float] = None
    duration_s: Optional[float] = None


@dataclass
class TurnDetectionCase:
    name: str
    description: str
    segments: list[TurnSegment]
    mid_pause_s: Optional[float] = None
    expect_turn_switch: Optional[bool] = None
    expect_mid_pause_switch: Optional[bool] = None
    expect_final_switch: Optional[bool] = None


def load_interruption_cases() -> list[InterruptionCase]:
    """加载普通打断测试场景"""
    with open(SCENARIOS_DIR / "interruption.yaml", 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)

    cases = []
    for c in data.get("cases", []):
        cases.append(InterruptionCase(
            name=c["name"],
            description=c["description"],
            audio_type=c["audio_type"],
            audio_duration_s=c["audio_duration_s"],
            inject_after_deltas=c["inject_after_deltas"],
            expect_interrupt=c["expect_interrupt"],
        ))
    return cases


def load_compound_interruption_cases() -> list[CompoundInterruptionCase]:
    """加载复合打断场景（打断后轮次恢复）"""
    with open(SCENARIOS_DIR / "interruption.yaml", 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)

    cases = []
    for c in data.get("compound_cases", []):
        cases.append(CompoundInterruptionCase(
            name=c["name"],
            description=c["description"],
            inject_after_deltas=c["inject_after_deltas"],
            barge_audio_type=c["barge_audio_type"],
            barge_audio_duration_s=c["barge_audio_duration_s"],
            post_silence_s=c["post_silence_s"],
            expect_interrupt=c["expect_interrupt"],
            expect_recovery=c["expect_recovery"],
        ))
    return cases


def load_interruption_config() -> dict:
    with open(SCENARIOS_DIR / "interruption.yaml", 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    return data.get("config", {})


def load_turn_detection_cases() -> list[TurnDetectionCase]:
    """加载轮次检测测试场景"""
    with open(SCENARIOS_DIR / "turn_detection.yaml", 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)

    cases = []
    for c in data["cases"]:
        segments = []
        for seg in c["segments"]:
            segments.append(TurnSegment(
                type=seg["type"],
                audio_type=seg.get("audio_type"),
                audio_duration_s=seg.get("audio_duration_s"),
                duration_s=seg.get("duration_s"),
            ))
        cases.append(TurnDetectionCase(
            name=c["name"],
            description=c["description"],
            segments=segments,
            mid_pause_s=c.get("mid_pause_s"),
            expect_turn_switch=c.get("expect_turn_switch"),
            expect_mid_pause_switch=c.get("expect_mid_pause_switch"),
            expect_final_switch=c.get("expect_final_switch"),
        ))
    return cases


def load_turn_detection_config() -> dict:
    with open(SCENARIOS_DIR / "turn_detection.yaml", 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    return data.get("config", {})


# ========== 音频生成辅助 ==========

def generate_audio(audio_type: str, duration_s: float) -> bytes:
    """根据类型生成测试音频"""
    generators = {
        "speech_like": AudioGenerator.speech_like,
        "silence": AudioGenerator.silence,
        "white_noise": AudioGenerator.white_noise,
        "sine_wave": AudioGenerator.sine_wave,
        "low_amplitude_noise": AudioGenerator.low_amplitude_noise,
    }
    gen_func = generators.get(audio_type)
    if gen_func is None:
        raise ValueError(f"Unknown audio type: {audio_type}")
    return gen_func(duration_s)


# ========== Fixtures ==========

@pytest_asyncio.fixture
async def ws_client():
    """创建 WebSocket 测试客户端，测试结束后自动断开"""
    client = RealtimeTestClient()
    yield client
    await client.disconnect()


@pytest.fixture
def audio_gen():
    """音频生成器实例"""
    return AudioGenerator()


@pytest.fixture(scope="session")
def metrics_aggregator():
    """session 级别的指标聚合器，跨测试收集"""
    return MetricsAggregator()


@pytest.fixture(scope="session", autouse=True)
def report_on_finish(metrics_aggregator):
    """测试结束后自动输出报告"""
    yield
    if metrics_aggregator.interruption_results or metrics_aggregator.turn_detection_results:
        print_terminal_report(metrics_aggregator)
        save_json_report(
            metrics_aggregator,
            output_dir=str(Path(__file__).parent / "test_reports"),
            agent_mode=get_agent_mode(),
        )


@pytest.fixture
def ws_url():
    return get_ws_url()


@pytest.fixture
def auth_token():
    return get_auth_token()


@pytest.fixture
def agent_mode():
    return get_agent_mode()


# ========== pytest 配置 ==========

def pytest_collection_modifyitems(config, items):
    """根据 AGENT_RUNTIME__AGENT_MODE 自动跳过不匹配的测试"""
    mode = get_agent_mode()
    skip_mock = pytest.mark.skip(reason="Skipped in real mode")
    skip_real = pytest.mark.skip(reason="Skipped in mock mode")

    for item in items:
        if "mock_only" in item.keywords and mode != "mock":
            item.add_marker(skip_mock)
        elif "real_only" in item.keywords and mode != "real":
            item.add_marker(skip_real)

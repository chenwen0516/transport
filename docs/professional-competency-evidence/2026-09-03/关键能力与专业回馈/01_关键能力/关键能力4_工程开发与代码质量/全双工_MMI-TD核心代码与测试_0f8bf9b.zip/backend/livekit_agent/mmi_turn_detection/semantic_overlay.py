"""Asynchronous semantic correction observer for online MMI Shadow runs."""

from __future__ import annotations

import asyncio
import json
import logging
import math
import re
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Protocol

import aiohttp

from .models import MMITurnAction, MMITurnContext, MMITurnDecision

logger = logging.getLogger("health-agent.mmi.semantic_overlay")

PROMPT_VERSION = "2026-07-23.streaming-semantic-v3"
POLICY_VERSION = "2026-07-27.semantic-overlay-v5-online-guard"

_EXPLICIT_INTERRUPT_CUES = (
    re.compile(r"\bbefore i forget\b", re.IGNORECASE),
    re.compile(r"\bby the way\b", re.IGNORECASE),
    re.compile(r"\bhold on\b", re.IGNORECASE),
    re.compile(r"^\s*wait\b", re.IGNORECASE),
    re.compile(r"^\s*hey[\s,]+(?:can|could|would|will|please)\b", re.IGNORECASE),
    re.compile(r"\btalk about something else\b", re.IGNORECASE),
    re.compile(r"\btalk about\b.*\binstead\b", re.IGNORECASE),
    re.compile(r"\bdiscuss\b.*\binstead\b", re.IGNORECASE),
    re.compile(r"\b(?:switch|change)\s+(?:to|the topic|the subject)\b", re.IGNORECASE),
    re.compile(
        r"\bactually\b.*\b(?:let'?s|can we|switch|change)\b",
        re.IGNORECASE,
    ),
    re.compile(r"\bjust a minute\b", re.IGNORECASE),
    re.compile(r"^\s*either way\b.*\?", re.IGNORECASE),
)
_DIRECT_INTERACTION_PATTERN = re.compile(
    r"^\s*(?:oh[\s,]+)?(?:can|could|would|will|do|does|did|is|are|am|"
    r"what|when|where|why|how|who|please|tell|show|remind|set|turn|"
    r"stop|wait|hold)\b",
    re.IGNORECASE,
)
_SYSTEM_PROMPT = """You are a conservative streaming turn-control classifier.
The user began speaking while a voice assistant was speaking or thinking.
Classify who the utterance addresses and whether it should stop the assistant.

Allowed states:
- INTERRUPT: a clear request to stop, correct, reject, or redirect the assistant,
  or a new assistant request introduced by an explicit floor-taking phrase.
- ADDRESSED_OTHER: speech explicitly addressed to another person, role, or device.
- BACKCHANNEL: a short acknowledgement encouraging the assistant to continue.
- CONTINUE: speech that should not stop the assistant and fits none of the above.
- UNCERTAIN: partial or ambiguous evidence; prefer this over a risky interruption.

Rules:
1. A generic request or question alone is not enough evidence to interrupt.
2. Explicit floor-taking phrases followed by a new request are INTERRUPT.
3. Explicit addressee evidence takes priority over every interruption cue.
4. Preserve an earlier vocative if a later streaming rewrite drops it.
5. Short acknowledgements are BACKCHANNEL.
6. Use UNCERTAIN for incomplete or garbled hypotheses.
7. Return one JSON object only with keys state, confidence, and reason.
"""


class SemanticState(str, Enum):
    INTERRUPT = "INTERRUPT"
    ADDRESSED_OTHER = "ADDRESSED_OTHER"
    BACKCHANNEL = "BACKCHANNEL"
    CONTINUE = "CONTINUE"
    UNCERTAIN = "UNCERTAIN"


@dataclass(frozen=True)
class SemanticPrediction:
    turn_id: int
    event_id: int
    state: SemanticState
    confidence: float
    reason: str
    transcript: str
    hypothesis_history: tuple[str, ...]
    is_final: bool
    latency_ms: float
    completed_at: float


@dataclass(frozen=True)
class OverlayRecommendation:
    action: MMITurnAction
    reason: str
    semantic_state: SemanticState | None = None


class SemanticClassifier(Protocol):
    async def classify(
        self,
        context: MMITurnContext,
        *,
        is_final: bool,
    ) -> SemanticPrediction:
        ...


class SemanticOverlayCapacityError(RuntimeError):
    """Raised when an online request would wait behind the realtime window."""


def has_overlay_interrupt_cue(hypotheses: tuple[str, ...]) -> bool:
    texts = (*hypotheses, " ".join(hypotheses))
    return any(pattern.search(text) for text in texts for pattern in _EXPLICIT_INTERRUPT_CUES)


def looks_like_direct_interaction(text: str) -> bool:
    return bool("?" in text or _DIRECT_INTERACTION_PATTERN.search(text))


def interrupt_suppression_state(
    predictions: tuple[SemanticPrediction, ...],
    transcript: str,
) -> SemanticState | None:
    decisive = [
        prediction
        for prediction in predictions
        if prediction.state != SemanticState.UNCERTAIN
    ]
    if not decisive:
        return None
    first = decisive[0]
    if first.state == SemanticState.ADDRESSED_OTHER and first.confidence >= 0.8:
        return SemanticState.ADDRESSED_OTHER
    prediction_texts = tuple(prediction.transcript for prediction in decisive)
    if (
        decisive[-1].state == SemanticState.BACKCHANNEL
        and not looks_like_direct_interaction(transcript)
        and not has_overlay_interrupt_cue(prediction_texts)
    ):
        return SemanticState.BACKCHANNEL
    if (
        not looks_like_direct_interaction(transcript)
        and not any(
            prediction.state == SemanticState.INTERRUPT
            for prediction in decisive
        )
        and not has_overlay_interrupt_cue(prediction_texts)
    ):
        return SemanticState.CONTINUE
    return None


class OpenAICompatibleSemanticClassifier:
    """One-shot async classifier with no retries so Shadow cannot amplify latency."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        timeout_ms: int,
        max_concurrency: int,
    ) -> None:
        self._url = base_url.rstrip("/") + "/chat/completions"
        self._api_key = api_key
        self._model = model
        self._timeout_sec = timeout_ms / 1000
        self._semaphore = asyncio.Semaphore(max_concurrency)

    async def classify(
        self,
        context: MMITurnContext,
        *,
        is_final: bool,
    ) -> SemanticPrediction:
        started_at = time.monotonic()
        history = context.transcript_hypotheses[-6:]
        prompt_history = "\n".join(
            f"{index + 1}. {text}"
            for index, text in enumerate(history)
        )
        user_prompt = (
            f"Streaming hypotheses, oldest to newest:\n{prompt_history}\n\n"
            f"Latest hypothesis is_final={str(is_final).lower()}.\n"
            f"Turn began during assistant speaking="
            f"{str(context.started_during_agent_speaking).lower()}.\n"
            f"Turn began during assistant thinking="
            f"{str(context.started_during_agent_thinking).lower()}."
        )
        payload = {
            "model": self._model,
            "temperature": 0,
            "max_tokens": 100,
            "enable_thinking": False,
            "messages": [
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
        }
        timeout = aiohttp.ClientTimeout(total=self._timeout_sec)
        try:
            await asyncio.wait_for(self._semaphore.acquire(), timeout=0.001)
        except TimeoutError as exc:
            raise SemanticOverlayCapacityError("max_concurrency_reached") from exc
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    self._url,
                    json=payload,
                    headers={"Authorization": f"Bearer {self._api_key}"},
                ) as response:
                    response.raise_for_status()
                    body = await response.json()
        finally:
            self._semaphore.release()
        content = str(body["choices"][0]["message"]["content"])
        parsed = parse_semantic_response(content)
        completed_at = time.monotonic()
        return SemanticPrediction(
            turn_id=context.turn_id,
            event_id=context.event_id,
            state=SemanticState(parsed["state"]),
            confidence=parsed["confidence"],
            reason=parsed["reason"],
            transcript=context.latest_transcript_text,
            hypothesis_history=history,
            is_final=is_final,
            latency_ms=round((completed_at - started_at) * 1000, 3),
            completed_at=completed_at,
        )


def parse_semantic_response(content: str) -> dict[str, Any]:
    text = content.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1]).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        raise ValueError("Semantic response does not contain a JSON object")
    value = json.loads(text[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("Semantic response JSON must be an object")
    state = SemanticState(str(value.get("state") or "").upper())
    confidence = float(value.get("confidence") or 0.0)
    if not math.isfinite(confidence):
        raise ValueError("Semantic confidence must be finite")
    return {
        "state": state.value,
        "confidence": max(0.0, min(1.0, confidence)),
        "reason": str(value.get("reason") or "")[:500],
    }


class OnlineSemanticOverlayShadow:
    """Observe online transcripts and compare v4 recommendations without executing."""

    def __init__(
        self,
        classifier: SemanticClassifier,
        *,
        effective_budget_ms: int,
    ) -> None:
        self._classifier = classifier
        self._effective_budget_ms = effective_budget_ms
        self._predictions: dict[int, list[SemanticPrediction]] = {}
        self._base_decisions: dict[
            int,
            tuple[MMITurnDecision, MMITurnContext, str, float],
        ] = {}

    async def observe_transcript(
        self,
        context: MMITurnContext,
        *,
        is_final: bool,
    ) -> None:
        if not (
            context.latest_transcript_text
            and (
                context.started_during_agent_speaking
                or context.started_during_agent_thinking
            )
        ):
            return
        started_at = time.monotonic()
        try:
            prediction = await self._classifier.classify(context, is_final=is_final)
        except asyncio.CancelledError:
            raise
        except SemanticOverlayCapacityError as exc:
            logger.info(
                "[MMI-TD] semantic_overlay_dropped %s",
                json.dumps(
                    {
                        "session_id": context.session_id,
                        "turn_id": context.turn_id,
                        "event_id": context.event_id,
                        "policy_version": POLICY_VERSION,
                        "reason": str(exc),
                        "is_final": is_final,
                    },
                    ensure_ascii=False,
                ),
            )
            return
        except Exception as exc:
            logger.warning(
                "[MMI-TD] semantic_overlay_error %s",
                json.dumps(
                    {
                        "session_id": context.session_id,
                        "turn_id": context.turn_id,
                        "event_id": context.event_id,
                        "policy_version": POLICY_VERSION,
                        "prompt_version": PROMPT_VERSION,
                        "latency_ms": round((time.monotonic() - started_at) * 1000, 3),
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:500],
                    },
                    ensure_ascii=False,
                ),
            )
            return

        predictions = self._predictions.setdefault(context.turn_id, [])
        predictions.append(prediction)
        predictions.sort(key=lambda value: value.event_id)
        base = self._base_decisions.get(context.turn_id)
        recommendation = (
            self._recommend(base[0], base[1], tuple(predictions))
            if base is not None
            else None
        )
        logger.info(
            "[MMI-TD] semantic_overlay_result %s",
            json.dumps(
                {
                    "session_id": context.session_id,
                    "turn_id": context.turn_id,
                    "event_id": context.event_id,
                    "policy_version": POLICY_VERSION,
                    "prompt_version": PROMPT_VERSION,
                    "semantic_state": prediction.state.value,
                    "semantic_confidence": prediction.confidence,
                    "semantic_reason": prediction.reason,
                    "is_final": prediction.is_final,
                    "latency_ms": prediction.latency_ms,
                    "within_effective_budget": (
                        prediction.latency_ms <= self._effective_budget_ms
                    ),
                    "base_action": base[0].action.value if base is not None else None,
                    "base_trigger": base[2] if base is not None else None,
                    "arrived_before_base_decision": (
                        prediction.completed_at <= base[3]
                        if base is not None
                        else None
                    ),
                    "overlay_action": (
                        recommendation.action.value
                        if recommendation is not None
                        else None
                    ),
                    "overlay_reason": (
                        recommendation.reason
                        if recommendation is not None
                        else None
                    ),
                    "would_change_action": (
                        recommendation.action != base[0].action
                        if recommendation is not None and base is not None
                        else None
                    ),
                },
                ensure_ascii=False,
            ),
        )
        self._discard_old_turns(context.turn_id)

    def observe_base_decision(
        self,
        decision: MMITurnDecision,
        context: MMITurnContext,
        *,
        trigger: str,
    ) -> None:
        if not (
            context.started_during_agent_speaking
            or context.started_during_agent_thinking
        ):
            return
        observed_at = time.monotonic()
        self._base_decisions[context.turn_id] = (
            decision,
            context,
            trigger,
            observed_at,
        )
        predictions = tuple(self._predictions.get(context.turn_id, ()))
        recommendation = self._recommend(decision, context, predictions)
        logger.info(
            "[MMI-TD] semantic_overlay_comparison %s",
            json.dumps(
                {
                    "session_id": context.session_id,
                    "turn_id": context.turn_id,
                    "event_id": context.event_id,
                    "policy_version": POLICY_VERSION,
                    "trigger": trigger,
                    "base_action": decision.action.value,
                    "base_reason": decision.reason,
                    "semantic_predictions_available": len(predictions),
                    "semantic_arrived_before_base_decision": bool(predictions),
                    "overlay_action": recommendation.action.value,
                    "overlay_reason": recommendation.reason,
                    "overlay_state": (
                        recommendation.semantic_state.value
                        if recommendation.semantic_state is not None
                        else None
                    ),
                    "would_change_action": recommendation.action != decision.action,
                },
                ensure_ascii=False,
            ),
        )
        self._discard_old_turns(context.turn_id)

    def _recommend(
        self,
        decision: MMITurnDecision,
        context: MMITurnContext,
        predictions: tuple[SemanticPrediction, ...],
    ) -> OverlayRecommendation:
        decisive = tuple(
            prediction
            for prediction in predictions
            if prediction.state != SemanticState.UNCERTAIN
        )
        first_is_other = bool(
            decisive
            and decisive[0].state == SemanticState.ADDRESSED_OTHER
            and decisive[0].confidence >= 0.8
        )
        if (
            decision.action == MMITurnAction.CONTINUE_SPEAKING
            and bool(predictions)
            and not first_is_other
            and has_overlay_interrupt_cue(context.transcript_hypotheses)
        ):
            return OverlayRecommendation(
                action=MMITurnAction.START_LISTENING,
                reason="overlay_explicit_floor_taking_or_redirect_cue",
                semantic_state=SemanticState.INTERRUPT,
            )
        if decision.action == MMITurnAction.START_LISTENING:
            suppression = interrupt_suppression_state(
                predictions,
                context.transcript_text,
            )
            if suppression is not None:
                return OverlayRecommendation(
                    action=MMITurnAction.CONTINUE_SPEAKING,
                    reason=f"overlay_suppress_interrupt:{suppression.value.lower()}",
                    semantic_state=suppression,
                )
        return OverlayRecommendation(
            action=decision.action,
            reason="overlay_keep_base_action",
        )

    def _discard_old_turns(self, current_turn_id: int) -> None:
        cutoff = current_turn_id - 3
        self._predictions = {
            turn_id: values
            for turn_id, values in self._predictions.items()
            if turn_id >= cutoff
        }
        self._base_decisions = {
            turn_id: value
            for turn_id, value in self._base_decisions.items()
            if turn_id >= cutoff
        }


def build_online_semantic_overlay(config: Any) -> OnlineSemanticOverlayShadow | None:
    if not bool(getattr(config, "semantic_overlay_shadow_enabled", False)):
        return None
    base_url = str(getattr(config, "semantic_overlay_base_url", "") or "").strip()
    api_key = str(getattr(config, "semantic_overlay_api_key", "") or "").strip()
    model = str(getattr(config, "semantic_overlay_model", "") or "").strip()
    if not base_url or not api_key or not model:
        logger.warning(
            "[MMI-TD] semantic overlay disabled: base_url, api_key, or model is missing"
        )
        return None
    classifier = OpenAICompatibleSemanticClassifier(
        base_url=base_url,
        api_key=api_key,
        model=model,
        timeout_ms=int(getattr(config, "semantic_overlay_timeout_ms", 1500)),
        max_concurrency=int(
            getattr(config, "semantic_overlay_max_concurrency", 2)
        ),
    )
    return OnlineSemanticOverlayShadow(
        classifier,
        effective_budget_ms=int(
            getattr(config, "semantic_overlay_effective_budget_ms", 300)
        ),
    )

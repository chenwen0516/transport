"""Trace committed replies and retry one response that produces no user-visible output."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, Coroutine

logger = logging.getLogger("health-agent.mmi.response")

_RETRY_INSTRUCTIONS = (
    "The previous response produced no final text or audio. Continue the current "
    "conversation and answer the user's latest message now in the same language as "
    "the user. Give a concise spoken answer and do not return an empty response."
)


@dataclass
class _ResponseAttempt:
    turn_id: int
    commit_text: str
    attempt: int
    started_at: float
    speech_handle: Any | None = None
    speech_id: str = ""
    generation_seen: bool = False
    content_seen: bool = False
    first_audio_seen: bool = False
    retry_started: bool = False
    timeout_task: asyncio.Task[None] | None = None


class MMIResponseWatchdog:
    """Observe a committed MMI reply and retry at most once when output is empty."""

    def __init__(
        self,
        session: Any,
        *,
        session_id: str,
        is_current_turn: Callable[[int], bool],
        first_output_timeout_ms: int = 20_000,
        max_retries: int = 1,
        cancel_grace_ms: int = 3_000,
        retry_settle_ms: int = 100,
    ) -> None:
        self._session = session
        self._session_id = session_id
        self._is_current_turn = is_current_turn
        self._first_output_timeout_ms = first_output_timeout_ms
        self._max_retries = max_retries
        self._cancel_grace_ms = cancel_grace_ms
        self._retry_settle_ms = max(0, retry_settle_ms)
        self._pending: _ResponseAttempt | None = None
        self._tasks: set[asyncio.Task[Any]] = set()
        self._closed = False

    def setup(self) -> None:
        self._session.on("speech_created")(self._on_speech_created)
        self._session.on("generation_created")(self._on_generation_created)
        self._session.on("conversation_item_added")(
            self._on_conversation_item_added
        )
        self._session.on("agent_state_changed")(self._on_agent_state_changed)

    def arm(self, turn_id: int, commit_text: str) -> None:
        if self._closed:
            return
        self._clear_pending("superseded")
        pending = _ResponseAttempt(
            turn_id=turn_id,
            commit_text=commit_text,
            attempt=0,
            started_at=time.monotonic(),
        )
        self._pending = pending
        self._trace(pending, "commit_requested", commit_text_len=len(commit_text))
        self._schedule_timeout(pending)

    def cancel(self, turn_id: int, reason: str) -> None:
        pending = self._pending
        if pending is None or pending.turn_id != turn_id:
            return
        self._clear_pending(reason)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._clear_pending("session_closed")
        for task in tuple(self._tasks):
            if not task.done():
                task.cancel()
        self._tasks.clear()

    def _on_speech_created(self, event: Any) -> None:
        pending = self._valid_pending()
        if pending is None:
            return
        handle = getattr(event, "speech_handle", None)
        if handle is None:
            return
        self._bind_handle(pending, handle)

    def _on_generation_created(self, _event: Any) -> None:
        pending = self._valid_pending()
        if pending is None or pending.generation_seen:
            return
        pending.generation_seen = True
        self._trace(pending, "generation_created")

    def _on_conversation_item_added(self, event: Any) -> None:
        pending = self._valid_pending()
        if pending is None or pending.content_seen:
            return
        item = getattr(event, "item", None)
        if getattr(item, "role", "") != "assistant":
            return
        text = self._item_text(item)
        if not text:
            return
        pending.content_seen = True
        self._trace(pending, "first_content", content_chars=len(text))

    def _on_agent_state_changed(self, event: Any) -> None:
        pending = self._valid_pending()
        if pending is None or getattr(event, "new_state", "") != "speaking":
            return
        if pending.first_audio_seen:
            return
        pending.first_audio_seen = True
        self._trace(pending, "first_audio")
        self._complete_success(pending, "agent_speaking")

    def _bind_handle(self, pending: _ResponseAttempt, handle: Any) -> None:
        speech_id = str(getattr(handle, "id", ""))
        if pending.speech_id == speech_id and pending.speech_handle is handle:
            return
        if pending.speech_handle is not None:
            return
        pending.speech_handle = handle
        pending.speech_id = speech_id
        attempt = pending.attempt
        self._trace(pending, "speech_created", speech_id=speech_id)

        def done(completed: Any) -> None:
            self._spawn(self._on_handle_done(attempt, speech_id, completed))

        handle.add_done_callback(done)

    async def _on_handle_done(
        self,
        attempt: int,
        speech_id: str,
        handle: Any,
    ) -> None:
        pending = self._valid_pending()
        if (
            pending is None
            or pending.attempt != attempt
            or pending.speech_id != speech_id
        ):
            return
        content_chars = len(self._handle_text(handle))
        interrupted = bool(getattr(handle, "interrupted", False))
        self._trace(
            pending,
            "response_done",
            content_chars=content_chars,
            first_audio=pending.first_audio_seen,
            interrupted=interrupted,
        )
        if pending.first_audio_seen:
            self._complete_success(pending, "response_done_with_output")
            return
        if interrupted and not pending.retry_started:
            self._clear_pending("response_interrupted")
            return
        failure_kind = (
            "tts_or_playout_missing"
            if pending.content_seen or content_chars > 0
            else "model_empty_response"
        )
        await self._retry(pending, failure_kind)

    async def _timeout_after(self, pending: _ResponseAttempt) -> None:
        try:
            await asyncio.sleep(self._first_output_timeout_ms / 1000)
        except asyncio.CancelledError:
            return
        if self._valid_pending() is not pending:
            return
        self._trace(pending, "first_output_timeout")
        await self._retry(pending, "first_output_timeout")

    async def _retry(self, pending: _ResponseAttempt, reason: str) -> None:
        if self._valid_pending() is not pending or pending.retry_started:
            return
        if pending.attempt >= self._max_retries:
            self._trace(pending, "retry_exhausted", reason=reason)
            self._clear_pending("retry_exhausted")
            return

        pending.retry_started = True
        self._cancel_timeout(pending)
        handle = pending.speech_handle
        try:
            if handle is not None and not handle.done():
                handle.interrupt(force=True)
                await asyncio.wait_for(
                    handle.wait_for_playout(),
                    timeout=self._cancel_grace_ms / 1000,
                )
            elif handle is None:
                await self._session.interrupt(force=True)
        except asyncio.TimeoutError:
            self._trace(pending, "retry_aborted", reason="cancel_timeout")
            self._clear_pending("cancel_timeout")
            return
        except RuntimeError:
            logger.info(
                "[MMI-RESPONSE] no active response to interrupt session=%s turn=%s",
                self._session_id,
                pending.turn_id,
            )
        except Exception:
            logger.exception(
                "[MMI-RESPONSE] failed to stop empty response session=%s turn=%s",
                self._session_id,
                pending.turn_id,
            )
            self._clear_pending("cancel_failed")
            return

        if self._valid_pending() is not pending:
            return
        if self._retry_settle_ms:
            await asyncio.sleep(self._retry_settle_ms / 1000)
        if self._valid_pending() is not pending:
            return
        pending.attempt += 1
        pending.started_at = time.monotonic()
        pending.speech_handle = None
        pending.speech_id = ""
        pending.generation_seen = False
        pending.content_seen = False
        pending.first_audio_seen = False
        pending.retry_started = False
        self._trace(pending, "retry_requested", reason=reason)
        try:
            retry_handle = self._session.generate_reply(
                instructions=_RETRY_INSTRUCTIONS,
            )
        except Exception:
            logger.exception(
                "[MMI-RESPONSE] retry generate_reply failed session=%s turn=%s",
                self._session_id,
                pending.turn_id,
            )
            self._clear_pending("retry_request_failed")
            return
        self._bind_handle(pending, retry_handle)
        self._schedule_timeout(pending)

    def _valid_pending(self) -> _ResponseAttempt | None:
        pending = self._pending
        if pending is None or self._closed:
            return None
        if not self._is_current_turn(pending.turn_id):
            self._clear_pending("stale_turn")
            return None
        return pending

    def _complete_success(self, pending: _ResponseAttempt, reason: str) -> None:
        if self._pending is not pending:
            return
        self._trace(pending, "output_confirmed", reason=reason)
        self._clear_pending("output_confirmed", trace=False)

    def _schedule_timeout(self, pending: _ResponseAttempt) -> None:
        if self._first_output_timeout_ms <= 0:
            return
        pending.timeout_task = self._spawn(self._timeout_after(pending))

    def _cancel_timeout(self, pending: _ResponseAttempt) -> None:
        task = pending.timeout_task
        if task is not None and not task.done() and task is not asyncio.current_task():
            task.cancel()
        pending.timeout_task = None

    def _clear_pending(self, reason: str, *, trace: bool = True) -> None:
        pending = self._pending
        if pending is None:
            return
        if trace:
            self._trace(pending, "watch_cancelled", reason=reason)
        self._cancel_timeout(pending)
        self._pending = None

    def _spawn(self, coroutine: Coroutine[Any, Any, Any]) -> asyncio.Task[Any]:
        task = asyncio.create_task(coroutine)
        self._tasks.add(task)
        task.add_done_callback(self._task_done)
        return task

    def _task_done(self, task: asyncio.Task[Any]) -> None:
        self._tasks.discard(task)
        if task.cancelled():
            return
        try:
            task.result()
        except Exception:
            logger.exception("[MMI-RESPONSE] background task failed")

    def _trace(self, pending: _ResponseAttempt, stage: str, **fields: Any) -> None:
        payload = {
            "session_id": self._session_id,
            "turn_id": pending.turn_id,
            "attempt": pending.attempt,
            "stage": stage,
            "elapsed_ms": round((time.monotonic() - pending.started_at) * 1000, 3),
            **fields,
        }
        logger.info(
            "[MMI-RESPONSE] trace %s",
            json.dumps(payload, ensure_ascii=False),
        )

    @classmethod
    def _handle_text(cls, handle: Any) -> str:
        return " ".join(
            text
            for text in (cls._item_text(item) for item in getattr(handle, "chat_items", []))
            if text
        )

    @staticmethod
    def _item_text(item: Any) -> str:
        direct = str(getattr(item, "text_content", "") or "").strip()
        if direct:
            return direct
        parts: list[str] = []
        for content in getattr(item, "content", []) or []:
            if isinstance(content, str):
                parts.append(content)
                continue
            transcript = getattr(content, "transcript", "")
            if transcript:
                parts.append(str(transcript))
        return " ".join(parts).strip()

#!/usr/bin/env python3
"""Join Full-Duplex-Bench v1.5 samples with MMI Shadow session logs.

The FDB WebRTC runner records the LiveKit room in each sample's
``output_events.jsonl``. Agent artifacts use the same room in the directory name,
so the join is exact and does not depend on timestamps.

Only metadata and decision fields are emitted by default. Transcript text is
included only when ``--include-transcripts`` is explicitly requested for a
synthetic-data diagnostic run.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Any, Iterable

DECISION_MARKER = "[MMI-TD] decision "
NATIVE_ACTION_MARKER = "[MMI-TD] native_action "
AGENT_RUN_RE = re.compile(r"^\d{8}_\d{6}_(.+)$")

SCENARIOS = (
    "background_speech",
    "talking_to_other",
    "user_backchannel",
    "user_interruption",
)
EXPECTED_OUTCOME = {
    "background_speech": "SUPPRESS",
    "talking_to_other": "SUPPRESS",
    "user_backchannel": "SUPPRESS",
    "user_interruption": "INTERRUPT",
}
OUTCOMES = ("INTERRUPT", "COMMIT", "SUPPRESS", "NO_TARGET_DECISION")


@dataclass(frozen=True)
class ParsedMMILog:
    decisions: list[dict[str, Any]]
    native_actions: list[dict[str, Any]]
    malformed_lines: int = 0


def _load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        value = json.load(fh)
    return value if isinstance(value, dict) else {}


def _marker_payload(line: str, marker: str) -> dict[str, Any] | None:
    index = line.find(marker)
    if index < 0:
        return None
    try:
        value = json.loads(line[index + len(marker) :].strip())
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def extract_room(event_path: Path) -> str | None:
    if not event_path.is_file():
        return None
    room: str | None = None
    with event_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if event.get("type") == "client.livekit_credentials" and event.get("room"):
                # A rerun may append fresh events to copied sample artifacts.
                # The final credentials event belongs to the current inference.
                room = str(event["room"])
    return room


def extract_final_evaluator_transcripts(event_path: Path) -> list[str]:
    """Return final user transcripts published by the FDB evaluator."""
    if not event_path.is_file():
        return []
    transcripts: list[str] = []
    with event_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if (
                event.get("type") != "livekit.transcription_received"
                or event.get("final") is not True
                or not str(event.get("participant") or "").startswith("fdb-evaluator-")
            ):
                continue
            text = str(event.get("text") or "").strip()
            if text:
                transcripts.append(text)
    return transcripts


def build_agent_run_index(root: Path) -> tuple[dict[str, Path], dict[str, list[str]]]:
    candidates: dict[str, list[Path]] = {}
    if root.is_dir():
        for path in root.iterdir():
            match = AGENT_RUN_RE.match(path.name) if path.is_dir() else None
            if match:
                candidates.setdefault(match.group(1), []).append(path)

    index: dict[str, Path] = {}
    duplicates: dict[str, list[str]] = {}
    for room, paths in candidates.items():
        ordered = sorted(paths, key=lambda path: path.name)
        index[room] = ordered[-1]
        if len(ordered) > 1:
            duplicates[room] = [str(path) for path in ordered]
    return index, duplicates


def parse_mmi_log(path: Path) -> ParsedMMILog:
    decisions: list[dict[str, Any]] = []
    native_actions: list[dict[str, Any]] = []
    malformed = 0
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            if DECISION_MARKER in line:
                payload = _marker_payload(line, DECISION_MARKER)
                if payload is None:
                    malformed += 1
                else:
                    decisions.append(payload)
            if NATIVE_ACTION_MARKER in line:
                payload = _marker_payload(line, NATIVE_ACTION_MARKER)
                if payload is None:
                    malformed += 1
                else:
                    native_actions.append(payload)
    return ParsedMMILog(decisions, native_actions, malformed)


def is_target_related(decision: dict[str, Any]) -> bool:
    return bool(
        decision.get("started_during_agent_speaking")
        or decision.get("started_during_agent_thinking")
        or decision.get("agent_state") == "speaking"
        or decision.get("tts_playing")
    )


def is_control_lane(decision: dict[str, Any]) -> bool:
    """Return whether a decision controls active or pending agent output."""
    return bool(
        decision.get("agent_state") == "speaking"
        or decision.get("tts_playing")
        or decision.get("agent_state") == "thinking"
    )


def classify_outcome(decisions: list[dict[str, Any]]) -> str:
    if not decisions:
        return "NO_TARGET_DECISION"
    if any(decision.get("action") == "START_LISTENING" for decision in decisions):
        return "INTERRUPT"
    if any(
        decision.get("action") == "START_SPEAKING"
        and not decision.get("ignore_input", False)
        for decision in decisions
    ):
        return "COMMIT"
    return "SUPPRESS"


def is_strict_control_correct(expected: str, outcome: str) -> bool:
    if outcome == expected:
        return True
    return expected == "SUPPRESS" and outcome == "NO_TARGET_DECISION"


def select_target_turn(
    decisions: list[dict[str, Any]],
) -> tuple[int | None, list[dict[str, Any]], dict[str, Any] | None, str]:
    related = [decision for decision in decisions if is_target_related(decision)]
    if not related:
        return None, [], None, "NO_TARGET_DECISION"

    target_turn = related[-1].get("turn_id")
    turn_decisions = [
        decision for decision in decisions if decision.get("turn_id") == target_turn
    ]
    if not turn_decisions:
        turn_decisions = related
    control_decisions = [decision for decision in turn_decisions if is_control_lane(decision)]
    if not control_decisions:
        return None, [], None, "NO_TARGET_DECISION"
    return (
        target_turn,
        control_decisions,
        control_decisions[-1],
        classify_outcome(control_decisions),
    )


def _number(value: Any) -> float | int | None:
    return value if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def _percentile(values: Iterable[float | int], percentile: float) -> float | None:
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return None
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * percentile
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def _distribution(values: Iterable[float | int]) -> dict[str, Any]:
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return {"count": 0, "p50": None, "p95": None, "min": None, "max": None}
    return {
        "count": len(ordered),
        "p50": round(median(ordered), 3),
        "p95": round(_percentile(ordered, 0.95) or 0.0, 3),
        "min": round(ordered[0], 3),
        "max": round(ordered[-1], 3),
    }


def _behavior_label(sample_dir: Path) -> str | None:
    path = sample_dir / "content_tag.json"
    if not path.is_file():
        return None
    labels = _load_json(path).get("behaviour") or []
    return str(labels[0]) if labels else None


def analyze_sample(
    scenario: str,
    sample_dir: Path,
    agent_index: dict[str, Path],
    include_transcripts: bool = False,
) -> dict[str, Any]:
    sample_key = f"v1.5/{scenario}/{sample_dir.name}"
    room = extract_room(sample_dir / "output_events.jsonl")
    row: dict[str, Any] = {
        "sample": sample_key,
        "scenario": scenario,
        "sample_id": sample_dir.name,
        "room": room,
        "behavior_label": _behavior_label(sample_dir),
        "expected_outcome": EXPECTED_OUTCOME[scenario],
        "join_status": "missing_room",
        "mmi_outcome": "NO_TARGET_DECISION",
        "strict_correct": False,
    }
    if include_transcripts:
        metadata_path = sample_dir / "metadata.json"
        metadata = _load_json(metadata_path) if metadata_path.is_file() else {}
        observed = extract_final_evaluator_transcripts(
            sample_dir / "output_events.jsonl"
        )
        row.update(
            {
                "expected_context_text": metadata.get("context_text"),
                "expected_current_turn_text": metadata.get("current_turn_text"),
                "observed_context_text": observed[0] if observed else None,
                "observed_current_turn_text": observed[-1] if observed else None,
            }
        )
    if not room:
        return row

    agent_dir = agent_index.get(room)
    if agent_dir is None:
        row["join_status"] = "missing_agent_run"
        return row
    row["agent_run_dir"] = str(agent_dir)

    logs = sorted(agent_dir.glob("mmi_turn_detection_active_*.log"))
    if not logs:
        row["join_status"] = "missing_mmi_log"
        return row

    parsed = parse_mmi_log(logs[-1])
    target_turn, control_decisions, terminal, outcome = select_target_turn(parsed.decisions)
    lifecycle_decisions = [
        decision
        for decision in parsed.decisions
        if target_turn is not None and decision.get("turn_id") == target_turn
    ]
    first_related = control_decisions[0] if control_decisions else None
    processing_latencies = [
        value
        for decision in control_decisions
        if (value := _number(decision.get("event_processing_latency_ms"))) is not None
    ]
    verdict_rechecks = [
        decision
        for decision in control_decisions
        if str(decision.get("trigger") or "").startswith("speaker_verdict_")
    ]

    row.update(
        {
            "join_status": "joined",
            "mmi_log": str(logs[-1]),
            "decision_count": len(parsed.decisions),
            "native_action_count": len(parsed.native_actions),
            "malformed_log_lines": parsed.malformed_lines,
            "executed_count": sum(bool(item.get("executed")) for item in parsed.decisions),
            "target_turn_id": target_turn,
            "target_decision_count": len(control_decisions),
            "speaker_verdict_recheck_count": len(verdict_rechecks),
            "event_processing_latencies_ms": processing_latencies,
            "event_processing_latency_p95_ms": _percentile(
                processing_latencies,
                0.95,
            ),
            "mmi_outcome": outcome,
            "strict_correct": is_strict_control_correct(
                EXPECTED_OUTCOME[scenario],
                outcome,
            ),
            "lifecycle_decision_count": len(lifecycle_decisions),
            "lifecycle_outcome": classify_outcome(lifecycle_decisions),
            "target_has_start_listening": any(
                item.get("action") == "START_LISTENING" for item in control_decisions
            ),
            "target_has_start_speaking": any(
                item.get("action") == "START_SPEAKING"
                and not item.get("ignore_input", False)
                for item in control_decisions
            ),
            "native_has_start_listening": any(
                item.get("action") == "START_LISTENING" for item in parsed.native_actions
            ),
            "native_has_start_speaking": any(
                item.get("action") == "START_SPEAKING" for item in parsed.native_actions
            ),
            "first_target_observe_ms": _number(
                first_related.get("transcript_observe_ms") if first_related else None
            ),
            "terminal_observe_ms": _number(
                terminal.get("transcript_observe_ms") if terminal else None
            ),
            "terminal_silence_ms": _number(terminal.get("silence_ms") if terminal else None),
            "terminal_action": terminal.get("action") if terminal else None,
            "terminal_reason": terminal.get("reason") if terminal else None,
            "terminal_confidence": _number(
                terminal.get("confidence") if terminal else None
            ),
            "terminal_pattern_version": (
                terminal.get("pattern_version") if terminal else None
            ),
            "terminal_external_voice_confidence": _number(
                terminal.get("external_voice_confidence") if terminal else None
            ),
            "terminal_speaker_gate_locked": (
                terminal.get("external_speaker_gate_locked") if terminal else None
            ),
            "terminal_started_before_speaker_gate_locked": (
                terminal.get("started_before_speaker_gate_locked") if terminal else None
            ),
            "terminal_speaker_is_target": (
                terminal.get("external_speaker_is_target") if terminal else None
            ),
            "terminal_turn_speaker_is_target": (
                terminal.get("turn_speaker_is_target") if terminal else None
            ),
        }
    )
    return row


def _counter_to_dict(counter: Counter[Any]) -> dict[str, int]:
    return {str(key): value for key, value in sorted(counter.items(), key=lambda item: str(item[0]))}


def summarize(rows: list[dict[str, Any]], duplicate_rooms: dict[str, list[str]]) -> dict[str, Any]:
    joined = [row for row in rows if row.get("join_status") == "joined"]
    scenario_reports: dict[str, Any] = {}

    for scenario in SCENARIOS:
        items = [row for row in rows if row["scenario"] == scenario]
        target = [row for row in items if row.get("target_turn_id") is not None]
        outcomes = Counter(row.get("mmi_outcome") for row in items)
        lifecycle_outcomes = Counter(row.get("lifecycle_outcome") for row in items)
        labels = Counter(row.get("behavior_label") or "MISSING" for row in items)
        terminal_actions = Counter(row.get("terminal_action") or "MISSING" for row in items)
        terminal_reasons = Counter(row.get("terminal_reason") or "MISSING" for row in items)
        pattern_versions = Counter(
            row.get("terminal_pattern_version") or "MISSING" for row in items
        )
        turn_speaker_states = Counter(
            "TARGET" if row.get("terminal_turn_speaker_is_target") is True
            else "NON_TARGET" if row.get("terminal_turn_speaker_is_target") is False
            else "UNKNOWN"
            for row in items
            if row.get("terminal_action")
        )
        cross = Counter(
            f"{row.get('mmi_outcome')}|{row.get('behavior_label') or 'MISSING'}"
            for row in items
        )
        strict_correct = sum(bool(row.get("strict_correct")) for row in items)
        terminal = [row for row in items if row.get("terminal_action")]
        scenario_reports[scenario] = {
            "samples": len(items),
            "joined": sum(row.get("join_status") == "joined" for row in items),
            "target_decision_coverage": round(len(target) / len(items), 6) if items else None,
            "strict_control_accuracy": round(strict_correct / len(items), 6) if items else None,
            "outcomes": _counter_to_dict(outcomes),
            "lifecycle_outcomes": _counter_to_dict(lifecycle_outcomes),
            "behavior_labels": _counter_to_dict(labels),
            "terminal_actions": _counter_to_dict(terminal_actions),
            "terminal_reasons": _counter_to_dict(terminal_reasons),
            "terminal_pattern_versions": _counter_to_dict(pattern_versions),
            "terminal_turn_speaker_states": _counter_to_dict(turn_speaker_states),
            "outcome_by_behavior": _counter_to_dict(cross),
            "first_target_observe_ms": _distribution(
                row["first_target_observe_ms"]
                for row in items
                if row.get("first_target_observe_ms") is not None
            ),
            "terminal_observe_ms": _distribution(
                row["terminal_observe_ms"]
                for row in items
                if row.get("terminal_observe_ms") is not None
            ),
            "event_processing_latency_ms": _distribution(
                value
                for row in items
                for value in row.get("event_processing_latencies_ms", [])
            ),
            "speaker_verdict_recheck_count": sum(
                int(row.get("speaker_verdict_recheck_count") or 0) for row in items
            ),
            "terminal_external_voice_signal_coverage": round(
                sum(row.get("terminal_external_voice_confidence") is not None for row in terminal)
                / len(terminal),
                6,
            ) if terminal else None,
            "terminal_speaker_gate_locked_rate": round(
                sum(row.get("terminal_speaker_gate_locked") is True for row in terminal)
                / len(terminal),
                6,
            ) if terminal else None,
            "terminal_started_before_speaker_gate_locked_rate": round(
                sum(
                    row.get("terminal_started_before_speaker_gate_locked") is True
                    for row in terminal
                ) / len(terminal),
                6,
            ) if terminal else None,
            "native_start_listening_sessions": sum(
                bool(row.get("native_has_start_listening")) for row in items
            ),
        }

    expected_positive = [row for row in rows if row["scenario"] == "user_interruption"]
    expected_negative = [row for row in rows if row["scenario"] != "user_interruption"]
    true_positive = sum(row.get("mmi_outcome") == "INTERRUPT" for row in expected_positive)
    false_negative = len(expected_positive) - true_positive
    false_positive = sum(row.get("mmi_outcome") == "INTERRUPT" for row in expected_negative)
    true_negative = len(expected_negative) - false_positive
    backchannels = [row for row in rows if row["scenario"] == "user_backchannel"]
    backchannel_false_interrupts = sum(
        row.get("mmi_outcome") == "INTERRUPT" for row in backchannels
    )

    confusion = {
        "positive_class": "user_interruption_requires_START_LISTENING",
        "tp": true_positive,
        "fn": false_negative,
        "fp": false_positive,
        "tn": true_negative,
        "recall": round(true_positive / len(expected_positive), 6) if expected_positive else None,
        "precision": round(true_positive / (true_positive + false_positive), 6)
        if true_positive + false_positive else None,
        "false_positive_rate": round(false_positive / len(expected_negative), 6)
        if expected_negative else None,
    }

    executed = sum(int(row.get("executed_count") or 0) for row in rows)
    target_covered = sum(row.get("target_turn_id") is not None for row in rows)
    required_control = [
        row for row in rows if row.get("scenario") == "user_interruption"
    ]
    required_control_covered = sum(
        row.get("target_turn_id") is not None for row in required_control
    )
    strong_recall = confusion["recall"]
    backchannel_false_rate = (
        backchannel_false_interrupts / len(backchannels) if backchannels else None
    )
    processing_latencies = [
        value
        for row in rows
        for value in row.get("event_processing_latencies_ms", [])
    ]
    processing_latency_p95 = _percentile(processing_latencies, 0.95)
    phase_gates = {
        "agent_log_join_rate": {
            "value": round(len(joined) / len(rows), 6) if rows else None,
            "threshold": 0.999,
            "pass": bool(rows) and len(joined) / len(rows) >= 0.999,
        },
        "shadow_executed_actions_zero": {
            "value": executed,
            "threshold": 0,
            "pass": executed == 0,
        },
        "required_interruption_decision_coverage": {
            "value": (
                round(required_control_covered / len(required_control), 6)
                if required_control
                else None
            ),
            "threshold": 0.999,
            "pass": bool(required_control)
            and required_control_covered / len(required_control) >= 0.999,
            "note": (
                "Required for user_interruption; negative scenarios without an active or "
                "pending agent output need no control action."
            ),
        },
        "strong_interruption_recall": {
            "value": strong_recall,
            "threshold": 0.95,
            "pass": strong_recall is not None and strong_recall >= 0.95,
        },
        "non_interruption_false_interruption_rate": {
            "value": confusion["false_positive_rate"],
            "threshold": 0.0,
            "pass": bool(expected_negative) and false_positive == 0,
            "note": (
                "Any interruption in background_speech, talking_to_other, or "
                "user_backchannel blocks Active rollout."
            ),
        },
        "backchannel_false_interruption_rate": {
            "value": round(backchannel_false_rate, 6) if backchannel_false_rate is not None else None,
            "threshold": 0.03,
            "pass": backchannel_false_rate is not None and backchannel_false_rate <= 0.03,
        },
        "event_processing_latency_p95_ms": {
            "value": round(processing_latency_p95, 3)
            if processing_latency_p95 is not None
            else None,
            "threshold": 20,
            "pass": processing_latency_p95 <= 20
            if processing_latency_p95 is not None
            else None,
            "note": (
                "SpeakerGate callback-to-MMI-decision latency; transcript_observe_ms is not processing latency."
                if processing_latency_p95 is not None
                else "No SpeakerGate verdict-triggered MMI decisions were present."
            ),
        },
    }

    return {
        "scope": "FDB v1.5 noisy output sessions",
        "samples": len(rows),
        "joined_samples": len(joined),
        "join_rate": round(len(joined) / len(rows), 6) if rows else None,
        "target_decision_samples": target_covered,
        "target_decision_coverage": round(target_covered / len(rows), 6) if rows else None,
        "decision_count": sum(int(row.get("decision_count") or 0) for row in rows),
        "malformed_log_lines": sum(int(row.get("malformed_log_lines") or 0) for row in rows),
        "executed_count": executed,
        "duplicate_agent_room_count": len(duplicate_rooms),
        "control_confusion_matrix": confusion,
        "phase_gates": phase_gates,
        "active_verdict": "BLOCK" if any(gate.get("pass") is False for gate in phase_gates.values()) else "REVIEW",
        "scenarios": scenario_reports,
    }


def analyze_run(
    run_dir: Path,
    agent_runs_dir: Path,
    include_transcripts: bool = False,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if (run_dir / "data" / "v1.5").is_dir():
        v15_root = run_dir / "data" / "v1.5"
    elif (run_dir / "v1.5").is_dir():
        v15_root = run_dir / "v1.5"
    elif run_dir.name == "v1.5" and run_dir.is_dir():
        v15_root = run_dir
    else:
        raise FileNotFoundError(f"Cannot find v1.5 data below {run_dir}")

    agent_index, duplicates = build_agent_run_index(agent_runs_dir)
    rows: list[dict[str, Any]] = []
    for scenario in SCENARIOS:
        scenario_dir = v15_root / scenario
        if not scenario_dir.is_dir():
            continue
        samples = sorted(
            (path for path in scenario_dir.iterdir() if path.is_dir() and path.name.isdigit()),
            key=lambda path: int(path.name),
        )
        rows.extend(
            analyze_sample(
                scenario,
                sample,
                agent_index,
                include_transcripts=include_transcripts,
            )
            for sample in samples
        )

    report = {
        "run_dir": str(run_dir.resolve()),
        "agent_runs_dir": str(agent_runs_dir.resolve()),
        "summary": summarize(rows, duplicates),
        "duplicate_agent_rooms": duplicates,
        "samples": rows,
    }
    return report, rows


def _pct(value: float | None) -> str:
    return "N/A" if value is None else f"{100 * value:.2f}%"


def render_text(report: dict[str, Any]) -> str:
    summary = report["summary"]
    gates = summary["phase_gates"]
    lines = [
        "FDB v1.5 + MMI Shadow 关联分析",
        "=" * 34,
        "",
        f"FDB 目录：{report['run_dir']}",
        f"Agent 日志目录：{report['agent_runs_dir']}",
        "分析范围：v1.5 noisy output sessions",
        "",
        "一、关联完整性",
        "--------------",
        f"样本数：{summary['samples']}",
        f"成功关联：{summary['joined_samples']}/{summary['samples']} ({_pct(summary['join_rate'])})",
        f"存在目标轮次决策：{summary['target_decision_samples']}/{summary['samples']} "
        f"({_pct(summary['target_decision_coverage'])})",
        f"MMI 决策总数：{summary['decision_count']}",
        f"JSON 解析失败行：{summary['malformed_log_lines']}",
        f"Shadow executed=true：{summary['executed_count']}",
        "",
        "二、按场景结果",
        "--------------",
        "场景                  样本  目标覆盖  INTERRUPT  COMMIT  SUPPRESS  NO_TARGET  严格正确率",
    ]
    for scenario in SCENARIOS:
        item = summary["scenarios"].get(scenario)
        if not item:
            continue
        outcomes = item["outcomes"]
        lines.append(
            f"{scenario:<22} {item['samples']:>4}  {_pct(item['target_decision_coverage']):>8}  "
            f"{outcomes.get('INTERRUPT', 0):>9}  {outcomes.get('COMMIT', 0):>6}  "
            f"{outcomes.get('SUPPRESS', 0):>8}  {outcomes.get('NO_TARGET_DECISION', 0):>9}  "
            f"{_pct(item['strict_control_accuracy']):>10}"
        )

    confusion = summary["control_confusion_matrix"]
    lines.extend(
        [
            "",
            "三、控制动作混淆矩阵",
            "--------------------",
            "正类：user_interruption 应产生 START_LISTENING。",
            f"TP={confusion['tp']}  FN={confusion['fn']}  FP={confusion['fp']}  TN={confusion['tn']}",
            f"强打断召回率：{_pct(confusion['recall'])}",
            f"非打断场景误触发率：{_pct(confusion['false_positive_rate'])}",
            "",
            "四、Phase 门禁",
            "------------",
        ]
    )
    for name, gate in gates.items():
        state = "PASS" if gate["pass"] is True else ("FAIL" if gate["pass"] is False else "N/A")
        value = gate.get("value")
        if isinstance(value, float) and name != "event_processing_latency_p95_ms":
            value_text = _pct(value)
        else:
            value_text = str(value)
        lines.append(f"{name}: {value_text} -> {state}")
        if gate.get("note"):
            lines.append(f"  说明：{gate['note']}")

    lines.extend(
        [
            "",
            f"Active 结论：{summary['active_verdict']}",
            "",
            "五、裁判标签与 MMI 的对照提示",
            "-----------------------------",
            "下列数字是 Shadow 决策的反事实线索，不等价于真实 Active A/B 结果。",
        ]
    )
    for scenario in SCENARIOS:
        item = summary["scenarios"].get(scenario)
        if not item:
            continue
        lines.append(f"{scenario} behavior={item['behavior_labels']}")
        lines.append(f"  MMI outcome x behavior={item['outcome_by_behavior']}")
        lines.append(f"  native lifecycle outcome={item['lifecycle_outcomes']}")
        lines.append(
            f"  observe_ms first={item['first_target_observe_ms']} terminal={item['terminal_observe_ms']}"
        )
        lines.append(
            f"  speaker_verdict_rechecks={item['speaker_verdict_recheck_count']} "
            f"callback_to_decision_ms={item['event_processing_latency_ms']}"
        )
        lines.append(
            f"  voice_signal={_pct(item['terminal_external_voice_signal_coverage'])} "
            f"speaker_gate_locked={_pct(item['terminal_speaker_gate_locked_rate'])} "
            f"started_before_lock={_pct(item['terminal_started_before_speaker_gate_locked_rate'])}"
        )
        lines.append(f"  turn_speaker={item['terminal_turn_speaker_states']}")

    lines.extend(
        [
            "",
            "六、口径限制",
            "------------",
            "1. 只分析 noisy output room；clean room 是对照，不计入真值混淆矩阵。",
            "2. 主指标使用 Agent 正在说话、播放 TTS 或存在 pending reply 时的控制决策；native 后续状态单列为 lifecycle。",
            "3. START_LISTENING 用作打断控制正类；控制通道无打断动作归为 SUPPRESS。",
            "4. native_action 不是权威打断真值；官方 FDB behavior 标签用于实际行为对照。",
            "5. event_processing_latency_ms 仅衡量 SpeakerGate callback 到 MMI 重算完成的耗时。",
            "",
        ]
    )
    diagnostic_rows = [
        row
        for row in report.get("samples", [])
        if "expected_current_turn_text" in row and not row.get("strict_correct")
    ]
    if diagnostic_rows:
        lines.extend(
            [
                "七、显式启用的合成数据 badcase 诊断",
                "----------------------------------",
            ]
        )
        for row in diagnostic_rows:
            lines.extend(
                [
                    f"{row['sample']} expected={row.get('expected_current_turn_text')!r}",
                    f"  observed={row.get('observed_current_turn_text')!r}",
                    f"  MMI={row.get('mmi_outcome')} reason={row.get('terminal_reason')}",
                ]
            )
        lines.append("")
    return "\n".join(lines)


CSV_FIELDS = (
    "sample",
    "scenario",
    "sample_id",
    "room",
    "behavior_label",
    "expected_outcome",
    "mmi_outcome",
    "strict_correct",
    "join_status",
    "decision_count",
    "executed_count",
    "target_turn_id",
    "target_decision_count",
    "speaker_verdict_recheck_count",
    "event_processing_latency_p95_ms",
    "lifecycle_decision_count",
    "lifecycle_outcome",
    "terminal_action",
    "terminal_reason",
    "first_target_observe_ms",
    "terminal_observe_ms",
    "terminal_silence_ms",
    "terminal_confidence",
    "terminal_external_voice_confidence",
    "terminal_speaker_gate_locked",
    "terminal_started_before_speaker_gate_locked",
    "terminal_speaker_is_target",
    "terminal_turn_speaker_is_target",
    "native_has_start_listening",
    "native_has_start_speaking",
)

TRANSCRIPT_CSV_FIELDS = (
    "expected_context_text",
    "expected_current_turn_text",
    "observed_context_text",
    "observed_current_turn_text",
)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(
    path: Path,
    rows: list[dict[str, Any]],
    include_transcripts: bool = False,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        fields = CSV_FIELDS + TRANSCRIPT_CSV_FIELDS if include_transcripts else CSV_FIELDS
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Join FDB v1.5 samples with MMI Shadow logs")
    parser.add_argument("run_dir", type=Path, help="FDB run directory or a directory containing v1.5")
    parser.add_argument("agent_runs_dir", type=Path, help="Agent tmp/runs directory")
    parser.add_argument("--json-out", type=Path, default=None)
    parser.add_argument("--csv-out", type=Path, default=None)
    parser.add_argument("--text-out", type=Path, default=None)
    parser.add_argument(
        "--include-transcripts",
        action="store_true",
        help=(
            "Include synthetic FDB expected/observed transcript text in outputs. "
            "Disabled by default to keep reports metadata-only."
        ),
    )
    args = parser.parse_args()

    report, rows = analyze_run(
        args.run_dir,
        args.agent_runs_dir,
        include_transcripts=args.include_transcripts,
    )
    text = render_text(report)
    if args.json_out:
        write_json(args.json_out, report)
    if args.csv_out:
        write_csv(args.csv_out, rows, include_transcripts=args.include_transcripts)
    if args.text_out:
        args.text_out.parent.mkdir(parents=True, exist_ok=True)
        args.text_out.write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()

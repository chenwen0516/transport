#!/usr/bin/env python3
"""SpeakerGate 效果量化分析。

把 tmp/ 下的「raw/stt 录音 + speaker_gate 日志 (+ MMI 日志)」按 session 时间戳对齐，
量化强背景人声场景下 SpeakerGate 的三大痛点：

  1. 锁定 (enroll)：锁定耗时、失败次数、是否最终锁上 —— fail-open 窗口有多长。
  2. 判决质量：PASS / SILENCE 的 sim 分布与重叠区，borderline 误杀 / 漏过。
  3. 漏入 (leak)：每个 SILENCE 段在被静音前漏进 STT 的 onset 时长（零延迟设计的代价），
     并用 raw vs stt 波形交叉验证 SpeakerGate 实际移除了多少语音。

只依赖 numpy + stdlib。用法：
    python evaluation/analyze_speaker_gate.py            # 分析 ./tmp
    python evaluation/analyze_speaker_gate.py path/to/tmp
    python evaluation/analyze_speaker_gate.py tmp --json report.json
"""

from __future__ import annotations

import glob
import json
import os
import re
import sys
import wave
from dataclasses import dataclass, field, asdict
from datetime import datetime
from statistics import median

import numpy as np

# ---------------------------------------------------------------- 日志正则
_TS = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})")
_CFG = re.compile(
    r"decide_min=([\d.]+)s max=([\d.]+)s gap=([\d.]+)s theta_silence=([\d.]+)"
)
_LOCK = re.compile(r"LOCKED on target speaker \(K=(\d+) consistent, min_pair=([\d.]+)\)")
_ENROLL_BAD = re.compile(r"enroll inconsistent \(min_pair=([\d.]+) < ([\d.]+)\)")
_NUM = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)"
_BARGE = re.compile(
    rf"segment#(\d+) barge-in verdict: sim=({_NUM}) min=({_NUM}) → (TARGET|BACKGROUND|UNKNOWN)"
)
_DECIDE = re.compile(rf"segment#(\d+) decision: sim=({_NUM}) theta=({_NUM}) → (PASS|SILENCE)")
_REHEAL = re.compile(r"RE-HEAL")

_TS_FMT = "%Y-%m-%d %H:%M:%S,%f"


def _parse_ts(line: str) -> datetime | None:
    m = _TS.match(line)
    return datetime.strptime(m.group(1), _TS_FMT) if m else None


@dataclass
class GateStats:
    decide_min_sec: float = 1.5
    theta_close: float = 0.35
    session_start: datetime | None = None
    session_end: datetime | None = None
    locked: bool = False
    lock_time: datetime | None = None
    lock_latency_sec: float | None = None
    lock_min_pair: float | None = None
    enroll_consist_min: float | None = None
    enroll_fail_count: int = 0
    enroll_fail_min_pairs: list[float] = field(default_factory=list)
    reheal_count: int = 0

    pass_sims: list[float] = field(default_factory=list)
    silence_sims: list[float] = field(default_factory=list)
    barge_target_sims: list[float] = field(default_factory=list)
    barge_background_sims: list[float] = field(default_factory=list)
    barge_min: float = 0.30

    # seg_id -> (barge verdict, decide verdict) 用于检测同段窗口判决矛盾
    _barge_by_seg: dict[int, str] = field(default_factory=dict)
    _decide_by_seg: dict[int, str] = field(default_factory=dict)


def parse_gate_log(path: str) -> GateStats:
    st = GateStats()
    with open(path, encoding="utf-8") as f:
        for line in f:
            ts = _parse_ts(line)
            if ts is not None:
                if st.session_start is None:
                    st.session_start = ts
                st.session_end = ts

            m = _CFG.search(line)
            if m:
                st.decide_min_sec = float(m.group(1))
                st.theta_close = float(m.group(4))
                continue
            m = _LOCK.search(line)
            if m and not st.locked:
                st.locked = True
                st.lock_time = ts
                st.lock_min_pair = float(m.group(2))
                if st.session_start and ts:
                    st.lock_latency_sec = (ts - st.session_start).total_seconds()
                continue
            m = _ENROLL_BAD.search(line)
            if m:
                st.enroll_fail_count += 1
                st.enroll_fail_min_pairs.append(float(m.group(1)))
                st.enroll_consist_min = float(m.group(2))
                continue
            if _REHEAL.search(line):
                st.reheal_count += 1
                continue
            m = _BARGE.search(line)
            if m:
                seg, sim, mn, verdict = int(m.group(1)), float(m.group(2)), float(m.group(3)), m.group(4)
                st.barge_min = mn
                if verdict == "TARGET":
                    st.barge_target_sims.append(sim)
                elif verdict == "BACKGROUND":
                    st.barge_background_sims.append(sim)
                st._barge_by_seg[seg] = verdict
                continue
            m = _DECIDE.search(line)
            if m:
                seg, sim, theta, verdict = int(m.group(1)), float(m.group(2)), float(m.group(3)), m.group(4)
                st.theta_close = theta
                (st.pass_sims if verdict == "PASS" else st.silence_sims).append(sim)
                st._decide_by_seg[seg] = verdict
    return st


# ---------------------------------------------------------------- 波形分析
_FRAME_MS = 20
_VOICED_RMS = 50.0      # 与 SpeakerGate min_energy 一致（int16 口径）
_SILENT_RMS = 5.0       # stt 帧低于此值视为被静音/本就静音


def _frame_rms(x: np.ndarray, fl: int) -> np.ndarray:
    n = (len(x) // fl) * fl
    if n == 0:
        return np.empty(0)
    f = x[:n].reshape(-1, fl).astype(np.float64)
    return np.sqrt(np.mean(f * f, axis=1))


def _read_wav(path: str) -> tuple[np.ndarray, int]:
    with wave.open(path, "rb") as w:
        sr = w.getframerate()
        ch = w.getnchannels()
        data = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    if ch > 1:
        data = data[::ch]
    return data, sr


def analyze_wav(raw_path: str, stt_path: str) -> dict | None:
    if not (os.path.exists(raw_path) and os.path.exists(stt_path)):
        return None
    raw, sr = _read_wav(raw_path)
    stt, _ = _read_wav(stt_path)
    n = min(len(raw), len(stt))
    raw, stt = raw[:n], stt[:n]
    fl = int(sr * _FRAME_MS / 1000)
    rr, sr_ = _frame_rms(raw, fl), _frame_rms(stt, fl)
    m = min(len(rr), len(sr_))
    rr, sr_ = rr[:m], sr_[:m]
    frame_sec = fl / sr

    voiced_raw = rr >= _VOICED_RMS
    silenced = voiced_raw & (sr_ < _SILENT_RMS)   # raw 有声、stt 被清零 → SpeakerGate 移除
    passed_voiced = voiced_raw & (sr_ >= _VOICED_RMS)

    vr = int(voiced_raw.sum())
    return {
        "total_sec": round(m * frame_sec, 1),
        "voiced_raw_sec": round(vr * frame_sec, 1),
        "silenced_sec": round(int(silenced.sum()) * frame_sec, 1),
        "passed_voiced_sec": round(int(passed_voiced.sum()) * frame_sec, 1),
        "silenced_ratio_of_voiced": round(silenced.sum() / vr, 3) if vr else None,
    }


# ---------------------------------------------------------------- MMI 日志（可选）
def scan_mmi(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    reasons: dict[str, int] = {}
    n = 0
    with open(path, encoding="utf-8") as f:
        for line in f:
            i = line.find("decision {")
            if i < 0:
                continue
            try:
                d = json.loads(line[i + len("decision "):])
            except Exception:
                continue
            n += 1
            r = d.get("reason", "?")
            reasons[r] = reasons.get(r, 0) + 1
    # 与 SpeakerGate 相关的 reason
    sg = {k: v for k, v in reasons.items() if "speaker" in k or "non_target" in k}
    return {"mmi_decisions": n, "speaker_related_reasons": sg}


# ---------------------------------------------------------------- 报告
def _dist(xs: list[float]) -> dict | None:
    if not xs:
        return None
    a = sorted(xs)
    return {"n": len(a), "min": round(a[0], 3), "median": round(median(a), 3), "max": round(a[-1], 3)}


def build_session_report(ts: str, gate_log: str, rec_json: str, mmi_log: str | None) -> dict:
    st = parse_gate_log(gate_log)
    rep: dict = {"session_ts": ts}

    # enroll / lock
    dur = None
    if st.session_start and st.session_end:
        dur = round((st.session_end - st.session_start).total_seconds(), 1)
    rep["lock"] = {
        "locked": st.locked,
        "lock_latency_sec": round(st.lock_latency_sec, 1) if st.lock_latency_sec else None,
        "lock_min_pair": st.lock_min_pair,
        "enroll_consist_min": st.enroll_consist_min,
        "enroll_fail_count": st.enroll_fail_count,
        "enroll_fail_min_pair_dist": _dist(st.enroll_fail_min_pairs),
        "reheal_count": st.reheal_count,
        "session_log_span_sec": dur,
        "fail_open_fraction": (
            round(st.lock_latency_sec / dur, 3) if (st.lock_latency_sec and dur) else (1.0 if not st.locked else None)
        ),
    }

    # 判决质量
    theta = st.theta_close
    sil = st.silence_sims
    pas = st.pass_sims
    borderline_silence = [s for s in sil if 0.30 <= s < theta]       # 可能误杀真用户
    overlap_pass_low = [s for s in pas if s < theta + 0.05]          # 贴近门的放行
    conflicts = [
        seg for seg in st._decide_by_seg
        if st._barge_by_seg.get(seg) == "TARGET" and st._decide_by_seg[seg] == "SILENCE"
    ]
    rep["decision"] = {
        "pass_sim_dist": _dist(pas),
        "silence_sim_dist": _dist(sil),
        "silence_rate": round(len(sil) / (len(sil) + len(pas)), 3) if (sil or pas) else None,
        "borderline_silence_0.30_theta": len(borderline_silence),  # SILENCE 但 sim∈[0.30,theta)
        "pass_near_theta": len(overlap_pass_low),
        "barge_vs_decide_conflicts": len(conflicts),                # 同段：barge=TARGET 但 decide=SILENCE
        "conflict_segments": conflicts[:20],
        "barge_target_dist": _dist(st.barge_target_sims),
        "barge_background_dist": _dist(st.barge_background_sims),
    }

    # 漏入估计：每个 SILENCE 段在被静音前漏过约 decide_min 秒
    leak_est = len(sil) * st.decide_min_sec
    rep["leak"] = {
        "decide_min_sec": st.decide_min_sec,
        "silence_segments": len(sil),
        "est_leaked_onset_sec": round(leak_est, 1),
    }

    # 波形交叉验证
    wav = None
    try:
        meta = json.load(open(rec_json, encoding="utf-8"))
        raw_p = meta.get("raw_input", {}).get("path", "")
        stt_p = meta.get("stt_input", {}).get("path", "")
        base = os.path.dirname(rec_json)
        raw_p = raw_p if os.path.isabs(raw_p) else os.path.join(os.path.dirname(base) if False else os.path.dirname(rec_json), os.path.basename(raw_p))
        stt_p = os.path.join(os.path.dirname(rec_json), os.path.basename(stt_p))
        wav = analyze_wav(raw_p, stt_p)
    except Exception as e:
        wav = {"error": str(e)}
    if wav:
        # 真实漏入占比：漏过的 onset / (漏过的 onset + 实际被移除的语音)
        if isinstance(wav, dict) and wav.get("silenced_sec") is not None:
            removed = wav["silenced_sec"]
            total_bg = removed + leak_est
            wav["est_leak_fraction_of_background"] = round(leak_est / total_bg, 3) if total_bg > 0 else None
    rep["waveform"] = wav

    if mmi_log:
        rep["mmi"] = scan_mmi(mmi_log)
    return rep


def aggregate(reports: list[dict]) -> dict:
    locked = [r for r in reports if r["lock"]["locked"]]
    lat = [r["lock"]["lock_latency_sec"] for r in locked if r["lock"]["lock_latency_sec"] is not None]
    all_sil = [s for r in reports for s in (r["decision"]["silence_sim_dist"] or {}).get("_raw", [])]
    leak = sum(r["leak"]["est_leaked_onset_sec"] for r in reports)
    sil_segs = sum(r["leak"]["silence_segments"] for r in reports)
    conflicts = sum(r["decision"]["barge_vs_decide_conflicts"] for r in reports)
    borderline = sum(r["decision"]["borderline_silence_0.30_theta"] for r in reports)
    enroll_fail = sum(r["lock"]["enroll_fail_count"] for r in reports)
    leak_fracs = [
        r["waveform"]["est_leak_fraction_of_background"]
        for r in reports
        if isinstance(r.get("waveform"), dict) and r["waveform"].get("est_leak_fraction_of_background") is not None
    ]
    return {
        "sessions": len(reports),
        "locked_sessions": len(locked),
        "lock_latency_sec": _dist(lat),
        "total_enroll_failures": enroll_fail,
        "total_silence_segments": sil_segs,
        "total_est_leaked_onset_sec": round(leak, 1),
        "avg_leaked_onset_per_silence_seg_sec": round(leak / sil_segs, 2) if sil_segs else None,
        "total_barge_vs_decide_conflicts": conflicts,
        "total_borderline_silence_0.30_theta": borderline,
        "mean_leak_fraction_of_background": round(sum(leak_fracs) / len(leak_fracs), 3) if leak_fracs else None,
    }


def main() -> None:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    tmp = args[0] if args else "tmp"
    out_json = None
    if "--json" in sys.argv:
        out_json = sys.argv[sys.argv.index("--json") + 1]

    gate_logs = sorted(
        glob.glob(os.path.join(tmp, "speaker_gate_*.log"))
        + glob.glob(os.path.join(tmp, "**", "speaker_gate_*.log"), recursive=True)
    )
    gate_logs = sorted(dict.fromkeys(gate_logs))
    if not gate_logs:
        print(f"No speaker_gate_*.log under {tmp}")
        return

    reports = []
    for gl in gate_logs:
        m = re.search(r"speaker_gate_(\d{8}_\d{6})\.log", gl)
        if not m:
            continue
        ts = m.group(1)
        log_dir = os.path.dirname(gl)
        recs = (
            glob.glob(os.path.join(log_dir, f"audio_recording_*_{ts}.json"))
            + glob.glob(os.path.join(tmp, "**", f"audio_recording_*_{ts}.json"), recursive=True)
        )
        recs = sorted(dict.fromkeys(recs))
        rec = recs[0] if recs else ""
        mmis = (
            glob.glob(os.path.join(log_dir, f"mmi_turn_detection_active_{ts}.log"))
            + glob.glob(os.path.join(tmp, "**", f"mmi_turn_detection_active_{ts}.log"), recursive=True)
        )
        mmis = sorted(dict.fromkeys(mmis))
        mmi = mmis[0] if mmis else None
        if not rec:
            # 无录音元数据也能出日志侧指标
            rec = os.path.join(tmp, f"__missing_{ts}.json")
        reports.append(build_session_report(ts, gl, rec, mmi))

    print("=" * 78)
    print("SpeakerGate 量化报告")
    print("=" * 78)
    for r in reports:
        lk, dc, le, wv = r["lock"], r["decision"], r["leak"], r.get("waveform")
        print(f"\n● session {r['session_ts']}  (log span {lk['session_log_span_sec']}s)")
        if lk["locked"]:
            print(f"  锁定: ✓ 耗时 {lk['lock_latency_sec']}s  min_pair={lk['lock_min_pair']}  "
                  f"注册失败 {lk['enroll_fail_count']} 次  fail-open 占比 {lk['fail_open_fraction']}")
        else:
            print(f"  锁定: ✗ 全程未锁定 (fail-open 100%)  注册失败 {lk['enroll_fail_count']} 次")
        if lk["enroll_fail_min_pair_dist"]:
            d = lk["enroll_fail_min_pair_dist"]
            threshold = lk.get("enroll_consist_min")
            suffix = f"  当前阈值 {threshold}" if threshold is not None else ""
            print(f"        注册失败 min_pair 分布: {d['min']}~{d['max']} (中位 {d['median']}){suffix}")
        print(f"  判决: PASS {dc['pass_sim_dist']}")
        print(f"        SILENCE {dc['silence_sim_dist']}  静音率={dc['silence_rate']}")
        print(f"        borderline 静音(sim∈[0.30,θ)): {dc['borderline_silence_0.30_theta']}  "
              f"barge/decide 矛盾段: {dc['barge_vs_decide_conflicts']} {dc['conflict_segments']}")
        print(f"  漏入: {le['silence_segments']} 个静音段 × ~{le['decide_min_sec']}s onset "
              f"= 估计漏入 {le['est_leaked_onset_sec']}s")
        if isinstance(wv, dict) and wv.get("silenced_sec") is not None:
            print(f"  波形: 有声 {wv['voiced_raw_sec']}s  SpeakerGate 实际移除 {wv['silenced_sec']}s "
                  f"(占有声 {wv['silenced_ratio_of_voiced']})  漏入占背景估计 {wv.get('est_leak_fraction_of_background')}")
        elif isinstance(wv, dict) and wv.get("error"):
            print(f"  波形: (跳过: {wv['error']})")
        if "mmi" in r and r["mmi"]:
            print(f"  MMI : {r['mmi'].get('mmi_decisions')} 决策, 声纹相关 reason: {r['mmi'].get('speaker_related_reasons')}")

    agg = aggregate(reports)
    print("\n" + "=" * 78)
    print("汇总")
    print("=" * 78)
    for k, v in agg.items():
        print(f"  {k}: {v}")

    if out_json:
        json.dump({"sessions": reports, "aggregate": agg}, open(out_json, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=2, default=str)
        print(f"\nJSON 已写入 {out_json}")


if __name__ == "__main__":
    main()

"""指标计算模块 (v2)

打断时延拆分为三段（VAD检测 / 打断执行 / 端到端），残留音频独立为质量指标。
端点时延使用"超额时延"（扣除注入静音后的纯检测耗时）。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, List, Dict


# ========== 打断指标 ==========

@dataclass
class InterruptionResult:
    """单次打断测试结果

    时延拆分（避免歧义）:
      vad_latency          = t_speech_started  - t_inject_first    (VAD 检测时延)
      interrupt_exec_latency = t_response_done - t_speech_started  (打断执行时延)
      e2e_interrupt_latency  = t_response_done - t_inject_first    (端到端主指标)
      residual_audio         = t_last_audio_delta - t_speech_started (质量指标: 打断后残留音频)
    """
    case_name: str
    expected_interrupt: bool
    actual_interrupted: bool
    t_inject_first: float                       # 注入第一帧时间
    t_inject_last: float                        # 注入最后一帧时间
    t_speech_started: Optional[float] = None    # speech_started 收到时间
    t_last_audio_delta: Optional[float] = None  # 最后一个 audio.delta 时间
    t_response_done: Optional[float] = None     # response.done(cancelled) 时间

    @property
    def correct(self) -> bool:
        return self.expected_interrupt == self.actual_interrupted

    @property
    def vad_latency_ms(self) -> Optional[float]:
        """VAD 检测时延"""
        if self.t_speech_started is None:
            return None
        return (self.t_speech_started - self.t_inject_first) * 1000

    @property
    def interrupt_exec_latency_ms(self) -> Optional[float]:
        """打断执行时延: speech_started → response.done(cancelled)"""
        if self.t_response_done is None or self.t_speech_started is None:
            return None
        return (self.t_response_done - self.t_speech_started) * 1000

    @property
    def e2e_interrupt_latency_ms(self) -> Optional[float]:
        """端到端打断时延（主指标）: inject_first → response.done(cancelled)"""
        if self.t_response_done is None:
            return None
        return (self.t_response_done - self.t_inject_first) * 1000

    @property
    def residual_audio_ms(self) -> Optional[float]:
        """残留音频时长（质量指标）: VAD 触发后 server 还推了多少音频"""
        if self.t_last_audio_delta is None or self.t_speech_started is None:
            return None
        return max(0, (self.t_last_audio_delta - self.t_speech_started) * 1000)


# ========== 轮次检测指标 ==========

@dataclass
class TurnDetectionResult:
    """单次轮次检测结果

    endpointing_excess = (t_agent_thinking - t_audio_end) - silence_duration
    即：扣除注入静音后的纯检测 + 处理耗时（主指标）。
    """
    case_name: str
    silence_duration_s: float                       # 注入的静音时长（最后一段）
    expected_turn_switch: bool
    actual_turn_switched: bool
    t_audio_end: float                              # 最后一帧用户音频发送完毕
    t_agent_thinking: Optional[float] = None        # agent → thinking
    t_agent_speaking: Optional[float] = None        # agent → speaking
    t_first_agent_audio_delta: Optional[float] = None
    mid_pause_switched: bool = False                # 中间停顿是否被误切轮

    @property
    def correct(self) -> bool:
        return self.expected_turn_switch == self.actual_turn_switched

    @property
    def endpointing_excess_ms(self) -> Optional[float]:
        """超额端点时延: 扣除注入静音后的纯检测耗时"""
        if self.t_agent_thinking is None:
            return None
        raw = (self.t_agent_thinking - self.t_audio_end) * 1000
        return raw - self.silence_duration_s * 1000

    @property
    def time_to_first_audio_ms(self) -> Optional[float]:
        """TTFB: 用户说完到收到第一个 agent 音频帧"""
        if self.t_first_agent_audio_delta is None:
            return None
        return (self.t_first_agent_audio_delta - self.t_audio_end) * 1000


# ========== 聚合器 ==========

def _percentiles(values: list[float]) -> dict[str, Optional[float]]:
    """计算 P50/P90/P95/P99/max"""
    if not values:
        return {"p50": None, "p90": None, "p95": None, "p99": None, "max": None}
    values = sorted(values)
    n = len(values)
    return {
        "p50": values[int(n * 0.50)],
        "p90": values[min(int(n * 0.90), n - 1)],
        "p95": values[min(int(n * 0.95), n - 1)],
        "p99": values[min(int(n * 0.99), n - 1)],
        "max": values[-1],
    }


class MetricsAggregator:
    """聚合多次测试结果，计算统计指标"""

    def __init__(self):
        self._interruptions: list[InterruptionResult] = []
        self._turn_detections: list[TurnDetectionResult] = []

    def add_interruption(self, result: InterruptionResult) -> None:
        self._interruptions.append(result)

    def add_turn_detection(self, result: TurnDetectionResult) -> None:
        self._turn_detections.append(result)

    # ---------- 打断：准确率 ----------

    def interruption_accuracy(self) -> float:
        if not self._interruptions:
            return 0.0
        return sum(1 for r in self._interruptions if r.correct) / len(self._interruptions)

    def false_barge_in_rate(self) -> float:
        should_not = [r for r in self._interruptions if not r.expected_interrupt]
        if not should_not:
            return 0.0
        return sum(1 for r in should_not if r.actual_interrupted) / len(should_not)

    # ---------- 打断：时延百分位 ----------

    def _successful_interruptions(self) -> list[InterruptionResult]:
        return [r for r in self._interruptions if r.expected_interrupt and r.actual_interrupted]

    def vad_latency_percentiles(self) -> dict[str, Optional[float]]:
        return _percentiles([
            r.vad_latency_ms for r in self._successful_interruptions()
            if r.vad_latency_ms is not None
        ])

    def interrupt_exec_latency_percentiles(self) -> dict[str, Optional[float]]:
        return _percentiles([
            r.interrupt_exec_latency_ms for r in self._successful_interruptions()
            if r.interrupt_exec_latency_ms is not None
        ])

    def e2e_interrupt_latency_percentiles(self) -> dict[str, Optional[float]]:
        return _percentiles([
            r.e2e_interrupt_latency_ms for r in self._successful_interruptions()
            if r.e2e_interrupt_latency_ms is not None
        ])

    def residual_audio_percentiles(self) -> dict[str, Optional[float]]:
        return _percentiles([
            r.residual_audio_ms for r in self._successful_interruptions()
            if r.residual_audio_ms is not None
        ])

    # ---------- 轮次：准确率 ----------

    def endpointing_accuracy(self) -> float:
        if not self._turn_detections:
            return 0.0
        return sum(1 for r in self._turn_detections if r.correct) / len(self._turn_detections)

    def false_endpointing_rate(self) -> float:
        should_not = [r for r in self._turn_detections if not r.expected_turn_switch]
        if not should_not:
            return 0.0
        return sum(1 for r in should_not if r.actual_turn_switched) / len(should_not)

    def missed_turn_rate(self) -> float:
        should = [r for r in self._turn_detections if r.expected_turn_switch]
        if not should:
            return 0.0
        return sum(1 for r in should if not r.actual_turn_switched) / len(should)

    # ---------- 轮次：时延百分位 ----------

    def endpointing_excess_percentiles(self) -> dict[str, Optional[float]]:
        return _percentiles([
            r.endpointing_excess_ms
            for r in self._turn_detections
            if r.endpointing_excess_ms is not None
            and r.expected_turn_switch and r.actual_turn_switched
        ])

    def ttfb_percentiles(self) -> dict[str, Optional[float]]:
        return _percentiles([
            r.time_to_first_audio_ms
            for r in self._turn_detections
            if r.time_to_first_audio_ms is not None
            and r.expected_turn_switch and r.actual_turn_switched
        ])

    # ---------- 汇总 ----------

    @property
    def interruption_results(self) -> list[InterruptionResult]:
        return list(self._interruptions)

    @property
    def turn_detection_results(self) -> list[TurnDetectionResult]:
        return list(self._turn_detections)

    def summary(self) -> dict:
        return {
            "interruption": {
                "total": len(self._interruptions),
                "accuracy": self.interruption_accuracy(),
                "false_barge_in_rate": self.false_barge_in_rate(),
                "e2e_latency": self.e2e_interrupt_latency_percentiles(),
                "residual_audio": self.residual_audio_percentiles(),
                "vad_latency": self.vad_latency_percentiles(),
                "interrupt_exec_latency": self.interrupt_exec_latency_percentiles(),
            },
            "turn_detection": {
                "total": len(self._turn_detections),
                "accuracy": self.endpointing_accuracy(),
                "false_endpointing_rate": self.false_endpointing_rate(),
                "missed_turn_rate": self.missed_turn_rate(),
                "endpointing_excess": self.endpointing_excess_percentiles(),
                "ttfb": self.ttfb_percentiles(),
            },
        }

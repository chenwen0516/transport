"""WebSocket 测试客户端

自动化测试专用的 WebSocket 客户端，封装 WS 连接、事件收集、音频注入。
支持精确时间戳记录，用于计算打断时延和端点检测延迟。
"""

import asyncio
import base64
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable

import websockets

logger = logging.getLogger("test.ws_client")


@dataclass
class TimestampedEvent:
    """带精确时间戳的服务端事件"""
    timestamp: float          # time.monotonic()
    wall_time: float          # time.time()
    event: dict[str, Any]     # 原始 JSON 事件

    @property
    def event_type(self) -> str:
        return self.event.get("type", "")


class RealtimeTestClient:
    """自动化测试专用的 WebSocket 客户端

    Features:
    - 后台协程持续收集事件并记录时间戳
    - 按 100ms 一帧注入 PCM 音频
    - 事件查询/过滤/等待 API
    """

    CHUNK_BYTES = 3200  # 100ms @ 16kHz/16bit = 1600 samples * 2 bytes

    def __init__(self):
        self._ws: websockets.WebSocketClientProtocol | None = None
        self._events: list[TimestampedEvent] = []
        self._receive_task: asyncio.Task | None = None
        self._event_waiters: list[tuple[str, asyncio.Event, list]] = []
        self._connected = False

    async def connect(
        self,
        ws_url: str,
        token: str | None = None,
        session_config: dict | None = None,
        timeout: float = 15.0,
    ) -> TimestampedEvent:
        """连接 WebSocket 并等待 session.created

        Args:
            ws_url: WebSocket URL
            token: API Key（Bearer token）
            session_config: 可选的 session.update 配置
            timeout: 连接超时

        Returns:
            session.created 事件
        """
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        self._ws = await asyncio.wait_for(
            websockets.connect(ws_url, extra_headers=headers, max_size=10 * 1024 * 1024),
            timeout=timeout,
        )
        self._connected = True
        self._events.clear()

        # 启动后台事件接收
        self._receive_task = asyncio.create_task(self._receive_loop())

        # 等待 session.created
        session_created = await self.wait_for_event("session.created", timeout=timeout)

        # 可选发送 session.update
        if session_config:
            await self._send({
                "type": "session.update",
                "session": session_config,
            })
            await self.wait_for_event("session.updated", timeout=10.0)

        return session_created

    async def _receive_loop(self):
        """后台持续接收事件"""
        try:
            async for message in self._ws:
                event = json.loads(message)
                ts_event = TimestampedEvent(
                    timestamp=time.monotonic(),
                    wall_time=time.time(),
                    event=event,
                )
                self._events.append(ts_event)
                logger.debug(f"[WS] Received: {event.get('type', 'unknown')}")

                # 唤醒等待者
                for event_type, waiter_event, result_list in self._event_waiters:
                    if ts_event.event_type == event_type:
                        result_list.append(ts_event)
                        waiter_event.set()
        except websockets.exceptions.ConnectionClosed:
            logger.info("[WS] Connection closed")
        except Exception as e:
            logger.error(f"[WS] Receive error: {e}")
        finally:
            self._connected = False

    async def _send(self, data: dict) -> None:
        """发送 JSON 消息"""
        if self._ws:
            await self._ws.send(json.dumps(data))

    async def wait_for_event(
        self,
        event_type: str,
        timeout: float = 10.0,
        predicate: Callable[[dict], bool] | None = None,
    ) -> TimestampedEvent:
        """等待指定类型的事件

        Args:
            event_type: 事件类型
            timeout: 超时时间
            predicate: 可选的事件过滤条件

        Returns:
            匹配的 TimestampedEvent

        Raises:
            asyncio.TimeoutError: 超时
        """
        # 先检查已有事件
        for ev in self._events:
            if ev.event_type == event_type:
                if predicate is None or predicate(ev.event):
                    return ev

        # 注册等待
        waiter_event = asyncio.Event()
        result_list: list[TimestampedEvent] = []
        waiter = (event_type, waiter_event, result_list)
        self._event_waiters.append(waiter)

        try:
            deadline = time.monotonic() + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise asyncio.TimeoutError(
                        f"Timeout waiting for event '{event_type}' after {timeout}s"
                    )
                waiter_event.clear()
                await asyncio.wait_for(waiter_event.wait(), timeout=remaining)

                # 检查是否匹配
                for ev in result_list:
                    if predicate is None or predicate(ev.event):
                        return ev
                result_list.clear()
        finally:
            self._event_waiters.remove(waiter)

    async def wait_for_agent_state(
        self,
        state: str,
        timeout: float = 15.0,
    ) -> TimestampedEvent:
        """等待 agent 进入指定状态"""
        return await self.wait_for_event(
            "agent.state_changed",
            timeout=timeout,
            predicate=lambda e: e.get("state") == state,
        )

    async def inject_audio(
        self,
        pcm_data: bytes,
        chunk_ms: int = 100,
    ) -> tuple[float, float]:
        """注入 PCM 音频，按 chunk_ms 分帧发送

        Args:
            pcm_data: 原始 PCM 16kHz/16bit 数据
            chunk_ms: 每帧时长（毫秒）

        Returns:
            (t_first_chunk, t_last_chunk) monotonic 时间戳
        """
        chunk_bytes = int(16000 * (chunk_ms / 1000) * 2)
        t_first = None
        t_last = None

        for offset in range(0, len(pcm_data), chunk_bytes):
            chunk = pcm_data[offset:offset + chunk_bytes]
            audio_b64 = base64.b64encode(chunk).decode('ascii')

            now = time.monotonic()
            if t_first is None:
                t_first = now
            t_last = now

            await self._send({
                "type": "input_audio_buffer.append",
                "audio": audio_b64,
            })
            await asyncio.sleep(chunk_ms / 1000)

        return (t_first or time.monotonic(), t_last or time.monotonic())

    async def inject_silence(self, duration_s: float, chunk_ms: int = 100) -> None:
        """注入静音（实际发送零值 PCM）"""
        chunk_bytes = int(16000 * (chunk_ms / 1000) * 2)
        total_bytes = int(16000 * duration_s * 2)

        for offset in range(0, total_bytes, chunk_bytes):
            size = min(chunk_bytes, total_bytes - offset)
            audio_b64 = base64.b64encode(b'\x00' * size).decode('ascii')
            await self._send({
                "type": "input_audio_buffer.append",
                "audio": audio_b64,
            })
            await asyncio.sleep(chunk_ms / 1000)

    async def send_cancel(self) -> float:
        """发送 response.cancel，返回发送时间戳"""
        t = time.monotonic()
        await self._send({"type": "response.cancel"})
        return t

    async def drain_events(self, timeout: float = 5.0) -> list[TimestampedEvent]:
        """等待一段时间收集所有事件"""
        t_start = len(self._events)
        await asyncio.sleep(timeout)
        return self._events[t_start:]

    async def disconnect(self) -> None:
        """断开连接"""
        if self._receive_task:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                pass
        if self._ws:
            await self._ws.close()
            self._ws = None
        self._connected = False

    # ========== 事件查询 API ==========

    def get_events(self, event_type: str | None = None) -> list[TimestampedEvent]:
        """获取已收集的事件，可按类型过滤"""
        if event_type is None:
            return list(self._events)
        return [e for e in self._events if e.event_type == event_type]

    def get_last_event(self, event_type: str) -> TimestampedEvent | None:
        """获取指定类型的最后一个事件"""
        for e in reversed(self._events):
            if e.event_type == event_type:
                return e
        return None

    def has_event(self, event_type: str) -> bool:
        """是否有指定类型的事件"""
        return any(e.event_type == event_type for e in self._events)

    def count_events(self, event_type: str) -> int:
        """统计指定类型事件数量"""
        return sum(1 for e in self._events if e.event_type == event_type)

    def has_event_after(
        self,
        event_type: str,
        after_time: float,
        predicate: Callable[[dict], bool] | None = None,
    ) -> bool:
        """在指定时间之后是否有匹配的事件"""
        for e in self._events:
            if e.timestamp > after_time and e.event_type == event_type:
                if predicate is None or predicate(e.event):
                    return True
        return False

    def get_event_time_after(
        self,
        event_type: str,
        after_time: float,
    ) -> float | None:
        """获取指定时间之后某类型事件的时间戳"""
        for e in self._events:
            if e.timestamp > after_time and e.event_type == event_type:
                return e.timestamp
        return None

    def get_last_event_time(self, event_type: str) -> float | None:
        """获取指定类型最后一个事件的时间戳"""
        ev = self.get_last_event(event_type)
        return ev.timestamp if ev else None

    def clear_events(self) -> None:
        """清除已收集的所有事件"""
        self._events.clear()

    @property
    def is_connected(self) -> bool:
        return self._connected

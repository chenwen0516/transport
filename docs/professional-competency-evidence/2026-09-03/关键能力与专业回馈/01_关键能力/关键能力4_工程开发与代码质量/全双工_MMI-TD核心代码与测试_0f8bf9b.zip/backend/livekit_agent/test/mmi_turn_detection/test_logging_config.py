from __future__ import annotations

import logging
from types import SimpleNamespace

from mmi_turn_detection.logging_config import configure_mmi_logging

_HANDLER_MARKER = "_mmi_turn_detection_handler"


def config(path, *, enabled=True, to_console=False):
    return SimpleNamespace(
        log_file_enabled=enabled,
        log_file=str(path),
        log_level="INFO",
        log_to_console=to_console,
    )


def test_mmi_child_loggers_write_to_dedicated_file_without_propagation(tmp_path):
    path = tmp_path / "mmi.log"
    resolved = configure_mmi_logging(config(path))

    logging.getLogger("health-agent.mmi.runtime").info("runtime decision")
    logging.getLogger("health-agent.mmi.eou").warning("eou timeout")
    for handler in logging.getLogger("health-agent.mmi").handlers:
        handler.flush()

    content = resolved.read_text(encoding="utf-8")
    assert resolved.parent == path.parent.resolve()
    assert resolved.name.startswith("mmi_")
    assert resolved.suffix == ".log"
    assert "runtime decision" in content
    assert "eou timeout" in content
    assert logging.getLogger("health-agent.mmi").propagate is False

    configure_mmi_logging(config(path, enabled=False))


def test_reconfigure_replaces_existing_mmi_file_handler(tmp_path):
    path = tmp_path / "mmi.log"
    cfg = config(path)

    configure_mmi_logging(cfg)
    configure_mmi_logging(cfg)

    logger = logging.getLogger("health-agent.mmi")
    mmi_handlers = [
        handler for handler in logger.handlers if getattr(handler, _HANDLER_MARKER, False)
    ]
    assert len(mmi_handlers) == 1

    configure_mmi_logging(config(path, enabled=False))
    assert not any(getattr(handler, _HANDLER_MARKER, False) for handler in logger.handlers)

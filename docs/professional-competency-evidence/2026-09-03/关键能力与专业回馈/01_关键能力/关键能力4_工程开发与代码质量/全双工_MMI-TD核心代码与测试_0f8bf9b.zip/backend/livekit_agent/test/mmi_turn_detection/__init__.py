"""MMI-TD unit tests."""

"""Controlled access to LiveKit's MultilingualModel EOU prediction."""

from __future__ import annotations

import asyncio
import logging

from livekit.agents import AgentSession
from livekit.agents.language import LanguageCode
from livekit.plugins.turn_detector.multilingual import MultilingualModel

logger = logging.getLogger("health-agent.mmi.eou")


class EOUService:
    def __init__(self, *, timeout_ms: int = 200) -> None:
        self._model = MultilingualModel()
        self._timeout_s = timeout_ms / 1000

    async def predict(
        self,
        session: AgentSession,
        *,
        text: str,
        locale: str,
    ) -> tuple[float | None, float | None]:
        if not text.strip():
            return None, None

        chat_ctx = session.history.copy()
        chat_ctx.add_message(role="user", content=text.strip())
        language = LanguageCode(locale)

        try:
            probability, threshold = await asyncio.wait_for(
                asyncio.gather(
                    self._model.predict_end_of_turn(chat_ctx, timeout=self._timeout_s),
                    self._model.unlikely_threshold(language),
                ),
                timeout=self._timeout_s,
            )
            return probability, threshold
        except asyncio.TimeoutError:
            logger.warning("[MMI-TD] EOU prediction timed out")
        except Exception:
            logger.exception("[MMI-TD] EOU prediction failed")
        return None, None

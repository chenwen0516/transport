#!/usr/bin/env python3
"""验证 VAD 对齐注册是否消除强背景误锁。

对强背景录音，用 sync-executor 回放 SpeakerGate（VAD off vs on），记录每帧放行/静音，
再用 silero VAD 量度放行帧 vs 静音帧的语音性：
  · 误锁(C=背景)：静音帧更像语音（删用户）。
  · 正确(C=用户)：放行帧更像语音；或干脆不锁(全放行 fail-open，至少不删用户)。
"""
from __future__ import annotations
import wave
import numpy as np
import onnxruntime as ort
from concurrent.futures import Future
from types import SimpleNamespace
from livekit import rtc

from _bootstrap import ensure_livekit_agent_path

ensure_livekit_agent_path()
from audio_filter import SpeakerGate, CampplusEmbedder

CAMPP = "model/pretrained/campplus_sv_zh-cn_16k-common.onnx"
VAD = ".venv/lib/python3.12/site-packages/livekit/plugins/silero/resources/silero_vad.onnx"
SR16 = 16000
C = 512

SESSIONS = {
    "152517 强背景(原误锁)": "tmp/audio_raw_input_health-voice-79-1781767506_20260618_152517.wav",
    "104824 强背景(原误锁)": "tmp/audio_raw_input_health-voice-79-1781750893_20260618_104824.wav",
    "173826 强背景(原误锁)": None,  # 自动按时间戳找
    "160955 干净(原正确)":   "tmp/audio_raw_input_health-voice-79-1781770187_20260618_160955.wav",
}


class Sync:
    def submit(self, fn, *a, **k):
        f = Future()
        try:
            f.set_result(fn(*a, **k))
        except Exception as e:
            f.set_exception(e)
        return f
    def shutdown(self, *a, **k):
        pass


def read(p):
    with wave.open(p, "rb") as w:
        sr, ch = w.getframerate(), w.getnchannels()
        d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    return (d[::ch] if ch > 1 else d), sr


def to16(x, sr):
    if sr == SR16:
        return x.astype(np.float32)
    t = int(len(x) * SR16 / sr)
    return np.interp(np.linspace(0, len(x), t, endpoint=False), np.arange(len(x)), x).astype(np.float32)


def cfg(vad_on):
    return SimpleNamespace(
        enabled=True, debug=False, target_sr=SR16, min_energy=50.0, window_sec=3.0,
        decision_min_sec=1.5, segment_gap_sec=0.5, barge_in_decision_sec=1.0, barge_in_target_min=0.30,
        early_mute_sim=0.0, reheal_after_silences=5, reheal_count_early_mute=False,
        enroll_min_seg_ms=1500, enroll_segments=2, enroll_consist_min=0.45,
        enroll_use_hnr=False, hnr_threshold=0.35, theta_close=0.35,
        enroll_use_vad=vad_on, vad_model_path=VAD, vad_speech_threshold=0.5, vad_min_speech_sec=0.6,
    )


def replay(raw, sr, vad_on):
    """回放 gate，返回每 20ms 帧的 (raw_rms, out_rms) 与是否锁定。"""
    emb = CampplusEmbedder(CAMPP)
    g = SpeakerGate(cfg(vad_on), emb)
    g._executor = Sync()
    fl = int(sr * 0.02)
    n = (len(raw) // fl) * fl
    rr, oo = [], []
    for chunk in raw[:n].reshape(-1, fl):
        out = g.filter(rtc.AudioFrame(data=chunk.tobytes(), sample_rate=sr, num_channels=1, samples_per_channel=fl))
        o = np.frombuffer(out.data, dtype=np.int16)
        rr.append(float(np.sqrt(np.mean(chunk.astype(np.float64) ** 2))))
        oo.append(float(np.sqrt(np.mean(o.astype(np.float64) ** 2))) if o.size else 0.0)
    return np.array(rr), np.array(oo), (g.stats["state"] == "locked")


def vad_speechness(raw16):
    sess = ort.InferenceSession(VAD, providers=["CPUExecutionProvider"])
    st = np.zeros((2, 1, 128), np.float32)
    srt = np.array(SR16, np.int64)
    m = (len(raw16) // C) * C
    p = []
    for i in range(0, m, C):
        o, st = sess.run(["output", "stateN"], {"input": (raw16[i:i + C] / 32768.0).astype(np.float32)[None], "state": st, "sr": srt})
        p.append(float(o[0, 0]))
    return np.array(p)


def mislock_metric(raw, sr, rr, oo):
    """把 20ms 帧的 pass/silence 对齐到 512-chunk VAD，算放行/静音语音性。"""
    raw16 = to16(raw, sr)
    vad = vad_speechness(raw16)
    # 20ms 帧 → 秒，512chunk → 秒，统一到 chunk 网格
    nchunk = len(vad)
    fl_sec = 0.02
    ch_sec = C / SR16
    passed_sp, silenced_sp = [], []
    for ci in range(nchunk):
        t = ci * ch_sec
        fi = int(t / fl_sec)
        if fi >= len(rr):
            break
        if rr[fi] < 50.0:
            continue  # 非有声帧不计
        if oo[fi] >= 50.0:
            passed_sp.append(vad[ci])
        elif oo[fi] < 5.0:
            silenced_sp.append(vad[ci])
    ps = np.array(passed_sp)
    ss = np.array(silenced_sp)
    pv = float((ps >= 0.5).mean()) if len(ps) else None
    sv = float((ss >= 0.5).mean()) if len(ss) else None
    return pv, sv, len(ss)


def main():
    import glob, re
    for label, path in SESSIONS.items():
        if path is None:
            ts = re.search(r"(\d{6})", label).group(1)
            cands = glob.glob(f"tmp/audio_raw_input_*_*{ts}.wav")
            if not cands:
                print(f"● {label}: 找不到录音，跳过"); continue
            path = cands[0]
        raw, sr = read(path)
        print(f"\n● {label}")
        for vad_on in (False, True):
            rr, oo, locked = replay(raw, sr, vad_on)
            pv, sv, nsil = mislock_metric(raw, sr, rr, oo)
            tag = "VAD-ON " if vad_on else "VAD-OFF"
            if nsil < 20:
                print(f"  {tag}: locked={locked} 静音帧少({nsil})→近全放行(不删用户) ✅")
            else:
                pvs = f"{pv:.0%}" if pv is not None else "NA"
                verdict = "❌误锁(删用户)" if (sv or 0) > (pv or 0) + 0.05 else "✅正确(留用户)" if (pv or 0) > (sv or 0) + 0.05 else "⚠️不明"
                print(f"  {tag}: locked={locked} 放行语音性={pvs} 静音语音性={sv:.0%} 静音帧={nsil}  {verdict}")


if __name__ == "__main__":
    main()

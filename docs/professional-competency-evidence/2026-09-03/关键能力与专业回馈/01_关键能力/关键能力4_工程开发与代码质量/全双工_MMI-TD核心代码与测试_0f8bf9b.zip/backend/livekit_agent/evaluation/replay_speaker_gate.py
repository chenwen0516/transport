#!/usr/bin/env python3
"""SpeakerGate 离线回放对比工具。

把一段 raw 录音逐帧喂进真实 SpeakerGate（真 CAM++ embedder），统计：
锁定的音频时刻、注册候选/HNR 拒绝数、静音段数、early-mute 数、实际移除时长。
用同一条录音跑「改前 baseline」与「改后」两套配置，直接量化优化效果。

用法：
    .venv/bin/python evaluation/replay_speaker_gate.py tmp/audio_raw_input_xxx.wav
依赖：onnxruntime + kaldi_native_fbank + SPEAKER_GATE_MODEL_PATH 指向的 .onnx。
"""

from __future__ import annotations

import logging
import os
import sys
import wave
from concurrent.futures import Future
from types import SimpleNamespace

import numpy as np
from livekit import rtc

from _bootstrap import ensure_livekit_agent_path

ensure_livekit_agent_path()
from audio_filter import SpeakerGate, CampplusEmbedder, SPEAKER_GATE_LOGGER_NAME

MODEL = os.getenv("SPEAKER_GATE_MODEL_PATH", "model/pretrained/campplus_sv_zh-cn_16k-common.onnx")
FRAME_MS = 20


def _read_wav(path: str) -> tuple[np.ndarray, int]:
    with wave.open(path, "rb") as w:
        sr, ch = w.getframerate(), w.getnchannels()
        data = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    if ch > 1:
        data = data[::ch]
    return data, sr


class _SyncExecutor:
    """同步 executor：submit 立即跑完并回调，使回放完全确定、锁定时刻精确对齐音频。"""

    def submit(self, fn, *a, **k):
        f: Future = Future()
        try:
            f.set_result(fn(*a, **k))
        except Exception as e:  # noqa: BLE001
            f.set_exception(e)
        return f

    def shutdown(self, *a, **k) -> None:
        pass


class _Capture(logging.Handler):
    """抓 SpeakerGate debug 日志做计数（HNR 拒绝 / early-mute）。"""

    def __init__(self) -> None:
        super().__init__(level=logging.DEBUG)
        self.lines: list[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.lines.append(record.getMessage())

    def count(self, needle: str) -> int:
        return sum(1 for ln in self.lines if needle in ln)

    def hnr_peaks(self) -> list[float]:
        import re
        out = []
        for ln in self.lines:
            m = re.search(r"enroll HNR gate: peak=([\d.]+)", ln)
            if m:
                out.append(float(m.group(1)))
        return out


def replay_frames(wav: np.ndarray, sr: int, gate, frame_ms: int = FRAME_MS) -> tuple[list[tuple[float, float, float]], float | None]:
    """逐帧把 wav 喂进**已构造**的 SpeakerGate（同步确定性回放），返回：

      - trace: [(t_sec, in_rms, out_rms)]，每 20ms 一帧（按 frame_ms）。
      - lock_sec: 首次进入 locked 的音频时刻（None=全程未锁）。

    复用同步 executor → 锁定时刻精确对齐音频。注意 gate.filter 只在 audio_mode=='mute'
    时返回静音帧（shadow 模式恒等返回原帧），故 out_rms 反映静音需 cfg.audio_mode='mute'。
    """
    gate._executor = _SyncExecutor()  # 同步推理 → 确定性回放
    fl = int(sr * frame_ms / 1000)
    n = (len(wav) // fl) * fl
    frames = wav[:n].reshape(-1, fl)
    trace: list[tuple[float, float, float]] = []
    lock_sec: float | None = None
    for i, chunk in enumerate(frames):
        fr = rtc.AudioFrame(
            data=chunk.tobytes(), sample_rate=sr,
            num_channels=1, samples_per_channel=fl,
        )
        out = gate.filter(fr)
        in_rms = float(np.sqrt(np.mean(chunk.astype(np.float64) ** 2)))
        out_arr = np.frombuffer(out.data, dtype=np.int16)
        out_rms = float(np.sqrt(np.mean(out_arr.astype(np.float64) ** 2))) if out_arr.size else 0.0
        trace.append((round(i * frame_ms / 1000, 3), in_rms, out_rms))
        if lock_sec is None and gate.stats["state"] == "locked":
            lock_sec = round(i * frame_ms / 1000, 1)
    return trace, lock_sec


def base_cfg(**over) -> SimpleNamespace:
    cfg = dict(
        enabled=True, debug=True, target_sr=16000, min_energy=50.0,
        window_sec=3.0, decision_min_sec=1.5, segment_gap_sec=0.5,
        barge_in_decision_sec=1.0, barge_in_target_min=0.18,
        early_mute_sim=0.0, reheal_after_silences=5,
        enroll_min_seg_ms=1500, enroll_segments=2, enroll_consist_min=0.35,
        enroll_use_hnr=False, hnr_threshold=0.35, theta_close=0.30,
        reheal_count_early_mute=False,
    )
    cfg.update(over)
    return SimpleNamespace(**cfg)


def run(wav: np.ndarray, sr: int, cfg: SimpleNamespace, label: str, embedder=None) -> dict:
    lg = logging.getLogger(SPEAKER_GATE_LOGGER_NAME)
    lg.setLevel(logging.DEBUG)
    cap = _Capture()
    lg.addHandler(cap)
    try:
        if embedder is None:
            embedder = CampplusEmbedder(MODEL, target_sr=cfg.target_sr)
        gate = SpeakerGate(cfg, embedder)
        trace, lock_sec = replay_frames(wav, sr, gate)
        voiced_in = silenced_out = 0
        for _t, in_rms, out_rms in trace:
            if in_rms >= 50.0:
                voiced_in += 1
                if out_rms < 5.0:
                    silenced_out += 1
        st = gate.stats
        if lock_sec is None and st["state"] == "locked":
            lock_sec = round(len(trace) * FRAME_MS / 1000, 1)
        frame_sec = FRAME_MS / 1000.0
        return {
            "label": label,
            "locked": st["state"] == "locked",
            "lock_audio_sec": lock_sec,
            "enroll_hnr_admit": cap.count("→ ADMIT"),
            "enroll_hnr_reject": cap.count("REJECT(far-field"),
            "enroll_inconsistent": cap.count("enroll inconsistent"),
            "early_mute": cap.count("EARLY-MUTE"),
            "segments_total": st["segments"],
            "segments_silenced": st["segments_silenced"],
            "reheal": st["reheal_count"],
            "voiced_in_sec": round(voiced_in * frame_sec, 1),
            "gate_removed_sec": round(silenced_out * frame_sec, 1),
            "removed_ratio_of_voiced": round(silenced_out / voiced_in, 3) if voiced_in else None,
            "hnr_peaks": [round(p, 3) for p in cap.hnr_peaks()],
        }
    finally:
        lg.removeHandler(cap)


def main() -> None:
    if len(sys.argv) < 2:
        print("usage: replay_speaker_gate.py <raw.wav>")
        return
    path = sys.argv[1]
    wav, sr = _read_wav(path)
    print(f"录音: {os.path.basename(path)}  {len(wav)/sr:.1f}s @ {sr}Hz\n")

    variants = {
        "BEFORE": base_cfg(),                                          # 现状：early_mute=0, reheal=5
        # 旧行为：early_mute 计入 reheal → 强背景下自我解锁（问题复现）
        "EM_COUPLED": base_cfg(early_mute_sim=0.20, reheal_count_early_mute=True),
        # 解耦后（本次修复，默认）：early_mute 不计入 reheal，reheal 仍由整段判决驱动
        "EM_DECOUPLED": base_cfg(early_mute_sim=0.20, reheal_count_early_mute=False),
    }
    results = {name: run(wav, sr, cfg, name) for name, cfg in variants.items()}

    keys = [
        ("locked", "锁定成功"), ("lock_audio_sec", "锁定音频时刻(s)"),
        ("enroll_hnr_admit", "HNR放行注册段"), ("enroll_hnr_reject", "HNR拒绝注册段"),
        ("enroll_inconsistent", "注册一致性失败次数"),
        ("early_mute", "early-mute 次数"),
        ("segments_total", "判决段数"), ("segments_silenced", "静音段数"),
        ("gate_removed_sec", "实际移除语音(s)"), ("removed_ratio_of_voiced", "移除占有声比"),
        ("reheal", "reheal 次数"),
    ]
    names = list(variants.keys())
    hdr = f"{'指标':<20}" + "".join(f"{n:>12}" for n in names)
    print(hdr)
    print("-" * len(hdr))
    for k, name in keys:
        row = f"{name:<18}" + "".join(f"{str(results[n][k]):>12}" for n in names)
        print(row)


if __name__ == "__main__":
    main()

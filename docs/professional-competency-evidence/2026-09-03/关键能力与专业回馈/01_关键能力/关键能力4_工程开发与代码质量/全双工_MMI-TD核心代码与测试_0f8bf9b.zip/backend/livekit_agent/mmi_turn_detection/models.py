"""Core input, output, and state models for MMI-TD."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any


class MMIMode(str, Enum):
    OFF = "off"
    SHADOW = "shadow"
    ACTIVE = "active"


class MMITurnAction(str, Enum):
    CONTINUE_LISTENING = "CONTINUE_LISTENING"
    START_SPEAKING = "START_SPEAKING"
    START_LISTENING = "START_LISTENING"
    CONTINUE_SPEAKING = "CONTINUE_SPEAKING"


class MMIConfidenceLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class MMISpeakerGateState(str, Enum):
    TARGET_CONFIDENT = "TARGET_CONFIDENT"
    TARGET_WEAK = "TARGET_WEAK"
    NON_TARGET = "NON_TARGET"
    UNKNOWN = "UNKNOWN"


class MMIRuntimeState(str, Enum):
    IDLE = "IDLE"
    USER_SPEAKING = "USER_SPEAKING"
    USER_PAUSING = "USER_PAUSING"
    AGENT_SPEAKING = "AGENT_SPEAKING"
    OBSERVING_INTERRUPTION = "OBSERVING_INTERRUPTION"
    WAITING_USER = "WAITING_USER"
    TURN_COMMITTED = "TURN_COMMITTED"
    FAIL_SAFE = "FAIL_SAFE"


@dataclass(frozen=True)
class MMITurnContext:
    session_id: str
    turn_id: int
    event_id: int

    agent_state: str = "idle"
    user_state: str = "listening"
    tts_playing: bool = False
    awaiting_confirmation: bool = False

    vad_speech: bool = False
    speech_ms: int = 0
    transcript_observe_ms: int = 0
    silence_ms: int = 0

    partial_text: str = ""
    final_text: str = ""
    latest_transcript_text: str = ""
    transcript_hypotheses: tuple[str, ...] = ()
    stt_confidence: float | None = None

    # 前端 NoiseGate 经数据通道送来的连续语音置信度（高=前景语音，低=背景/安静）。
    # None 表示无信号（如 WebRTC 无数据 / 过期）→ 所有消费方 fail-open 退回原行为。
    external_voice_confidence: float | None = None
    external_voice_energy_db: float | None = None
    external_voice_stale: bool = False

    # agent 端 SpeakerGate（CAM++ 声纹）对"当前说话段"是否为目标说话人的判决。
    # True=目标 / False=背景(非目标) / None=无信号(未锁定/未判/过期) → 消费方 fail-open。
    external_speaker_is_target: bool | None = None
    external_speaker_state: str | None = None
    external_speaker_similarity: float | None = None
    external_speaker_verdict_kind: str | None = None
    # True=SpeakerGate 已锁定主说话人 / False=正在注册 / None=无 SpeakerGate 信号。
    external_speaker_gate_locked: bool | None = None
    # 当前 MMI 用户轮次内见过的完整段声纹判决。用于避免长句 endpointing 时短 TTL 过期。
    turn_speaker_is_target: bool | None = None
    turn_speaker_state: str | None = None
    turn_speaker_similarity: float | None = None
    turn_speaker_verdict_kind: str | None = None
    turn_speaker_age_ms: int | None = None

    eou_prob: float | None = None
    eou_unlikely_threshold: float | None = None

    last_user_text: str = ""
    last_agent_text: str = ""

    wait_intent_active: bool = False
    wait_intent_consumed_text: str = ""
    user_turn_active: bool = False
    started_during_agent_thinking: bool = False
    started_during_agent_speaking: bool = False
    started_before_speaker_gate_locked: bool = False
    turn_started_after_previous_speech_ms: int | None = None
    locale: str = "zh-CN"

    @property
    def transcript_text(self) -> str:
        return " ".join(part for part in (self.final_text, self.partial_text) if part).strip()


@dataclass(frozen=True)
class MMITurnDecision:
    action: MMITurnAction
    confidence: float
    confidence_level: MMIConfidenceLevel
    reason: str

    eou_prob: float | None = None
    barge_in_score: float | None = None
    backchannel_score: float | None = None

    wait_intent: bool = False
    ignore_input: bool = False
    observe_more_ms: int = 0
    pattern_version: str = ""
    matched_rule: str = ""
    matched_pattern: str = ""

    turn_id: int = 0
    based_on_event_id: int = 0

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["action"] = self.action.value
        data["confidence_level"] = self.confidence_level.value
        return data

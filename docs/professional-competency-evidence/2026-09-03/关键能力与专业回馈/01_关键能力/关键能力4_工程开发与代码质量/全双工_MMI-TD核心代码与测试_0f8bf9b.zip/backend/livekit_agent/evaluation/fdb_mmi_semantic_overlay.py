#!/usr/bin/env python3
"""Replay a conservative semantic correction layer over logged MMI decisions."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from evaluation.fdb_mmi_semantic import (
    CachedSemanticDetector,
    has_explicit_interrupt_cue,
    load_cache,
    semantic_request_for_event,
)
from evaluation.run_fdb_mmi_replay import (
    DetectorPrediction,
    LoggedMMIBaseline,
    ReplayContext,
    ReplayInput,
    StreamingReplayDetector,
    TargetState,
    run_replay,
    write_report,
)

POLICY_VERSION = "2026-07-23.semantic-overlay-v4-frozen"

_OVERLAY_CUE_PATTERNS = (
    re.compile(r"\bjust a minute\b", re.IGNORECASE),
    re.compile(r"^\s*either way\b.*\?", re.IGNORECASE),
)
_DIRECT_INTERACTION_PATTERN = re.compile(
    r"^\s*(?:oh[\s,]+)?(?:can|could|would|will|do|does|did|is|are|am|"
    r"what|when|where|why|how|who|please|tell|show|remind|set|turn|"
    r"stop|wait|hold)\b",
    re.IGNORECASE,
)


def has_overlay_interrupt_cue(hypothesis_history: tuple[str, ...]) -> bool:
    if has_explicit_interrupt_cue(hypothesis_history):
        return True
    texts = (*hypothesis_history, " ".join(hypothesis_history))
    return any(
        pattern.search(text)
        for text in texts
        for pattern in _OVERLAY_CUE_PATTERNS
    )


def looks_like_direct_interaction(text: str) -> bool:
    return bool("?" in text or _DIRECT_INTERACTION_PATTERN.search(text))


def interrupt_suppression_state(
    predictions: list[DetectorPrediction],
    transcript: str,
) -> TargetState | None:
    decisive = [
        prediction
        for prediction in predictions
        if prediction.state != TargetState.UNCERTAIN
    ]
    if not decisive:
        return None
    first = decisive[0]
    if (
        first.state == TargetState.ADDRESSED_OTHER
        and first.confidence >= 0.8
    ):
        return TargetState.ADDRESSED_OTHER
    if decisive[-1].state == TargetState.BACKCHANNEL:
        return TargetState.BACKCHANNEL
    if (
        not looks_like_direct_interaction(transcript)
        and not any(
            prediction.state == TargetState.INTERRUPT
            for prediction in decisive
        )
        and not has_overlay_interrupt_cue(
            tuple(
                str(prediction.metadata.get("transcript") or "")
                for prediction in decisive
            )
        )
    ):
        return TargetState.CONTINUE
    return None


class LoggedMMISemanticOverlay:
    """Keep logged MMI as primary control and apply narrow semantic corrections."""

    name = POLICY_VERSION

    def __init__(
        self,
        cache: dict[str, Any],
        *,
        min_confidence: float = 0.8,
        partial_confirmations: int = 2,
    ) -> None:
        self._semantic = CachedSemanticDetector(
            cache,
            min_confidence=min_confidence,
            partial_confirmations=partial_confirmations,
        )
        self._logged = LoggedMMIBaseline()
        self._semantic_predictions: list[DetectorPrediction] = []
        self._overlay_cue_streak = 0
        self._partial_confirmations = partial_confirmations

    def reset(self, sample: dict[str, Any]) -> None:
        self._semantic.reset(sample)
        self._logged.reset(sample)
        self._semantic_predictions = []
        self._overlay_cue_streak = 0

    def observe(
        self,
        event: ReplayInput,
        context: ReplayContext,
    ) -> DetectorPrediction | None:
        if event.kind == "asr":
            semantic = self._semantic.observe(event, context)
            if semantic is None:
                return None
            request = semantic_request_for_event(
                {
                    "sample": context.sample,
                    "scenario": "",
                },
                event,
                context,
            )
            metadata = {
                **semantic.metadata,
                "transcript": str(event.payload.get("text") or ""),
            }
            semantic = DetectorPrediction(
                state=semantic.state,
                relative_ms=semantic.relative_ms,
                confidence=semantic.confidence,
                reason=semantic.reason,
                source=self.name,
                metadata=metadata,
            )
            self._semantic_predictions.append(semantic)
            history = (
                request.hypothesis_history if request is not None else ()
            )
            cue = (
                semantic.state != TargetState.ADDRESSED_OTHER
                and has_overlay_interrupt_cue(history)
            )
            if not cue:
                self._overlay_cue_streak = 0
                return None
            self._overlay_cue_streak += 1
            is_final = bool(event.payload.get("is_final"))
            if (
                not is_final
                and self._overlay_cue_streak < self._partial_confirmations
            ):
                return None
            return DetectorPrediction(
                state=TargetState.INTERRUPT,
                relative_ms=event.relative_ms,
                confidence=max(semantic.confidence, 0.95),
                reason="overlay_explicit_floor_taking_or_redirect_cue",
                source=self.name,
                metadata={
                    "semantic_state": semantic.state.value,
                    "overlay_cue": True,
                    "is_final": is_final,
                    "transcript": str(event.payload.get("text") or ""),
                },
            )

        logged = self._logged.observe(event, context)
        if logged is None or logged.state != TargetState.INTERRUPT:
            return logged
        suppression = interrupt_suppression_state(
            self._semantic_predictions,
            context.latest_asr,
        )
        if suppression is None:
            return DetectorPrediction(
                state=logged.state,
                relative_ms=logged.relative_ms,
                confidence=logged.confidence,
                reason=logged.reason,
                source=self.name,
                metadata={
                    **logged.metadata,
                    "overlay_action": "keep_logged_interrupt",
                },
            )
        return DetectorPrediction(
            state=suppression,
            relative_ms=logged.relative_ms,
            confidence=0.9,
            reason=f"overlay_suppress_logged_interrupt:{suppression.value.lower()}",
            source=self.name,
            metadata={
                **logged.metadata,
                "overlay_action": "suppress_logged_interrupt",
                "overlay_state": suppression.value,
            },
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Replay the semantic correction layer over logged MMI"
    )
    parser.add_argument("manifest", type=Path)
    parser.add_argument("cache", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--frame-ms", type=int, default=200)
    parser.add_argument(
        "--audio-source",
        choices=["raw_input", "stt_input"],
        default="stt_input",
    )
    parser.add_argument("--min-confidence", type=float, default=0.8)
    parser.add_argument("--partial-confirmations", type=int, default=2)
    args = parser.parse_args()

    cache = load_cache(args.cache)
    detector: StreamingReplayDetector = LoggedMMISemanticOverlay(
        cache,
        min_confidence=args.min_confidence,
        partial_confirmations=args.partial_confirmations,
    )
    summary, results = run_replay(
        args.manifest,
        detector,
        frame_ms=args.frame_ms,
        audio_source=args.audio_source,
    )
    summary["semantic_cache"] = cache["summary"]
    summary["overlay_policy_version"] = POLICY_VERSION
    summary["min_confidence"] = args.min_confidence
    summary["partial_confirmations"] = args.partial_confirmations
    write_report(args.output_dir, summary, results)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

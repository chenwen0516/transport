"""前端语音置信度（external_voice_confidence）消费的 fail-open 行为测试。

要点：
- 无信号(None)时行为与改动前完全一致（fail-open）。
- 低置信度先延迟观察"普通打断"，但不直接丢弃；观察到上限后放行有效文本。
- 低置信度 + 噪声文本可立即丢弃背景"嗯/啊"，但不影响正常完整语音的提交。
"""

from __future__ import annotations

from dataclasses import replace

import pytest

from mmi_turn_detection.detector import RuleBasedMMITurnDetector
from mmi_turn_detection.endpointing_policy import (
    BaselineEndpointingPolicy,
    EndpointingPolicyConfig,
)
from mmi_turn_detection.interruption_policy import (
    InterruptionPolicyConfig,
    RuleBasedInterruptionPolicy,
)
from mmi_turn_detection.models import MMITurnAction, MMITurnContext


@pytest.fixture
def detector() -> RuleBasedMMITurnDetector:
    return RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(min_delay_ms=500, max_delay_ms=3000)
        ),
    )


def context(**overrides) -> MMITurnContext:
    base = MMITurnContext(session_id="test", turn_id=1, event_id=1)
    return replace(base, **overrides)


# ---------- 打断侧：fail-open + 低置信度观察 ----------

ORDINARY_INTERRUPT = dict(
    agent_state="speaking",
    tts_playing=True,
    user_state="listening",
    speech_ms=0,
    transcript_observe_ms=650,
    partial_text="我想换一本",
)


@pytest.mark.asyncio
async def test_ordinary_interrupt_unchanged_without_signal(detector):
    decision = await detector.detect(context(**ORDINARY_INTERRUPT))
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_ordinary_interrupt_unchanged_with_high_confidence(detector):
    decision = await detector.detect(
        context(**ORDINARY_INTERRUPT, external_voice_confidence=0.9)
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_low_confidence_observes_ordinary_interrupt_when_speaker_unknown(detector):
    # 无声纹判决时，低置信度只延迟观察，避免 agent speaking 期间前端 gate
    # 短暂塌到 0 后把真实打断直接丢弃。
    decision = await detector.detect(
        context(**ORDINARY_INTERRUPT, external_voice_confidence=0.2)
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "low_voice_confidence_observe"
    assert decision.ignore_input is False
    assert decision.observe_more_ms == 150


@pytest.mark.asyncio
async def test_low_confidence_allows_ordinary_interrupt_after_observation(detector):
    decision = await detector.detect(
        context(
            **{
                **ORDINARY_INTERRUPT,
                "transcript_observe_ms": 850,
            },
            external_voice_confidence=0.2,
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_low_confidence_observes_stt_only_final_interrupt_when_speaker_unknown(detector):
    base = dict(
        agent_state="speaking",
        tts_playing=True,
        user_state="listening",
        vad_speech=False,
        speech_ms=0,
        transcript_observe_ms=304,
        final_text="清朝。",
    )
    high = await detector.detect(context(**base, external_voice_confidence=0.9))
    low = await detector.detect(context(**base, external_voice_confidence=0.2))
    assert high.action == MMITurnAction.START_LISTENING
    assert high.reason == "stt_only_final_interjection"
    assert low.action == MMITurnAction.CONTINUE_SPEAKING
    assert low.reason == "low_voice_confidence_observe"
    assert low.ignore_input is False
    assert low.observe_more_ms == 400


@pytest.mark.asyncio
async def test_low_confidence_allows_stt_only_final_interrupt_after_observation(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            vad_speech=False,
            speech_ms=0,
            transcript_observe_ms=850,
            final_text="清朝。",
            external_voice_confidence=0.2,
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "stt_only_final_interjection"


# ---------- 打断侧：SpeakerGate 声纹判决（negative-only 辅助）----------


@pytest.mark.asyncio
async def test_non_target_speaker_suppresses_ordinary_interrupt(detector):
    # SpeakerGate 判为背景(非目标) → 抑制打断，即使能量置信度高。
    decision = await detector.detect(
        context(**ORDINARY_INTERRUPT, external_voice_confidence=1.0,
                external_speaker_is_target=False,
                external_speaker_similarity=0.12)
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "non_target_speaker_suppressed"


@pytest.mark.asyncio
async def test_borderline_non_target_speaker_does_not_suppress_interrupt(detector):
    # 声纹 false 但 sim 只在灰区时 fail-open，避免把真用户短插话误杀。
    decision = await detector.detect(
        context(**ORDINARY_INTERRUPT, external_voice_confidence=1.0,
                external_speaker_is_target=False,
                external_speaker_state="NON_TARGET",
                external_speaker_similarity=0.24)
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_configured_non_target_threshold_suppresses_borderline_interrupt():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(
            InterruptionPolicyConfig(speaker_non_target_sim_max=0.35)
        ),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(min_delay_ms=500, max_delay_ms=3000)
        ),
    )
    decision = await detector.detect(
        context(
            **ORDINARY_INTERRUPT,
            external_voice_confidence=1.0,
            external_speaker_is_target=False,
            external_speaker_state="NON_TARGET",
            external_speaker_similarity=0.24,
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "non_target_speaker_suppressed"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_target_weak_state_is_observable_but_fail_open(detector):
    decision = await detector.detect(
        context(**ORDINARY_INTERRUPT, external_voice_confidence=1.0,
                external_speaker_is_target=None,
                external_speaker_state="TARGET_WEAK",
                external_speaker_similarity=0.24)
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_target_speaker_allows_interrupt_despite_low_energy_confidence(detector):
    # 声纹判为目标 → 放行打断，即使前端能量置信度塌成 0（agent 说话期常见）。
    decision = await detector.detect(
        context(**ORDINARY_INTERRUPT, external_voice_confidence=0.0,
                external_speaker_is_target=True)
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_strong_interrupt_not_suppressed_by_low_confidence(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            vad_speech=True,
            speech_ms=200,
            partial_text="等一下",
            external_voice_confidence=0.05,
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


# ---------- 提交侧：噪声轮提前丢弃 + 不误伤正常语音 ----------

NOISE_PENDING = dict(
    user_state="listening",
    silence_ms=500,  # 远未到 max_delay(3000)
    final_text="哎，嗯。",
)


@pytest.mark.asyncio
async def test_noise_turn_pending_unchanged_without_signal(detector):
    decision = await detector.detect(context(**NOISE_PENDING))
    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.reason == "invalid_or_noise_turn_pending"
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_low_confidence_discards_noise_turn_early(detector):
    decision = await detector.detect(
        context(**NOISE_PENDING, external_voice_confidence=0.2)
    )
    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.reason == "invalid_or_noise_low_voice_confidence"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_low_confidence_does_not_block_complete_speech(detector):
    # 完整正常问句即使置信度低也应正常提交（不走 noise 分支）。
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="今天天气怎么样",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
            external_voice_confidence=0.1,
        )
    )
    assert decision.action == MMITurnAction.START_SPEAKING

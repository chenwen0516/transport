"""Mutable per-session state used to build immutable detector contexts."""

from __future__ import annotations

import time
from dataclasses import dataclass

from .models import MMIRuntimeState, MMISpeakerGateState, MMITurnContext

# 语音置信度有效期：超过则视为过期、作废为 None（fail-open）。
_VOICE_CONFIDENCE_TTL_MS = 500
# SpeakerGate 说话人判决有效期：覆盖一次打断的观察窗（onset~判决），过期作废为 None。
_SPEAKER_VERDICT_TTL_MS = 1500
_MAX_TRANSCRIPT_HYPOTHESES = 12


@dataclass
class FinalTranscriptSegment:
    text: str
    target_confirmed: bool = False
    confirmed_by_verdict: bool = False
    speaker_segment_id: int | None = None


@dataclass
class MMITurnContextStore:
    session_id: str
    locale: str = "zh-CN"
    speaker_non_target_sim_max: float = 0.18

    turn_id: int = 0
    event_id: int = 0
    agent_speech_id: int = 0
    runtime_state: MMIRuntimeState = MMIRuntimeState.IDLE

    agent_state: str = "idle"
    user_state: str = "listening"
    awaiting_confirmation: bool = False

    partial_text: str = ""
    final_text: str = ""
    latest_transcript_text: str = ""
    transcript_hypotheses: list[str] | None = None
    final_segments: list[FinalTranscriptSegment] | None = None
    stt_confidence: float | None = None
    eou_prob: float | None = None
    eou_unlikely_threshold: float | None = None

    # 前端 NoiseGate 经数据通道送来的语音置信度（被动更新，不触发 next_event）。
    external_voice_confidence: float | None = None
    external_voice_energy_db: float | None = None
    external_voice_updated_at: float | None = None

    # agent 端 SpeakerGate 声纹判决（True=目标 / False=背景）+ 更新时刻。
    external_speaker_is_target: bool | None = None
    external_speaker_state: str | None = None
    external_speaker_similarity: float | None = None
    external_speaker_verdict_kind: str | None = None
    external_speaker_updated_at: float | None = None
    external_speaker_gate_locked: bool | None = None
    turn_speaker_is_target: bool | None = None
    turn_speaker_state: str | None = None
    turn_speaker_similarity: float | None = None
    turn_speaker_verdict_kind: str | None = None
    turn_speaker_updated_at: float | None = None
    current_speaker_segment_id: int | None = None
    turn_speaker_segment_id: int | None = None

    last_user_text: str = ""
    last_agent_text: str = ""
    wait_intent_active: bool = False
    wait_intent_consumed_text: str = ""

    committed: bool = False
    commit_pending: bool = False
    commit_requested_text: str = ""
    commit_attempt_count: int = 0
    user_turn_active: bool = False
    stt_started_without_vad: bool = False
    started_during_agent_thinking: bool = False
    started_during_agent_speaking: bool = False
    started_before_speaker_gate_locked: bool = False
    turn_started_after_previous_speech_ms: int | None = None
    interrupted_agent_speech_id: int | None = None
    consecutive_error_count: int = 0

    speech_started_at: float | None = None
    transcript_started_at: float | None = None
    silence_started_at: float | None = None
    last_user_stopped_at: float | None = None

    def next_event(self) -> int:
        self.event_id += 1
        return self.event_id

    def _start_new_turn(self) -> None:
        now = time.monotonic()
        self.turn_id += 1
        self.committed = False
        self.commit_pending = False
        self.commit_requested_text = ""
        self.commit_attempt_count = 0
        self.user_turn_active = True
        self.partial_text = ""
        self.final_text = ""
        self.latest_transcript_text = ""
        self.transcript_hypotheses = []
        self.final_segments = []
        self.eou_prob = None
        self.eou_unlikely_threshold = None
        self.turn_speaker_is_target = None
        self.turn_speaker_state = None
        self.turn_speaker_similarity = None
        self.turn_speaker_verdict_kind = None
        self.turn_speaker_updated_at = None
        self.turn_speaker_segment_id = None
        self.stt_started_without_vad = False
        self.started_during_agent_thinking = False
        self.started_during_agent_speaking = False
        self.started_before_speaker_gate_locked = self.external_speaker_gate_locked is False
        self.turn_started_after_previous_speech_ms = (
            max(0, int((now - self.last_user_stopped_at) * 1000))
            if self.last_user_stopped_at is not None
            else None
        )
        self.wait_intent_consumed_text = ""
        self.speech_started_at = now if self.user_state == "speaking" else None
        self.transcript_started_at = None
        self.silence_started_at = None

    def on_user_speaking(self, *, force_new_turn: bool = False) -> None:
        self.next_event()
        commit_in_flight = self.commit_pending
        self.commit_pending = False
        if self.user_state != "speaking":
            if (
                self.committed
                or commit_in_flight
                or (force_new_turn and not self.stt_started_without_vad)
            ):
                self._start_new_turn()
            if self.agent_state == "thinking":
                self.started_during_agent_thinking = True
            elif self.agent_state == "speaking":
                self.started_during_agent_speaking = True
        self.stt_started_without_vad = False
        self.user_state = "speaking"
        self.user_turn_active = True
        self.speech_started_at = time.monotonic()
        self.silence_started_at = None
        self.wait_intent_active = False
        self.runtime_state = MMIRuntimeState.USER_SPEAKING

    def on_user_listening(self, *, silence_offset_ms: int = 0) -> None:
        self.next_event()
        self.user_state = "listening"
        self.silence_started_at = time.monotonic() - max(0, silence_offset_ms) / 1000
        self.last_user_stopped_at = self.silence_started_at
        self.runtime_state = MMIRuntimeState.USER_PAUSING

    def ensure_listening_silence(self, *, silence_offset_ms: int = 0) -> None:
        if self.user_state != "speaking" and self.silence_started_at is None:
            self.silence_started_at = time.monotonic() - max(0, silence_offset_ms) / 1000

    def on_agent_state(self, state: str) -> None:
        self.next_event()
        previous = self.agent_state
        self.agent_state = state
        if state == "speaking":
            if previous != "speaking":
                self.agent_speech_id += 1
            self.runtime_state = MMIRuntimeState.AGENT_SPEAKING
        elif self.user_state == "speaking":
            self.runtime_state = MMIRuntimeState.USER_SPEAKING
        elif self.runtime_state != MMIRuntimeState.WAITING_USER:
            self.runtime_state = MMIRuntimeState.IDLE

    def consume_current_turn(self) -> None:
        self.next_event()
        self.committed = True
        self.commit_pending = False
        self.commit_requested_text = ""
        self.user_turn_active = False
        self.partial_text = ""
        self.final_text = ""
        self.latest_transcript_text = ""
        self.transcript_hypotheses = []
        self.final_segments = []
        self.eou_prob = None
        self.eou_unlikely_threshold = None
        self.turn_speaker_is_target = None
        self.turn_speaker_state = None
        self.turn_speaker_similarity = None
        self.turn_speaker_verdict_kind = None
        self.turn_speaker_updated_at = None
        self.turn_speaker_segment_id = None
        self.transcript_started_at = None
        self.stt_started_without_vad = False
        self.started_during_agent_thinking = False
        self.started_during_agent_speaking = False
        self.started_before_speaker_gate_locked = False
        self.wait_intent_consumed_text = ""

    def confirm_commit(self) -> None:
        self.next_event()
        self.committed = True
        self.commit_pending = False
        self.user_turn_active = False
        self.runtime_state = MMIRuntimeState.TURN_COMMITTED

    def on_transcript(self, text: str, *, is_final: bool) -> None:
        self.next_event()
        text = text.strip()
        if text:
            previous_transcript = self.transcript_text
            if text not in {self.partial_text, self.final_text, self.transcript_text}:
                self.commit_pending = False
            if self.committed:
                self._start_new_turn()
                previous_transcript = ""
            self.latest_transcript_text = self._latest_segment(previous_transcript, text)
            if self.agent_state == "thinking":
                # STT-only input may arrive without a VAD speaking event. Treat it
                # as a new user turn so Active mode can cancel the pending reply.
                self.started_during_agent_thinking = True
            if self.agent_state == "speaking" and self.user_state != "speaking":
                self.stt_started_without_vad = True
                self.started_during_agent_speaking = True
            if self.external_speaker_gate_locked is False:
                self.started_before_speaker_gate_locked = True
            if self.transcript_started_at is None:
                self.transcript_started_at = time.monotonic()
            self.user_turn_active = True
            self._append_transcript_hypothesis(text)
        if is_final:
            if text:
                self.final_text = self._merge_final_transcript(self.final_text, text)
                self._append_final_segment(
                    self.latest_transcript_text or text,
                    target_confirmed=(
                        self.turn_speaker_is_target is True
                        and (
                            self.turn_speaker_segment_id is None
                            or self.current_speaker_segment_id
                            == self.turn_speaker_segment_id
                        )
                    ),
                )
            self.partial_text = ""
        else:
            self.partial_text = text

    def on_voice_confidence(
        self, confidence: float, energy_db: float | None = None
    ) -> None:
        """前端语音置信度更新。被动信号：只记录最新值与时间戳，不递增 event。"""
        self.external_voice_confidence = confidence
        self.external_voice_energy_db = energy_db
        self.external_voice_updated_at = time.monotonic()

    def on_speaker_verdict(
        self,
        is_target: bool | None,
        similarity: float | None = None,
        kind: str | None = None,
        state: str | None = None,
        *,
        segment_id: int | None = None,
    ) -> None:
        """SpeakerGate 声纹判决更新。被动信号：只记录最新值与时间戳，不递增 event。

        线程安全注意：由 SpeakerGate 的 worker 线程回调调用，仅做简单赋值（GIL 下原子），
        不触碰 event/turn 状态。
        """
        normalized_state = self._normalize_speaker_state(
            state,
            is_target=is_target,
            similarity=similarity,
        )
        if segment_id is not None:
            self.current_speaker_segment_id = segment_id
        self.external_speaker_is_target = is_target
        self.external_speaker_state = normalized_state
        self.external_speaker_similarity = similarity
        self.external_speaker_verdict_kind = kind
        self.external_speaker_updated_at = (
            None if normalized_state is None else time.monotonic()
        )
        if normalized_state is None:
            return
        # 轮次级 latch：完整段 target 判决一旦出现，本轮后续 endpointing 即使 TTL 过期也可提交。
        # 背景判决只在尚未看到 target 时记录，避免早判/贴边误杀覆盖后续更稳的 target。
        if is_target:
            self.turn_speaker_is_target = True
            self.turn_speaker_state = normalized_state
            self.turn_speaker_similarity = similarity
            self.turn_speaker_verdict_kind = kind
            self.turn_speaker_updated_at = time.monotonic()
            self.turn_speaker_segment_id = segment_id
            self._mark_current_speaker_segment_target_confirmed(segment_id)
        elif self._decisive_non_target_similarity(similarity) and (
            self.turn_speaker_is_target is not True or kind == "decide"
        ):
            self.turn_speaker_is_target = False
            self.turn_speaker_state = normalized_state
            self.turn_speaker_similarity = similarity
            self.turn_speaker_verdict_kind = kind
            self.turn_speaker_updated_at = time.monotonic()
            self.turn_speaker_segment_id = segment_id
            self._mark_current_speaker_segment_non_target(segment_id)
        elif self.turn_speaker_is_target is not True:
            self.turn_speaker_is_target = False
            self.turn_speaker_state = normalized_state
            self.turn_speaker_similarity = similarity
            self.turn_speaker_verdict_kind = kind
            self.turn_speaker_updated_at = time.monotonic()

    def on_speaker_gate_status(self, locked: bool | None) -> None:
        """SpeakerGate 锁定状态更新。None 表示无可用 SpeakerGate，消费方 fail-open。"""
        self.external_speaker_gate_locked = locked

    def consume_wait_intent(self, text: str) -> None:
        self.wait_intent_active = True
        self.wait_intent_consumed_text = text.strip()

    def _normalize_speaker_state(
        self,
        state: str | None,
        *,
        is_target: bool | None,
        similarity: float | None,
    ) -> str | None:
        if state:
            try:
                return MMISpeakerGateState(state).value
            except ValueError:
                return MMISpeakerGateState.UNKNOWN.value
        if is_target is True:
            return MMISpeakerGateState.TARGET_CONFIDENT.value
        if is_target is False:
            if similarity is None or similarity <= self.speaker_non_target_sim_max:
                return MMISpeakerGateState.NON_TARGET.value
            return MMISpeakerGateState.TARGET_WEAK.value
        return None

    def _decisive_non_target_similarity(self, similarity: float | None) -> bool:
        return similarity is None or similarity <= self.speaker_non_target_sim_max

    @staticmethod
    def _latest_segment(previous: str, current: str) -> str:
        if previous and current.startswith(previous):
            suffix = current[len(previous) :].strip()
            if suffix and any(character.isalnum() for character in suffix):
                return suffix
            return current
        return current

    @classmethod
    def _merge_final_transcript(cls, previous: str, current: str) -> str:
        """Merge STT final segments while collapsing same-utterance rewrites.

        Qwen ASR can emit several final hypotheses for the same short utterance
        with different segment ids, for example "有冇？" -> "天气。" ->
        "有没有天气？". Treat a later, longer hypothesis that covers most of
        the earlier content as a replacement; keep unrelated segments appended.
        """
        if not previous:
            return current
        if current.startswith(previous):
            return current
        if previous.endswith(current):
            return previous

        previous_norm = cls._normalize_transcript_for_merge(previous)
        current_norm = cls._normalize_transcript_for_merge(current)
        if not previous_norm or not current_norm:
            return f"{previous} {current}"
        if current_norm.startswith(previous_norm) or previous_norm in current_norm:
            return current

        previous_chars = set(previous_norm)
        current_chars = set(current_norm)
        coverage = len(previous_chars & current_chars) / max(1, len(previous_chars))
        if (
            len(current_norm) >= len(previous_norm)
            and len(previous_norm) <= 12
            and coverage >= 0.75
        ):
            return current

        return f"{previous} {current}"

    @staticmethod
    def _normalize_transcript_for_merge(text: str) -> str:
        normalized = []
        for character in text:
            if character.isspace() or character in "，。！？、,.!?;；:：\"'“”‘’（）()[]【】":
                continue
            normalized.append("没" if character == "冇" else character.lower())
        return "".join(normalized)

    @property
    def transcript_text(self) -> str:
        return " ".join(
            part for part in (self.final_text, self.partial_text) if part
        ).strip()

    @property
    def target_confirmed_transcript_text(self) -> str:
        """Transcript slice safe to submit after a target speaker verdict.

        The detector still reasons over ``transcript_text`` so it can observe a
        full turn, but commits should avoid text captured before the first
        target-speaker confirmation in mixed background/target turns.
        """
        segments = self.final_segments or []
        parts = [segment.text for segment in segments if segment.target_confirmed]
        if (
            self.turn_speaker_is_target is True
            and self.partial_text
            and (
                self.turn_speaker_segment_id is None
                or self.current_speaker_segment_id == self.turn_speaker_segment_id
            )
        ):
            parts.append(self.partial_text)
        return " ".join(part for part in parts if part).strip()

    @property
    def commit_transcript_text(self) -> str:
        return self.target_confirmed_transcript_text or self.transcript_text

    def _append_final_segment(self, text: str, *, target_confirmed: bool) -> None:
        text = text.strip()
        if not text:
            return
        if self.final_segments is None:
            self.final_segments = []
        if not self.final_segments:
            self.final_segments.append(
                FinalTranscriptSegment(
                    text=text,
                    target_confirmed=target_confirmed,
                    speaker_segment_id=self.current_speaker_segment_id,
                )
            )
            return

        last = self.final_segments[-1]
        if (
            text.startswith(last.text)
            or last.text.endswith(text)
            or self._final_segment_rewrite(last.text, text)
            or self._final_segment_rewrite(text, last.text)
        ):
            if text.startswith(last.text) or self._final_segment_rewrite(last.text, text):
                last.text = text
            last.target_confirmed = last.target_confirmed or target_confirmed
            return

        # A verdict can arrive between the background segment and the first
        # target-speaker transcript. We initially mark the latest available
        # segment so a single-segment utterance remains committable. If a new
        # distinct target-confirmed segment then arrives, move that boundary
        # forward instead of retaining the pre-verdict background text.
        if target_confirmed and last.confirmed_by_verdict:
            last.target_confirmed = False
            last.confirmed_by_verdict = False
        self.final_segments.append(
            FinalTranscriptSegment(
                text=text,
                target_confirmed=target_confirmed,
                speaker_segment_id=self.current_speaker_segment_id,
            )
        )

    def _append_transcript_hypothesis(self, text: str) -> None:
        if self.transcript_hypotheses is None:
            self.transcript_hypotheses = []
        if self.transcript_hypotheses and self.transcript_hypotheses[-1] == text:
            return
        self.transcript_hypotheses.append(text)
        del self.transcript_hypotheses[:-_MAX_TRANSCRIPT_HYPOTHESES]

    def _mark_current_speaker_segment_target_confirmed(
        self,
        segment_id: int | None,
    ) -> None:
        segments = self.final_segments or []
        if segment_id is not None:
            matching = [
                segment
                for segment in segments
                if segment.speaker_segment_id == segment_id
            ]
            for segment in matching:
                segment.target_confirmed = True
                segment.confirmed_by_verdict = False
            return
        if segments:
            segments[-1].target_confirmed = True
            segments[-1].confirmed_by_verdict = True

    def _mark_current_speaker_segment_non_target(
        self,
        segment_id: int | None,
    ) -> None:
        if segment_id is None:
            return
        for segment in self.final_segments or []:
            if segment.speaker_segment_id == segment_id:
                segment.target_confirmed = False
                segment.confirmed_by_verdict = False

    @classmethod
    def _final_segment_rewrite(cls, previous: str, current: str) -> bool:
        previous_norm = cls._normalize_transcript_for_merge(previous)
        current_norm = cls._normalize_transcript_for_merge(current)
        if not previous_norm or not current_norm:
            return False
        if current_norm.startswith(previous_norm) or previous_norm in current_norm:
            return True
        previous_chars = set(previous_norm)
        current_chars = set(current_norm)
        coverage = len(previous_chars & current_chars) / max(1, len(previous_chars))
        return (
            len(current_norm) >= len(previous_norm)
            and len(previous_norm) <= 12
            and coverage >= 0.75
        )

    def snapshot(self) -> MMITurnContext:
        now = time.monotonic()
        speech_ms = (
            max(0, int((now - self.speech_started_at) * 1000))
            if self.user_state == "speaking" and self.speech_started_at is not None
            else 0
        )
        transcript_observe_ms = (
            max(0, int((now - self.transcript_started_at) * 1000))
            if self.transcript_started_at is not None and self.transcript_text
            else 0
        )
        silence_ms = (
            max(0, int((now - self.silence_started_at) * 1000))
            if self.user_state != "speaking" and self.silence_started_at is not None
            else 0
        )
        voice_confidence: float | None = None
        voice_energy_db: float | None = None
        voice_stale = False
        if self.external_voice_updated_at is not None:
            if (now - self.external_voice_updated_at) * 1000 <= _VOICE_CONFIDENCE_TTL_MS:
                voice_confidence = self.external_voice_confidence
                voice_energy_db = self.external_voice_energy_db
            else:
                voice_stale = True
        speaker_is_target: bool | None = None
        speaker_state: str | None = None
        speaker_similarity: float | None = None
        speaker_verdict_kind: str | None = None
        if (
            self.external_speaker_updated_at is not None
            and (now - self.external_speaker_updated_at) * 1000 <= _SPEAKER_VERDICT_TTL_MS
        ):
            speaker_is_target = self.external_speaker_is_target
            speaker_state = self.external_speaker_state
            speaker_similarity = self.external_speaker_similarity
            speaker_verdict_kind = self.external_speaker_verdict_kind
        turn_speaker_age_ms = (
            max(0, int((now - self.turn_speaker_updated_at) * 1000))
            if self.turn_speaker_updated_at is not None
            else None
        )
        return MMITurnContext(
            session_id=self.session_id,
            turn_id=self.turn_id,
            event_id=self.event_id,
            agent_state=self.agent_state,
            user_state=self.user_state,
            tts_playing=self.agent_state == "speaking",
            awaiting_confirmation=self.awaiting_confirmation,
            vad_speech=self.user_state == "speaking",
            speech_ms=speech_ms,
            transcript_observe_ms=transcript_observe_ms,
            silence_ms=silence_ms,
            partial_text=self.partial_text,
            final_text=self.final_text,
            latest_transcript_text=self.latest_transcript_text,
            transcript_hypotheses=tuple(self.transcript_hypotheses or ()),
            stt_confidence=self.stt_confidence,
            external_voice_confidence=voice_confidence,
            external_voice_energy_db=voice_energy_db,
            external_voice_stale=voice_stale,
            external_speaker_is_target=speaker_is_target,
            external_speaker_state=speaker_state,
            external_speaker_similarity=speaker_similarity,
            external_speaker_verdict_kind=speaker_verdict_kind,
            external_speaker_gate_locked=self.external_speaker_gate_locked,
            turn_speaker_is_target=self.turn_speaker_is_target,
            turn_speaker_state=self.turn_speaker_state,
            turn_speaker_similarity=self.turn_speaker_similarity,
            turn_speaker_verdict_kind=self.turn_speaker_verdict_kind,
            turn_speaker_age_ms=turn_speaker_age_ms,
            eou_prob=self.eou_prob,
            eou_unlikely_threshold=self.eou_unlikely_threshold,
            last_user_text=self.last_user_text,
            last_agent_text=self.last_agent_text,
            wait_intent_active=self.wait_intent_active,
            wait_intent_consumed_text=self.wait_intent_consumed_text,
            user_turn_active=self.user_turn_active,
            started_during_agent_thinking=self.started_during_agent_thinking,
            started_during_agent_speaking=self.started_during_agent_speaking,
            started_before_speaker_gate_locked=self.started_before_speaker_gate_locked,
            turn_started_after_previous_speech_ms=(
                self.turn_started_after_previous_speech_ms
            ),
            locale=self.locale,
        )

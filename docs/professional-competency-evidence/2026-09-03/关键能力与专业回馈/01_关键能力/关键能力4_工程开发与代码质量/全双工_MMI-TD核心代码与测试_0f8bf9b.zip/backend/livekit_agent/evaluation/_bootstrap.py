"""Shared path bootstrap for evaluation scripts run as standalone files."""

from __future__ import annotations

import sys
from pathlib import Path


LIVEKIT_AGENT_DIR = Path(__file__).resolve().parent.parent


def ensure_livekit_agent_path() -> None:
    path = str(LIVEKIT_AGENT_DIR)
    if path not in sys.path:
        sys.path.insert(0, path)

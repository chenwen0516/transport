"""Create a fixed SpeakerGate long-term profile from enrollment WAV files.

Run from `backend/livekit_agent`:

    uv run python evaluation/enroll_speaker_profile.py \
      --model model/pretrained/campplus_sv_zh-cn_16k-common.onnx \
      --profile-id user123 \
      --output tmp/user123_speaker_profile.json \
      enroll_1.wav enroll_2.wav enroll_3.wav

Input WAV files must be 16 kHz, mono, 16-bit PCM. Keep this script explicit and
offline so fixed-profile experiments stay separate from runtime enrollment.
"""

from __future__ import annotations

import argparse
import json
import sys
import wave
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from audio_filter import CampplusEmbedder  # noqa: E402


def _read_wav_i16(path: Path) -> tuple[np.ndarray, float]:
    with wave.open(str(path), "rb") as wf:
        channels = wf.getnchannels()
        sample_rate = wf.getframerate()
        sample_width = wf.getsampwidth()
        frames = wf.getnframes()
        if channels != 1 or sample_rate != 16000 or sample_width != 2:
            raise ValueError(
                f"{path} must be 16 kHz mono 16-bit PCM WAV "
                f"(got channels={channels}, sample_rate={sample_rate}, sample_width={sample_width})"
            )
        data = np.frombuffer(wf.readframes(frames), dtype=np.int16).astype(np.float32)
    return data, frames / 16000.0


def _pairwise_min(embeddings: list[np.ndarray]) -> float | None:
    if len(embeddings) < 2:
        return None
    matrix = np.stack(embeddings)
    sims = matrix @ matrix.T
    upper = np.triu_indices(len(embeddings), k=1)
    return float(sims[upper].min())


def main() -> int:
    parser = argparse.ArgumentParser(description="Create SpeakerGate long-term profile JSON")
    parser.add_argument("wavs", nargs="+", help="Enrollment WAV files, 16k mono 16-bit PCM")
    parser.add_argument("--model", required=True, help="CAM++ ONNX model path")
    parser.add_argument("--output", required=True, help="Output profile JSON path")
    parser.add_argument("--profile-id", default="", help="Stable profile id")
    args = parser.parse_args()

    embedder = CampplusEmbedder(args.model, target_sr=16000)
    if not embedder.ok:
        raise RuntimeError("failed to load CAM++ embedder")

    embeddings: list[np.ndarray] = []
    total_duration = 0.0
    skipped: list[str] = []
    for raw_path in args.wavs:
        path = Path(raw_path).expanduser()
        wav, duration = _read_wav_i16(path)
        emb = embedder.embed(wav)
        if emb is None:
            skipped.append(str(path))
            continue
        embeddings.append(emb)
        total_duration += duration

    if not embeddings:
        raise RuntimeError("no usable enrollment embeddings were produced")

    centroid = np.mean(np.stack(embeddings), axis=0)
    centroid = centroid / max(float(np.linalg.norm(centroid)), 1e-8)
    min_pairwise_similarity = _pairwise_min(embeddings)
    profile = {
        "schema_version": 1,
        "profile_id": args.profile_id or Path(args.output).stem,
        "model": "campplus_sv_zh-cn_16k-common",
        "sample_rate": 16000,
        "duration_seconds": round(total_duration, 3),
        "quality_score": min_pairwise_similarity,
        "min_pairwise_similarity": min_pairwise_similarity,
        "clean_centroid_embedding": centroid.astype(float).tolist(),
        "segment_embeddings": [emb.astype(float).tolist() for emb in embeddings],
        "source_files": [str(Path(p).expanduser()) for p in args.wavs],
        "skipped_files": skipped,
    }

    output = Path(args.output).expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        f"wrote {output} with {len(embeddings)} segment embeddings, "
        f"duration={total_duration:.2f}s, min_pairwise={min_pairwise_similarity}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

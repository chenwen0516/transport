from __future__ import annotations

import json
from pathlib import Path

from mmi_turn_detection.patterns import (
    DEFAULT_PATTERN_VERSION,
    MultilingualPatternMatcher,
)


def test_default_patterns_support_chinese_english_and_mixed_input():
    matcher = MultilingualPatternMatcher()

    assert matcher.strong_interrupt("等一下 please").matched is True
    assert matcher.strong_interrupt("wait, 不是这个").matched is True
    assert matcher.strong_interrupt("no no, use another one").matched is True
    assert matcher.strong_interrupt("normal conversation").matched is False

    assert matcher.backchannel("嗯嗯 okay").matched is True
    assert matcher.backchannel("yeah").matched is True
    assert matcher.backchannel("okay, I want another one").matched is False
    assert matcher.addressed_to_other("Laura, lights flickered again").matched is True
    assert matcher.addressed_to_other("Laura. Lights flickered again").matched is True
    assert matcher.addressed_to_other("zena, dog's chewing your shoe").matched is True
    assert matcher.addressed_to_other("Coach Garcia, ankle's still sore").matched is True
    assert matcher.addressed_to_other("Coach Garcia' ankle still kind of sore").matched is True
    assert matcher.addressed_to_other("Coach Garcia's ankle is sore").matched is False
    assert matcher.addressed_to_other("trainer kim, how many reps left?").matched is True
    assert matcher.addressed_to_other("Dr. Smith, see you next week").matched is True
    assert matcher.addressed_to_other("officer, is this the right form?").matched is True
    assert matcher.addressed_to_other("Actually, can you tell me more?").matched is False
    assert matcher.addressed_to_other("Oh, actually, let's switch topics").matched is False
    assert matcher.addressed_to_other("Oh, before I forget, set an alarm").matched is False
    assert matcher.addressed_to_other("Oh, by the way, how much sunlight?").matched is False
    assert matcher.addressed_to_other("Yeah, there are a lot of stations").matched is False
    assert matcher.addressed_to_other("And. Her cousin lives nearby.").matched is False
    assert matcher.addressed_to_other("Prolific, specifically about surveys").matched is False
    assert matcher.addressed_to_other("Endlessly, I need advice").matched is False
    assert matcher.addressed_to_other("Enderly, I need advice").matched is False
    assert matcher.addressed_to_other("Hopefully, everything will improve").matched is False
    assert matcher.addressed_to_other("Cross. Hopefully, everything will improve").matched is False
    assert matcher.addressed_to_other("There, was another hurricane").matched is False
    assert matcher.addressed_to_other("Good. Finally, I was...").matched is False
    assert matcher.addressed_to_other("Yep. Next, there is a survey").matched is False
    assert matcher.addressed_to_other("Gotcha. I have read about that").matched is False
    assert matcher.addressed_to_other("Ah, sheesh!").matched is False
    assert matcher.addressed_to_other("Mask. I did not know that").matched is False
    assert matcher.addressed_to_other("I've. I love this service").matched is False
    assert matcher.addressed_to_other("Assistant, stop talking").matched is False
    assert matcher.addressed_to_other("Hello! Somebody's knocking on my door.").matched is False
    assert matcher.addressed_to_other("Hello, can you help me?").matched is False
    assert matcher.addressed_to_other("Hi there. Can you help me?").matched is False
    greeting_vocative = matcher.addressed_to_other("Hello, Laura, can you help?")
    assert greeting_vocative.matched is True
    assert greeting_vocative.rule == "addressee.english_greeting_vocative"
    assert greeting_vocative.pattern == "Laura"
    assert matcher.addressed_to_other("Hi coach, how many reps left?").matched is True

    assert matcher.wait_expression("let me think for a moment").matched is True
    assert matcher.wait_expression("hold on, let me think").matched is True
    assert matcher.wait_expression("Wait. Can you help me with something else?").matched is False
    assert matcher.wait_expression("等一下，帮我查一下天气").matched is False
    assert matcher.incomplete_suffix("I want to ask because").matched is True


def test_default_patterns_recognize_aa_fdb_chinese_short_feedback():
    matcher = MultilingualPatternMatcher()

    for text in (
        "哈哈哈！",
        "嘿嘿嘿。",
        "Ha ha ha!",
        "哇哦！",
        "确实。",
        "哎，对对。",
        "爽啊！",
        "有意思。",
        "诶诶。",
        "呵呵。",
    ):
        assert matcher.backchannel(text).matched is True

    assert matcher.backchannel("呃，你能再解释一下吗？").matched is False
    assert matcher.backchannel("Haha, can you explain that?").matched is False


def test_default_patterns_preserve_strong_interrupt_exclusions():
    matcher = MultilingualPatternMatcher()

    assert matcher.strong_interrupt("不要停止服药").matched is False
    assert matcher.strong_interrupt("do not stop taking this medicine").matched is False
    assert matcher.strong_interrupt("please stop talking").matched is True
    assert matcher.explicit_overlap_intent("Actually, tell me about movies").matched is True
    assert matcher.explicit_overlap_intent("By the way, what about podcasts?").matched is True
    assert matcher.explicit_overlap_intent("Oh, before I forget, set an alarm").matched is True
    assert matcher.explicit_overlap_intent("Hold that thought, I have a question").matched is True
    assert matcher.explicit_overlap_intent("My phone is almost dead").matched is False


def test_pattern_config_adds_removes_and_replaces_rules(tmp_path):
    path = tmp_path / "patterns.json"
    path.write_text(
        json.dumps(
            {
                "version": "badcase-42",
                "locales": {
                    "zh-CN": {
                        "backchannels": ["确实"],
                        "remove": {"backchannels": ["嗯"]},
                    },
                    "en-US": {
                        "replace_defaults": True,
                        "strong_interrupt": {"exact": ["halt"]},
                        "backchannels": ["sure"],
                    },
                },
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    matcher = MultilingualPatternMatcher.from_file(str(path))

    assert matcher.version == "badcase-42"
    assert matcher.backchannel("确实").matched is True
    assert matcher.backchannel("嗯").matched is False
    assert matcher.strong_interrupt("halt").matched is True
    assert matcher.strong_interrupt("stop").matched is False
    assert matcher.backchannel("sure").matched is True


def test_invalid_pattern_config_falls_back_to_defaults(tmp_path):
    path = tmp_path / "patterns.json"
    path.write_text('{"version": "", "locales": []}', encoding="utf-8")

    matcher = MultilingualPatternMatcher.from_file(str(path))

    assert matcher.version == DEFAULT_PATTERN_VERSION
    assert matcher.strong_interrupt("等一下").matched is True
    assert matcher.strong_interrupt("wait").matched is True


def test_formal_initial_pattern_file_contains_tested_zh_and_en_rules():
    path = (
        Path(__file__).resolve().parents[2]
        / "mmi_turn_detection"
        / "mmi-patterns.json"
    )
    raw = json.loads(path.read_text(encoding="utf-8"))
    matcher = MultilingualPatternMatcher.from_file(str(path))

    assert raw["version"] == "2026-08-03.aa-fdb-badcase-v9"
    assert raw["locales"]["zh-CN"]["replace_defaults"] is True
    assert raw["locales"]["en-US"]["replace_defaults"] is True

    assert matcher.strong_interrupt("等一下").matched is True
    assert matcher.strong_interrupt("不不不").matched is True
    assert matcher.backchannel("嗯嗯").matched is True
    assert matcher.backchannel("哈哈哈！").matched is True
    assert matcher.backchannel("嘿嘿嘿。").matched is True
    assert matcher.backchannel("Ha ha ha!").matched is True
    assert matcher.backchannel("确实。").matched is True
    assert matcher.backchannel("uh-huh").matched is True
    assert matcher.backchannel("uh-huh sure").matched is True
    assert matcher.backchannel("mm-hmm yeah").matched is True
    assert matcher.backchannel("Hmm. Yeah.").matched is True
    assert matcher.backchannel("i see that").matched is True
    assert matcher.wait_expression("我想想").matched is True
    assert matcher.wait_expression("我想一下啊").matched is True
    assert matcher.wait_expression("让我想一下").matched is True
    assert matcher.incomplete_suffix("我觉得").matched is True

    assert matcher.strong_interrupt("wait").matched is True
    assert matcher.strong_interrupt("no no").matched is True
    assert matcher.backchannel("yeah").matched is True
    assert matcher.wait_expression("let me think").matched is True
    assert matcher.incomplete_suffix("because").matched is True

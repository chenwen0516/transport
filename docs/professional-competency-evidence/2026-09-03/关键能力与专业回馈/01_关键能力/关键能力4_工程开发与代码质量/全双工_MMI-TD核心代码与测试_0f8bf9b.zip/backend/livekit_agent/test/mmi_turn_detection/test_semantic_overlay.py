from __future__ import annotations

import asyncio
import json
import logging
import time

import pytest

from mmi_turn_detection.models import (
    MMIConfidenceLevel,
    MMITurnAction,
    MMITurnContext,
    MMITurnDecision,
)
from mmi_turn_detection.semantic_overlay import (
    OnlineSemanticOverlayShadow,
    SemanticPrediction,
    SemanticOverlayCapacityError,
    SemanticState,
    has_overlay_interrupt_cue,
    interrupt_suppression_state,
    parse_semantic_response,
)


def _context(
    *hypotheses: str,
    turn_id: int = 1,
    event_id: int = 1,
) -> MMITurnContext:
    return MMITurnContext(
        session_id="test-session",
        turn_id=turn_id,
        event_id=event_id,
        agent_state="speaking",
        user_state="speaking",
        tts_playing=True,
        latest_transcript_text=hypotheses[-1],
        partial_text=hypotheses[-1],
        transcript_hypotheses=hypotheses,
        started_during_agent_speaking=True,
    )


def _decision(action: MMITurnAction) -> MMITurnDecision:
    return MMITurnDecision(
        action=action,
        confidence=0.9,
        confidence_level=MMIConfidenceLevel.HIGH,
        reason="base_test",
        turn_id=1,
        based_on_event_id=1,
    )


def _prediction(
    state: SemanticState,
    transcript: str,
    *,
    event_id: int,
    confidence: float = 0.9,
) -> SemanticPrediction:
    return SemanticPrediction(
        turn_id=1,
        event_id=event_id,
        state=state,
        confidence=confidence,
        reason="test",
        transcript=transcript,
        hypothesis_history=(transcript,),
        is_final=False,
        latency_ms=10,
        completed_at=time.monotonic(),
    )


class FakeClassifier:
    def __init__(
        self,
        predictions: list[tuple[SemanticState, float]],
        *,
        delay_sec: float = 0,
        error: Exception | None = None,
    ) -> None:
        self.predictions = predictions
        self.delay_sec = delay_sec
        self.error = error
        self.calls = 0

    async def classify(
        self,
        context: MMITurnContext,
        *,
        is_final: bool,
    ) -> SemanticPrediction:
        await asyncio.sleep(self.delay_sec)
        if self.error is not None:
            raise self.error
        state, confidence = self.predictions[self.calls]
        self.calls += 1
        return SemanticPrediction(
            turn_id=context.turn_id,
            event_id=context.event_id,
            state=state,
            confidence=confidence,
            reason="fake",
            transcript=context.latest_transcript_text,
            hypothesis_history=context.transcript_hypotheses,
            is_final=is_final,
            latency_ms=self.delay_sec * 1000,
            completed_at=time.monotonic(),
        )


def _payload(caplog: pytest.LogCaptureFixture, marker: str) -> dict:
    message = next(record.message for record in caplog.records if marker in record.message)
    return json.loads(message.split(marker, 1)[1].strip())


def test_parse_semantic_response_accepts_fenced_json():
    parsed = parse_semantic_response(
        '```json\n{"state":"interrupt","confidence":1.2,"reason":"cue"}\n```'
    )

    assert parsed == {
        "state": "INTERRUPT",
        "confidence": 1.0,
        "reason": "cue",
    }


def test_overlay_cues_cover_frozen_v4_variants():
    assert has_overlay_interrupt_cue(("Open just a minute.",))
    assert has_overlay_interrupt_cue(("Either way, do we need milk?",))
    assert has_overlay_interrupt_cue(("Actually, let's switch gears.",))


def test_stable_declarative_continue_can_suppress_base_interrupt():
    predictions = (
        _prediction(SemanticState.CONTINUE, "Roomy fridge is empty.", event_id=1),
        _prediction(SemanticState.CONTINUE, "Groceries.", event_id=2),
    )

    assert (
        interrupt_suppression_state(
            predictions,
            "Roomy fridge is empty again. Groceries.",
        )
        == SemanticState.CONTINUE
    )


def test_final_declarative_continue_can_suppress_base_interrupt():
    predictions = (
        _prediction(
            SemanticState.CONTINUE,
            "Let's grab coffee later.",
            event_id=1,
        ),
    )

    assert (
        interrupt_suppression_state(
            predictions,
            "Let's grab coffee later.",
        )
        == SemanticState.CONTINUE
    )


def test_direct_question_does_not_suppress_base_interrupt():
    predictions = (
        _prediction(SemanticState.CONTINUE, "Can we talk", event_id=1),
        _prediction(
            SemanticState.CONTINUE,
            "Can we talk about sleep?",
            event_id=2,
        ),
    )

    assert (
        interrupt_suppression_state(
            predictions,
            "Can we talk about sleep?",
        )
        is None
    )


def test_backchannel_prediction_does_not_suppress_floor_taking_question():
    predictions = (
        _prediction(
            SemanticState.BACKCHANNEL,
            "Oh, by the way.",
            event_id=1,
        ),
        _prediction(
            SemanticState.BACKCHANNEL,
            "Oh, by the way, how do I know?",
            event_id=2,
        ),
    )

    assert (
        interrupt_suppression_state(
            predictions,
            "Oh, by the way, how do I know if my plant needs more sunlight?",
        )
        is None
    )


@pytest.mark.asyncio
async def test_online_overlay_logs_late_suppression_without_executing(
    caplog: pytest.LogCaptureFixture,
):
    classifier = FakeClassifier(
        [
            (SemanticState.CONTINUE, 0.9),
            (SemanticState.CONTINUE, 0.9),
        ],
        delay_sec=0.001,
    )
    overlay = OnlineSemanticOverlayShadow(
        classifier,
        effective_budget_ms=300,
    )
    first = _context("Let's grab coffee", event_id=1)
    second = _context(
        "Let's grab coffee",
        "Let's grab coffee later.",
        event_id=2,
    )
    caplog.set_level(logging.INFO, logger="health-agent.mmi.semantic_overlay")

    overlay.observe_base_decision(
        _decision(MMITurnAction.START_LISTENING),
        second,
        trigger="test",
    )
    await overlay.observe_transcript(first, is_final=False)
    await overlay.observe_transcript(second, is_final=True)

    payloads = [
        json.loads(record.message.split("semantic_overlay_result", 1)[1].strip())
        for record in caplog.records
        if "semantic_overlay_result" in record.message
    ]
    assert payloads[-1]["overlay_action"] == "CONTINUE_SPEAKING"
    assert payloads[-1]["would_change_action"] is True
    assert payloads[-1]["arrived_before_base_decision"] is False


@pytest.mark.asyncio
async def test_online_overlay_error_is_fail_open(
    caplog: pytest.LogCaptureFixture,
):
    overlay = OnlineSemanticOverlayShadow(
        FakeClassifier([], error=TimeoutError("slow")),
        effective_budget_ms=300,
    )
    caplog.set_level(logging.WARNING, logger="health-agent.mmi.semantic_overlay")

    await overlay.observe_transcript(_context("Wait, one thing."), is_final=True)

    payload = _payload(caplog, "semantic_overlay_error")
    assert payload["error_type"] == "TimeoutError"


@pytest.mark.asyncio
async def test_online_overlay_capacity_drop_is_observable(
    caplog: pytest.LogCaptureFixture,
):
    overlay = OnlineSemanticOverlayShadow(
        FakeClassifier([], error=SemanticOverlayCapacityError("max_concurrency_reached")),
        effective_budget_ms=300,
    )
    caplog.set_level(logging.INFO, logger="health-agent.mmi.semantic_overlay")

    await overlay.observe_transcript(_context("Wait, one thing."), is_final=True)

    payload = _payload(caplog, "semantic_overlay_dropped")
    assert payload["reason"] == "max_concurrency_reached"
    assert payload["is_final"] is True


@pytest.mark.asyncio
async def test_local_cue_recommends_interrupt_after_semantic_arrives(
    caplog: pytest.LogCaptureFixture,
):
    overlay = OnlineSemanticOverlayShadow(
        FakeClassifier([(SemanticState.CONTINUE, 0.9)]),
        effective_budget_ms=300,
    )
    context = _context("Before I forget, what is tomorrow's date?")
    caplog.set_level(logging.INFO, logger="health-agent.mmi.semantic_overlay")

    await overlay.observe_transcript(context, is_final=True)
    overlay.observe_base_decision(
        _decision(MMITurnAction.CONTINUE_SPEAKING),
        context,
        trigger="test",
    )

    payload = _payload(caplog, "semantic_overlay_comparison")
    assert payload["overlay_action"] == "START_LISTENING"
    assert payload["would_change_action"] is True


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "base_action",
    [
        MMITurnAction.START_SPEAKING,
        MMITurnAction.CONTINUE_LISTENING,
    ],
)
async def test_local_cue_does_not_rewrite_endpointing_actions(
    caplog: pytest.LogCaptureFixture,
    base_action: MMITurnAction,
):
    overlay = OnlineSemanticOverlayShadow(
        FakeClassifier([(SemanticState.INTERRUPT, 0.9)]),
        effective_budget_ms=300,
    )
    context = _context("Before I forget, what is tomorrow's date?")
    caplog.set_level(logging.INFO, logger="health-agent.mmi.semantic_overlay")

    await overlay.observe_transcript(context, is_final=True)
    overlay.observe_base_decision(
        _decision(base_action),
        context,
        trigger="test",
    )

    payload = _payload(caplog, "semantic_overlay_comparison")
    assert payload["overlay_action"] == base_action.value
    assert payload["would_change_action"] is False

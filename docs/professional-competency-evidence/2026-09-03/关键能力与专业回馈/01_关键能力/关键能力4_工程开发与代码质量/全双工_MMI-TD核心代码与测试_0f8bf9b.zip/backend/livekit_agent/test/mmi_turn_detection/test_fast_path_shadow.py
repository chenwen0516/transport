from __future__ import annotations

import json
import logging
from dataclasses import replace

import pytest

from mmi_turn_detection.fast_path_shadow import (
    FastPathRecommendation,
    FastPathShadowObserver,
)
from mmi_turn_detection.models import (
    MMIConfidenceLevel,
    MMITurnAction,
    MMITurnContext,
    MMITurnDecision,
)


def _context(*, turn_id: int = 1, event_id: int = 1) -> MMITurnContext:
    return MMITurnContext(
        session_id="test-session",
        turn_id=turn_id,
        event_id=event_id,
        agent_state="speaking",
        user_state="speaking",
        tts_playing=True,
        started_during_agent_speaking=True,
    )


def _decision(
    action: MMITurnAction,
    *,
    reason: str,
    observe_more_ms: int = 0,
    ignore_input: bool = False,
) -> MMITurnDecision:
    return MMITurnDecision(
        action=action,
        confidence=0.9,
        confidence_level=MMIConfidenceLevel.HIGH,
        reason=reason,
        ignore_input=ignore_input,
        observe_more_ms=observe_more_ms,
        turn_id=1,
        based_on_event_id=1,
    )


def _payloads(caplog: pytest.LogCaptureFixture, marker: str) -> list[dict]:
    return [
        json.loads(record.message.split(marker, 1)[1].strip())
        for record in caplog.records
        if marker in record.message
    ]


def test_low_confidence_observation_stays_pending_until_deadline(caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    observer = FastPathShadowObserver(deadline_ms=200)
    context = _context()

    observer.start(context, agent_speech_id=3, observed_at=10.0)
    recommendation = observer.observe_decision(
        _decision(
            MMITurnAction.CONTINUE_SPEAKING,
            reason="observe_interruption_candidate",
            observe_more_ms=400,
        ),
        context,
        trigger="user_started_speaking",
        observed_at=10.01,
    )
    observer.mark_deadline(
        turn_id=1,
        agent_speech_id=3,
        observed_at=10.2,
    )

    assert recommendation == FastPathRecommendation.PENDING_BARGE_IN
    deadline = _payloads(caplog, "fast_path_deadline")[-1]
    assert deadline["recommendation"] == "PENDING_BARGE_IN"
    assert deadline["decisive_within_deadline"] is False


def test_backchannel_suppression_is_decisive_before_native_stop(caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    observer = FastPathShadowObserver(deadline_ms=200)
    context = _context()

    observer.start(context, agent_speech_id=4, observed_at=20.0)
    recommendation = observer.observe_decision(
        _decision(
            MMITurnAction.CONTINUE_SPEAKING,
            reason="backchannel",
            ignore_input=True,
        ),
        context,
        trigger="user_transcript_during_agent_speech",
        observed_at=20.08,
    )
    observer.mark_agent_stop_candidate(
        turn_id=1,
        agent_speech_id=4,
        observed_at=20.12,
    )
    observer.confirm_native_stop(
        turn_id=1,
        agent_speech_id=4,
        trigger="assistant_item_interrupted",
        observed_at=20.15,
    )

    assert recommendation == FastPathRecommendation.SUPPRESS
    native_stop = _payloads(caplog, "fast_path_native_stop")[-1]
    assert native_stop["first_decisive_ms"] == 80.0
    assert native_stop["start_to_native_stop_ms"] == 120.0
    assert native_stop["observer_started_before_native_stop"] is True
    assert native_stop["decision_before_native_stop"] is True
    assert native_stop["decisive_within_deadline"] is True


def test_late_interrupt_is_recorded_but_misses_deadline(caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    observer = FastPathShadowObserver(deadline_ms=200)
    context = _context()

    observer.start(context, agent_speech_id=5, observed_at=30.0)
    observer.mark_deadline(
        turn_id=1,
        agent_speech_id=5,
        observed_at=30.2,
    )
    recommendation = observer.observe_decision(
        _decision(
            MMITurnAction.START_LISTENING,
            reason="ordinary_valid_interjection",
        ),
        context,
        trigger="user_transcript_during_agent_speech",
        observed_at=30.35,
    )

    assert recommendation == FastPathRecommendation.INTERRUPT
    decision = _payloads(caplog, "fast_path_decision")[-1]
    assert decision["elapsed_ms"] == 350.0


def test_audio_only_target_speech_is_decisive_without_transcript(caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    observer = FastPathShadowObserver(
        deadline_ms=200,
        audio_interrupt_min_ms=200,
    )
    context = replace(
        _context(),
        speech_ms=200,
        external_voice_confidence=0.9,
    )

    observer.start(context, agent_speech_id=7, observed_at=50.0)
    recommendation = observer.observe_audio_context(
        context,
        trigger="fast_path_audio_deadline",
        observed_at=50.2,
    )

    assert recommendation == FastPathRecommendation.INTERRUPT
    decision = _payloads(caplog, "fast_path_decision")[-1]
    assert decision["audio_only"] is True
    assert decision["base_reason"] == "audio_target_speech_sustained"
    assert decision["target_evidence"] == "voice_confidence"
    assert decision["elapsed_ms"] == 200.0


def test_audio_only_non_target_speaker_is_suppressed_early(caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    observer = FastPathShadowObserver(deadline_ms=200)
    context = replace(
        _context(),
        speech_ms=80,
        external_speaker_is_target=False,
        external_speaker_state="NON_TARGET",
        external_speaker_similarity=0.1,
    )

    observer.start(context, agent_speech_id=8, observed_at=60.0)
    recommendation = observer.observe_audio_context(
        context,
        trigger="speaker_verdict_recheck",
        observed_at=60.08,
    )

    assert recommendation == FastPathRecommendation.SUPPRESS
    decision = _payloads(caplog, "fast_path_decision")[-1]
    assert decision["base_reason"] == "audio_non_target_speaker"
    assert decision["elapsed_ms"] == 80.0


def test_audio_only_unknown_speaker_remains_pending(caplog):
    caplog.set_level(logging.INFO, logger="health-agent.mmi.fast_path")
    observer = FastPathShadowObserver(deadline_ms=200)
    context = replace(_context(), speech_ms=250)

    observer.start(context, agent_speech_id=9, observed_at=70.0)
    recommendation = observer.observe_audio_context(
        context,
        trigger="fast_path_audio_deadline",
        observed_at=70.25,
    )

    assert recommendation == FastPathRecommendation.PENDING_BARGE_IN
    assert observer.attempt is not None
    assert observer.attempt.first_decisive_at is None


@pytest.mark.parametrize(
    "action",
    [
        MMITurnAction.START_SPEAKING,
        MMITurnAction.CONTINUE_LISTENING,
    ],
)
def test_endpointing_decisions_are_not_part_of_fast_path(action):
    observer = FastPathShadowObserver(deadline_ms=200)
    context = _context()
    observer.start(context, agent_speech_id=6, observed_at=40.0)

    recommendation = observer.observe_decision(
        _decision(action, reason="endpointing"),
        context,
        trigger="endpointing_timer",
        observed_at=40.05,
    )

    assert recommendation is None
    assert observer.attempt is not None
    assert observer.attempt.first_decisive_at is None

"""Rule-based interruption decisions while the agent is speaking."""

from __future__ import annotations

from dataclasses import dataclass

from .models import (
    MMIConfidenceLevel,
    MMITurnAction,
    MMITurnContext,
    MMITurnDecision,
)
from .patterns import (
    DEFAULT_PATTERN_MATCHER,
    MultilingualPatternMatcher,
    PatternMatch,
    normalize_text,
)


@dataclass(frozen=True)
class InterruptionPolicyConfig:
    strong_interrupt_min_ms: int = 150
    ordinary_interrupt_min_ms: int = 600
    ordinary_interrupt_min_chars: int = 3
    stt_only_final_interrupt_min_ms: int = 250
    stt_only_final_interrupt_min_chars: int = 2
    observe_ms: int = 400
    max_observe_ms: int = 800
    speaker_non_target_sim_max: float = 0.18
    require_target_speaker: bool = False
    require_explicit_intent_for_overlapping_followup: bool = False
    overlapping_followup_min_gap_ms: int = 2000
    interrupt_target_min_similarity: float = 0.44
    target_latch_max_ms: int = 3000


class RuleBasedInterruptionPolicy:
    # 前端语音置信度低于此值 → 视为很可能的背景人声，抑制"普通打断"。
    _LOW_VOICE_CONFIDENCE = 0.4

    def __init__(
        self,
        config: InterruptionPolicyConfig,
        patterns: MultilingualPatternMatcher = DEFAULT_PATTERN_MATCHER,
    ) -> None:
        self._config = config
        self._patterns = patterns

    def decide(self, ctx: MMITurnContext) -> MMITurnDecision:
        text = ctx.transcript_text
        effective_observe_ms = max(ctx.speech_ms, ctx.transcript_observe_ms)
        strong_interrupt = self._patterns.strong_interrupt(text)
        addressed_to_other = self._addressed_to_other(ctx)
        # 默认 SpeakerGate 只作为 negative-only 辅助；开启严格模式后，
        # 已锁定但目标未确认的候选也会被观察/抑制。
        low_voice_conf = (
            ctx.external_voice_confidence is not None
            and ctx.external_voice_confidence < self._LOW_VOICE_CONFIDENCE
        )
        target_confirmed = self._interrupt_target_confirmed(ctx)
        non_target_speaker = self._decisive_non_target(ctx)
        speaker_unknown = not target_confirmed and not non_target_speaker
        target_required_pending = (
            self._target_speaker_required(ctx)
            and not target_confirmed
            and not non_target_speaker
        )
        speaker_gate_warmup_pending = (
            target_required_pending
            and ctx.external_speaker_gate_locked is False
        )
        speaker_identity_suppressed = non_target_speaker
        low_voice_confidence_pending = (
            speaker_unknown
            and low_voice_conf
            and effective_observe_ms < self._config.max_observe_ms
        )
        enrollment_partial_pending = (
            target_confirmed
            and ctx.started_before_speaker_gate_locked
            and not bool(ctx.final_text)
            and bool(ctx.partial_text)
            and (
                ctx.external_speaker_verdict_kind == "enroll"
                or ctx.turn_speaker_verdict_kind == "enroll"
            )
        )
        observe_more_ms = self._remaining_observation(ctx)
        if low_voice_confidence_pending:
            observe_more_ms = min(
                self._config.observe_ms,
                max(0, self._config.max_observe_ms - effective_observe_ms),
            )
        suppress_barge_in = (
            speaker_identity_suppressed
            or low_voice_confidence_pending
            or target_required_pending
        )
        # Explicit control phrases are allowed while identity is still unknown.
        # A decisive non-target verdict remains authoritative, but waiting for a
        # verdict must not swallow time-critical commands such as "hold on".
        suppress_high_priority_barge_in = speaker_identity_suppressed

        if addressed_to_other.matched:
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_SPEAKING,
                confidence=0.95,
                level=MMIConfidenceLevel.HIGH,
                reason="addressed_to_other",
                ignore_input=True,
                pattern_match=addressed_to_other,
            )

        if (
            not suppress_high_priority_barge_in
            and effective_observe_ms >= self._config.strong_interrupt_min_ms
            and strong_interrupt.matched
        ):
            return self._decision(
                ctx,
                MMITurnAction.START_LISTENING,
                confidence=0.95,
                level=MMIConfidenceLevel.HIGH,
                reason="strong_interrupt_intent",
                barge_in_score=0.95,
                pattern_match=strong_interrupt,
            )

        confirmation = self._patterns.confirmation(text)
        if (
            not suppress_high_priority_barge_in
            and ctx.awaiting_confirmation
            and confirmation.matched
        ):
            return self._decision(
                ctx,
                MMITurnAction.START_LISTENING,
                confidence=0.9,
                level=MMIConfidenceLevel.HIGH,
                reason="confirmation_response",
                barge_in_score=0.9,
                pattern_match=confirmation,
            )

        backchannel = self._patterns.backchannel(text)
        if backchannel.matched:
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_SPEAKING,
                confidence=0.95,
                level=MMIConfidenceLevel.HIGH,
                reason="backchannel",
                backchannel_score=0.95,
                ignore_input=True,
                pattern_match=backchannel,
            )

        invalid_or_noise = self._patterns.invalid_or_noise(text)
        if invalid_or_noise.matched:
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_SPEAKING,
                confidence=0.55,
                level=MMIConfidenceLevel.LOW,
                reason="insufficient_interruption_evidence",
                observe_more_ms=self._remaining_observation(ctx),
                pattern_match=invalid_or_noise,
            )

        # The enrollment verdict can arrive a few hundred milliseconds before
        # the final transcript exposes a trailing vocative such as "Laura".
        # Keep observing this one warmup turn unless an earlier high-priority
        # rule has already matched.
        if enrollment_partial_pending:
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_SPEAKING,
                confidence=0.65,
                level=MMIConfidenceLevel.MEDIUM,
                reason="speaker_enrollment_partial",
                observe_more_ms=self._config.observe_ms,
            )

        if self._overlapping_followup_requires_explicit_intent(ctx):
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_SPEAKING,
                confidence=0.85 if ctx.final_text else 0.65,
                level=(
                    MMIConfidenceLevel.MEDIUM
                    if ctx.final_text
                    else MMIConfidenceLevel.LOW
                ),
                reason="overlap_without_interrupt_intent",
                ignore_input=bool(ctx.final_text),
                observe_more_ms=(
                    0 if ctx.final_text else self._remaining_observation(ctx)
                ),
            )

        if (
            not suppress_barge_in
            and not ctx.vad_speech
            and bool(ctx.final_text)
            and ctx.transcript_observe_ms >= self._config.stt_only_final_interrupt_min_ms
            and self._patterns.effective_char_count(text)
            >= self._config.stt_only_final_interrupt_min_chars
        ):
            return self._decision(
                ctx,
                MMITurnAction.START_LISTENING,
                confidence=0.7,
                level=MMIConfidenceLevel.MEDIUM,
                reason="stt_only_final_interjection",
                barge_in_score=0.7,
            )

        if (
            not suppress_barge_in
            and effective_observe_ms >= self._config.ordinary_interrupt_min_ms
            and self._patterns.effective_char_count(text)
            >= self._config.ordinary_interrupt_min_chars
        ):
            return self._decision(
                ctx,
                MMITurnAction.START_LISTENING,
                confidence=0.8,
                level=MMIConfidenceLevel.MEDIUM,
                reason="ordinary_valid_interjection",
                barge_in_score=0.8,
            )

        return self._decision(
            ctx,
            MMITurnAction.CONTINUE_SPEAKING,
            confidence=0.5,
            level=MMIConfidenceLevel.LOW,
            reason=(
                "non_target_speaker_suppressed"
                if non_target_speaker
                else "low_voice_confidence_observe"
                if low_voice_confidence_pending
                else "speaker_gate_warmup"
                if speaker_gate_warmup_pending
                else "target_speaker_pending"
                if target_required_pending
                else "observe_interruption_candidate"
            ),
            barge_in_score=(
                0.0
                if non_target_speaker
                else ctx.external_voice_confidence
                if low_voice_confidence_pending
                else None
            ),
            ignore_input=speaker_identity_suppressed,
            observe_more_ms=observe_more_ms,
        )

    def _addressed_to_other(self, ctx: MMITurnContext) -> PatternMatch:
        current = self._patterns.addressed_to_other(ctx.transcript_text)
        if current.matched:
            return current
        if ctx.final_text:
            return current

        current_normalized = normalize_text(ctx.transcript_text)
        for hypothesis in reversed(ctx.transcript_hypotheses):
            historical = self._patterns.addressed_to_other(hypothesis)
            if not historical.matched:
                continue
            hypothesis_words = normalize_text(hypothesis).split()
            vocative_word_count = len(normalize_text(historical.pattern).split())
            suffix_words = hypothesis_words[vocative_word_count:]
            if len(suffix_words) < 2:
                continue
            prefix_lengths = range(min(4, len(suffix_words)), 1, -1)
            if any(
                " ".join(suffix_words[:length]) in current_normalized
                for length in prefix_lengths
            ):
                return PatternMatch(
                    matched=True,
                    rule="addressee.hypothesis_rewrite",
                    pattern=historical.pattern,
                    version=historical.version,
                )
        return current

    def _decisive_non_target(self, ctx: MMITurnContext) -> bool:
        if ctx.external_speaker_state == "TARGET_WEAK":
            return False
        if ctx.turn_speaker_state == "TARGET_WEAK":
            return False
        if ctx.external_speaker_is_target is False:
            if (
                ctx.external_speaker_verdict_kind != "decide"
                and self._turn_target_confirmed(ctx)
            ):
                return False
            sim = ctx.external_speaker_similarity
        elif ctx.turn_speaker_is_target is False:
            sim = ctx.turn_speaker_similarity
        else:
            return False
        return sim is None or sim <= self._config.speaker_non_target_sim_max

    def _target_speaker_required(self, ctx: MMITurnContext) -> bool:
        return (
            ctx.external_speaker_gate_locked is True
            or (
                self._config.require_target_speaker
                and ctx.external_speaker_gate_locked is False
            )
        )

    def _overlapping_followup_requires_explicit_intent(
        self,
        ctx: MMITurnContext,
    ) -> bool:
        return (
            self._config.require_explicit_intent_for_overlapping_followup
            and ctx.turn_id > 0
            and (
                ctx.started_during_agent_thinking
                or ctx.started_during_agent_speaking
            )
            and ctx.turn_started_after_previous_speech_ms is not None
            and (
                ctx.turn_started_after_previous_speech_ms
                >= self._config.overlapping_followup_min_gap_ms
            )
            and not self._patterns.explicit_overlap_intent(
                ctx.transcript_text
            ).matched
        )

    def _external_target_confirmed(
        self,
        ctx: MMITurnContext,
        *,
        min_similarity: float | None = None,
    ) -> bool:
        if not (
            ctx.external_speaker_state == "TARGET_CONFIDENT"
            or ctx.external_speaker_is_target is True
        ):
            return False
        return self._similarity_confirmed(
            ctx.external_speaker_similarity,
            min_similarity=min_similarity,
        )

    def _turn_target_confirmed(
        self,
        ctx: MMITurnContext,
        *,
        min_similarity: float | None = None,
    ) -> bool:
        if ctx.turn_speaker_age_ms is not None and (
            ctx.turn_speaker_age_ms > self._config.target_latch_max_ms
        ):
            return False
        if not (
            ctx.turn_speaker_state == "TARGET_CONFIDENT"
            or ctx.turn_speaker_is_target is True
        ):
            return False
        return self._similarity_confirmed(
            ctx.turn_speaker_similarity,
            min_similarity=min_similarity,
        )

    @staticmethod
    def _similarity_confirmed(
        similarity: float | None,
        *,
        min_similarity: float | None = None,
    ) -> bool:
        if min_similarity is None:
            return True
        return similarity is not None and similarity >= min_similarity

    def _target_speaker_confirmed(self, ctx: MMITurnContext) -> bool:
        if self._external_target_confirmed(ctx):
            return True
        if ctx.external_speaker_state in {"TARGET_WEAK", "NON_TARGET", "UNKNOWN"}:
            return False
        if self._turn_target_confirmed(ctx):
            return True
        return False

    def _interrupt_target_confirmed(self, ctx: MMITurnContext) -> bool:
        if ctx.external_speaker_gate_locked is not True:
            return self._target_speaker_confirmed(ctx)
        min_similarity = self._config.interrupt_target_min_similarity
        if self._external_target_confirmed(
            ctx,
            min_similarity=min_similarity,
        ):
            return True
        if ctx.external_speaker_state in {"TARGET_WEAK", "NON_TARGET", "UNKNOWN"}:
            return False
        return self._turn_target_confirmed(
            ctx,
            min_similarity=min_similarity,
        )

    def _remaining_observation(self, ctx: MMITurnContext) -> int:
        effective_observe_ms = max(ctx.speech_ms, ctx.transcript_observe_ms)
        text = ctx.transcript_text
        if self._patterns.strong_interrupt(text).matched:
            target_ms = self._config.strong_interrupt_min_ms
        elif (
            not ctx.vad_speech
            and bool(ctx.final_text)
            and self._patterns.effective_char_count(text)
            >= self._config.stt_only_final_interrupt_min_chars
        ):
            target_ms = self._config.stt_only_final_interrupt_min_ms
        elif (
            self._patterns.effective_char_count(text)
            >= self._config.ordinary_interrupt_min_chars
        ):
            target_ms = self._config.ordinary_interrupt_min_ms
        else:
            target_ms = self._config.max_observe_ms
        if effective_observe_ms >= target_ms:
            return 0
        return min(self._config.observe_ms, target_ms - effective_observe_ms)

    def _decision(
        self,
        ctx: MMITurnContext,
        action: MMITurnAction,
        *,
        confidence: float,
        level: MMIConfidenceLevel,
        reason: str,
        barge_in_score: float | None = None,
        backchannel_score: float | None = None,
        ignore_input: bool = False,
        observe_more_ms: int = 0,
        pattern_match: PatternMatch | None = None,
    ) -> MMITurnDecision:
        pattern_match = pattern_match or PatternMatch(version=self._patterns.version)
        return MMITurnDecision(
            action=action,
            confidence=confidence,
            confidence_level=level,
            reason=reason,
            barge_in_score=barge_in_score,
            backchannel_score=backchannel_score,
            ignore_input=ignore_input,
            observe_more_ms=observe_more_ms,
            pattern_version=pattern_match.version,
            matched_rule=pattern_match.rule,
            matched_pattern=pattern_match.pattern,
            turn_id=ctx.turn_id,
            based_on_event_id=ctx.event_id,
        )

"""Session-level MMI-TD runtime and LiveKit event integration."""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import logging
import threading
import time
from dataclasses import replace
from typing import Any, Coroutine

from livekit.agents import AgentSession

from .context_store import MMITurnContextStore
from .detector import RuleBasedMMITurnDetector
from .endpointing_policy import BaselineEndpointingPolicy, EndpointingPolicyConfig
from .eou_service import EOUService
from .executor import MMITurnExecutor, StaleDecisionError
from .fast_path_shadow import build_fast_path_shadow
from .interruption_policy import InterruptionPolicyConfig, RuleBasedInterruptionPolicy
from .models import (
    MMIConfidenceLevel,
    MMIMode,
    MMIRuntimeState,
    MMITurnAction,
    MMITurnDecision,
)
from .patterns import MultilingualPatternMatcher
from .response_watchdog import MMIResponseWatchdog
from .semantic_overlay import build_online_semantic_overlay

logger = logging.getLogger("health-agent.mmi.runtime")
# 前端 NoiseGate 调试转发：子 logger 会传播到 health-agent.mmi 的文件 handler，
# 因此直接落进同一个 mmi_turn_detection_active.log，省去移动端 F12。
client_logger = logging.getLogger("health-agent.mmi.client")


def resolve_mmi_mode(
    config: Any,
    *,
    pipeline: str,
    session_id: str,
    text_signals_available: bool = True,
) -> MMIMode:
    requested = MMIMode(config.mode)
    if requested == MMIMode.OFF:
        return MMIMode.OFF
    if pipeline not in config.enabled_pipelines:
        return MMIMode.OFF
    if requested == MMIMode.SHADOW:
        return MMIMode.SHADOW
    if not text_signals_available:
        return MMIMode.SHADOW

    bucket = int(hashlib.sha256(session_id.encode()).hexdigest()[:8], 16) % 100
    return MMIMode.ACTIVE if bucket < config.active_percentage else MMIMode.SHADOW


class MMITurnRuntime:
    """Collect signals, decide actions, and optionally control a LiveKit session."""

    def __init__(
        self,
        *,
        session: AgentSession,
        session_id: str,
        mode: MMIMode,
        config: Any,
        room: Any = None,
    ) -> None:
        self.session = session
        self.mode = mode
        self.config = config
        # LiveKit room：用于接收前端经数据通道发来的语音置信度（topic="mmi"）。
        self.room = room
        speaker_non_target_sim_max = getattr(config, "speaker_non_target_sim_max", 0.18)
        require_target_speaker = getattr(config, "require_target_speaker", False)
        overlapping_followup_min_gap_ms = getattr(
            config,
            "overlapping_followup_min_gap_ms",
            2000,
        )
        interrupt_target_min_similarity = getattr(
            config,
            "interrupt_target_min_similarity",
            0.44,
        )
        target_latch_max_ms = getattr(config, "target_latch_max_ms", 3000)
        endpoint_target_latch_max_ms = getattr(
            config,
            "endpoint_target_latch_max_ms",
            15000,
        )
        self.store = MMITurnContextStore(
            session_id=session_id,
            speaker_non_target_sim_max=speaker_non_target_sim_max,
        )
        self.patterns = MultilingualPatternMatcher.from_file(
            getattr(config, "patterns_file", ""),
            enabled_locales=getattr(config, "pattern_locales", ("zh-CN", "en-US")),
        )
        self.endpointing_policy = BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=int(config.min_endpointing_delay * 1000),
                complete_statement_delay_ms=int(
                    getattr(
                        config,
                        "complete_statement_endpointing_delay",
                        config.min_endpointing_delay,
                    )
                    * 1000
                ),
                uncertain_delay_ms=int(
                    getattr(config, "uncertain_endpointing_delay", 1.5) * 1000
                ),
                max_delay_ms=int(config.max_endpointing_delay * 1000),
                eou_complete_threshold_floor=getattr(
                    config,
                    "eou_complete_threshold_floor",
                    0.2,
                ),
                wait_intent_max_ms=config.wait_intent_max_ms,
                speaker_non_target_sim_max=speaker_non_target_sim_max,
                require_target_speaker=require_target_speaker,
                require_explicit_intent_for_overlapping_followup=getattr(
                    config,
                    "require_explicit_intent_for_overlapping_followup",
                    False,
                ),
                overlapping_followup_min_gap_ms=overlapping_followup_min_gap_ms,
                target_latch_max_ms=endpoint_target_latch_max_ms,
            ),
            patterns=self.patterns,
        )
        self.detector = RuleBasedMMITurnDetector(
            interruption_policy=RuleBasedInterruptionPolicy(
                InterruptionPolicyConfig(
                    strong_interrupt_min_ms=config.strong_interrupt_min_ms,
                    ordinary_interrupt_min_ms=config.ordinary_interrupt_min_ms,
                    ordinary_interrupt_min_chars=config.ordinary_interrupt_min_chars,
                    stt_only_final_interrupt_min_ms=config.stt_only_final_interrupt_min_ms,
                    stt_only_final_interrupt_min_chars=config.stt_only_final_interrupt_min_chars,
                    observe_ms=config.observe_ms,
                    max_observe_ms=config.max_observe_ms,
                    speaker_non_target_sim_max=speaker_non_target_sim_max,
                    require_target_speaker=require_target_speaker,
                    require_explicit_intent_for_overlapping_followup=getattr(
                        config,
                        "require_explicit_intent_for_overlapping_followup",
                        False,
                    ),
                    overlapping_followup_min_gap_ms=overlapping_followup_min_gap_ms,
                    interrupt_target_min_similarity=interrupt_target_min_similarity,
                    target_latch_max_ms=target_latch_max_ms,
                ),
                patterns=self.patterns,
            ),
            endpointing_policy=self.endpointing_policy,
            patterns=self.patterns,
        )
        self.eou_service = EOUService(timeout_ms=config.eou_timeout_ms)
        self.response_watchdog = (
            MMIResponseWatchdog(
                session,
                session_id=session_id,
                is_current_turn=lambda turn_id: (
                    not self._closed
                    and self.store.turn_id == turn_id
                    and (self.store.committed or self.store.commit_pending)
                ),
                first_output_timeout_ms=int(
                    getattr(config, "empty_response_timeout_ms", 20_000)
                ),
                max_retries=int(getattr(config, "empty_response_max_retries", 1)),
                cancel_grace_ms=int(
                    getattr(config, "empty_response_cancel_grace_ms", 3_000)
                ),
            )
            if mode == MMIMode.ACTIVE
            and bool(getattr(config, "empty_response_retry_enabled", False))
            else None
        )
        self.executor = MMITurnExecutor(
            session,
            self.store,
            force_interruptions=mode == MMIMode.ACTIVE,
            response_watchdog=self.response_watchdog,
        )
        self.semantic_overlay = (
            build_online_semantic_overlay(config)
            if mode == MMIMode.SHADOW
            else None
        )
        self.fast_path_shadow = (
            build_fast_path_shadow(config)
            if mode == MMIMode.SHADOW
            else None
        )

        self._endpointing_task: asyncio.Task[None] | None = None
        self._observation_task: asyncio.Task[None] | None = None
        self._eou_task: asyncio.Task[None] | None = None
        self._wait_task: asyncio.Task[None] | None = None
        self._fail_safe_interrupt_task: asyncio.Task[None] | None = None
        self._fast_path_deadline_task: asyncio.Task[None] | None = None
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self._closed = False
        self._fail_safe = False
        self._native_interruption_speech_id: int | None = None
        self._pending_native_stop: tuple[int, Any] | None = None
        self._pending_native_stop_at: float | None = None
        self._last_shadow_interruption_context: Any | None = None
        self._event_loop: asyncio.AbstractEventLoop | None = None
        self._speaker_signal_lock = threading.Lock()
        self._speaker_signal_sequence = 0

    def setup(self) -> None:
        if self.mode == MMIMode.OFF:
            return
        try:
            self._event_loop = asyncio.get_running_loop()
        except RuntimeError:
            self._event_loop = None
        self.session.on("user_state_changed")(self._on_user_state_changed)
        self.session.on("agent_state_changed")(self._on_agent_state_changed)
        self.session.on("user_input_transcribed")(self._on_user_input_transcribed)
        self.session.on("conversation_item_added")(self._on_conversation_item_added)
        self.session.on("agent_false_interruption")(self._on_false_interruption)
        self.session.on("close")(self._on_close)
        if self.response_watchdog is not None:
            self.response_watchdog.setup()
        if self.room is not None:
            try:
                self.room.on("data_received", self._on_data_received)
            except Exception:
                logger.warning("[MMI-TD] failed to subscribe room data_received", exc_info=True)
        logger.info(
            "[MMI-TD] runtime enabled session=%s mode=%s pattern_version=%s "
            "locales=%s semantic_overlay_shadow=%s fast_path_shadow=%s "
            "response_watchdog=%s",
            self.store.session_id,
            self.mode.value,
            self.patterns.version,
            ",".join(self.patterns.enabled_locales),
            self.semantic_overlay is not None,
            self.fast_path_shadow is not None,
            self.response_watchdog is not None,
        )

    def set_awaiting_confirmation(self, value: bool) -> None:
        self.store.awaiting_confirmation = value
        self.store.next_event()

    def on_speaker_verdict(
        self,
        is_target: bool | None,
        similarity: float | None = None,
        kind: str | None = None,
        state: str | None = None,
    ) -> None:
        """Receive a SpeakerGate verdict from its worker thread."""
        received_at = time.monotonic()
        self.store.on_speaker_verdict(is_target, similarity, kind, state)
        with self._speaker_signal_lock:
            self._speaker_signal_sequence += 1
            sequence = self._speaker_signal_sequence
        turn_id = self.store.turn_id
        event_id = self.store.event_id
        logger.info(
            "[MMI-TD] speaker_verdict_callback %s",
            json.dumps(
                {
                    "session_id": self.store.session_id,
                    "sequence": sequence,
                    "turn_id": turn_id,
                    "event_id": event_id,
                    "is_target": is_target,
                    "similarity": similarity,
                    "kind": kind,
                    "state": state,
                    "thread": threading.current_thread().name,
                },
                ensure_ascii=False,
            ),
        )
        loop = self._event_loop
        if self._closed or loop is None or loop.is_closed():
            logger.debug(
                "[MMI-TD] speaker verdict recheck unavailable session=%s sequence=%s",
                self.store.session_id,
                sequence,
            )
            return
        loop.call_soon_threadsafe(
            self._on_speaker_verdict_on_loop,
            sequence,
            turn_id,
            event_id,
            received_at,
            state,
        )

    def on_speaker_gate_status(self, locked: bool | None) -> None:
        """Receive SpeakerGate lock status without touching asyncio from its worker."""
        self.store.on_speaker_gate_status(locked)
        logger.info(
            "[MMI-TD] speaker_gate_status session=%s locked=%s thread=%s",
            self.store.session_id,
            locked,
            threading.current_thread().name,
        )

    def _on_speaker_verdict_on_loop(
        self,
        sequence: int,
        turn_id: int,
        event_id: int,
        received_at: float,
        state: str | None,
    ) -> None:
        queue_delay_ms = max(0.0, (time.monotonic() - received_at) * 1000)
        with self._speaker_signal_lock:
            latest_sequence = self._speaker_signal_sequence
        if self._closed or sequence != latest_sequence or turn_id != self.store.turn_id:
            logger.info(
                "[MMI-TD] speaker_verdict_recheck_skipped %s",
                json.dumps(
                    {
                        "session_id": self.store.session_id,
                        "sequence": sequence,
                        "latest_sequence": latest_sequence,
                        "verdict_turn_id": turn_id,
                        "current_turn_id": self.store.turn_id,
                        "reason": "stale_signal",
                        "queue_delay_ms": round(queue_delay_ms, 3),
                    },
                    ensure_ascii=False,
                ),
            )
            return
        if state is None:
            return

        context = self._speaker_recheck_context(turn_id)
        if context is None or (
            not context.transcript_text and self.fast_path_shadow is None
        ):
            logger.info(
                "[MMI-TD] speaker_verdict_recheck_skipped %s",
                json.dumps(
                    {
                        "session_id": self.store.session_id,
                        "sequence": sequence,
                        "verdict_turn_id": turn_id,
                        "current_event_id": self.store.event_id,
                        "verdict_event_id": event_id,
                        "reason": "no_current_turn_context",
                        "queue_delay_ms": round(queue_delay_ms, 3),
                    },
                    ensure_ascii=False,
                ),
            )
            return

        trigger = (
            "speaker_verdict_after_native_interrupt"
            if self.mode == MMIMode.SHADOW and context.agent_state == "speaking"
            and self.store.agent_state != "speaking"
            else "speaker_verdict_recheck"
        )
        self._observe_fast_path_audio_context(
            context,
            trigger=trigger,
            observed_at=received_at,
        )
        logger.info(
            "[MMI-TD] speaker_verdict_recheck %s",
            json.dumps(
                {
                    "session_id": self.store.session_id,
                    "sequence": sequence,
                    "turn_id": turn_id,
                    "verdict_event_id": event_id,
                    "current_event_id": self.store.event_id,
                    "trigger": trigger,
                    "queue_delay_ms": round(queue_delay_ms, 3),
                },
                ensure_ascii=False,
            ),
        )
        if self.mode == MMIMode.SHADOW:
            self._schedule_shadow_comparison(
                trigger,
                context,
                signal_received_at=received_at,
            )
        else:
            self._schedule_decision(trigger, signal_received_at=received_at)

    def _speaker_recheck_context(self, turn_id: int) -> Any | None:
        current = self.store.snapshot()
        saved = self._last_shadow_interruption_context
        if saved is not None and saved.turn_id == turn_id:
            base = saved
        elif current.turn_id != turn_id:
            return None
        elif current.started_during_agent_speaking:
            base = (
                current
                if current.agent_state == "speaking"
                else self._shadow_interruption_context()
            )
        elif current.started_during_agent_thinking:
            base = replace(current, agent_state="thinking", tts_playing=False)
        elif current.user_turn_active:
            base = current
        else:
            return None
        return replace(
            base,
            event_id=current.event_id,
            external_speaker_is_target=current.external_speaker_is_target,
            external_speaker_state=current.external_speaker_state,
            external_speaker_similarity=current.external_speaker_similarity,
            external_speaker_verdict_kind=current.external_speaker_verdict_kind,
            external_speaker_gate_locked=current.external_speaker_gate_locked,
            turn_speaker_is_target=current.turn_speaker_is_target,
            turn_speaker_state=current.turn_speaker_state,
            turn_speaker_similarity=current.turn_speaker_similarity,
            turn_speaker_verdict_kind=current.turn_speaker_verdict_kind,
            turn_speaker_age_ms=current.turn_speaker_age_ms,
        )

    def _on_data_received(self, *args: Any) -> None:
        """接收前端 NoiseGate 的语音置信度（topic="mmi"）。容错：任何异常都忽略。"""
        try:
            packet = args[0] if args else None
            if packet is None:
                return
            raw = getattr(packet, "data", None)
            topic = getattr(packet, "topic", None)
            if raw is None and isinstance(packet, (bytes, bytearray)):
                # 兼容旧签名 (payload, participant, kind, topic)
                raw = packet
                topic = args[3] if len(args) > 3 else None
            if topic not in (None, "", "mmi"):
                return
            if raw is None:
                return
            payload = json.loads(bytes(raw).decode("utf-8"))
            mtype = payload.get("type")
            if mtype == "gate_debug":
                self._log_client_gate_debug(payload)
                return
            if mtype != "voice_confidence":
                return
            conf = payload.get("confidence")
            if not isinstance(conf, (int, float)):
                return
            energy = payload.get("energyDb")
            self.store.on_voice_confidence(
                float(conf),
                float(energy) if isinstance(energy, (int, float)) else None,
            )
        except Exception:
            logger.debug("[MMI-TD] failed to parse data packet", exc_info=True)

    def _log_client_gate_debug(self, payload: dict[str, Any]) -> None:
        """把前端 NoiseGate 调试信息打到 agent 端日志（落入 MMI 日志文件）。"""
        session = self.store.session_id
        if payload.get("kind") == "session_start":
            client_logger.info(
                "[CLIENT-GATE] session_start session=%s engine=%s version=%s mic=%s ua=%s",
                session,
                payload.get("engine"),
                payload.get("version"),
                json.dumps(payload.get("mic"), ensure_ascii=False),
                payload.get("ua"),
            )
        else:
            client_logger.info(
                "[CLIENT-GATE] snapshot session=%s %s",
                session,
                json.dumps(payload.get("debug"), ensure_ascii=False),
            )

    def _on_user_state_changed(self, event: Any) -> None:
        if event.new_state == "speaking":
            if self._current_turn_is_decisive_non_target():
                self._discard_current_turn("non_target_speaker_ignored")
            self.store.on_user_speaking(
                force_new_turn=self.store.agent_state in {"thinking", "speaking"},
            )
            if self.store.agent_state in {"speaking", "thinking"}:
                self._start_fast_path_shadow(source="user_state_changed")
            if (
                self._last_shadow_interruption_context is not None
                and self._last_shadow_interruption_context.turn_id != self.store.turn_id
            ):
                self._last_shadow_interruption_context = None
            self._cancel_task("_endpointing_task")
            self._cancel_task("_eou_task")
            self._cancel_task("_wait_task")
            if self.store.agent_state == "speaking":
                if self._fail_safe:
                    self._schedule_fail_safe_interrupt()
                else:
                    self._schedule_decision(
                        "user_started_speaking",
                        require_agent_speaking=True,
                    )
        elif event.new_state == "listening":
            self.store.on_user_listening(
                silence_offset_ms=self.config.vad_silence_offset_ms,
            )
            if self.store.agent_state in {"speaking", "thinking"}:
                self._resolve_fast_path_shadow("user_stopped_without_native_stop")
            if self.store.agent_state == "speaking":
                if self.mode == MMIMode.SHADOW:
                    self._log_native_action(
                        MMITurnAction.CONTINUE_SPEAKING,
                        trigger="user_stopped_during_agent_speech",
                    )
                self._schedule_decision(
                    "user_stopped_during_agent_speech",
                    require_agent_speaking=True,
                )
            else:
                self._schedule_endpointing()

    def _on_agent_state_changed(self, event: Any) -> None:
        previous_state = self.store.agent_state
        previous_speech_id = self.store.agent_speech_id
        previous_user_turn_active = self.store.user_turn_active
        previous_context = self.store.snapshot()
        state_changed_at = time.monotonic()
        if (
            previous_state in {"speaking", "thinking"}
            and event.new_state in {"idle", "listening"}
        ):
            self._mark_fast_path_stop_candidate(
                previous_context.turn_id,
                previous_speech_id,
                observed_at=state_changed_at,
            )
        self.store.on_agent_state(event.new_state)
        active_user_input = (
            not self.store.commit_pending
            and self.store.user_turn_active
            and (
                self.store.user_state == "speaking"
                or bool(self.store.transcript_text)
            )
        )
        if event.new_state == "thinking" and active_user_input:
            self.store.started_during_agent_thinking = True
            if self._should_preempt_short_gap_continuation():
                self._spawn_background(
                    self.executor.cancel_pending_reply_for_user_continuation()
                )
        elif event.new_state == "speaking" and active_user_input:
            if self._fail_safe:
                self._schedule_fail_safe_interrupt()
            else:
                self._schedule_decision(
                    "agent_started_during_user_turn",
                    require_agent_speaking=True,
                )
        if (
            self.mode == MMIMode.SHADOW
            and previous_state == "speaking"
            and event.new_state != "speaking"
        ):
            self._pending_native_stop = (
                self.store.agent_speech_id,
                previous_context,
            )
            self._pending_native_stop_at = state_changed_at
        elif (
            self.mode == MMIMode.ACTIVE
            and previous_state == "speaking"
            and event.new_state != "speaking"
            and previous_user_turn_active
            and (
                previous_context.user_state == "speaking"
                or bool(previous_context.transcript_text)
            )
            and self.store.interrupted_agent_speech_id != previous_speech_id
        ):
            logger.warning(
                "[MMI-TD] agent stopped during active user input without MMI "
                "START_LISTENING session=%s speech=%s new_state=%s "
                "user_state=%s transcript_len=%s",
                self.store.session_id,
                previous_speech_id,
                event.new_state,
                previous_context.user_state,
                len(previous_context.transcript_text),
            )
        if event.new_state != "speaking":
            self._cancel_task("_observation_task")
            if self.store.user_state == "listening" and not self.store.committed:
                self._schedule_endpointing()

    def _should_preempt_short_gap_continuation(self) -> bool:
        gap_ms = self.store.turn_started_after_previous_speech_ms
        return (
            self.mode == MMIMode.ACTIVE
            and getattr(
                self.config,
                "require_explicit_intent_for_overlapping_followup",
                False,
            )
            and gap_ms is not None
            and gap_ms
            < getattr(self.config, "overlapping_followup_min_gap_ms", 2000)
        )

    def _on_user_input_transcribed(self, event: Any) -> None:
        text = (event.transcript or "").strip()
        self.store.on_transcript(text, is_final=event.is_final)
        if self.store.agent_state in {"speaking", "thinking"}:
            self._start_fast_path_shadow(
                source="user_input_transcribed",
                observed_at=self.store.transcript_started_at,
            )
        if self.semantic_overlay is not None:
            self._spawn_background(
                self.semantic_overlay.observe_transcript(
                    self.store.snapshot(),
                    is_final=bool(event.is_final),
                )
            )
        if event.is_final and self.store.user_state != "speaking":
            self.store.ensure_listening_silence(
                silence_offset_ms=self.config.vad_silence_offset_ms,
            )
        if self.store.agent_state == "speaking":
            self._schedule_decision(
                "user_transcript_during_agent_speech",
                require_agent_speaking=True,
            )
        elif self.store.agent_state == "thinking":
            # Classify strong controls and backchannels before endpointing can
            # turn them into a replacement request for the pending reply.
            if self.mode == MMIMode.SHADOW:
                self._schedule_shadow_comparison(
                    "user_transcript_during_agent_thinking",
                    self.store.snapshot(),
                )
            else:
                self._schedule_decision("user_transcript_during_agent_thinking")
        else:
            if (
                self.mode == MMIMode.SHADOW
                and self.store.started_during_agent_speaking
                and self._native_interruption_speech_id == self.store.agent_speech_id
            ):
                self._schedule_shadow_comparison(
                    "shadow_transcript_after_native_interrupt",
                    self._shadow_interruption_context(),
                )
            if event.is_final and self.store.user_state != "speaking":
                self._schedule_endpointing()

    def _on_conversation_item_added(self, event: Any) -> None:
        item = event.item
        role = getattr(item, "role", "")
        text = (getattr(item, "text_content", None) or "").strip()
        if role == "assistant":
            speech_id = self.store.agent_speech_id
            pending_stop = self._pending_native_stop
            if not getattr(item, "interrupted", False):
                self._resolve_fast_path_shadow("natural_agent_stop")
            if (
                self.mode == MMIMode.ACTIVE
                and getattr(item, "interrupted", False)
                and self.store.interrupted_agent_speech_id != speech_id
            ):
                logger.warning(
                    "[MMI-TD] assistant item interrupted outside MMI executor "
                    "session=%s speech=%s",
                    self.store.session_id,
                    speech_id,
                )
            if (
                self.mode == MMIMode.SHADOW
                and getattr(item, "interrupted", False)
                and self._native_interruption_speech_id != speech_id
            ):
                pre_stop_context = (
                    pending_stop[1]
                    if pending_stop is not None and pending_stop[0] == speech_id
                    else None
                )
                comparison_context = self._shadow_interruption_context(pre_stop_context)
                self._ensure_fast_path_for_native_stop(
                    comparison_context,
                    speech_id,
                    stop_at=self._pending_native_stop_at,
                )
                self._confirm_fast_path_native_stop(
                    comparison_context.turn_id,
                    speech_id,
                    trigger="assistant_item_interrupted",
                )
                self._last_shadow_interruption_context = comparison_context
                self._schedule_shadow_comparison(
                    "native_assistant_item_interrupted",
                    comparison_context,
                )
                self._log_native_action(
                    MMITurnAction.START_LISTENING,
                    trigger="assistant_item_interrupted",
                )
                self._native_interruption_speech_id = speech_id
            if pending_stop is not None and pending_stop[0] == speech_id:
                self._pending_native_stop = None
                self._pending_native_stop_at = None
            if text:
                self.store.last_agent_text = text
        elif role == "user":
            if text:
                self.store.last_user_text = text
            if self.mode == MMIMode.SHADOW:
                if text:
                    self._schedule_shadow_comparison(
                        "native_user_turn_committed",
                        self.store.snapshot(),
                    )
                    self._log_native_action(
                        MMITurnAction.START_SPEAKING,
                        trigger="conversation_user_turn_committed",
                    )
                    # Shadow mode never executes MMI decisions, but the native
                    # LiveKit conversation item is authoritative evidence that
                    # this user turn was accepted. Publish the same commit
                    # protocol expected by older frontends so their pending
                    # final STT cannot remain hidden forever.
                    self._publish_transcript_commit(
                        "native_user_turn_committed",
                        text,
                    )
                self._confirm_commit(trigger="native_conversation_user_item")
            elif self.mode == MMIMode.ACTIVE and not self.store.committed:
                logger.warning(
                    "[MMI-TD] observed user conversation item before current "
                    "MMI turn completed; ignoring for state correlation "
                    "session=%s turn=%s item_text_len=%s current_text_len=%s",
                    self.store.session_id,
                    self.store.turn_id,
                    len(text),
                    len(self.store.transcript_text),
                )

    def _on_false_interruption(self, event: Any) -> None:
        logger.info(
            "[MMI-TD] livekit false interruption session=%s resumed=%s",
            self.store.session_id,
            getattr(event, "resumed", False),
        )

    def _on_close(self, _event: Any) -> None:
        self.close()

    def _schedule_decision(
        self,
        trigger: str,
        *,
        require_agent_speaking: bool = False,
        signal_received_at: float | None = None,
    ) -> None:
        if self._closed:
            return
        agent_speech_id = self.store.agent_speech_id if require_agent_speaking else None
        self._spawn_background(
            self._decide(
                trigger,
                expected_agent_speech_id=agent_speech_id,
                signal_received_at=signal_received_at,
            )
        )

    def _schedule_shadow_comparison(
        self,
        trigger: str,
        context: Any,
        *,
        signal_received_at: float | None = None,
    ) -> None:
        if self._closed or self.mode != MMIMode.SHADOW:
            return
        self._spawn_background(
            self._compare_shadow_action(
                trigger,
                context,
                signal_received_at=signal_received_at,
            )
        )

    def _shadow_interruption_context(self, pre_stop_context: Any | None = None) -> Any:
        """Build the control context that Shadow would have seen before native stop."""
        current = self.store.snapshot()
        return replace(
            current,
            agent_state="speaking",
            tts_playing=True,
            started_during_agent_speaking=(
                current.started_during_agent_speaking
                or bool(
                    pre_stop_context is not None
                    and pre_stop_context.started_during_agent_speaking
                )
            ),
            last_agent_text=(
                current.last_agent_text
                or (
                    pre_stop_context.last_agent_text
                    if pre_stop_context is not None
                    else ""
                )
            ),
        )

    def _confirm_commit(self, *, trigger: str) -> None:
        if self.store.committed and not self.store.commit_pending:
            return
        requested_text = self.store.commit_requested_text
        attempts = self.store.commit_attempt_count
        self.store.confirm_commit()
        self._cancel_task("_endpointing_task")
        self._cancel_task("_eou_task")
        logger.info(
            "[MMI-TD] user turn commit confirmed session=%s turn=%s "
            "trigger=%s attempts=%s requested_text_len=%s",
            self.store.session_id,
            self.store.turn_id,
            trigger,
            attempts,
            len(requested_text),
        )

    async def _compare_shadow_action(
        self,
        trigger: str,
        context: Any,
        *,
        signal_received_at: float | None = None,
    ) -> None:
        try:
            if (
                trigger == "native_user_turn_committed"
                and context.transcript_text
                and context.eou_prob is None
            ):
                probability, threshold = await self.eou_service.predict(
                    self.session,
                    text=context.transcript_text,
                    locale=context.locale,
                )
                context = replace(
                    context,
                    eou_prob=probability,
                    eou_unlikely_threshold=threshold,
                )
            decision = await asyncio.wait_for(
                self.detector.detect(context),
                timeout=self.config.decision_timeout_ms / 1000,
            )
            self._observe_fast_path_decision(decision, context, trigger)
            self._observe_semantic_overlay_decision(decision, context, trigger)
            self._log_decision(
                decision,
                trigger=trigger,
                executed=False,
                context=context,
                event_processing_latency_ms=self._elapsed_ms(signal_received_at),
            )
        except Exception:
            logger.exception("[MMI-TD] shadow comparison failed trigger=%s", trigger)

    async def _decide(
        self,
        trigger: str,
        *,
        expected_agent_speech_id: int | None = None,
        signal_received_at: float | None = None,
    ) -> None:
        if self._closed or self._fail_safe:
            return
        if (
            expected_agent_speech_id is not None
            and (
                self.store.agent_state != "speaking"
                or self.store.agent_speech_id != expected_agent_speech_id
            )
        ):
            return
        context = self.store.snapshot()
        try:
            decision = await asyncio.wait_for(
                self.detector.detect(context),
                timeout=self.config.decision_timeout_ms / 1000,
            )
            self.store.consecutive_error_count = 0
            await self._handle_decision(
                decision,
                trigger,
                context=context,
                event_processing_latency_ms=self._elapsed_ms(signal_received_at),
            )
        except StaleDecisionError:
            logger.debug("[MMI-TD] skipped stale decision trigger=%s", trigger)
        except Exception:
            logger.exception("[MMI-TD] decision failed trigger=%s", trigger)
            self.store.consecutive_error_count += 1
            if self.store.consecutive_error_count >= self.config.max_consecutive_errors:
                self._enter_fail_safe("max_consecutive_errors")

    async def _handle_decision(
        self,
        decision: MMITurnDecision,
        trigger: str,
        *,
        context: Any | None = None,
        event_processing_latency_ms: float | None = None,
    ) -> None:
        executed = False
        if decision.wait_intent:
            wait_text = (
                context.latest_transcript_text
                if context is not None
                else self.store.latest_transcript_text
            )
            self.store.consume_wait_intent(
                decision.matched_pattern or wait_text or self.store.transcript_text
            )
            self.store.runtime_state = MMIRuntimeState.WAITING_USER
            self._schedule_wait_timeout()

        if self.mode == MMIMode.ACTIVE:
            if decision.wait_intent and self.store.agent_state == "thinking":
                executed = await self.executor.cancel_pending_reply_for_wait()
            else:
                executed = await self.executor.execute(decision)
            if executed and decision.action == MMITurnAction.START_SPEAKING:
                commit_text = (
                    self.store.commit_requested_text
                    or self.store.commit_transcript_text
                    or (context.transcript_text if context is not None else "")
                )
                self._publish_transcript_commit(decision.reason, commit_text)
            if decision.action == MMITurnAction.START_LISTENING:
                self._cancel_task("_observation_task")
                if self.store.user_state != "speaking":
                    self._schedule_endpointing()

        self._log_decision(
            decision,
            trigger=trigger,
            executed=executed,
            context=context,
            event_processing_latency_ms=event_processing_latency_ms,
        )
        self._observe_fast_path_decision(decision, context, trigger)
        self._observe_semantic_overlay_decision(decision, context, trigger)

        if (
            decision.ignore_input
            and self.store.user_state != "speaking"
            and self.store.user_turn_active
            and (bool(self.store.final_text) or not self.store.transcript_text)
        ):
            self._discard_current_turn(decision.reason)
            return

        if (
            decision.action == MMITurnAction.CONTINUE_SPEAKING
            and bool(self.store.final_text)
            and (decision.ignore_input or self.store.agent_state != "speaking")
        ):
            self._discard_current_turn(decision.reason)

        if (
            decision.action == MMITurnAction.CONTINUE_SPEAKING
            and decision.observe_more_ms > 0
            and self.store.agent_state == "speaking"
            and (
                bool(self.store.transcript_text)
                or self.fast_path_shadow is not None
            )
        ):
            self._schedule_observation(decision.observe_more_ms)
        elif (
            decision.action == MMITurnAction.CONTINUE_LISTENING
            and not decision.wait_intent
            and decision.observe_more_ms > 0
            and self.store.user_state != "speaking"
        ):
            self._cancel_task("_endpointing_task")
            event_id = self.store.event_id
            self._endpointing_task = asyncio.create_task(
                self._endpoint_after(decision.observe_more_ms, event_id)
            )
            self._endpointing_task.add_done_callback(self._log_task_error)

    def _schedule_endpointing(self) -> None:
        if (
            self.store.wait_intent_active
            and not self.endpointing_policy.wait_intent_still_active(
                self.store.snapshot()
            )
        ):
            self.store.wait_intent_active = False
            self._cancel_task("_wait_task")
            logger.info(
                "[MMI-TD] released wait intent after substantive continuation "
                "session=%s turn=%s",
                self.store.session_id,
                self.store.turn_id,
            )
        if (
            self._closed
            or self.store.committed
            or self.store.commit_pending
            or not self.store.user_turn_active
            or self.store.wait_intent_active
        ):
            return
        self._cancel_task("_endpointing_task")
        self._cancel_task("_eou_task")
        event_id = self.store.event_id
        self._eou_task = asyncio.create_task(self._prepare_endpointing(event_id))
        self._eou_task.add_done_callback(self._log_task_error)

    def _discard_current_turn(self, reason: str) -> None:
        transcript_text = self.store.transcript_text
        logger.info(
            "[MMI-TD] discarded ignored user turn session=%s turn=%s reason=%s",
            self.store.session_id,
            self.store.turn_id,
            reason,
        )
        self._cancel_task("_endpointing_task")
        self._cancel_task("_eou_task")
        if self.mode == MMIMode.ACTIVE:
            try:
                self.session.clear_user_turn()
            except Exception:
                logger.exception(
                    "[MMI-TD] failed to clear LiveKit user turn session=%s turn=%s",
                    self.store.session_id,
                    self.store.turn_id,
                )
        self._publish_transcript_retract(reason, transcript_text)
        self.store.consume_current_turn()

    def _current_turn_is_decisive_non_target(self) -> bool:
        if (
            self.store.committed
            or self.store.commit_pending
            or not self.store.user_turn_active
            or not self.store.transcript_text
            or self.store.turn_speaker_state == "TARGET_WEAK"
        ):
            return False
        if self.store.turn_speaker_is_target is not False:
            return False
        sim = self.store.turn_speaker_similarity
        return sim is None or sim <= self.store.speaker_non_target_sim_max

    def _publish_transcript_commit(self, reason: str, text: str) -> None:
        self._publish_transcript_control("transcript_commit", reason, text)

    def _publish_transcript_retract(self, reason: str, text: str) -> None:
        self._publish_transcript_control("transcript_retract", reason, text)

    def _publish_transcript_control(self, event_type: str, reason: str, text: str) -> None:
        if self.room is None or not text:
            return
        try:
            payload = {
                "type": event_type,
                "id": f"mmi-{self.store.turn_id}",
                "role": "user",
                "turnId": self.store.turn_id,
                "reason": reason,
                "text": text,
            }
            result = self.room.local_participant.publish_data(
                json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                reliable=True,
                topic="transcript",
            )
            logger.info(
                "[MMI-TD] published %s session=%s turn=%s reason=%s text_len=%s",
                event_type,
                self.store.session_id,
                self.store.turn_id,
                reason,
                len(text),
            )
            if inspect.isawaitable(result):
                task = asyncio.ensure_future(result)
                task.add_done_callback(self._log_task_error)
        except Exception:
            logger.exception(
                "[MMI-TD] failed to publish %s session=%s turn=%s",
                event_type,
                self.store.session_id,
                self.store.turn_id,
            )

    async def _prepare_endpointing(self, event_id: int) -> None:
        probability, threshold = await self.eou_service.predict(
            self.session,
            text=self.store.transcript_text,
            locale=self.store.locale,
        )
        if self._closed or event_id != self.store.event_id:
            return
        self.store.eou_prob = probability
        self.store.eou_unlikely_threshold = threshold
        context = self.store.snapshot()
        delay_ms = max(0, self.endpointing_policy.target_delay_ms(context) - context.silence_ms)
        self._endpointing_task = asyncio.create_task(self._endpoint_after(delay_ms, event_id))
        self._endpointing_task.add_done_callback(self._log_task_error)

    async def _endpoint_after(self, delay_ms: int, event_id: int) -> None:
        await asyncio.sleep(delay_ms / 1000)
        if self._closed or event_id != self.store.event_id or self.store.user_state == "speaking":
            return
        if self._fail_safe:
            await self._fail_safe_commit(event_id)
            return
        await self._decide("endpointing_timer")

    def _schedule_observation(self, delay_ms: int) -> None:
        self._cancel_task("_observation_task")
        event_id = self.store.event_id
        agent_speech_id = self.store.agent_speech_id
        self.store.runtime_state = MMIRuntimeState.OBSERVING_INTERRUPTION
        self._observation_task = asyncio.create_task(
            self._observe_after(delay_ms, event_id, agent_speech_id)
        )
        self._observation_task.add_done_callback(self._log_task_error)

    async def _observe_after(
        self,
        delay_ms: int,
        event_id: int,
        agent_speech_id: int,
    ) -> None:
        await asyncio.sleep(delay_ms / 1000)
        if self._closed or event_id != self.store.event_id:
            return
        await self._decide(
            "interruption_observation_timer",
            expected_agent_speech_id=agent_speech_id,
        )

    def _schedule_wait_timeout(self) -> None:
        self._cancel_task("_wait_task")
        event_id = self.store.event_id
        self._wait_task = asyncio.create_task(self._wait_timeout(event_id))
        self._wait_task.add_done_callback(self._log_task_error)

    async def _wait_timeout(self, event_id: int) -> None:
        await asyncio.sleep(self.config.wait_intent_max_ms / 1000)
        if self._closed or event_id != self.store.event_id:
            return
        self.store.wait_intent_active = False
        self.store.next_event()
        logger.info("[MMI-TD] wait intent expired session=%s", self.store.session_id)
        self._schedule_endpointing()

    def _enter_fail_safe(self, reason: str) -> None:
        if self.mode != MMIMode.ACTIVE or not self.config.fail_safe_enabled:
            return
        self._fail_safe = True
        self.store.runtime_state = MMIRuntimeState.FAIL_SAFE
        self._cancel_task("_observation_task")
        self._cancel_task("_eou_task")
        self._cancel_task("_wait_task")
        logger.error("[MMI-TD] entered fail-safe session=%s reason=%s", self.store.session_id, reason)
        if (
            self.store.user_state != "speaking"
            and self.store.user_turn_active
            and not self.store.committed
        ):
            self._cancel_task("_endpointing_task")
            event_id = self.store.event_id
            self._endpointing_task = asyncio.create_task(
                self._endpoint_after(int(self.config.max_endpointing_delay * 1000), event_id)
            )
        elif self.store.agent_state == "speaking":
            self._schedule_fail_safe_interrupt()

    def _schedule_fail_safe_interrupt(self) -> None:
        self._cancel_task("_fail_safe_interrupt_task")
        turn_id = self.store.turn_id
        agent_speech_id = self.store.agent_speech_id
        self._fail_safe_interrupt_task = asyncio.create_task(
            self._fail_safe_interrupt_after(turn_id, agent_speech_id)
        )
        self._fail_safe_interrupt_task.add_done_callback(self._log_task_error)

    async def _fail_safe_interrupt_after(self, turn_id: int, agent_speech_id: int) -> None:
        await asyncio.sleep(self.config.fail_safe_interrupt_ms / 1000)
        if (
            self._closed
            or turn_id != self.store.turn_id
            or agent_speech_id != self.store.agent_speech_id
            or self.store.user_state != "speaking"
            or self.store.agent_state != "speaking"
        ):
            return
        decision = MMITurnDecision(
            action=MMITurnAction.START_LISTENING,
            confidence=0.5,
            confidence_level=MMIConfidenceLevel.LOW,
            reason="fail_safe_sustained_user_speech",
            turn_id=self.store.turn_id,
            based_on_event_id=self.store.event_id,
        )
        executed = await self.executor.execute(decision)
        self._log_decision(
            decision,
            trigger="fail_safe",
            executed=executed,
            context=self.store.snapshot(),
        )

    async def _fail_safe_commit(self, event_id: int) -> None:
        if (
            event_id != self.store.event_id
            or self.store.committed
            or not self.store.user_turn_active
        ):
            return
        decision = MMITurnDecision(
            action=MMITurnAction.START_SPEAKING,
            confidence=0.5,
            confidence_level=MMIConfidenceLevel.LOW,
            reason="fail_safe_max_endpointing_delay",
            turn_id=self.store.turn_id,
            based_on_event_id=self.store.event_id,
        )
        executed = await self.executor.execute(decision)
        self._log_decision(
            decision,
            trigger="fail_safe",
            executed=executed,
            context=self.store.snapshot(),
        )

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self.response_watchdog is not None:
            self.response_watchdog.close()
        with self._speaker_signal_lock:
            self._speaker_signal_sequence += 1
        for name in (
            "_endpointing_task",
            "_observation_task",
            "_eou_task",
            "_wait_task",
            "_fail_safe_interrupt_task",
            "_fast_path_deadline_task",
        ):
            self._cancel_task(name)
        try:
            current = asyncio.current_task()
        except RuntimeError:
            current = None
        for task in tuple(self._background_tasks):
            if not task.done() and task is not current:
                task.cancel()
        self._background_tasks.clear()

    def _cancel_task(self, name: str) -> None:
        task = getattr(self, name)
        if (
            task is not None
            and not task.done()
            and task is not asyncio.current_task()
        ):
            task.cancel()
        setattr(self, name, None)

    @staticmethod
    def _log_task_error(task: asyncio.Task[Any]) -> None:
        if task.cancelled():
            return
        try:
            task.result()
        except Exception:
            logger.exception("[MMI-TD] background task failed")

    def _spawn_background(self, coroutine: Coroutine[Any, Any, Any]) -> None:
        task = asyncio.create_task(coroutine)
        self._background_tasks.add(task)

        def done(completed: asyncio.Task[Any]) -> None:
            self._background_tasks.discard(completed)
            self._log_task_error(completed)

        task.add_done_callback(done)

    @staticmethod
    def _elapsed_ms(started_at: float | None) -> float | None:
        if started_at is None:
            return None
        return round(max(0.0, (time.monotonic() - started_at) * 1000), 3)

    def _log_decision(
        self,
        decision: MMITurnDecision,
        *,
        trigger: str,
        executed: bool,
        context: Any | None = None,
        event_processing_latency_ms: float | None = None,
    ) -> None:
        payload = {
            "session_id": self.store.session_id,
            "mode": self.mode.value,
            "trigger": trigger,
            **decision.to_dict(),
            "executed": executed,
            "commit_pending": self.store.commit_pending,
            "commit_attempt_count": self.store.commit_attempt_count,
            "event_processing_latency_ms": event_processing_latency_ms,
        }
        if context is not None:
            payload.update(
                {
                    "agent_state": context.agent_state,
                    "user_state": context.user_state,
                    "tts_playing": context.tts_playing,
                    "speech_ms": context.speech_ms,
                    "transcript_observe_ms": context.transcript_observe_ms,
                    "silence_ms": context.silence_ms,
                    "partial_text_len": len(context.partial_text),
                    "final_text_len": len(context.final_text),
                    "context_eou_prob": context.eou_prob,
                    "context_eou_unlikely_threshold": context.eou_unlikely_threshold,
                    "started_during_agent_thinking": (
                        context.started_during_agent_thinking
                    ),
                    "started_during_agent_speaking": (
                        context.started_during_agent_speaking
                    ),
                    "started_before_speaker_gate_locked": (
                        context.started_before_speaker_gate_locked
                    ),
                    "external_voice_confidence": context.external_voice_confidence,
                    "external_voice_energy_db": context.external_voice_energy_db,
                    "external_voice_stale": context.external_voice_stale,
                    # SpeakerGate 声纹判决：用于排查打断到底是声纹放行还是能量兜底。
                    "external_speaker_is_target": context.external_speaker_is_target,
                    "external_speaker_state": context.external_speaker_state,
                    "external_speaker_similarity": context.external_speaker_similarity,
                    "external_speaker_verdict_kind": context.external_speaker_verdict_kind,
                    "external_speaker_gate_locked": context.external_speaker_gate_locked,
                    "turn_speaker_is_target": context.turn_speaker_is_target,
                    "turn_speaker_state": context.turn_speaker_state,
                    "turn_speaker_similarity": context.turn_speaker_similarity,
                    "turn_speaker_verdict_kind": context.turn_speaker_verdict_kind,
                    "turn_speaker_age_ms": context.turn_speaker_age_ms,
                }
            )
        logger.info("[MMI-TD] decision %s", json.dumps(payload, ensure_ascii=False))

    def _observe_semantic_overlay_decision(
        self,
        decision: MMITurnDecision,
        context: Any | None,
        trigger: str,
    ) -> None:
        if self.semantic_overlay is None or context is None:
            return
        try:
            self.semantic_overlay.observe_base_decision(
                decision,
                context,
                trigger=trigger,
            )
        except Exception:
            logger.exception(
                "[MMI-TD] semantic overlay comparison failed trigger=%s",
                trigger,
            )

    def _start_fast_path_shadow(
        self,
        *,
        source: str,
        observed_at: float | None = None,
        context: Any | None = None,
        start_time_estimated: bool = False,
    ) -> None:
        if self.fast_path_shadow is None:
            return
        snapshot = context or self.store.snapshot()
        current = self.fast_path_shadow.attempt
        if (
            current is not None
            and not current.resolved
            and current.turn_id == snapshot.turn_id
            and current.agent_speech_id == self.store.agent_speech_id
        ):
            return
        self._cancel_task("_fast_path_deadline_task")
        attempt = self.fast_path_shadow.start(
            snapshot,
            agent_speech_id=self.store.agent_speech_id,
            observed_at=observed_at,
            source=source,
            start_time_estimated=start_time_estimated,
        )
        self._fast_path_deadline_task = asyncio.create_task(
            self._fast_path_deadline_after(
                attempt.turn_id,
                attempt.agent_speech_id,
                attempt.deadline_at,
            )
        )
        self._fast_path_deadline_task.add_done_callback(self._log_task_error)

    async def _fast_path_deadline_after(
        self,
        turn_id: int,
        agent_speech_id: int,
        deadline_at: float,
    ) -> None:
        await asyncio.sleep(max(0.0, deadline_at - time.monotonic()))
        if self._closed or self.fast_path_shadow is None:
            return
        observed_at = time.monotonic()
        if (
            self.store.turn_id == turn_id
            and self.store.agent_speech_id == agent_speech_id
            and self.store.agent_state == "speaking"
        ):
            self._observe_fast_path_audio_context(
                self.store.snapshot(),
                trigger="fast_path_audio_deadline",
                observed_at=observed_at,
            )
        self.fast_path_shadow.mark_deadline(
            turn_id=turn_id,
            agent_speech_id=agent_speech_id,
            observed_at=observed_at,
        )

    def _observe_fast_path_decision(
        self,
        decision: MMITurnDecision,
        context: Any | None,
        trigger: str,
    ) -> None:
        if self.fast_path_shadow is None or context is None:
            return
        try:
            self.fast_path_shadow.observe_decision(
                decision,
                context,
                trigger=trigger,
            )
        except Exception:
            logger.exception(
                "[MMI-TD] fast path observation failed trigger=%s",
                trigger,
            )

    def _observe_fast_path_audio_context(
        self,
        context: Any,
        *,
        trigger: str,
        observed_at: float | None = None,
    ) -> None:
        if self.fast_path_shadow is None:
            return
        try:
            self.fast_path_shadow.observe_audio_context(
                context,
                trigger=trigger,
                observed_at=observed_at,
            )
        except Exception:
            logger.exception(
                "[MMI-TD] fast path audio observation failed trigger=%s",
                trigger,
            )

    def _mark_fast_path_stop_candidate(
        self,
        turn_id: int,
        agent_speech_id: int,
        *,
        observed_at: float | None = None,
    ) -> None:
        if self.fast_path_shadow is None:
            return
        self.fast_path_shadow.mark_agent_stop_candidate(
            turn_id=turn_id,
            agent_speech_id=agent_speech_id,
            observed_at=observed_at,
        )

    def _ensure_fast_path_for_native_stop(
        self,
        context: Any,
        agent_speech_id: int,
        *,
        stop_at: float | None,
    ) -> None:
        if self.fast_path_shadow is None:
            return
        current = self.fast_path_shadow.attempt
        if (
            current is not None
            and not current.resolved
            and current.turn_id == context.turn_id
            and current.agent_speech_id == agent_speech_id
        ):
            self._mark_fast_path_stop_candidate(
                context.turn_id,
                agent_speech_id,
                observed_at=stop_at,
            )
            return
        now = time.monotonic()
        observed_ms = max(context.speech_ms, context.transcript_observe_ms)
        estimated_start = now - observed_ms / 1000 if observed_ms > 0 else now
        self._start_fast_path_shadow(
            source="reconstructed_from_native_stop",
            observed_at=estimated_start,
            context=context,
            start_time_estimated=True,
        )
        reconstructed = self.fast_path_shadow.attempt
        if reconstructed is not None:
            self.fast_path_shadow.mark_deadline(
                turn_id=context.turn_id,
                agent_speech_id=agent_speech_id,
                observed_at=reconstructed.deadline_at,
            )
        self._mark_fast_path_stop_candidate(
            context.turn_id,
            agent_speech_id,
            observed_at=stop_at or now,
        )

    def _confirm_fast_path_native_stop(
        self,
        turn_id: int,
        agent_speech_id: int,
        *,
        trigger: str,
    ) -> None:
        if self.fast_path_shadow is None:
            return
        self.fast_path_shadow.confirm_native_stop(
            turn_id=turn_id,
            agent_speech_id=agent_speech_id,
            trigger=trigger,
        )
        self._cancel_task("_fast_path_deadline_task")

    def _resolve_fast_path_shadow(self, reason: str) -> None:
        if self.fast_path_shadow is None:
            return
        self.fast_path_shadow.resolve(reason)
        self._cancel_task("_fast_path_deadline_task")

    def _log_native_action(self, action: MMITurnAction, *, trigger: str) -> None:
        payload = {
            "session_id": self.store.session_id,
            "mode": self.mode.value,
            "action": action.value,
            "trigger": trigger,
            "turn_id": self.store.turn_id,
            "event_id": self.store.event_id,
        }
        logger.info("[MMI-TD] native_action %s", json.dumps(payload, ensure_ascii=False))

from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from mmi_turn_detection.context_store import MMITurnContextStore
from mmi_turn_detection.executor import MMITurnExecutor
from mmi_turn_detection.models import (
    MMIConfidenceLevel,
    MMITurnAction,
    MMITurnDecision,
)
from mmi_turn_detection.response_watchdog import MMIResponseWatchdog


class FakeHandle:
    def __init__(self, speech_id: str, *, finish_on_interrupt: bool = True):
        self.id = speech_id
        self.interrupted = False
        self.chat_items = []
        self._finish_on_interrupt = finish_on_interrupt
        self._done = False
        self._callbacks = []
        self._done_event = asyncio.Event()

    def add_done_callback(self, callback):
        self._callbacks.append(callback)

    def done(self):
        return self._done

    def interrupt(self, *, force=False):
        assert force is True
        self.interrupted = True
        if self._finish_on_interrupt:
            self.finish()
        return self

    async def wait_for_playout(self):
        await self._done_event.wait()

    def finish(self, text: str = ""):
        if self._done:
            return
        if text:
            self.chat_items.append(
                SimpleNamespace(role="assistant", text_content=text, content=[text])
            )
        self._done = True
        self._done_event.set()
        for callback in list(self._callbacks):
            callback(self)


class FakeSession:
    def __init__(self):
        self.handlers = {}
        self.generated = []
        self.interrupts = 0

    def on(self, event_name):
        def register(handler):
            self.handlers.setdefault(event_name, []).append(handler)
            return handler

        return register

    def emit(self, event_name, **fields):
        for handler in self.handlers.get(event_name, []):
            handler(SimpleNamespace(**fields))

    def generate_reply(self, **kwargs):
        handle = FakeHandle(f"retry-{len(self.generated) + 1}")
        self.generated.append((kwargs, handle))
        return handle

    async def interrupt(self, *, force=False):
        assert force is True
        self.interrupts += 1


def build_watchdog(
    session,
    current,
    *,
    timeout_ms=1000,
    grace_ms=100,
    settle_ms=0,
):
    watchdog = MMIResponseWatchdog(
        session,
        session_id="test-session",
        is_current_turn=lambda turn_id: current[0] == turn_id,
        first_output_timeout_ms=timeout_ms,
        max_retries=1,
        cancel_grace_ms=grace_ms,
        retry_settle_ms=settle_ms,
    )
    watchdog.setup()
    return watchdog


class SpyWatchdog:
    def __init__(self):
        self.arms = []
        self.cancels = []

    def arm(self, turn_id, commit_text):
        self.arms.append((turn_id, commit_text))

    def cancel(self, turn_id, reason):
        self.cancels.append((turn_id, reason))


def start_speaking_decision(store):
    return MMITurnDecision(
        action=MMITurnAction.START_SPEAKING,
        confidence=1.0,
        confidence_level=MMIConfidenceLevel.HIGH,
        reason="test",
        turn_id=store.turn_id,
        based_on_event_id=store.event_id,
    )


@pytest.mark.asyncio
async def test_executor_arms_watchdog_before_committing_response():
    store = MMITurnContextStore(session_id="test")
    store.on_agent_state("listening")
    store.on_transcript("question", is_final=True)
    store.on_user_listening()
    session = FakeSession()
    session.commit_user_turn = lambda: asyncio.sleep(0)
    watchdog = SpyWatchdog()
    executor = MMITurnExecutor(session, store, response_watchdog=watchdog)

    executed = await executor.execute(start_speaking_decision(store))

    assert executed is True
    assert watchdog.arms == [(store.turn_id, "question")]
    assert watchdog.cancels == []


@pytest.mark.asyncio
async def test_first_audio_confirms_output_without_retry():
    session = FakeSession()
    current = [4]
    watchdog = build_watchdog(session, current, timeout_ms=20)
    handle = FakeHandle("original")

    watchdog.arm(4, "question")
    session.emit("speech_created", speech_handle=handle, user_initiated=True)
    session.emit("agent_state_changed", new_state="speaking")
    handle.finish()
    await asyncio.sleep(0.04)

    assert session.generated == []
    watchdog.close()


@pytest.mark.asyncio
async def test_nonempty_assistant_item_and_first_audio_confirm_output():
    session = FakeSession()
    current = [5]
    watchdog = build_watchdog(session, current, timeout_ms=20)
    handle = FakeHandle("original")

    watchdog.arm(5, "question")
    session.emit("speech_created", speech_handle=handle, user_initiated=True)
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="answer",
            content=["answer"],
        ),
    )
    session.emit("agent_state_changed", new_state="speaking")
    handle.finish("answer")
    await asyncio.sleep(0.04)

    assert session.generated == []
    watchdog.close()


@pytest.mark.asyncio
async def test_text_without_first_audio_retries_as_playout_failure():
    session = FakeSession()
    current = [51]
    watchdog = build_watchdog(session, current)
    handle = FakeHandle("original")

    watchdog.arm(51, "question")
    session.emit("speech_created", speech_handle=handle, user_initiated=True)
    session.emit(
        "conversation_item_added",
        item=SimpleNamespace(
            role="assistant",
            text_content="answer",
            content=["answer"],
        ),
    )
    handle.finish("answer")
    await asyncio.sleep(0.01)

    assert len(session.generated) == 1
    watchdog.close()


@pytest.mark.asyncio
async def test_empty_completed_response_retries_once_without_user_input():
    session = FakeSession()
    current = [6]
    watchdog = build_watchdog(session, current)
    original = FakeHandle("original")

    watchdog.arm(6, "question")
    session.emit("speech_created", speech_handle=original, user_initiated=True)
    original.finish()
    await asyncio.sleep(0.01)

    assert len(session.generated) == 1
    kwargs, retry = session.generated[0]
    assert "instructions" in kwargs
    assert "user_input" not in kwargs

    retry.finish()
    await asyncio.sleep(0.01)
    assert len(session.generated) == 1
    watchdog.close()


@pytest.mark.asyncio
async def test_first_output_timeout_interrupts_original_before_retry():
    session = FakeSession()
    current = [7]
    watchdog = build_watchdog(session, current, timeout_ms=10)
    original = FakeHandle("original")

    watchdog.arm(7, "question")
    session.emit("speech_created", speech_handle=original, user_initiated=True)
    await asyncio.sleep(0.04)

    assert original.interrupted is True
    assert len(session.generated) == 1
    watchdog.close()


@pytest.mark.asyncio
async def test_retry_waits_for_cancel_cleanup_before_generating():
    session = FakeSession()
    current = [71]
    watchdog = build_watchdog(
        session,
        current,
        timeout_ms=10,
        settle_ms=30,
    )
    original = FakeHandle("original")

    watchdog.arm(71, "question")
    session.emit("speech_created", speech_handle=original, user_initiated=True)
    await asyncio.sleep(0.025)

    assert original.interrupted is True
    assert session.generated == []

    await asyncio.sleep(0.04)
    assert len(session.generated) == 1
    watchdog.close()


@pytest.mark.asyncio
async def test_retry_is_aborted_when_original_cannot_stop():
    session = FakeSession()
    current = [8]
    watchdog = build_watchdog(session, current, timeout_ms=10, grace_ms=10)
    original = FakeHandle("original", finish_on_interrupt=False)

    watchdog.arm(8, "question")
    session.emit("speech_created", speech_handle=original, user_initiated=True)
    await asyncio.sleep(0.05)

    assert original.interrupted is True
    assert session.generated == []
    watchdog.close()


@pytest.mark.asyncio
async def test_new_user_turn_prevents_retry():
    session = FakeSession()
    current = [9]
    watchdog = build_watchdog(session, current)
    original = FakeHandle("original")

    watchdog.arm(9, "question")
    session.emit("speech_created", speech_handle=original, user_initiated=True)
    current[0] = 10
    original.finish()
    await asyncio.sleep(0.01)

    assert session.generated == []
    watchdog.close()

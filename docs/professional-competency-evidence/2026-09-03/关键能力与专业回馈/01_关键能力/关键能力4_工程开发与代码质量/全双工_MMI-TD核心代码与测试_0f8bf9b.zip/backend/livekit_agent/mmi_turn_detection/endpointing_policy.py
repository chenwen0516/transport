"""Baseline endpointing policy matching the current LiveKit behavior."""

from __future__ import annotations

from dataclasses import dataclass

from .models import (
    MMIConfidenceLevel,
    MMITurnAction,
    MMITurnContext,
    MMITurnDecision,
)
from .patterns import DEFAULT_PATTERN_MATCHER, MultilingualPatternMatcher, PatternMatch


@dataclass(frozen=True)
class EndpointingPolicyConfig:
    min_delay_ms: int = 500
    complete_statement_delay_ms: int = 500
    uncertain_delay_ms: int = 1500
    max_delay_ms: int = 3000
    eou_complete_threshold_floor: float = 0.2
    wait_intent_max_ms: int = 15000
    speaker_non_target_sim_max: float = 0.18
    require_target_speaker: bool = False
    require_explicit_intent_for_overlapping_followup: bool = False
    overlapping_followup_min_gap_ms: int = 2000
    target_latch_max_ms: int = 3000


class BaselineEndpointingPolicy:
    _INCOMPLETE_EOU_OVERRIDE_THRESHOLD = 0.1
    # 文本已命中噪声模式且前端语音置信度低于此值 → 双重佐证，立即丢弃背景"嗯/啊"。
    _LOW_VOICE_CONFIDENCE = 0.4

    def __init__(
        self,
        config: EndpointingPolicyConfig,
        patterns: MultilingualPatternMatcher = DEFAULT_PATTERN_MATCHER,
    ) -> None:
        self._config = config
        self._patterns = patterns

    def target_delay_ms(self, ctx: MMITurnContext) -> int:
        if not ctx.transcript_text:
            return self._config.max_delay_ms
        if ctx.final_text and self._looks_like_explicit_question(ctx.final_text):
            return self._config.min_delay_ms
        incomplete_without_positive_eou = (
            self._patterns.incomplete_suffix(ctx.transcript_text).matched
            and not self._has_positive_incomplete_eou(ctx)
        )
        if incomplete_without_positive_eou:
            return self._config.max_delay_ms
        eou_delay = self._eou_delay_ms(ctx)
        if eou_delay == self._config.min_delay_ms and bool(ctx.final_text):
            eou_delay = max(
                eou_delay,
                self._config.complete_statement_delay_ms,
            )
        if (
            ctx.started_before_speaker_gate_locked
            and ctx.external_speaker_gate_locked is False
        ):
            if eou_delay == self._config.min_delay_ms:
                return self._config.min_delay_ms
            return self._config.max_delay_ms
        if not ctx.final_text and (
            ctx.eou_prob is None
            or ctx.eou_unlikely_threshold is None
        ):
            return self._config.max_delay_ms
        if eou_delay is not None:
            return eou_delay
        return self._config.min_delay_ms

    def wait_intent_still_active(self, ctx: MMITurnContext) -> bool:
        wait_candidate = ctx.latest_transcript_text or ctx.transcript_text
        return self._patterns.wait_expression(wait_candidate).matched

    def decide(self, ctx: MMITurnContext) -> MMITurnDecision:
        text = ctx.transcript_text
        addressed_to_other = self._patterns.addressed_to_other(ctx.final_text or text)
        if addressed_to_other.matched:
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_LISTENING,
                confidence=0.95,
                level=MMIConfidenceLevel.HIGH,
                reason="addressed_to_other",
                ignore_input=True,
                pattern_match=addressed_to_other,
            )
        if self._overlapping_followup_requires_explicit_intent(ctx):
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_LISTENING,
                confidence=0.85,
                level=MMIConfidenceLevel.MEDIUM,
                reason="overlap_without_interrupt_intent",
                ignore_input=True,
            )
        if text and self._decisive_non_target(ctx):
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_LISTENING,
                confidence=0.9,
                level=MMIConfidenceLevel.HIGH,
                reason="non_target_speaker_ignored",
                ignore_input=True,
            )
        if (
            text
            and self._target_speaker_required(ctx)
            and not self._target_speaker_confirmed(ctx)
        ):
            if ctx.silence_ms < self._config.max_delay_ms:
                return self._decision(
                    ctx,
                    MMITurnAction.CONTINUE_LISTENING,
                    confidence=0.75,
                    level=MMIConfidenceLevel.MEDIUM,
                    reason="target_speaker_pending",
                    observe_more_ms=max(
                        0,
                        self._config.max_delay_ms - ctx.silence_ms,
                    ),
                )
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_LISTENING,
                confidence=0.9,
                level=MMIConfidenceLevel.HIGH,
                reason="target_speaker_not_confirmed",
                ignore_input=True,
            )
        wait_candidate = ctx.latest_transcript_text or text
        wait_expression = self._patterns.wait_expression(wait_candidate)
        wait_identity = wait_expression.pattern.strip()
        new_wait_intent = (
            wait_expression.matched
            and wait_identity != ctx.wait_intent_consumed_text.strip()
        )
        active_wait_intent = (
            ctx.wait_intent_active and self.wait_intent_still_active(ctx)
        )
        if new_wait_intent or active_wait_intent:
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_LISTENING,
                confidence=0.95,
                level=MMIConfidenceLevel.HIGH,
                reason="wait_intent",
                wait_intent=True,
                pattern_match=wait_expression,
            )

        invalid_or_noise = self._patterns.invalid_or_noise(text)
        if invalid_or_noise.matched:
            # fail-open：无信号(None)时 low_voice_conf=False，等价于原 max_delay 超时逻辑。
            low_voice_conf = (
                ctx.external_voice_confidence is not None
                and ctx.external_voice_confidence < self._LOW_VOICE_CONFIDENCE
            )
            if ctx.silence_ms >= self._config.max_delay_ms or low_voice_conf:
                if not text:
                    reason = "empty_turn_timeout"
                elif low_voice_conf and ctx.silence_ms < self._config.max_delay_ms:
                    reason = "invalid_or_noise_low_voice_confidence"
                else:
                    reason = "invalid_or_noise_turn_timeout"
                return self._decision(
                    ctx,
                    MMITurnAction.CONTINUE_LISTENING,
                    confidence=0.9,
                    level=MMIConfidenceLevel.HIGH,
                    reason=reason,
                    ignore_input=True,
                    pattern_match=invalid_or_noise,
                )
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_LISTENING,
                confidence=0.7,
                level=MMIConfidenceLevel.MEDIUM,
                reason=(
                    "empty_turn_pending"
                    if not text
                    else "invalid_or_noise_turn_pending"
                ),
                observe_more_ms=max(0, self._config.max_delay_ms - ctx.silence_ms),
                pattern_match=invalid_or_noise,
            )

        incomplete_suffix = self._patterns.incomplete_suffix(text)
        incomplete_without_positive_eou = (
            incomplete_suffix.matched and not self._has_positive_incomplete_eou(ctx)
        )
        if incomplete_without_positive_eou and ctx.silence_ms < self._config.max_delay_ms:
            return self._decision(
                ctx,
                MMITurnAction.CONTINUE_LISTENING,
                confidence=0.8,
                level=MMIConfidenceLevel.MEDIUM,
                reason="text_looks_incomplete",
                observe_more_ms=max(0, self._config.max_delay_ms - ctx.silence_ms),
                pattern_match=incomplete_suffix,
            )

        target_delay = self.target_delay_ms(ctx)
        if ctx.silence_ms >= target_delay:
            return self._decision(
                ctx,
                MMITurnAction.START_SPEAKING,
                confidence=0.85,
                level=MMIConfidenceLevel.MEDIUM,
                reason=(
                    "max_endpointing_delay_reached"
                    if target_delay == self._config.max_delay_ms
                    else (
                        "uncertain_endpointing_delay_reached"
                        if target_delay == self._config.uncertain_delay_ms
                        else "min_endpointing_delay_reached"
                    )
                ),
            )

        return self._decision(
            ctx,
            MMITurnAction.CONTINUE_LISTENING,
            confidence=0.7,
            level=MMIConfidenceLevel.MEDIUM,
            reason="endpointing_delay_pending",
            observe_more_ms=max(0, target_delay - ctx.silence_ms),
        )

    def _decisive_non_target(self, ctx: MMITurnContext) -> bool:
        if ctx.external_speaker_state == "TARGET_WEAK":
            return False
        if ctx.turn_speaker_state == "TARGET_WEAK":
            return False
        if ctx.external_speaker_is_target is False:
            if (
                ctx.external_speaker_verdict_kind != "decide"
                and self._turn_target_confirmed(ctx)
            ):
                return False
            sim = ctx.external_speaker_similarity
        elif ctx.turn_speaker_is_target is False:
            sim = ctx.turn_speaker_similarity
        else:
            return False
        return sim is None or sim <= self._config.speaker_non_target_sim_max

    def _target_speaker_required(self, ctx: MMITurnContext) -> bool:
        if not self._config.require_target_speaker:
            return False

        # Speaker embeddings below the configured minimum duration are not
        # reliable. Preserve short semantic replies and let transcript
        # noise/EOU policies decide them instead of dropping them silently.
        if ctx.external_speaker_verdict_kind in {"too_short", "unavailable"}:
            return False
        if ctx.turn_speaker_verdict_kind in {"too_short", "unavailable"}:
            return False

        if ctx.external_speaker_gate_locked is True:
            # A session-auto enrollment turn was admitted while the gate was
            # warm. Locking during the same turn must not retroactively make a
            # target verdict mandatory; subsequent turns remain strict.
            return not ctx.started_before_speaker_gate_locked

        return (
            ctx.turn_id > 0
            and ctx.started_before_speaker_gate_locked
            and ctx.external_speaker_gate_locked is False
            and (
                ctx.started_during_agent_thinking
                or ctx.started_during_agent_speaking
            )
        )

    @staticmethod
    def _external_target_confirmed(ctx: MMITurnContext) -> bool:
        return (
            ctx.external_speaker_state == "TARGET_CONFIDENT"
            or ctx.external_speaker_is_target is True
        )

    def _turn_target_confirmed(self, ctx: MMITurnContext) -> bool:
        if ctx.turn_speaker_age_ms is not None and (
            ctx.turn_speaker_age_ms > self._config.target_latch_max_ms
        ):
            return False
        return (
            ctx.turn_speaker_state == "TARGET_CONFIDENT"
            or ctx.turn_speaker_is_target is True
        )

    def _target_speaker_confirmed(self, ctx: MMITurnContext) -> bool:
        if self._external_target_confirmed(ctx):
            return True
        if ctx.external_speaker_state in {"TARGET_WEAK", "NON_TARGET", "UNKNOWN"}:
            return False
        if self._turn_target_confirmed(ctx):
            return True
        return False

    def _has_positive_incomplete_eou(self, ctx: MMITurnContext) -> bool:
        if ctx.eou_prob is None or ctx.eou_unlikely_threshold is None:
            return False
        return ctx.eou_prob >= max(
            self._effective_eou_threshold(ctx),
            self._INCOMPLETE_EOU_OVERRIDE_THRESHOLD,
        )

    def _overlapping_followup_requires_explicit_intent(
        self,
        ctx: MMITurnContext,
    ) -> bool:
        return (
            self._config.require_explicit_intent_for_overlapping_followup
            and ctx.turn_id > 0
            and (
                ctx.started_during_agent_thinking
                or ctx.started_during_agent_speaking
            )
            and ctx.turn_started_after_previous_speech_ms is not None
            and (
                ctx.turn_started_after_previous_speech_ms
                >= self._config.overlapping_followup_min_gap_ms
            )
            and not self._patterns.explicit_overlap_intent(
                ctx.transcript_text
            ).matched
            and not self._patterns.backchannel(ctx.transcript_text).matched
        )

    def _effective_eou_threshold(self, ctx: MMITurnContext) -> float:
        return max(
            ctx.eou_unlikely_threshold or 0.0,
            self._config.eou_complete_threshold_floor,
        )

    @staticmethod
    def _looks_like_explicit_question(text: str) -> bool:
        return text.rstrip().endswith(("?", "？"))

    def _eou_delay_ms(self, ctx: MMITurnContext) -> int | None:
        if ctx.eou_prob is None or ctx.eou_unlikely_threshold is None:
            return None
        if ctx.eou_prob < ctx.eou_unlikely_threshold:
            return self._config.max_delay_ms
        if ctx.eou_prob < self._effective_eou_threshold(ctx):
            return self._config.uncertain_delay_ms
        return self._config.min_delay_ms

    def _decision(
        self,
        ctx: MMITurnContext,
        action: MMITurnAction,
        *,
        confidence: float,
        level: MMIConfidenceLevel,
        reason: str,
        wait_intent: bool = False,
        ignore_input: bool = False,
        observe_more_ms: int = 0,
        pattern_match: PatternMatch | None = None,
    ) -> MMITurnDecision:
        pattern_match = pattern_match or PatternMatch(version=self._patterns.version)
        return MMITurnDecision(
            action=action,
            confidence=confidence,
            confidence_level=level,
            reason=reason,
            eou_prob=ctx.eou_prob,
            wait_intent=wait_intent,
            ignore_input=ignore_input,
            observe_more_ms=observe_more_ms,
            pattern_version=pattern_match.version,
            matched_rule=pattern_match.rule,
            matched_pattern=pattern_match.pattern,
            turn_id=ctx.turn_id,
            based_on_event_id=ctx.event_id,
        )

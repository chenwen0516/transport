"""Dedicated logging configuration for MMI-TD."""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any

MMI_LOGGER_NAME = "health-agent.mmi"
_HANDLER_MARKER = "_mmi_turn_detection_handler"


def configure_mmi_logging(
    config: Any,
    *,
    timestamp: str | None = None,
    directory: str | Path | None = None,
) -> Path | None:
    """Route all MMI-TD logs to one dedicated file.

    文件名追加运行时间戳（与 session_report 同风格 %Y%m%d_%H%M%S），避免跨次运行覆盖。
    传入 timestamp 可让多个日志共用同一时间戳便于关联；不传则用当前时间。
    """
    logger = logging.getLogger(MMI_LOGGER_NAME)
    logger.setLevel(_resolve_level(config.log_level))
    logger.propagate = config.log_to_console

    for handler in list(logger.handlers):
        if getattr(handler, _HANDLER_MARKER, False):
            logger.removeHandler(handler)
            handler.close()

    if not config.log_file_enabled:
        return None

    ts = timestamp or datetime.now().strftime("%Y%m%d_%H%M%S")
    path = Path(config.log_file).expanduser()
    if directory is not None:
        path = Path(directory).expanduser() / path.name
    path = path.with_name(f"{path.stem}_{ts}{path.suffix}")
    path.parent.mkdir(parents=True, exist_ok=True)

    handler = logging.FileHandler(path, encoding="utf-8")
    setattr(handler, _HANDLER_MARKER, True)
    handler.setLevel(_resolve_level(config.log_level))
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s - pid=%(process)d - %(name)s - %(levelname)s - %(message)s"
        )
    )
    logger.addHandler(handler)
    return path.resolve()


def _resolve_level(value: str) -> int:
    level = logging.getLevelName(value.upper())
    if not isinstance(level, int):
        raise ValueError(f"Invalid MMI_TD_LOG_LEVEL: {value}")
    return level

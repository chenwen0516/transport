"""Configurable multilingual text patterns for MMI-TD."""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger("health-agent.mmi.patterns")

_PUNCTUATION_RE = re.compile(r"[\s，。！？、,.!?;；:：\"'“”‘’\-]+")
_LATIN_RE = re.compile(r"^[a-z0-9 ]+$")
_ENGLISH_VOCATIVE_RE = re.compile(
    r"^\s*([A-Za-z][A-Za-z'\-]{1,24})\s*[,\.!?;:]",
    flags=re.IGNORECASE,
)
_ENGLISH_GREETING_VOCATIVE_RE = re.compile(
    r"^\s*(?:hello|hi)(?:\s*,\s*|\s+)"
    r"([A-Za-z][A-Za-z'\-]{1,24})\s*[,\.!?;:]",
    flags=re.IGNORECASE,
)
_ENGLISH_TITLED_VOCATIVE_RE = re.compile(
    r"^\s*([A-Za-z][A-Za-z'\-]{1,24})\.?\s+"
    r"([A-Za-z][A-Za-z'\-]{1,24})(?:\s*[,\.!?;:]|['’](?=\s))",
    flags=re.IGNORECASE,
)
_ENGLISH_POST_VOCATIVE_DISCOURSE_RE = re.compile(
    r"^\s*[A-Za-z][A-Za-z'\-]{1,24}\s*[,\.!?;:]\s*"
    r"(?:specifically|generally|basically|particularly|especially)\b",
    flags=re.IGNORECASE,
)
_OTHER_ADDRESSEE_TERMS = {
    "mom", "mother", "dad", "father", "grandma", "grandmother",
    "grandpa", "grandfather", "officer", "teacher", "professor",
    "doctor", "dr", "nurse", "coach", "trainer", "boss", "sir",
    "madam", "ma'am", "dude", "bro", "buddy", "guys", "everyone",
}
_TARGET_OR_DISCOURSE_VOCATIVES = {
    "assistant", "agent", "qwen", "ziyan", "actually", "anyway",
    "well", "wait", "okay", "ok", "yes", "no", "hey", "sorry",
    "please", "so", "oh", "or", "and", "also", "however", "instead",
    "yeah", "right", "sure", "exactly", "totally", "alright",
    "indeed", "got", "understood", "uh", "um", "er", "hmm",
    "endlessly", "enderly", "hopefully", "there", "good", "yep",
    "gotcha", "ah", "mask", "i've", "hello", "hi",
    "cross",
}
_EXPLICIT_OVERLAP_INTENT_PREFIXES = (
    "actually",
    "by the way",
    "oh by the way",
    "before i forget",
    "oh before i forget",
    "hold that thought",
    "let's talk about",
    "对了",
    "顺便问一下",
    "换个话题",
    "我们聊聊",
    "先别说这个",
)


@dataclass(frozen=True)
class PatternMatch:
    matched: bool = False
    rule: str = ""
    pattern: str = ""
    version: str = ""


@dataclass(frozen=True)
class LocalePatternPack:
    strong_exact: tuple[str, ...] = ()
    strong_prefixes: tuple[str, ...] = ()
    strong_contains: tuple[str, ...] = ()
    strong_exclusions: tuple[str, ...] = ()
    strong_repeated_prefixes: tuple[str, ...] = ()
    backchannels: tuple[str, ...] = ()
    confirmations: tuple[str, ...] = ()
    wait_expressions: tuple[str, ...] = ()
    incomplete_suffixes: tuple[str, ...] = ()
    noise_expressions: tuple[str, ...] = ()


DEFAULT_PATTERN_VERSION = "builtin-zh-en-2026-08-03-aa-fdb-badcase-v9"
_BENIGN_WAIT_RESIDUES = {
    "",
    "please",
    "just",
    "a moment",
    "for a moment",
    "one second",
    "a second",
    "for a second",
}
_BENIGN_WAIT_CJK_RESIDUE_RE = re.compile(r"^[啊呀吧呢哦噢哈请先一会儿片刻]*$")

DEFAULT_LOCALE_PACKS: dict[str, LocalePatternPack] = {
    "zh-CN": LocalePatternPack(
        strong_exact=(
            "停",
            "停下",
            "停止",
            "暂停",
            "别说了",
            "不要说了",
            "取消",
            "重新",
            "重来",
            "等等",
            "等一下",
            "等下",
            "不对",
            "错了",
        ),
        strong_prefixes=(
            "停一下",
            "先停",
            "请停",
            "等等",
            "等一下",
            "不是",
            "不对",
            "错了",
            "取消",
            "重新",
            "重来",
            "换成",
            "改成",
            "别说",
            "不要说",
        ),
        strong_contains=("别说了", "不要说了", "先别说", "停一下", "暂停一下"),
        strong_exclusions=("不要停止", "别停止"),
        strong_repeated_prefixes=("别", "不"),
        backchannels=(
            "嗯",
            "嗯嗯",
            "哦",
            "噢",
            "好的",
            "好",
            "对",
            "是",
            "是的",
            "行",
            "明白",
            "知道了",
            "可以",
            "哈哈",
            "哈哈哈",
            "嘿嘿",
            "嘿嘿嘿",
            "呵呵",
            "哇",
            "哇哦",
            "确实",
            "说得对",
            "说的对",
            "有意思",
            "爽啊",
            "对对",
            "对对对",
            "哎对对",
            "哎 对对",
            "诶诶",
            "哎哎",
            "哎哎哎",
            "อื้อ",
        ),
        confirmations=("不是", "不对", "不要", "不用", "否"),
        wait_expressions=(
            "等一下",
            "等下",
            "等等",
            "稍等",
            "我想想",
            "让我想想",
            "我想一下",
            "让我想一下",
            "容我想一下",
            "先别说",
            "先等一下",
        ),
        incomplete_suffixes=(
            "然后",
            "还有",
            "因为",
            "所以",
            "但是",
            "就是",
            "如果",
            "比如",
            "或者",
            "以及",
            "和",
            "跟",
            "的",
            "是",
            "在",
            "我想",
            "我觉得",
        ),
        noise_expressions=("嗯", "啊", "哦", "噢", "呃", "额", "呀", "嘛", "哎", "哈"),
    ),
    "en-US": LocalePatternPack(
        strong_exact=(
            "stop",
            "wait",
            "hold on",
            "pause",
            "cancel",
            "restart",
            "start over",
            "that's wrong",
            "that is wrong",
        ),
        strong_prefixes=(
            "stop",
            "wait",
            "hold on",
            "pause",
            "no",
            "that's wrong",
            "that is wrong",
            "cancel",
            "restart",
            "start over",
            "change to",
            "switch to",
            "stop talking",
            "can we talk about",
            "can we discuss",
        ),
        strong_contains=("stop talking", "please stop", "don't say that"),
        strong_exclusions=(
            "don't stop taking",
            "do not stop taking",
            "don't stop treatment",
            "do not stop treatment",
        ),
        strong_repeated_prefixes=("stop", "no", "wait"),
        backchannels=(
            "uh",
            "uh huh",
            "uh-huh",
            "uhuh",
            "mm",
            "mm-hmm",
            "mhm",
            "hmm",
            "hmm yeah",
            "okay",
            "ok",
            "right",
            "yeah",
            "yes",
            "yup",
            "sure",
            "exactly",
            "totally",
            "alright",
            "i see",
            "i see that",
            "ha ha",
            "ha ha ha",
            "haha",
            "hahaha",
            "indeed",
            "got it",
            "understood",
        ),
        confirmations=("no", "nope", "don't", "do not"),
        wait_expressions=("wait", "hold on", "one moment", "let me think", "give me a second"),
        incomplete_suffixes=(
            "and",
            "because",
            "but",
            "if",
            "or",
            "so",
            "then",
            "for example",
            "i think",
            "i want",
            "i feel",
        ),
        noise_expressions=("uh", "um", "er", "erm", "hmm"),
    ),
}


def normalize_text(text: str) -> str:
    return _PUNCTUATION_RE.sub(" ", text or "").strip().lower()


def _deduplicate(values: Iterable[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(value.strip() for value in values if value.strip()))


def _validate_string_list(value: Any, path: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ValueError(f"{path} must be a list of strings")
    return _deduplicate(value)


def _pack_to_dict(pack: LocalePatternPack) -> dict[str, tuple[str, ...]]:
    return {field.name: getattr(pack, field.name) for field in fields(LocalePatternPack)}


def _read_locale_values(data: dict[str, Any], prefix: str) -> dict[str, tuple[str, ...]]:
    strong = data.get("strong_interrupt", {})
    if not isinstance(strong, dict):
        raise ValueError(f"{prefix}.strong_interrupt must be an object")
    return {
        "strong_exact": _validate_string_list(
            strong.get("exact"), f"{prefix}.strong_interrupt.exact"
        ),
        "strong_prefixes": _validate_string_list(
            strong.get("prefixes"), f"{prefix}.strong_interrupt.prefixes"
        ),
        "strong_contains": _validate_string_list(
            strong.get("contains"), f"{prefix}.strong_interrupt.contains"
        ),
        "strong_exclusions": _validate_string_list(
            strong.get("exclusions"), f"{prefix}.strong_interrupt.exclusions"
        ),
        "strong_repeated_prefixes": _validate_string_list(
            strong.get("repeated_prefixes"),
            f"{prefix}.strong_interrupt.repeated_prefixes",
        ),
        "backchannels": _validate_string_list(data.get("backchannels"), f"{prefix}.backchannels"),
        "confirmations": _validate_string_list(
            data.get("confirmations"), f"{prefix}.confirmations"
        ),
        "wait_expressions": _validate_string_list(
            data.get("wait_expressions"), f"{prefix}.wait_expressions"
        ),
        "incomplete_suffixes": _validate_string_list(
            data.get("incomplete_suffixes"), f"{prefix}.incomplete_suffixes"
        ),
        "noise_expressions": _validate_string_list(
            data.get("noise_expressions"), f"{prefix}.noise_expressions"
        ),
    }


def _merge_locale_pack(locale: str, data: dict[str, Any]) -> LocalePatternPack:
    replace_defaults = data.get("replace_defaults", False)
    if not isinstance(replace_defaults, bool):
        raise ValueError(f"locales.{locale}.replace_defaults must be a boolean")
    base = (
        LocalePatternPack()
        if replace_defaults
        else DEFAULT_LOCALE_PACKS.get(locale, LocalePatternPack())
    )
    merged = _pack_to_dict(base)
    additions = _read_locale_values(data, f"locales.{locale}")
    for key, values in additions.items():
        merged[key] = _deduplicate((*merged[key], *values))

    remove = data.get("remove", {})
    if not isinstance(remove, dict):
        raise ValueError(f"locales.{locale}.remove must be an object")
    removals = _read_locale_values(remove, f"locales.{locale}.remove")
    for key, values in removals.items():
        normalized_remove = {normalize_text(value) for value in values}
        merged[key] = tuple(
            value for value in merged[key] if normalize_text(value) not in normalized_remove
        )
    return LocalePatternPack(**merged)


class MultilingualPatternMatcher:
    """Match mixed Chinese/English turn-control expressions."""

    def __init__(
        self,
        *,
        version: str = DEFAULT_PATTERN_VERSION,
        locale_packs: dict[str, LocalePatternPack] | None = None,
        enabled_locales: tuple[str, ...] = ("zh-CN", "en-US"),
    ) -> None:
        self.version = version
        packs = locale_packs or DEFAULT_LOCALE_PACKS
        selected_locales = tuple(locale for locale in enabled_locales if locale in packs)
        if not selected_locales:
            logger.warning(
                "[MMI-TD] no configured pattern locales are available; "
                "falling back to zh-CN,en-US"
            )
            selected_locales = tuple(DEFAULT_LOCALE_PACKS)
            packs = DEFAULT_LOCALE_PACKS
        self.enabled_locales = selected_locales
        self._packs = tuple(packs[locale] for locale in self.enabled_locales)
        self._flat_values = {
            field.name: _deduplicate(
                value for pack in self._packs for value in getattr(pack, field.name)
            )
            for field in fields(LocalePatternPack)
        }
        self._whole_expression_patterns = {
            field: tuple(
                sorted(
                    self._flat_values[field],
                    key=lambda item: len(normalize_text(item)),
                    reverse=True,
                )
            )
            for field in ("backchannels", "confirmations", "noise_expressions")
        }
        self._whole_expression_regex = {
            field: self._compile_whole_expression_regex(patterns)
            for field, patterns in self._whole_expression_patterns.items()
        }

    @classmethod
    def from_file(
        cls,
        path: str = "",
        *,
        enabled_locales: tuple[str, ...] = ("zh-CN", "en-US"),
    ) -> MultilingualPatternMatcher:
        if not path:
            return cls(enabled_locales=enabled_locales)
        try:
            config_path = cls._resolve_config_path(path)
            raw = json.loads(config_path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("pattern config root must be an object")
            version = raw.get("version", "")
            if not isinstance(version, str) or not version.strip():
                raise ValueError("version must be a non-empty string")
            locales = raw.get("locales", {})
            if not isinstance(locales, dict):
                raise ValueError("locales must be an object")
            packs = dict(DEFAULT_LOCALE_PACKS)
            for locale, data in locales.items():
                if not isinstance(locale, str) or not isinstance(data, dict):
                    raise ValueError("each locale must map to an object")
                packs[locale] = _merge_locale_pack(locale, data)
            matcher = cls(
                version=version.strip(),
                locale_packs=packs,
                enabled_locales=enabled_locales,
            )
            logger.info(
                "[MMI-TD] loaded pattern config version=%s locales=%s path=%s",
                matcher.version,
                ",".join(matcher.enabled_locales),
                config_path,
            )
            return matcher
        except Exception:
            logger.exception(
                "[MMI-TD] failed to load pattern config path=%s; using built-in defaults",
                path,
            )
            return cls(enabled_locales=enabled_locales)

    @staticmethod
    def _resolve_config_path(path: str) -> Path:
        config_path = Path(path).expanduser()
        if config_path.is_absolute() or config_path.exists():
            return config_path
        return Path(__file__).resolve().parent.parent / config_path

    def strong_interrupt(self, text: str) -> PatternMatch:
        for pattern in self._values("strong_exclusions"):
            if self._contains(text, pattern):
                return PatternMatch(version=self.version)
        for field, rule, matcher in (
            ("strong_exact", "strong_interrupt.exact", self._exact),
            ("strong_prefixes", "strong_interrupt.prefixes", self._starts),
            ("strong_contains", "strong_interrupt.contains", self._contains),
        ):
            for pattern in self._values(field):
                if matcher(text, pattern):
                    return self._match(rule, pattern)
        for pattern in self._values("strong_repeated_prefixes"):
            if self._starts_repeated(text, pattern):
                return self._match("strong_interrupt.repeated_prefixes", pattern)
        return PatternMatch(version=self.version)

    def explicit_overlap_intent(self, text: str) -> PatternMatch:
        strong = self.strong_interrupt(text)
        if strong.matched:
            return strong
        for pattern in _EXPLICIT_OVERLAP_INTENT_PREFIXES:
            if self._starts(text, pattern):
                return self._match("overlap_intent.prefixes", pattern)
        return PatternMatch(version=self.version)

    def backchannel(self, text: str) -> PatternMatch:
        return self._whole_expression_match(text, "backchannels", "backchannel")

    def addressed_to_other(self, text: str) -> PatternMatch:
        """Detect explicit vocatives that address a person other than the agent."""
        raw = (text or "").strip()
        if _ENGLISH_POST_VOCATIVE_DISCOURSE_RE.match(raw):
            return PatternMatch(version=self.version)
        greeting_match = _ENGLISH_GREETING_VOCATIVE_RE.match(raw)
        if greeting_match:
            vocative = greeting_match.group(1)
            if vocative.lower() not in _TARGET_OR_DISCOURSE_VOCATIVES:
                return self._match("addressee.english_greeting_vocative", vocative)
        titled_match = _ENGLISH_TITLED_VOCATIVE_RE.match(raw)
        if titled_match:
            title = titled_match.group(1).lower()
            if title in _OTHER_ADDRESSEE_TERMS:
                return self._match(
                    "addressee.english_titled_vocative",
                    " ".join(titled_match.groups()),
                )
        match = _ENGLISH_VOCATIVE_RE.match(raw)
        if match:
            vocative = match.group(1)
            normalized = vocative.lower()
            if normalized not in _TARGET_OR_DISCOURSE_VOCATIVES:
                return self._match("addressee.english_vocative", vocative)
        normalized_text = normalize_text(raw)
        first = normalized_text.split(" ", 1)[0] if normalized_text else ""
        if first in _OTHER_ADDRESSEE_TERMS and re.match(
            rf"^\s*{re.escape(first)}\s*[,，]",
            raw,
            flags=re.IGNORECASE,
        ):
            return self._match("addressee.known_vocative", first)
        return PatternMatch(version=self.version)

    def confirmation(self, text: str) -> PatternMatch:
        match = self.backchannel(text)
        if match.matched:
            return PatternMatch(True, "confirmation.backchannel", match.pattern, self.version)
        return self._whole_expression_match(text, "confirmations", "confirmation")

    def wait_expression(self, text: str) -> PatternMatch:
        matched_pattern = ""
        for pattern in self._values("wait_expressions"):
            if self._contains(text, pattern):
                matched_pattern = matched_pattern or pattern
        if not matched_pattern:
            return PatternMatch(version=self.version)
        residue = normalize_text(text)
        for pattern in sorted(
            self._values("wait_expressions"),
            key=lambda value: len(normalize_text(value)),
            reverse=True,
        ):
            target = normalize_text(pattern)
            if not target:
                continue
            if _LATIN_RE.fullmatch(target):
                residue = re.sub(
                    rf"(?<![a-z0-9]){re.escape(target)}(?![a-z0-9])",
                    " ",
                    residue,
                )
            else:
                residue = residue.replace(target.replace(" ", ""), "")
            residue = " ".join(residue.split())
        if (
            residue not in _BENIGN_WAIT_RESIDUES
            and not _BENIGN_WAIT_CJK_RESIDUE_RE.fullmatch(residue.replace(" ", ""))
        ):
            return PatternMatch(version=self.version)
        return self._match("wait_expression", matched_pattern)

    def incomplete_suffix(self, text: str) -> PatternMatch:
        stripped = (text or "").rstrip()
        if stripped.endswith(("?", "？")):
            return PatternMatch(version=self.version)
        if self.backchannel(text).matched:
            return PatternMatch(version=self.version)
        for pattern in self._values("incomplete_suffixes"):
            if self._ends(text, pattern):
                return self._match("incomplete_suffix", pattern)
        return PatternMatch(version=self.version)

    def invalid_or_noise(self, text: str) -> PatternMatch:
        if not normalize_text(text):
            return self._match("noise.empty", "")
        return self._whole_expression_match(text, "noise_expressions", "noise.expression")

    @staticmethod
    def effective_char_count(text: str) -> int:
        return len(normalize_text(text).replace(" ", ""))

    def _values(self, field: str) -> tuple[str, ...]:
        return self._flat_values[field]

    def _match(self, rule: str, pattern: str) -> PatternMatch:
        return PatternMatch(True, rule, pattern, self.version)

    def _whole_expression_match(self, text: str, field: str, rule: str) -> PatternMatch:
        normalized = normalize_text(text)
        if not normalized:
            return PatternMatch(version=self.version)
        patterns = self._whole_expression_patterns[field]
        expression = self._whole_expression_regex[field]
        if expression is not None and expression.fullmatch(normalized):
            for pattern in patterns:
                if self._contains(normalized, pattern):
                    return self._match(rule, pattern)
        return PatternMatch(version=self.version)

    @staticmethod
    def _compile_whole_expression_regex(
        patterns: tuple[str, ...],
    ) -> re.Pattern[str] | None:
        alternatives = [
            re.escape(normalize_text(pattern)).replace(r"\ ", r"\s+")
            for pattern in patterns
            if normalize_text(pattern)
        ]
        if not alternatives:
            return None
        joined = "|".join(alternatives)
        return re.compile(rf"(?:{joined})(?:\s*(?:{joined}))*")

    @staticmethod
    def _exact(text: str, pattern: str) -> bool:
        return normalize_text(text) == normalize_text(pattern)

    @staticmethod
    def _contains(text: str, pattern: str) -> bool:
        normalized = normalize_text(text)
        target = normalize_text(pattern)
        if not target:
            return False
        if _LATIN_RE.fullmatch(target):
            return bool(re.search(rf"(?<![a-z0-9]){re.escape(target)}(?![a-z0-9])", normalized))
        return target.replace(" ", "") in normalized.replace(" ", "")

    @staticmethod
    def _starts(text: str, pattern: str) -> bool:
        normalized = normalize_text(text)
        target = normalize_text(pattern)
        if _LATIN_RE.fullmatch(target):
            return bool(re.match(rf"^{re.escape(target)}(?:\s|$)", normalized))
        return normalized.replace(" ", "").startswith(target.replace(" ", ""))

    @staticmethod
    def _ends(text: str, pattern: str) -> bool:
        normalized = normalize_text(text)
        target = normalize_text(pattern)
        if _LATIN_RE.fullmatch(target):
            return bool(re.search(rf"(?:^|\s){re.escape(target)}$", normalized))
        return normalized.replace(" ", "").endswith(target.replace(" ", ""))

    @staticmethod
    def _starts_repeated(text: str, pattern: str) -> bool:
        normalized = normalize_text(text)
        target = normalize_text(pattern)
        if _LATIN_RE.fullmatch(target):
            return bool(
                re.match(
                    rf"^{re.escape(target)}\s+{re.escape(target)}(?:\s|$)",
                    normalized,
                )
            )
        compact = normalized.replace(" ", "")
        return compact.startswith(target.replace(" ", "") * 2)


DEFAULT_PATTERN_MATCHER = MultilingualPatternMatcher()

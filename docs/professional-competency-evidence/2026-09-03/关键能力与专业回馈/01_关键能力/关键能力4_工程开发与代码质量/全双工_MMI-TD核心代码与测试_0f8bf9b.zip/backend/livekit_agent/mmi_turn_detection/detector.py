"""Detector protocol and V0 rule-based implementation."""

from __future__ import annotations

from typing import Protocol

from .endpointing_policy import BaselineEndpointingPolicy
from .interruption_policy import RuleBasedInterruptionPolicy
from .models import MMITurnContext, MMITurnDecision
from .patterns import DEFAULT_PATTERN_MATCHER, MultilingualPatternMatcher


class MMITurnDetector(Protocol):
    async def detect(self, ctx: MMITurnContext) -> MMITurnDecision:
        ...


class RuleBasedMMITurnDetector:
    def __init__(
        self,
        *,
        interruption_policy: RuleBasedInterruptionPolicy,
        endpointing_policy: BaselineEndpointingPolicy,
        patterns: MultilingualPatternMatcher = DEFAULT_PATTERN_MATCHER,
    ) -> None:
        self._interruption_policy = interruption_policy
        self._endpointing_policy = endpointing_policy
        self._patterns = patterns

    async def detect(self, ctx: MMITurnContext) -> MMITurnDecision:
        if (
            ctx.tts_playing
            or ctx.agent_state == "speaking"
            or (
                ctx.agent_state == "thinking"
                and (
                    self._patterns.strong_interrupt(ctx.transcript_text).matched
                    or self._patterns.backchannel(ctx.transcript_text).matched
                    or self._patterns.addressed_to_other(ctx.transcript_text).matched
                )
            )
        ):
            return self._interruption_policy.decide(ctx)
        return self._endpointing_policy.decide(ctx)

#!/usr/bin/env python3
"""Replay FDB Agent audio and streaming events through a detector interface."""

from __future__ import annotations

import argparse
import json
import wave
from collections import Counter
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Iterable, Protocol

from evaluation.analyze_fdb_mmi import is_strict_control_correct


class TargetState(str, Enum):
    INTERRUPT = "INTERRUPT"
    ADDRESSED_OTHER = "ADDRESSED_OTHER"
    BACKCHANNEL = "BACKCHANNEL"
    CONTINUE = "CONTINUE"
    UNCERTAIN = "UNCERTAIN"


@dataclass(frozen=True)
class AudioChunk:
    start_ms: int
    end_ms: int
    sample_rate: int
    channels: int
    sample_width: int
    pcm: bytes


@dataclass(frozen=True)
class ReplayInput:
    kind: str
    relative_ms: int
    payload: dict[str, Any]
    audio: AudioChunk | None = None


@dataclass
class ReplayContext:
    sample: str
    turn_id: int = -1
    latest_asr: str = ""
    final_asr: str = ""
    asr_hypotheses: list[str] = field(default_factory=list)
    agent_state: str = "unknown"
    user_state: str = "unknown"
    turn_started_during_agent_speaking: bool = False
    turn_started_during_agent_thinking: bool = False
    turn_inferred_from_asr: bool = False
    latest_speaker_gate_message: str = ""
    audio_observed_ms: int = 0


@dataclass(frozen=True)
class DetectorPrediction:
    state: TargetState
    relative_ms: int
    confidence: float
    reason: str
    source: str
    metadata: dict[str, Any] = field(default_factory=dict)


class StreamingReplayDetector(Protocol):
    name: str

    def reset(self, sample: dict[str, Any]) -> None: ...

    def observe(
        self,
        event: ReplayInput,
        context: ReplayContext,
    ) -> DetectorPrediction | Iterable[DetectorPrediction] | None: ...


def _is_control_lane(decision: dict[str, Any]) -> bool:
    return bool(
        decision.get("agent_state") in {"speaking", "thinking"}
        or decision.get("tts_playing")
    )


def _semantic_state(decision: dict[str, Any]) -> TargetState:
    action = str(decision.get("action") or "")
    if action == "START_LISTENING":
        return TargetState.INTERRUPT
    evidence = " ".join(
        str(decision.get(key) or "")
        for key in ("reason", "matched_rule", "matched_pattern")
    ).lower()
    if "backchannel" in evidence:
        return TargetState.BACKCHANNEL
    if "address" in evidence or "vocative" in evidence:
        return TargetState.ADDRESSED_OTHER
    return TargetState.CONTINUE


class LoggedMMIBaseline:
    """Replay historical control decisions to validate timeline parity."""

    name = "logged_mmi_baseline"

    def __init__(self) -> None:
        self._target_turn_id: int | None = None

    def reset(self, sample: dict[str, Any]) -> None:
        timeline = ((sample.get("agent") or {}).get("mmi_timeline") or {})
        target_turn_id = timeline.get("target_turn_id")
        self._target_turn_id = (
            int(target_turn_id) if isinstance(target_turn_id, int) else None
        )

    def observe(
        self,
        event: ReplayInput,
        context: ReplayContext,
    ) -> DetectorPrediction | None:
        del context
        if event.kind != "mmi_decision":
            return None
        decision = event.payload
        if (
            self._target_turn_id is None
            or decision.get("turn_id") != self._target_turn_id
            or not _is_control_lane(decision)
        ):
            return None
        return DetectorPrediction(
            state=_semantic_state(decision),
            relative_ms=event.relative_ms,
            confidence=float(decision.get("confidence") or 0.0),
            reason=str(decision.get("reason") or "historical_decision"),
            source=self.name,
            metadata={
                "historical_action": decision.get("action"),
                "ignore_input": bool(decision.get("ignore_input", False)),
                "turn_id": decision.get("turn_id"),
                "trigger": decision.get("trigger"),
            },
        )


def load_manifest(path: Path) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as fh:
        for line_number, line in enumerate(fh, start=1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"Manifest line {line_number} is not an object")
            items.append(value)
    return items


def _audio_inputs(path: Path, frame_ms: int) -> list[ReplayInput]:
    if frame_ms < 1:
        raise ValueError("frame_ms must be positive")
    events: list[ReplayInput] = []
    with wave.open(str(path), "rb") as reader:
        sample_rate = reader.getframerate()
        channels = reader.getnchannels()
        sample_width = reader.getsampwidth()
        if sample_rate < 1 or channels < 1 or sample_width < 1:
            raise ValueError(f"Invalid WAV format: {path}")
        frame_samples = max(1, round(sample_rate * frame_ms / 1000))
        samples_read = 0
        while True:
            pcm = reader.readframes(frame_samples)
            if not pcm:
                break
            sample_count = len(pcm) // (channels * sample_width)
            start_ms = round(samples_read * 1000 / sample_rate)
            samples_read += sample_count
            end_ms = round(samples_read * 1000 / sample_rate)
            events.append(
                ReplayInput(
                    kind="audio",
                    relative_ms=end_ms,
                    payload={},
                    audio=AudioChunk(
                        start_ms=start_ms,
                        end_ms=end_ms,
                        sample_rate=sample_rate,
                        channels=channels,
                        sample_width=sample_width,
                        pcm=pcm,
                    ),
                )
            )
    return events


def _event_inputs(sample: dict[str, Any]) -> list[ReplayInput]:
    agent = sample.get("agent") or {}
    session = agent.get("session_timeline") or {}
    timeline: list[ReplayInput] = []
    groups = (
        ("state", session.get("state_events") or []),
        ("asr", session.get("asr_hypotheses") or []),
        ("speaker_gate", agent.get("speaker_gate_timeline") or []),
        ("mmi_decision", (agent.get("mmi_timeline") or {}).get("decisions") or []),
    )
    for kind, events in groups:
        for payload in events:
            relative_ms = payload.get("relative_ms")
            if not isinstance(relative_ms, int) or relative_ms < 0:
                continue
            timeline.append(
                ReplayInput(
                    kind=kind,
                    relative_ms=relative_ms,
                    payload=dict(payload),
                )
            )
    return timeline


_EVENT_PRIORITY = {
    "audio": 0,
    "state": 1,
    "asr": 2,
    "speaker_gate": 3,
    "mmi_decision": 4,
}


def _event_order_key(event: ReplayInput) -> tuple[int, int, float, int]:
    if event.kind == "audio":
        return (event.relative_ms, 0, 0.0, 0)
    created_at = event.payload.get("created_at")
    precise_time = (
        float(created_at)
        if isinstance(created_at, (int, float))
        else float("inf")
    )
    return (
        event.relative_ms,
        1,
        precise_time,
        _EVENT_PRIORITY.get(event.kind, 99),
    )


def build_replay_inputs(
    sample: dict[str, Any],
    *,
    frame_ms: int,
    audio_source: str,
) -> list[ReplayInput]:
    agent = sample.get("agent") or {}
    audio = (agent.get("audio") or {}).get(audio_source) or {}
    path_value = audio.get("path")
    if not path_value:
        raise FileNotFoundError(
            f"{sample.get('sample')}: missing Agent {audio_source} audio path"
        )
    path = Path(path_value)
    if not path.is_file():
        raise FileNotFoundError(path)
    timeline = _audio_inputs(path, frame_ms) + _event_inputs(sample)
    return sorted(timeline, key=_event_order_key)


def update_replay_context(context: ReplayContext, event: ReplayInput) -> None:
    if event.kind == "audio" and event.audio is not None:
        context.audio_observed_ms = event.audio.end_ms
    elif event.kind == "asr":
        text = str(event.payload.get("text") or "")
        if (
            text
            and context.user_state != "speaking"
            and context.agent_state in {"speaking", "thinking"}
            and context.final_asr
            and text != context.final_asr
            and not context.turn_inferred_from_asr
        ):
            context.turn_id += 1
            context.turn_started_during_agent_speaking = (
                context.agent_state == "speaking"
            )
            context.turn_started_during_agent_thinking = (
                context.agent_state == "thinking"
            )
            context.turn_inferred_from_asr = True
            context.latest_asr = ""
            context.final_asr = ""
            context.asr_hypotheses = []
        context.latest_asr = text
        if text and (
            not context.asr_hypotheses or context.asr_hypotheses[-1] != text
        ):
            context.asr_hypotheses.append(text)
        if event.payload.get("is_final") and text:
            context.final_asr = text
    elif event.kind == "state":
        event_type = event.payload.get("type")
        if event_type == "agent_state_changed":
            context.agent_state = str(event.payload.get("new_state") or "unknown")
        elif event_type == "user_state_changed":
            new_state = str(event.payload.get("new_state") or "unknown")
            if new_state == "speaking" and context.user_state != "speaking":
                if context.turn_inferred_from_asr:
                    context.turn_inferred_from_asr = False
                else:
                    context.turn_id += 1
                    context.turn_started_during_agent_speaking = (
                        context.agent_state == "speaking"
                    )
                    context.turn_started_during_agent_thinking = (
                        context.agent_state == "thinking"
                    )
                    context.latest_asr = ""
                    context.final_asr = ""
                    context.asr_hypotheses = []
            context.user_state = new_state
    elif event.kind == "speaker_gate":
        context.latest_speaker_gate_message = str(
            event.payload.get("message") or ""
        )


def _predictions(
    value: DetectorPrediction | Iterable[DetectorPrediction] | None,
) -> list[DetectorPrediction]:
    if value is None:
        return []
    if isinstance(value, DetectorPrediction):
        return [value]
    return list(value)


def _control_outcome(predictions: list[DetectorPrediction]) -> str:
    if any(item.state == TargetState.INTERRUPT for item in predictions):
        return "INTERRUPT"
    if any(
        item.metadata.get("historical_action") == "START_SPEAKING"
        and not item.metadata.get("ignore_input", False)
        for item in predictions
    ):
        return "COMMIT"
    return "SUPPRESS" if predictions else "NO_TARGET_DECISION"


def _target_state_outcome(predictions: list[DetectorPrediction]) -> str:
    states = {item.state for item in predictions}
    for state in (
        TargetState.INTERRUPT,
        TargetState.ADDRESSED_OTHER,
        TargetState.BACKCHANNEL,
        TargetState.CONTINUE,
        TargetState.UNCERTAIN,
    ):
        if state in states:
            return state.value
    return TargetState.UNCERTAIN.value


def replay_sample(
    sample: dict[str, Any],
    detector: StreamingReplayDetector,
    *,
    frame_ms: int = 200,
    audio_source: str = "stt_input",
) -> dict[str, Any]:
    detector.reset(sample)
    context = ReplayContext(sample=str(sample.get("sample") or ""))
    inputs = build_replay_inputs(
        sample,
        frame_ms=frame_ms,
        audio_source=audio_source,
    )
    predictions: list[DetectorPrediction] = []
    event_counts: Counter[str] = Counter()
    for event in inputs:
        event_counts[event.kind] += 1
        update_replay_context(context, event)
        predictions.extend(_predictions(detector.observe(event, context)))

    labels = sample.get("labels") or {}
    historical_outcome = (
        ((sample.get("agent") or {}).get("mmi_timeline") or {}).get(
            "target_outcome"
        )
        or "NO_TARGET_DECISION"
    )
    predicted_outcome = _control_outcome(predictions)
    predicted_target_state = _target_state_outcome(predictions)
    expected_target_state = str(labels.get("target_state") or "")
    expected_outcome = str(labels.get("expected_control_outcome") or "")
    return {
        "sample": sample.get("sample"),
        "scenario": sample.get("scenario"),
        "sample_id": sample.get("sample_id"),
        "expected_target_state": expected_target_state,
        "predicted_target_state": predicted_target_state,
        "target_state_correct": predicted_target_state == expected_target_state,
        "expected_control_outcome": expected_outcome,
        "historical_control_outcome": historical_outcome,
        "predicted_control_outcome": predicted_outcome,
        "historical_parity": predicted_outcome == historical_outcome,
        "strict_control_correct": is_strict_control_correct(
            expected_outcome,
            predicted_outcome,
        ),
        "event_counts": dict(sorted(event_counts.items())),
        "duration_ms": max((event.relative_ms for event in inputs), default=0),
        "final_context": {
            "latest_asr": context.latest_asr,
            "final_asr": context.final_asr,
            "asr_hypothesis_count": len(context.asr_hypotheses),
            "agent_state": context.agent_state,
            "user_state": context.user_state,
            "turn_id": context.turn_id,
            "turn_started_during_agent_speaking": (
                context.turn_started_during_agent_speaking
            ),
            "turn_started_during_agent_thinking": (
                context.turn_started_during_agent_thinking
            ),
            "audio_observed_ms": context.audio_observed_ms,
        },
        "predictions": [
            {
                **asdict(prediction),
                "state": prediction.state.value,
            }
            for prediction in predictions
        ],
    }


def summarize(results: list[dict[str, Any]], detector_name: str) -> dict[str, Any]:
    expected_positive = [
        item for item in results if item["expected_control_outcome"] == "INTERRUPT"
    ]
    expected_negative = [
        item for item in results if item["expected_control_outcome"] != "INTERRUPT"
    ]
    tp = sum(
        item["predicted_control_outcome"] == "INTERRUPT"
        for item in expected_positive
    )
    fp = sum(
        item["predicted_control_outcome"] == "INTERRUPT"
        for item in expected_negative
    )
    scenario_counts = Counter(item["scenario"] for item in results)
    event_counts: Counter[str] = Counter()
    for item in results:
        event_counts.update(item["event_counts"])
    return {
        "detector": detector_name,
        "samples": len(results),
        "historical_parity_count": sum(
            bool(item["historical_parity"]) for item in results
        ),
        "historical_parity_rate": (
            round(
                sum(bool(item["historical_parity"]) for item in results)
                / len(results),
                6,
            )
            if results
            else None
        ),
        "strict_control_correct": sum(
            bool(item["strict_control_correct"]) for item in results
        ),
        "strict_control_accuracy": (
            round(
                sum(bool(item["strict_control_correct"]) for item in results)
                / len(results),
                6,
            )
            if results
            else None
        ),
        "target_state_correct": sum(
            bool(item["target_state_correct"]) for item in results
        ),
        "target_state_accuracy": (
            round(
                sum(bool(item["target_state_correct"]) for item in results)
                / len(results),
                6,
            )
            if results
            else None
        ),
        "control_confusion_matrix": {
            "tp": tp,
            "fn": len(expected_positive) - tp,
            "fp": fp,
            "tn": len(expected_negative) - fp,
            "recall": round(tp / len(expected_positive), 6)
            if expected_positive
            else None,
            "false_positive_rate": round(fp / len(expected_negative), 6)
            if expected_negative
            else None,
        },
        "scenario_counts": dict(sorted(scenario_counts.items())),
        "event_counts": dict(sorted(event_counts.items())),
    }


def run_replay(
    manifest_path: Path,
    detector: StreamingReplayDetector,
    *,
    frame_ms: int = 200,
    audio_source: str = "stt_input",
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    samples = load_manifest(manifest_path)
    results = [
        replay_sample(
            sample,
            detector,
            frame_ms=frame_ms,
            audio_source=audio_source,
        )
        for sample in samples
    ]
    summary = {
        "manifest_path": str(manifest_path.resolve()),
        "frame_ms": frame_ms,
        "audio_source": audio_source,
        **summarize(results, detector.name),
    }
    return summary, results


def write_report(
    output_dir: Path,
    summary: dict[str, Any],
    results: list[dict[str, Any]],
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    with (output_dir / "results.jsonl").open("w", encoding="utf-8") as fh:
        for item in results:
            fh.write(json.dumps(item, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Replay an FDB MMI manifest")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--frame-ms", type=int, default=200)
    parser.add_argument(
        "--audio-source",
        choices=["raw_input", "stt_input"],
        default="stt_input",
    )
    parser.add_argument(
        "--baseline",
        choices=["logged"],
        default="logged",
    )
    args = parser.parse_args()

    detector: StreamingReplayDetector = LoggedMMIBaseline()
    summary, results = run_replay(
        args.manifest,
        detector,
        frame_ms=args.frame_ms,
        audio_source=args.audio_source,
    )
    write_report(args.output_dir, summary, results)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

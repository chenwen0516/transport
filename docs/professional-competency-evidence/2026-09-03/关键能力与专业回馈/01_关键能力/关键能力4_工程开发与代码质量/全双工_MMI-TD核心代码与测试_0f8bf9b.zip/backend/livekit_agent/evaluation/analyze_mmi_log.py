#!/usr/bin/env python3
"""MMI-TD 决策日志分析（A/B 第一阶段观测）。

解析 `[MMI-TD] decision {...}` 行，把「门置信度 ↔ ASR 文本长度 ↔ 决策」按行 join 后聚合，
快速看出某次会话/某配置下：背景噪声丢弃、误打断抑制、提交分布、置信度覆盖与分布。

用法：
    python evaluation/analyze_mmi_log.py tmp                    # 递归扫描运行目录
    python evaluation/analyze_mmi_log.py tmp/runs/*/mmi_turn_detection_active_*.log
    python evaluation/analyze_mmi_log.py log --session health-voice-79-1781248463

无第三方依赖。
"""

from __future__ import annotations

import argparse
import glob
import json
import os
from collections import Counter
from typing import Any, Iterable

DECISION_MARKER = "[MMI-TD] decision "


def iter_decisions(paths: Iterable[str], session: str | None) -> Iterable[dict[str, Any]]:
    for path in paths:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                for line in fh:
                    idx = line.find(DECISION_MARKER)
                    if idx < 0:
                        continue
                    try:
                        payload = json.loads(line[idx + len(DECISION_MARKER):].strip())
                    except json.JSONDecodeError:
                        continue
                    if session and payload.get("session_id") != session:
                        continue
                    yield payload
        except OSError as exc:
            print(f"!! 无法读取 {path}: {exc}")


def _pct(part: int, total: int) -> str:
    return f"{(100 * part / total):.1f}%" if total else "—"


def _histogram(values: list[float], bins: int = 10) -> list[tuple[str, int]]:
    out: list[tuple[str, int]] = []
    edges = [i / bins for i in range(bins + 1)]
    for i in range(bins):
        lo, hi = edges[i], edges[i + 1]
        n = sum(1 for v in values if (lo <= v < hi) or (i == bins - 1 and v == hi))
        out.append((f"[{lo:.1f},{hi:.1f})", n))
    return out


def analyze(decisions: list[dict[str, Any]]) -> None:
    total = len(decisions)
    if total == 0:
        print("没有解析到任何决策行。")
        return

    actions = Counter(d.get("action", "?") for d in decisions)
    reasons = Counter(d.get("reason", "?") for d in decisions)
    triggers = Counter(d.get("trigger", "?") for d in decisions)
    matched_rules = Counter(d.get("matched_rule") or "(none)" for d in decisions)

    # 置信度覆盖：有信号 / 过期 / 无信号
    with_signal = [
        d for d in decisions if isinstance(d.get("external_voice_confidence"), (int, float))
    ]
    stale = [d for d in decisions if d.get("external_voice_stale")]
    conf_values = [float(d["external_voice_confidence"]) for d in with_signal]

    # 关注指标
    suppressed = reasons.get("low_voice_confidence_suppressed", 0)
    observed = reasons.get("low_voice_confidence_observe", 0)
    noise_low_conf = reasons.get("invalid_or_noise_low_voice_confidence", 0)
    noise_timeout = reasons.get("invalid_or_noise_turn_timeout", 0)
    noise_pending = reasons.get("invalid_or_noise_turn_pending", 0)
    backchannel = sum(1 for d in decisions if d.get("reason") == "backchannel")
    interrupts = sum(1 for d in decisions if d.get("action") == "START_LISTENING")
    commits = sum(1 for d in decisions if d.get("action") == "START_SPEAKING")

    print(f"== 决策总数: {total} ==")
    sessions = {d.get("session_id") for d in decisions}
    print(f"会话数: {len(sessions)}  {sorted(s for s in sessions if s)[:3]}{' ...' if len(sessions) > 3 else ''}")

    print("\n-- action 分布 --")
    for k, v in actions.most_common():
        print(f"  {k:<20} {v:>5}  {_pct(v, total)}")

    print("\n-- reason Top --")
    for k, v in reasons.most_common(15):
        print(f"  {k:<40} {v:>5}  {_pct(v, total)}")

    print("\n-- trigger 分布 --")
    for k, v in triggers.most_common():
        print(f"  {k:<40} {v:>5}")

    print("\n-- matched_rule 分布 --")
    for k, v in matched_rules.most_common():
        print(f"  {k:<28} {v:>5}")

    print("\n-- 语音置信度信号覆盖 --")
    print(f"  有信号:   {len(with_signal):>5}  {_pct(len(with_signal), total)}")
    print(f"  过期作废: {len(stale):>5}  {_pct(len(stale), total)}")
    print(f"  无信号:   {total - len(with_signal) - len(stale):>5}")
    if conf_values:
        mean = sum(conf_values) / len(conf_values)
        print(f"  置信度 min/mean/max: {min(conf_values):.3f} / {mean:.3f} / {max(conf_values):.3f}")
        print("  置信度直方图:")
        for label, n in _histogram(conf_values):
            bar = "#" * min(40, n)
            print(f"    {label:<12} {n:>4} {bar}")

    print("\n-- 关注指标（B+A 效果）--")
    print(f"  低置信抑制打断 (low_voice_confidence_suppressed): {suppressed}")
    print(f"  低置信延迟观察 (low_voice_confidence_observe): {observed}")
    print(f"  低置信提前丢弃噪声 (invalid_or_noise_low_voice_confidence): {noise_low_conf}")
    print(f"  噪声超时丢弃 (invalid_or_noise_turn_timeout): {noise_timeout}")
    print(f"  噪声待定 (invalid_or_noise_turn_pending): {noise_pending}")
    print(f"  backchannel 忽略: {backchannel}")
    print(f"  实际打断 START_LISTENING: {interrupts}")
    print(f"  提交开口 START_SPEAKING: {commits}")


def main() -> None:
    ap = argparse.ArgumentParser(description="分析 MMI-TD 决策日志")
    ap.add_argument("paths", nargs="+", help="日志文件路径（支持通配）")
    ap.add_argument("--session", default=None, help="只统计某个 session_id")
    args = ap.parse_args()

    expanded: list[str] = []
    for p in args.paths:
        matched = glob.glob(p)
        paths = matched if matched else [p]
        for path in paths:
            if os.path.isdir(path):
                expanded.extend(
                    glob.glob(
                        os.path.join(path, "**", "mmi_turn_detection_active_*.log"),
                        recursive=True,
                    )
                )
            else:
                expanded.append(path)
    expanded = sorted(dict.fromkeys(expanded))

    decisions = list(iter_decisions(expanded, args.session))
    analyze(decisions)


if __name__ == "__main__":
    main()

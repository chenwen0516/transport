#!/usr/bin/env python3
"""决定性验证：VAD 能否在强背景下切出能量切不出的 gap。

VAD 对齐注册是否有效，取决于背景是【非语音】(VAD 能切→有效) 还是【竞争人声】(VAD 也判语音→无效)。
对每个会话的锁定前窗口(及全程)对比：
  · 能量 voiced 占比 (RMS≥min_energy) —— 当前切段判据
  · VAD speech 占比 (silero prob≥0.5)  —— 候选判据
  · 各自的 ≥0.5s gap 数 (能否结束段、产出注册候选)
判定：VAD_speech 显著低于能量 voiced 且产出更多 gap → 背景非语音，VAD 对齐注册有效。
"""
from __future__ import annotations
import wave
import numpy as np
import onnxruntime as ort

VAD_MODEL = ".venv/lib/python3.12/site-packages/livekit/plugins/silero/resources/silero_vad.onnx"
MIN_ENERGY = 50.0
VAD_THR = 0.5
CHUNK = 512          # silero v5 @16k
SR16 = 16000
GAP_SEC = 0.5

SESSIONS = {
    "152517 慢锁42.6s 强背景": ("tmp/audio_raw_input_health-voice-79-1781767506_20260618_152517.wav", 24.0),
    "104824 慢锁44.9s 强背景": ("tmp/audio_raw_input_health-voice-79-1781750893_20260618_104824.wav", 45.0),
    "160955 快锁9.2s 干净":    ("tmp/audio_raw_input_health-voice-79-1781770187_20260618_160955.wav", 9.0),
}


def read(p):
    with wave.open(p, "rb") as w:
        sr, ch = w.getframerate(), w.getnchannels()
        d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    return (d[::ch] if ch > 1 else d), sr


def to16(x, sr):
    if sr == SR16:
        return x.astype(np.float32)
    t = int(len(x) * SR16 / sr)
    return np.interp(np.linspace(0, len(x), t, endpoint=False), np.arange(len(x)), x).astype(np.float32)


def vad_probs(x16):
    """逐 512 样本块跑 silero VAD，返回每块语音概率。"""
    sess = ort.InferenceSession(VAD_MODEL, providers=["CPUExecutionProvider"])
    state = np.zeros((2, 1, 128), dtype=np.float32)
    sr_t = np.array(SR16, dtype=np.int64)
    probs = []
    n = (len(x16) // CHUNK) * CHUNK
    for i in range(0, n, CHUNK):
        chunk = (x16[i:i + CHUNK] / 32768.0).astype(np.float32)[None, :]  # silero 期望 [-1,1]
        out, state = sess.run(["output", "stateN"], {"input": chunk, "state": state, "sr": sr_t})
        probs.append(float(out[0, 0]))
    return np.array(probs)


def gaps_count(mask_voiced, frame_sec, gap_sec=GAP_SEC):
    """非 voiced 连续段中 ≥gap_sec 的个数（= 能结束段的 gap 数）。"""
    need = int(round(gap_sec / frame_sec))
    cnt = run = 0
    for v in mask_voiced:
        if not v:
            run += 1
        else:
            if run >= need:
                cnt += 1
            run = 0
    if run >= need:
        cnt += 1
    return cnt


def analyze(x16, label):
    # 能量帧（20ms）
    efl = int(SR16 * 0.02)
    n = (len(x16) // efl) * efl
    erms = np.sqrt(np.mean(x16[:n].reshape(-1, efl).astype(np.float64) ** 2, axis=1))
    e_voiced = erms >= MIN_ENERGY
    # VAD 块（32ms）
    p = vad_probs(x16)
    v_speech = p >= VAD_THR
    print(f"  能量 voiced 占比={e_voiced.mean():.0%}  gap(≥0.5s)={gaps_count(e_voiced, 0.02)}")
    print(f"  VAD  speech 占比={v_speech.mean():.0%}  gap(≥0.5s)={gaps_count(v_speech, CHUNK / SR16)}")
    print(f"  VAD prob 分位: p25={np.percentile(p,25):.2f} p50={np.percentile(p,50):.2f} p75={np.percentile(p,75):.2f}")
    return e_voiced.mean(), v_speech.mean()


def main():
    for label, (path, pre_sec) in SESSIONS.items():
        raw, sr = read(path)
        x16 = to16(raw, sr)
        print(f"\n● {label}")
        print(f"  [锁定前 {pre_sec:.0f}s 窗口]")
        ev, vv = analyze(x16[: int(pre_sec * SR16)], label)
        verdict = (
            "✅ VAD 显著切开背景(非语音背景)→ VAD 对齐注册有效"
            if (ev - vv) >= 0.25 else
            "❌ VAD 仍判语音(竞争人声背景)→ VAD 对齐注册无效"
        )
        print(f"  → 能量voiced {ev:.0%} vs VAD speech {vv:.0%}  {verdict}")


if __name__ == "__main__":
    main()

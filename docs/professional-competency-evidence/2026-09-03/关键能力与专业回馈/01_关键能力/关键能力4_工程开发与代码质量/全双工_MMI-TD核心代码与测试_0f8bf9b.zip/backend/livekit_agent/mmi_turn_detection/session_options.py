"""Build LiveKit turn handling options for native and Active MMI-TD sessions."""

from __future__ import annotations

from typing import Any

from livekit.plugins.turn_detector.multilingual import MultilingualModel

from .models import MMIMode


def build_local_turn_handling(config: Any, mode: MMIMode) -> dict[str, Any]:
    endpointing = {
        "mode": config.session.endpointing_mode,
        "min_delay": config.session.min_endpointing_delay,
        "max_delay": config.session.max_endpointing_delay,
    }

    if mode == MMIMode.ACTIVE:
        return {
            "turn_detection": "manual",
            "endpointing": endpointing,
            "interruption": {
                # MMI-TD owns interruption decisions in Active mode. The executor
                # uses a forced programmatic interrupt after policy approval.
                "enabled": False,
                "min_duration": config.session.min_interruption_duration,
                "min_words": config.session.min_interruption_words,
                "discard_audio_if_uninterruptible": False,
                "resume_false_interruption": False,
                "false_interruption_timeout": None,
            },
            "preemptive_generation": {"enabled": False},
        }

    return {
        "turn_detection": MultilingualModel(),
        "endpointing": endpointing,
        "interruption": {
            "enabled": config.session.allow_interruptions,
            "mode": "vad",
            "min_duration": config.session.min_interruption_duration,
            "min_words": config.session.min_interruption_words,
            "discard_audio_if_uninterruptible": True,
            "resume_false_interruption": True,
            "false_interruption_timeout": 2.0,
        },
        "preemptive_generation": {"enabled": False},
    }

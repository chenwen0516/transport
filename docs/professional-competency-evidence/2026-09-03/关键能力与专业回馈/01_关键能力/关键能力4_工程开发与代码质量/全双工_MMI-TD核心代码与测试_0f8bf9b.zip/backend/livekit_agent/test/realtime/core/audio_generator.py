"""PCM 音频生成器

程序化生成 16kHz/16bit/单声道 PCM 测试音频，用于自动化测试。
支持静音、正弦波、白噪声、类语音信号（多谐波+包络调制）。
"""

import struct
import math
import random
from pathlib import Path


class AudioGenerator:
    """程序化生成 PCM16 测试音频"""

    SAMPLE_RATE = 16000
    SAMPLE_WIDTH = 2  # 16-bit
    MAX_AMPLITUDE = 32767

    @staticmethod
    def silence(duration_s: float) -> bytes:
        """生成指定时长的静音 PCM 数据"""
        num_samples = int(AudioGenerator.SAMPLE_RATE * duration_s)
        return b'\x00\x00' * num_samples

    @staticmethod
    def sine_wave(duration_s: float, freq: float = 440.0, amplitude: float = 0.8) -> bytes:
        """生成单一频率正弦波"""
        num_samples = int(AudioGenerator.SAMPLE_RATE * duration_s)
        amp = int(AudioGenerator.MAX_AMPLITUDE * amplitude)
        samples = []
        for i in range(num_samples):
            t = i / AudioGenerator.SAMPLE_RATE
            value = int(amp * math.sin(2 * math.pi * freq * t))
            samples.append(struct.pack('<h', max(-32768, min(32767, value))))
        return b''.join(samples)

    @staticmethod
    def white_noise(duration_s: float, amplitude: float = 0.3) -> bytes:
        """生成白噪声"""
        num_samples = int(AudioGenerator.SAMPLE_RATE * duration_s)
        amp = int(AudioGenerator.MAX_AMPLITUDE * amplitude)
        samples = []
        for i in range(num_samples):
            value = random.randint(-amp, amp)
            samples.append(struct.pack('<h', value))
        return b''.join(samples)

    @staticmethod
    def speech_like(duration_s: float, amplitude: float = 0.7) -> bytes:
        """生成类语音信号（多谐波叠加+包络调制，能触发 VAD）

        通过叠加人声基频(100-300Hz)及其谐波，加上随机幅度调制
        模拟语音频谱特征，使 Silero VAD 判定为语音。
        """
        num_samples = int(AudioGenerator.SAMPLE_RATE * duration_s)
        amp = AudioGenerator.MAX_AMPLITUDE * amplitude

        # 基频随时间缓慢变化 (100-250Hz，模拟语调)
        base_freq = 150.0
        # 谐波频率及其相对幅度
        harmonics = [
            (1.0, 1.0),     # 基频 ~150Hz
            (2.0, 0.7),     # 二次谐波 ~300Hz
            (3.0, 0.5),     # 三次谐波 ~450Hz
            (4.0, 0.3),     # 四次谐波 ~600Hz
            (5.0, 0.2),     # 五次谐波 ~750Hz
            (8.0, 0.15),    # 高次谐波 ~1200Hz
            (12.0, 0.1),    # 高次谐波 ~1800Hz
            (17.0, 0.05),   # 高频成分 ~2550Hz
        ]

        samples = []
        # 包络参数：模拟音节节奏 (约 4-6 个音节/秒)
        syllable_rate = 5.0  # 音节/秒
        envelope_phase = random.uniform(0, 2 * math.pi)

        for i in range(num_samples):
            t = i / AudioGenerator.SAMPLE_RATE

            # 基频微小抖动 (模拟自然语调变化)
            freq_variation = base_freq + 30 * math.sin(2 * math.pi * 0.5 * t)

            # 叠加谐波
            signal = 0.0
            for harmonic_mult, harmonic_amp in harmonics:
                freq = freq_variation * harmonic_mult
                signal += harmonic_amp * math.sin(2 * math.pi * freq * t)

            # 归一化谐波叠加
            max_harmonic_sum = sum(h[1] for h in harmonics)
            signal /= max_harmonic_sum

            # 包络调制 (模拟音节节奏)
            envelope = 0.5 + 0.5 * math.sin(
                2 * math.pi * syllable_rate * t + envelope_phase
            )
            # 添加随机微扰
            envelope *= (0.8 + 0.4 * random.random())
            envelope = max(0.1, min(1.0, envelope))

            value = int(amp * signal * envelope)
            value = max(-32768, min(32767, value))
            samples.append(struct.pack('<h', value))

        return b''.join(samples)

    @staticmethod
    def low_amplitude_noise(duration_s: float, amplitude: float = 0.02) -> bytes:
        """生成极低音量噪声（不应触发 VAD）"""
        return AudioGenerator.white_noise(duration_s, amplitude=amplitude)

    @staticmethod
    def concat(*segments: bytes) -> bytes:
        """拼接多段 PCM 数据"""
        return b''.join(segments)

    @staticmethod
    def load_pcm(file_path: str) -> bytes:
        """从文件加载原始 PCM 数据"""
        return Path(file_path).read_bytes()

    @staticmethod
    def save_pcm(data: bytes, file_path: str) -> None:
        """保存 PCM 数据到文件"""
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        Path(file_path).write_bytes(data)

    @staticmethod
    def duration_s(pcm_data: bytes) -> float:
        """计算 PCM 数据的时长（秒）"""
        num_samples = len(pcm_data) // AudioGenerator.SAMPLE_WIDTH
        return num_samples / AudioGenerator.SAMPLE_RATE

"""Aggregate fast-path Shadow timing events from MMI logs."""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

_EVENT_PATTERN = re.compile(
    r"\[MMI-TD\] "
    r"(fast_path_pending|fast_path_decision|fast_path_deadline|"
    r"fast_path_native_stop|fast_path_resolved) "
    r"(\{.*\})\s*$"
)


def percentile(values: list[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    rank = max(0, math.ceil(fraction * len(ordered)) - 1)
    return round(ordered[rank], 3)


def iter_fast_path_events(paths: Iterable[Path]) -> tuple[list[dict[str, Any]], int]:
    events: list[dict[str, Any]] = []
    malformed = 0
    for path in paths:
        with path.open(encoding="utf-8", errors="replace") as handle:
            for line_number, line in enumerate(handle, 1):
                match = _EVENT_PATTERN.search(line)
                if match is None:
                    continue
                try:
                    payload = json.loads(match.group(2))
                except json.JSONDecodeError:
                    malformed += 1
                    continue
                payload["event_type"] = match.group(1)
                payload["source_file"] = str(path)
                payload["line_number"] = line_number
                events.append(payload)
    return events, malformed


def analyze_fast_path_logs(paths: Iterable[Path]) -> dict[str, Any]:
    events, malformed = iter_fast_path_events(paths)
    attempts: dict[tuple[str, int, int], dict[str, Any]] = {}
    event_counts: Counter[str] = Counter()

    for event in events:
        event_counts[event["event_type"]] += 1
        key = (
            str(event.get("session_id", "")),
            int(event.get("turn_id", -1)),
            int(event.get("agent_speech_id", -1)),
        )
        attempt = attempts.setdefault(
            key,
            {
                "session_id": key[0],
                "turn_id": key[1],
                "agent_speech_id": key[2],
                "policy_version": event.get("policy_version"),
                "deadline_ms": event.get("deadline_ms"),
                "first_decisive_ms": None,
                "first_decisive_recommendation": None,
                "native_stop": None,
                "resolution": None,
            },
        )
        if (
            event["event_type"] == "fast_path_decision"
            and event.get("recommendation") != "PENDING_BARGE_IN"
            and attempt["first_decisive_ms"] is None
        ):
            attempt["first_decisive_ms"] = event.get("elapsed_ms")
            attempt["first_decisive_recommendation"] = event.get("recommendation")
        elif event["event_type"] == "fast_path_native_stop":
            attempt["native_stop"] = event
            if attempt["first_decisive_ms"] is None:
                attempt["first_decisive_ms"] = event.get("first_decisive_ms")
                attempt["first_decisive_recommendation"] = event.get("recommendation")
        elif event["event_type"] == "fast_path_resolved":
            attempt["resolution"] = event.get("reason")

    rows = list(attempts.values())
    decisive_rows = [
        row for row in rows if isinstance(row.get("first_decisive_ms"), (int, float))
    ]
    latencies = [float(row["first_decisive_ms"]) for row in decisive_rows]
    native_stops = [row["native_stop"] for row in rows if row["native_stop"]]
    decisive_within_deadline = sum(
        float(row["first_decisive_ms"]) <= float(row["deadline_ms"])
        for row in decisive_rows
        if isinstance(row.get("deadline_ms"), (int, float))
    )
    recommendation_counts = Counter(
        str(row["first_decisive_recommendation"])
        for row in decisive_rows
    )

    return {
        "summary": {
            "attempts": len(rows),
            "events": len(events),
            "malformed_events": malformed,
            "event_counts": dict(sorted(event_counts.items())),
            "first_decisive_count": len(decisive_rows),
            "first_decisive_p50_ms": percentile(latencies, 0.50),
            "first_decisive_p95_ms": percentile(latencies, 0.95),
            "decisive_within_deadline_count": decisive_within_deadline,
            "decisive_within_deadline_rate": (
                decisive_within_deadline / len(rows) if rows else None
            ),
            "native_stop_count": len(native_stops),
            "observer_started_before_native_stop_count": sum(
                event.get("observer_started_before_native_stop") is True
                for event in native_stops
            ),
            "observer_started_before_native_stop_rate": (
                sum(
                    event.get("observer_started_before_native_stop") is True
                    for event in native_stops
                )
                / len(native_stops)
                if native_stops
                else None
            ),
            "decision_before_native_stop_count": sum(
                event.get("decision_before_native_stop") is True
                for event in native_stops
            ),
            "decision_before_native_stop_rate": (
                sum(
                    event.get("decision_before_native_stop") is True
                    for event in native_stops
                )
                / len(native_stops)
                if native_stops
                else None
            ),
            "recommendation_counts": dict(sorted(recommendation_counts.items())),
        },
        "attempts": rows,
    }


def discover_logs(root: Path) -> list[Path]:
    if root.is_file():
        return [root]
    return sorted(root.rglob("mmi_turn_detection*.log"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()

    report = analyze_fast_path_logs(discover_logs(args.path))
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.json is not None:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

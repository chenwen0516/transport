#!/usr/bin/env python3
"""Export FDB v1.5 sessions as an audio + streaming MMI replay manifest.

The exporter does not copy recordings. It joins each FDB noisy session to the
Agent artifact directory by LiveKit room and writes absolute paths plus aligned
timelines. Transcript text is emitted only when ``--include-transcripts`` is
explicitly enabled for a synthetic-data run.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from evaluation.analyze_fdb_mmi import (
    DECISION_MARKER,
    EXPECTED_OUTCOME,
    NATIVE_ACTION_MARKER,
    SCENARIOS,
    build_agent_run_index,
    extract_room,
    select_target_turn,
)

FORMAT_VERSION = 1
TARGET_STATE = {
    "background_speech": "CONTINUE",
    "talking_to_other": "ADDRESSED_OTHER",
    "user_backchannel": "BACKCHANNEL",
    "user_interruption": "INTERRUPT",
}
LOG_TIMESTAMP_RE = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})")


def _load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        value = json.load(fh)
    return value if isinstance(value, dict) else {}


def _absolute(path: Path) -> str:
    return str(path.resolve())


def _find_latest(directory: Path, pattern: str) -> Path | None:
    matches = sorted(directory.glob(pattern)) if directory.is_dir() else []
    return matches[-1] if matches else None


def _local_epoch(value: str, timezone: ZoneInfo, *, log_format: bool = False) -> float:
    timestamp_format = "%Y-%m-%d %H:%M:%S,%f" if log_format else "%Y-%m-%dT%H:%M:%S"
    return datetime.strptime(value, timestamp_format).replace(tzinfo=timezone).timestamp()


def _relative_ms(created_at: float | None, recording_epoch: float | None) -> int | None:
    if created_at is None or recording_epoch is None:
        return None
    return round((created_at - recording_epoch) * 1000)


def _behavior_label(sample_dir: Path) -> str | None:
    labels = _load_json(sample_dir / "content_tag.json").get("behaviour") or []
    return str(labels[0]) if labels else None


def _v15_root(run_dir: Path) -> Path:
    candidates = (run_dir / "data" / "v1.5", run_dir / "v1.5", run_dir)
    for path in candidates:
        if path.is_dir() and (path.name == "v1.5" or any((path / item).is_dir() for item in SCENARIOS)):
            return path
    raise FileNotFoundError(f"Cannot find v1.5 data below {run_dir}")


def _audio_artifact(
    agent_dir: Path,
    recording: dict[str, Any],
    key: str,
    fallback_pattern: str,
) -> dict[str, Any] | None:
    declared = recording.get(key)
    declared = declared if isinstance(declared, dict) else {}
    path_value = str(declared.get("path") or "")
    path = agent_dir / Path(path_value).name if path_value else _find_latest(agent_dir, fallback_pattern)
    if path is None:
        return None
    return {
        "path": _absolute(path),
        "exists": path.is_file(),
        "sample_rate": declared.get("sample_rate"),
        "channels": declared.get("channels"),
        "duration_sec": declared.get("duration_sec"),
        "samples_per_channel": declared.get("samples_per_channel"),
    }


def extract_session_timeline(
    path: Path,
    recording_epoch: float | None,
    *,
    include_transcripts: bool,
) -> dict[str, list[dict[str, Any]]]:
    report = _load_json(path)
    hypotheses: list[dict[str, Any]] = []
    states: list[dict[str, Any]] = []
    for event in report.get("events") or []:
        if not isinstance(event, dict):
            continue
        event_type = str(event.get("type") or "")
        created_at = event.get("created_at")
        created_at = float(created_at) if isinstance(created_at, (int, float)) else None
        base = {
            "created_at": created_at,
            "relative_ms": _relative_ms(created_at, recording_epoch),
        }
        if event_type == "user_input_transcribed":
            text = str(event.get("transcript") or "")
            item = {
                **base,
                "is_final": bool(event.get("is_final")),
                "speaker_id": event.get("speaker_id"),
                "language": event.get("language"),
                "text_length": len(text),
            }
            if include_transcripts:
                item["text"] = text
            hypotheses.append(item)
        elif event_type in {"user_state_changed", "agent_state_changed", "speech_created"}:
            states.append(
                {
                    **base,
                    "type": event_type,
                    "old_state": event.get("old_state"),
                    "new_state": event.get("new_state"),
                    "user_initiated": event.get("user_initiated"),
                    "source": event.get("source"),
                }
            )
    return {"asr_hypotheses": hypotheses, "state_events": states}


def _payload_after_marker(line: str, marker: str) -> dict[str, Any] | None:
    index = line.find(marker)
    if index < 0:
        return None
    try:
        value = json.loads(line[index + len(marker) :].strip())
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def extract_mmi_timeline(
    path: Path,
    recording_epoch: float | None,
    timezone: ZoneInfo,
) -> dict[str, Any]:
    decisions: list[dict[str, Any]] = []
    native_actions: list[dict[str, Any]] = []
    malformed = 0
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            marker = (
                DECISION_MARKER
                if DECISION_MARKER in line
                else NATIVE_ACTION_MARKER
                if NATIVE_ACTION_MARKER in line
                else None
            )
            if marker is None:
                continue
            payload = _payload_after_marker(line, marker)
            timestamp_match = LOG_TIMESTAMP_RE.match(line)
            if payload is None:
                malformed += 1
                continue
            created_at = (
                _local_epoch(timestamp_match.group(1), timezone, log_format=True)
                if timestamp_match
                else None
            )
            item = {
                **payload,
                "created_at": created_at,
                "relative_ms": _relative_ms(created_at, recording_epoch),
            }
            (decisions if marker == DECISION_MARKER else native_actions).append(item)

    target_turn_id, _, _, target_outcome = select_target_turn(decisions)
    return {
        "decisions": decisions,
        "native_actions": native_actions,
        "malformed_lines": malformed,
        "target_turn_id": target_turn_id,
        "target_outcome": target_outcome,
    }


def extract_speaker_gate_timeline(
    path: Path,
    recording_epoch: float | None,
    timezone: ZoneInfo,
) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            match = LOG_TIMESTAMP_RE.match(line)
            if not match or "[SpeakerGate]" not in line:
                continue
            created_at = _local_epoch(match.group(1), timezone, log_format=True)
            events.append(
                {
                    "created_at": created_at,
                    "relative_ms": _relative_ms(created_at, recording_epoch),
                    "message": line.split("[SpeakerGate]", 1)[1].strip(),
                }
            )
    return events


def _fdb_audio(sample_dir: Path) -> dict[str, str]:
    return {path.stem: _absolute(path) for path in sorted(sample_dir.glob("*.wav"))}


def export_sample(
    scenario: str,
    sample_dir: Path,
    agent_index: dict[str, Path],
    timezone: ZoneInfo,
    *,
    include_transcripts: bool,
) -> dict[str, Any]:
    room = extract_room(sample_dir / "output_events.jsonl")
    metadata = _load_json(sample_dir / "metadata.json")
    item: dict[str, Any] = {
        "format_version": FORMAT_VERSION,
        "sample": f"v1.5/{scenario}/{sample_dir.name}",
        "scenario": scenario,
        "sample_id": sample_dir.name,
        "room": room,
        "labels": {
            "target_state": TARGET_STATE[scenario],
            "expected_control_outcome": EXPECTED_OUTCOME[scenario],
            "behavior": _behavior_label(sample_dir),
        },
        "fdb": {
            "sample_dir": _absolute(sample_dir),
            "metadata_path": _absolute(sample_dir / "metadata.json"),
            "audio": _fdb_audio(sample_dir),
        },
        "agent": None,
        "quality": {"joined": False, "replay_ready": False, "missing": []},
    }
    if include_transcripts:
        item["fdb"]["expected_context_text"] = metadata.get("context_text")
        item["fdb"]["expected_current_turn_text"] = metadata.get("current_turn_text")
    if not room:
        item["quality"]["missing"].append("room")
        return item

    agent_dir = agent_index.get(room)
    if agent_dir is None:
        item["quality"]["missing"].append("agent_run")
        return item

    recording_path = _find_latest(agent_dir, "audio_recording_*.json")
    session_path = _find_latest(agent_dir, "session_report_*.json")
    mmi_path = _find_latest(agent_dir, "mmi_turn_detection_active_*.log")
    gate_path = _find_latest(agent_dir, "speaker_gate_*.log")
    required = {
        "audio_recording": recording_path,
        "session_report": session_path,
        "mmi_log": mmi_path,
        "speaker_gate_log": gate_path,
    }
    missing = [name for name, path in required.items() if path is None]
    recording = _load_json(recording_path) if recording_path else {}
    started_at = str(recording.get("started_at") or "")
    try:
        recording_epoch = _local_epoch(started_at, timezone) if started_at else None
    except ValueError:
        recording_epoch = None
        missing.append("recording_started_at")

    raw_audio = _audio_artifact(agent_dir, recording, "raw_input", "audio_raw_input_*.wav")
    stt_audio = _audio_artifact(agent_dir, recording, "stt_input", "audio_stt_input_*.wav")
    if raw_audio is None or not raw_audio["exists"]:
        missing.append("raw_audio")
    if stt_audio is None or not stt_audio["exists"]:
        missing.append("stt_audio")

    agent: dict[str, Any] = {
        "run_dir": _absolute(agent_dir),
        "recording_started_at": started_at or None,
        "recording_started_epoch": recording_epoch,
        "audio": {"raw_input": raw_audio, "stt_input": stt_audio},
        "session_report_path": _absolute(session_path) if session_path else None,
        "mmi_log_path": _absolute(mmi_path) if mmi_path else None,
        "speaker_gate_log_path": _absolute(gate_path) if gate_path else None,
        "session_timeline": (
            extract_session_timeline(
                session_path,
                recording_epoch,
                include_transcripts=include_transcripts,
            )
            if session_path
            else {"asr_hypotheses": [], "state_events": []}
        ),
        "mmi_timeline": (
            extract_mmi_timeline(mmi_path, recording_epoch, timezone)
            if mmi_path
            else {"decisions": [], "native_actions": [], "malformed_lines": 0}
        ),
        "speaker_gate_timeline": (
            extract_speaker_gate_timeline(gate_path, recording_epoch, timezone)
            if gate_path
            else []
        ),
    }
    item["agent"] = agent
    item["quality"] = {
        "joined": True,
        "replay_ready": not missing,
        "missing": sorted(set(missing)),
    }
    return item


def export_run(
    run_dir: Path,
    agent_runs_dir: Path,
    *,
    timezone_name: str = "Asia/Shanghai",
    include_transcripts: bool = False,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    timezone = ZoneInfo(timezone_name)
    v15_root = _v15_root(run_dir)
    agent_index, duplicates = build_agent_run_index(agent_runs_dir)
    items: list[dict[str, Any]] = []
    for scenario in SCENARIOS:
        scenario_dir = v15_root / scenario
        if not scenario_dir.is_dir():
            continue
        samples = sorted(
            (path for path in scenario_dir.iterdir() if path.is_dir() and path.name.isdigit()),
            key=lambda path: int(path.name),
        )
        items.extend(
            export_sample(
                scenario,
                sample,
                agent_index,
                timezone,
                include_transcripts=include_transcripts,
            )
            for sample in samples
        )

    scenario_counts = Counter(item["scenario"] for item in items)
    state_counts = Counter(item["labels"]["target_state"] for item in items)
    summary = {
        "format_version": FORMAT_VERSION,
        "run_dir": _absolute(run_dir),
        "agent_runs_dir": _absolute(agent_runs_dir),
        "timezone": timezone_name,
        "includes_transcripts": include_transcripts,
        "samples": len(items),
        "joined": sum(item["quality"]["joined"] for item in items),
        "replay_ready": sum(item["quality"]["replay_ready"] for item in items),
        "scenario_counts": dict(sorted(scenario_counts.items())),
        "target_state_counts": dict(sorted(state_counts.items())),
        "duplicate_agent_room_count": len(duplicates),
        "missing_artifacts": dict(
            sorted(
                Counter(
                    missing
                    for item in items
                    for missing in item["quality"]["missing"]
                ).items()
            )
        ),
    }
    return summary, items


def write_export(output_dir: Path, summary: dict[str, Any], items: list[dict[str, Any]]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    with (output_dir / "manifest.jsonl").open("w", encoding="utf-8") as fh:
        for item in items:
            fh.write(json.dumps(item, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Export FDB + Agent artifacts for MMI replay")
    parser.add_argument("run_dir", type=Path, help="FDB run directory containing v1.5 data")
    parser.add_argument("agent_runs_dir", type=Path, help="Agent tmp/runs directory")
    parser.add_argument("output_dir", type=Path, help="Directory for manifest.jsonl and summary.json")
    parser.add_argument("--timezone", default="Asia/Shanghai", help="Timezone used by Agent log timestamps")
    parser.add_argument(
        "--include-transcripts",
        action="store_true",
        help="Include synthetic FDB expected text and streaming ASR hypotheses",
    )
    args = parser.parse_args()

    summary, items = export_run(
        args.run_dir,
        args.agent_runs_dir,
        timezone_name=args.timezone,
        include_transcripts=args.include_transcripts,
    )
    write_export(args.output_dir, summary, items)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Precompute and replay a conservative streaming semantic MMI baseline."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import time
import tomllib
import urllib.error
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from evaluation.run_fdb_mmi_replay import (
    DetectorPrediction,
    ReplayContext,
    ReplayInput,
    StreamingReplayDetector,
    TargetState,
    load_manifest,
    replay_sample,
    run_replay,
    write_report,
)

PROMPT_VERSION = "2026-07-23.streaming-semantic-v3"
POLICY_VERSION = "2026-07-23.semantic-hybrid-v3.2-frozen"
ALLOWED_STATES = {state.value for state in TargetState}

_EXPLICIT_INTERRUPT_CUES = (
    re.compile(r"\bbefore i forget\b", re.IGNORECASE),
    re.compile(r"\bby the way\b", re.IGNORECASE),
    re.compile(r"\bhold on\b", re.IGNORECASE),
    re.compile(r"^\s*wait\b", re.IGNORECASE),
    re.compile(r"^\s*hey[\s,]+(?:can|could|would|will|please)\b", re.IGNORECASE),
    re.compile(r"\btalk about something else\b", re.IGNORECASE),
    re.compile(r"\btalk about\b.*\binstead\b", re.IGNORECASE),
    re.compile(r"\bdiscuss\b.*\binstead\b", re.IGNORECASE),
    re.compile(r"\b(?:switch|change)\s+(?:to|the topic|the subject)\b", re.IGNORECASE),
    re.compile(
        r"\bactually\b.*\b(?:let'?s|can we|switch|change)\b",
        re.IGNORECASE,
    ),
)

SYSTEM_PROMPT = """You are a conservative streaming turn-control classifier.
The user began speaking while a voice assistant was speaking or thinking.
Classify who the utterance addresses and whether it should stop the assistant.

Allowed states:
- INTERRUPT: a clear request to stop, correct, reject, or redirect the assistant,
  or a new assistant request introduced by an explicit floor-taking phrase.
- ADDRESSED_OTHER: speech explicitly addressed to another person, role, or device.
- BACKCHANNEL: a short acknowledgement encouraging the assistant to continue.
- CONTINUE: speech that should not stop the assistant and fits none of the above.
- UNCERTAIN: partial or ambiguous evidence; prefer this over a risky interruption.

Rules:
1. The overlap context matters, but a generic request or question alone is not
   enough evidence to interrupt. Prefer CONTINUE or UNCERTAIN unless the utterance
   clearly stops, corrects, rejects, or redirects the assistant.
2. A floor-taking phrase such as "before I forget", "by the way", "actually",
   or "hold on" followed by a new request to the assistant is INTERRUPT, even if
   the request is otherwise a generic question or command.
3. Explicit addressee evidence takes priority over every interruption cue. An initial
   name, title, role, or device invocation followed by speech to that addressee is
   always ADDRESSED_OTHER, even if the speech is urgent, corrective, or a question.
   The first token may be a person's name even when ASR omits the comma.
   Examples: "Alex, your phone is ringing" and "Sam dinner is at seven" are
   ADDRESSED_OTHER, never INTERRUPT.
4. Preserve an explicit vocative in earlier streaming hypotheses even if a later ASR
   rewrite drops or corrupts it.
5. A short acknowledgement such as "uh-huh" is BACKCHANNEL.
6. For an incomplete or garbled hypothesis, use UNCERTAIN until either a direct
   assistant request or another addressee becomes clear. Do not invent a missing
   vocative or a missing interruption intent.
7. Return one JSON object only with keys state, confidence, and reason.
"""


@dataclass(frozen=True)
class SemanticRequest:
    key: str
    sample: str
    scenario: str
    relative_ms: int
    turn_id: int
    is_final: bool
    transcript: str
    hypothesis_history: tuple[str, ...]
    agent_state: str
    user_state: str
    started_during_agent_speaking: bool
    started_during_agent_thinking: bool


@dataclass(frozen=True)
class SemanticAPIConfig:
    base_url: str
    api_key: str
    model: str
    timeout_sec: float = 45.0
    retries: int = 2


def load_api_config(path: Path, *, section: str = "llm") -> SemanticAPIConfig:
    with path.open("rb") as fh:
        data = tomllib.load(fh)
    value = data.get(section)
    if not isinstance(value, dict):
        raise ValueError(f"Missing [{section}] in {path}")
    base_url = str(value.get("base_url") or "").strip()
    api_key = str(value.get("api_key") or "").strip()
    model = str(value.get("text_model") or value.get("model") or "").strip()
    if not base_url or not api_key or not model:
        raise ValueError(f"[{section}] must define base_url, api_key, and text_model")
    return SemanticAPIConfig(base_url=base_url, api_key=api_key, model=model)


def semantic_request_for_event(
    sample: dict[str, Any],
    event: ReplayInput,
    context: ReplayContext,
) -> SemanticRequest | None:
    if event.kind != "asr" or not (
        context.turn_started_during_agent_speaking
        or context.turn_started_during_agent_thinking
    ):
        return None
    transcript = str(event.payload.get("text") or "").strip()
    if not transcript:
        return None
    history = tuple(context.asr_hypotheses[-6:])
    identity = {
        "sample": sample.get("sample"),
        "relative_ms": event.relative_ms,
        "turn_id": context.turn_id,
        "history": history,
        "is_final": bool(event.payload.get("is_final")),
    }
    key = hashlib.sha256(
        json.dumps(
            identity,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return SemanticRequest(
        key=key,
        sample=str(sample.get("sample") or ""),
        scenario=str(sample.get("scenario") or ""),
        relative_ms=event.relative_ms,
        turn_id=context.turn_id,
        is_final=bool(event.payload.get("is_final")),
        transcript=transcript,
        hypothesis_history=history,
        agent_state=context.agent_state,
        user_state=context.user_state,
        started_during_agent_speaking=context.turn_started_during_agent_speaking,
        started_during_agent_thinking=context.turn_started_during_agent_thinking,
    )


class SemanticRequestCollector:
    name = "semantic_request_collector"

    def __init__(self) -> None:
        self.requests: list[SemanticRequest] = []
        self._sample: dict[str, Any] = {}
        self._seen: set[str] = set()

    def reset(self, sample: dict[str, Any]) -> None:
        self._sample = sample

    def observe(
        self,
        event: ReplayInput,
        context: ReplayContext,
    ) -> None:
        request = semantic_request_for_event(self._sample, event, context)
        if request is not None and request.key not in self._seen:
            self._seen.add(request.key)
            self.requests.append(request)
        return None


def collect_semantic_requests(
    samples: list[dict[str, Any]],
    *,
    frame_ms: int = 1000,
    audio_source: str = "stt_input",
) -> list[SemanticRequest]:
    collector = SemanticRequestCollector()
    for sample in samples:
        replay_sample(
            sample,
            collector,
            frame_ms=frame_ms,
            audio_source=audio_source,
        )
    return collector.requests


def build_prompt(request: SemanticRequest) -> str:
    history = "\n".join(
        f"{index + 1}. {text}"
        for index, text in enumerate(request.hypothesis_history)
    )
    return (
        f"Streaming hypotheses, oldest to newest:\n{history}\n\n"
        f"Latest hypothesis is_final={str(request.is_final).lower()}.\n"
        f"Turn began during assistant speaking="
        f"{str(request.started_during_agent_speaking).lower()}.\n"
        f"Turn began during assistant thinking="
        f"{str(request.started_during_agent_thinking).lower()}."
    )


def parse_semantic_response(content: str) -> dict[str, Any]:
    text = content.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1]).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        raise ValueError("Semantic response does not contain a JSON object")
    value = json.loads(text[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("Semantic response JSON must be an object")
    state = str(value.get("state") or "").upper()
    if state not in ALLOWED_STATES:
        raise ValueError(f"Unsupported semantic state: {state!r}")
    confidence = float(value.get("confidence") or 0.0)
    if not math.isfinite(confidence):
        raise ValueError("Semantic confidence must be finite")
    return {
        "state": state,
        "confidence": max(0.0, min(1.0, confidence)),
        "reason": str(value.get("reason") or "")[:500],
    }


def has_explicit_interrupt_cue(hypothesis_history: tuple[str, ...]) -> bool:
    texts = (*hypothesis_history, " ".join(hypothesis_history))
    return any(
        pattern.search(text)
        for text in texts
        for pattern in _EXPLICIT_INTERRUPT_CUES
    )


class OpenAICompatibleSemanticClient:
    def __init__(self, config: SemanticAPIConfig) -> None:
        self.config = config

    def classify(self, request: SemanticRequest) -> dict[str, Any]:
        payload = {
            "model": self.config.model,
            "temperature": 0,
            "max_tokens": 100,
            "enable_thinking": False,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": build_prompt(request)},
            ],
        }
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        url = self.config.base_url.rstrip("/") + "/chat/completions"
        last_error = ""
        started = time.perf_counter()
        attempts = self.config.retries + 1
        for attempt in range(attempts):
            http_request = urllib.request.Request(
                url,
                data=body,
                method="POST",
                headers={
                    "Authorization": f"Bearer {self.config.api_key}",
                    "Content-Type": "application/json",
                },
            )
            try:
                with urllib.request.urlopen(
                    http_request,
                    timeout=self.config.timeout_sec,
                ) as response:
                    response_data = json.loads(response.read().decode("utf-8"))
                content = response_data["choices"][0]["message"]["content"]
                parsed = parse_semantic_response(str(content))
                return {
                    **parsed,
                    "ok": True,
                    "latency_ms": round((time.perf_counter() - started) * 1000, 3),
                    "attempts": attempt + 1,
                    "model": str(response_data.get("model") or self.config.model),
                    "prompt_version": PROMPT_VERSION,
                }
            except (
                urllib.error.HTTPError,
                urllib.error.URLError,
                TimeoutError,
                KeyError,
                IndexError,
                TypeError,
                ValueError,
                json.JSONDecodeError,
            ) as exc:
                if isinstance(exc, urllib.error.HTTPError):
                    detail = exc.read().decode("utf-8", "replace")[:500]
                    last_error = f"HTTP {exc.code}: {detail}"
                else:
                    last_error = f"{type(exc).__name__}: {exc}"
                if attempt + 1 < attempts:
                    time.sleep(0.5 * (attempt + 1))
        return {
            "state": TargetState.UNCERTAIN.value,
            "confidence": 0.0,
            "reason": "semantic_api_error",
            "ok": False,
            "error": last_error,
            "latency_ms": round((time.perf_counter() - started) * 1000, 3),
            "attempts": attempts,
            "model": self.config.model,
            "prompt_version": PROMPT_VERSION,
        }


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * percentile
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def summarize_cache(entries: dict[str, Any], model: str) -> dict[str, Any]:
    results = [entry["result"] for entry in entries.values()]
    latencies = [
        float(result["latency_ms"])
        for result in results
        if result.get("ok") and isinstance(result.get("latency_ms"), (int, float))
    ]
    return {
        "prompt_version": PROMPT_VERSION,
        "model": model,
        "requests": len(results),
        "successful": sum(bool(result.get("ok")) for result in results),
        "errors": sum(not bool(result.get("ok")) for result in results),
        "state_counts": dict(
            sorted(Counter(str(result.get("state")) for result in results).items())
        ),
        "api_latency_ms": {
            "count": len(latencies),
            "p50": round(_percentile(latencies, 0.5) or 0.0, 3)
            if latencies
            else None,
            "p95": round(_percentile(latencies, 0.95) or 0.0, 3)
            if latencies
            else None,
            "min": round(min(latencies), 3) if latencies else None,
            "max": round(max(latencies), 3) if latencies else None,
        },
    }


def classify_requests(
    requests: list[SemanticRequest],
    client: OpenAICompatibleSemanticClient,
    *,
    workers: int,
    existing_entries: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if workers < 1:
        raise ValueError("workers must be positive")
    entries = dict(existing_entries or {})
    pending = [request for request in requests if request.key not in entries]
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(client.classify, request): request
            for request in pending
        }
        for future in as_completed(futures):
            request = futures[future]
            result = future.result()
            entries[request.key] = {
                "request": asdict(request),
                "result": result,
            }
    return entries


def load_cache(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        value = json.load(fh)
    if value.get("prompt_version") != PROMPT_VERSION:
        raise ValueError(
            f"Cache prompt version mismatch: {value.get('prompt_version')!r}"
        )
    if not isinstance(value.get("entries"), dict):
        raise ValueError("Semantic cache has no entries object")
    return value


def write_cache(
    path: Path,
    entries: dict[str, Any],
    *,
    model: str,
    manifest_path: Path,
) -> dict[str, Any]:
    summary = summarize_cache(entries, model)
    value = {
        "format_version": 1,
        "prompt_version": PROMPT_VERSION,
        "manifest_path": str(manifest_path.resolve()),
        "model": model,
        "summary": summary,
        "entries": entries,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return value


class CachedSemanticDetector:
    name = POLICY_VERSION

    def __init__(
        self,
        cache: dict[str, Any],
        *,
        min_confidence: float = 0.8,
        partial_confirmations: int = 2,
    ) -> None:
        self._entries = cache["entries"]
        self._min_confidence = min_confidence
        self._partial_confirmations = partial_confirmations
        self._sample: dict[str, Any] = {}
        self._interrupt_streak = 0

    def reset(self, sample: dict[str, Any]) -> None:
        self._sample = sample
        self._interrupt_streak = 0

    def observe(
        self,
        event: ReplayInput,
        context: ReplayContext,
    ) -> DetectorPrediction | None:
        request = semantic_request_for_event(self._sample, event, context)
        if request is None:
            return None
        entry = self._entries.get(request.key)
        if entry is None:
            self._interrupt_streak = 0
            return DetectorPrediction(
                state=TargetState.UNCERTAIN,
                relative_ms=event.relative_ms,
                confidence=0.0,
                reason="semantic_cache_miss",
                source=self.name,
                metadata={"cache_key": request.key, "cache_miss": True},
            )
        result = entry["result"]
        semantic_state = TargetState(str(result.get("state") or "UNCERTAIN"))
        confidence = float(result.get("confidence") or 0.0)
        cue_override = (
            semantic_state not in {TargetState.ADDRESSED_OTHER, TargetState.BACKCHANNEL}
            and has_explicit_interrupt_cue(request.hypothesis_history)
        )
        raw_state = TargetState.INTERRUPT if cue_override else semantic_state
        if cue_override:
            confidence = max(confidence, 0.95)
        is_final = request.is_final
        confirmed = True
        if raw_state == TargetState.INTERRUPT:
            self._interrupt_streak += 1
            confirmed = confidence >= self._min_confidence and (
                is_final or self._interrupt_streak >= self._partial_confirmations
            )
            state = raw_state if confirmed else TargetState.UNCERTAIN
        else:
            self._interrupt_streak = 0
            state = raw_state
        return DetectorPrediction(
            state=state,
            relative_ms=event.relative_ms,
            confidence=confidence,
            reason=(
                (
                    "explicit_floor_taking_or_redirect_cue"
                    if cue_override
                    else str(result.get("reason") or "")
                )
                if confirmed
                else "semantic_interrupt_awaiting_confirmation"
            ),
            source=self.name,
            metadata={
                "cache_key": request.key,
                "cache_miss": False,
                "raw_state": raw_state.value,
                "semantic_state": semantic_state.value,
                "cue_override": cue_override,
                "is_final": is_final,
                "interrupt_streak": self._interrupt_streak,
                "api_latency_ms": result.get("latency_ms"),
                "api_ok": bool(result.get("ok")),
            },
        )


def _classify_command(args: argparse.Namespace) -> None:
    samples = load_manifest(args.manifest)
    requests = collect_semantic_requests(
        samples,
        frame_ms=args.frame_ms,
        audio_source=args.audio_source,
    )
    config = load_api_config(args.config_toml, section=args.config_section)
    config = SemanticAPIConfig(
        base_url=config.base_url,
        api_key=config.api_key,
        model=args.model or config.model,
        timeout_sec=args.timeout_sec,
        retries=args.retries,
    )
    existing: dict[str, Any] = {}
    if args.resume and args.cache.is_file():
        existing = load_cache(args.cache)["entries"]
    client = OpenAICompatibleSemanticClient(config)
    entries = classify_requests(
        requests,
        client,
        workers=args.workers,
        existing_entries=existing,
    )
    value = write_cache(
        args.cache,
        entries,
        model=config.model,
        manifest_path=args.manifest,
    )
    print(json.dumps(value["summary"], ensure_ascii=False, indent=2))


def _replay_command(args: argparse.Namespace) -> None:
    cache = load_cache(args.cache)
    detector: StreamingReplayDetector = CachedSemanticDetector(
        cache,
        min_confidence=args.min_confidence,
        partial_confirmations=args.partial_confirmations,
    )
    summary, results = run_replay(
        args.manifest,
        detector,
        frame_ms=args.frame_ms,
        audio_source=args.audio_source,
    )
    summary["semantic_cache"] = cache["summary"]
    summary["semantic_policy_version"] = POLICY_VERSION
    summary["min_confidence"] = args.min_confidence
    summary["partial_confirmations"] = args.partial_confirmations
    write_report(args.output_dir, summary, results)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Precompute and replay a streaming semantic MMI baseline"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    classify = subparsers.add_parser("classify")
    classify.add_argument("manifest", type=Path)
    classify.add_argument("cache", type=Path)
    classify.add_argument("--config-toml", type=Path, required=True)
    classify.add_argument("--config-section", default="llm")
    classify.add_argument("--model", default=None)
    classify.add_argument("--workers", type=int, default=4)
    classify.add_argument("--timeout-sec", type=float, default=45.0)
    classify.add_argument("--retries", type=int, default=2)
    classify.add_argument("--frame-ms", type=int, default=1000)
    classify.add_argument(
        "--audio-source",
        choices=["raw_input", "stt_input"],
        default="stt_input",
    )
    classify.add_argument("--resume", action="store_true")
    classify.set_defaults(func=_classify_command)

    replay = subparsers.add_parser("replay")
    replay.add_argument("manifest", type=Path)
    replay.add_argument("cache", type=Path)
    replay.add_argument("output_dir", type=Path)
    replay.add_argument("--frame-ms", type=int, default=200)
    replay.add_argument(
        "--audio-source",
        choices=["raw_input", "stt_input"],
        default="stt_input",
    )
    replay.add_argument("--min-confidence", type=float, default=0.8)
    replay.add_argument("--partial-confirmations", type=int, default=2)
    replay.set_defaults(func=_replay_command)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

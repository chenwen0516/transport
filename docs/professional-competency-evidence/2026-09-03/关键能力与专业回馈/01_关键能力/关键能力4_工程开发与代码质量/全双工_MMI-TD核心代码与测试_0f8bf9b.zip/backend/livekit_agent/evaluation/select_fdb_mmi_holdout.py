#!/usr/bin/env python3
"""Build a deterministic FDB v1.5 holdout root excluding prior manifests."""

from __future__ import annotations

import argparse
import glob
import json
import os
import random
import shutil
from collections import Counter
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

from evaluation.analyze_fdb_mmi import SCENARIOS
from evaluation.export_fdb_mmi_replay import TARGET_STATE

FORMAT_VERSION = 1


def _load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def normalize_source_relative(value: str) -> str | None:
    """Return a canonical v1.5/scenario/id key from a manifest value."""
    parts = PurePosixPath(value.replace("\\", "/")).parts
    try:
        index = parts.index("v1.5")
    except ValueError:
        return None
    relative = parts[index:]
    if (
        len(relative) != 3
        or relative[1] not in SCENARIOS
        or not relative[2].isdigit()
    ):
        return None
    return str(PurePosixPath(*relative))


def load_excluded_samples(manifest_paths: Iterable[Path]) -> set[str]:
    excluded: set[str] = set()
    for path in manifest_paths:
        value = _load_json(path)
        if not isinstance(value, list):
            raise ValueError(f"Exclude manifest must contain a JSON list: {path}")
        for item in value:
            if not isinstance(item, dict):
                continue
            relative = normalize_source_relative(
                str(item.get("source_relative") or item.get("relative") or "")
            )
            if relative:
                excluded.add(relative)
    return excluded


def resolve_manifest_paths(
    explicit: Iterable[Path],
    patterns: Iterable[str],
) -> list[Path]:
    paths = {path.expanduser().resolve() for path in explicit}
    for pattern in patterns:
        for match in glob.glob(os.path.expanduser(pattern)):
            path = Path(match).resolve()
            paths.add(path / "sample_manifest.json" if path.is_dir() else path)
    missing = sorted(path for path in paths if not path.is_file())
    if missing:
        raise FileNotFoundError(f"Exclude manifest does not exist: {missing[0]}")
    return sorted(paths, key=str)


def _numeric_samples(root: Path) -> list[Path]:
    if not root.is_dir():
        return []
    return sorted(
        (path for path in root.iterdir() if path.is_dir() and path.name.isdigit()),
        key=lambda path: int(path.name),
    )


def select_holdout(
    data_root: Path,
    excluded: set[str],
    *,
    per_scenario: int,
    seed: int,
    scenarios: Iterable[str] = SCENARIOS,
) -> list[dict[str, Any]]:
    if per_scenario < 1:
        raise ValueError("per_scenario must be positive")
    selected: list[dict[str, Any]] = []
    for scenario in scenarios:
        if scenario not in SCENARIOS:
            raise ValueError(f"Unsupported scenario: {scenario}")
        candidates = [
            path
            for path in _numeric_samples(data_root / "v1.5" / scenario)
            if f"v1.5/{scenario}/{path.name}" not in excluded
        ]
        if len(candidates) < per_scenario:
            raise ValueError(
                f"Not enough unused samples for {scenario}: "
                f"need {per_scenario}, found {len(candidates)}"
            )
        rng = random.Random(f"{seed}:{scenario}")
        chosen = sorted(
            rng.sample(candidates, per_scenario),
            key=lambda path: int(path.name),
        )
        selected.extend(
            {
                "scenario": scenario,
                "sample_id": path.name,
                "source": str(path.resolve()),
                "source_relative": f"v1.5/{scenario}/{path.name}",
                "target_state": TARGET_STATE[scenario],
            }
            for path in chosen
        )
    return selected


def _copy_file(source: str, destination: str, *, mode: str) -> str:
    if mode == "copy":
        shutil.copy2(source, destination)
        return destination
    if mode == "symlink":
        os.symlink(source, destination)
        return destination
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)
    return destination


def materialize_holdout(
    output_root: Path,
    selected: list[dict[str, Any]],
    *,
    mode: str = "hardlink",
) -> None:
    if mode not in {"hardlink", "copy", "symlink"}:
        raise ValueError(f"Unsupported materialization mode: {mode}")
    if output_root.exists():
        raise FileExistsError(f"Refusing to replace existing output root: {output_root}")
    output_root.mkdir(parents=True)
    try:
        for item in selected:
            source = Path(item["source"])
            destination = output_root / item["source_relative"]
            shutil.copytree(
                source,
                destination,
                copy_function=lambda src, dst: _copy_file(src, dst, mode=mode),
            )
    except Exception:
        shutil.rmtree(output_root)
        raise


def build_holdout(
    data_root: Path,
    output_root: Path,
    manifest_paths: list[Path],
    *,
    per_scenario: int,
    seed: int,
    mode: str,
    scenarios: Iterable[str] = SCENARIOS,
) -> dict[str, Any]:
    data_root = data_root.expanduser().resolve()
    output_root = output_root.expanduser().resolve()
    excluded = load_excluded_samples(manifest_paths)
    selected = select_holdout(
        data_root,
        excluded,
        per_scenario=per_scenario,
        seed=seed,
        scenarios=scenarios,
    )
    materialize_holdout(output_root, selected, mode=mode)
    scenario_counts = Counter(item["scenario"] for item in selected)
    excluded_counts = Counter(
        PurePosixPath(relative).parts[1] for relative in excluded
    )
    manifest = {
        "format_version": FORMAT_VERSION,
        "purpose": "FDB v1.5 MMI tuning-isolated holdout",
        "data_root": str(data_root),
        "output_root": str(output_root),
        "per_scenario": per_scenario,
        "seed": seed,
        "materialization_mode": mode,
        "exclude_manifests": [str(path) for path in manifest_paths],
        "excluded_unique_samples": len(excluded),
        "excluded_counts": dict(sorted(excluded_counts.items())),
        "selected_counts": dict(sorted(scenario_counts.items())),
        "selected": selected,
    }
    (output_root / "holdout_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a deterministic FDB v1.5 holdout data root"
    )
    parser.add_argument("data_root", type=Path)
    parser.add_argument("output_root", type=Path)
    parser.add_argument("--per-scenario", type=int, default=20)
    parser.add_argument("--seed", type=int, default=20260723)
    parser.add_argument(
        "--scenarios",
        nargs="+",
        choices=SCENARIOS,
        default=list(SCENARIOS),
    )
    parser.add_argument(
        "--exclude-manifest",
        type=Path,
        action="append",
        default=[],
    )
    parser.add_argument(
        "--exclude-run-glob",
        action="append",
        default=[],
        help="Glob matching run directories or sample_manifest.json files",
    )
    parser.add_argument(
        "--mode",
        choices=["hardlink", "copy", "symlink"],
        default="hardlink",
    )
    args = parser.parse_args()

    manifest_paths = resolve_manifest_paths(
        args.exclude_manifest,
        args.exclude_run_glob,
    )
    manifest = build_holdout(
        args.data_root,
        args.output_root,
        manifest_paths,
        per_scenario=args.per_scenario,
        seed=args.seed,
        mode=args.mode,
        scenarios=args.scenarios,
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

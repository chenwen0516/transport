"""Mock Agent 组件

保留真实 VAD，替换 LLM/TTS 为确定性输出。
用于隔离 VAD + 打断链路测试，排除 LLM/TTS 的延迟和不确定性。

使用方式：设置 runtime.agent_mode = "mock" 或 AGENT_RUNTIME__AGENT_MODE=mock 启动 Agent。
"""

import asyncio
import math
import struct
import logging
from typing import AsyncIterator

logger = logging.getLogger("health-agent.mock")


class MockLLM:
    """固定回复的 Mock LLM

    返回预设的文本回复，延迟为 0。
    用于测试打断和轮次检测时排除 LLM 变量。
    """

    RESPONSES = [
        "这是一段用于测试打断功能的固定回复。我会持续说话大约五秒钟，"
        "在此期间您可以尝试打断我，验证打断检测功能是否正常工作。"
        "如果一切顺利，系统应该能够在检测到您说话时立即停止我的回复。",
    ]

    def __init__(self):
        self._response_index = 0

    async def chat(self, messages=None, **kwargs) -> str:
        """返回固定文本"""
        text = self.RESPONSES[self._response_index % len(self.RESPONSES)]
        self._response_index += 1
        logger.info(f"[MockLLM] Returning fixed response ({len(text)} chars)")
        return text


class MockTTS:
    """固定时长 PCM 输出的 Mock TTS

    生成指定时长的正弦波 PCM 数据流（24kHz/16bit），
    模拟 TTS 的流式输出行为。
    """

    def __init__(self, duration_s: float = 5.0, sample_rate: int = 24000):
        self.duration_s = duration_s
        self.sample_rate = sample_rate
        self.frame_duration_ms = 20  # 每帧 20ms

    async def synthesize(self, text: str) -> AsyncIterator[bytes]:
        """生成固定时长的 PCM 数据流，按 20ms 帧输出"""
        frame_samples = int(self.sample_rate * self.frame_duration_ms / 1000)
        total_frames = int(self.duration_s * 1000 / self.frame_duration_ms)
        freq = 440.0
        amplitude = 0.3

        logger.info(
            f"[MockTTS] Synthesizing {self.duration_s}s audio "
            f"({total_frames} frames @ {self.frame_duration_ms}ms)"
        )

        sample_idx = 0
        for frame_i in range(total_frames):
            frame_data = []
            for j in range(frame_samples):
                t = sample_idx / self.sample_rate
                value = int(32767 * amplitude * math.sin(2 * math.pi * freq * t))
                frame_data.append(struct.pack('<h', value))
                sample_idx += 1

            yield b''.join(frame_data)
            # 模拟实时性，但不引入额外延迟
            await asyncio.sleep(0)

    async def aclose(self):
        """兼容 TTS 接口的清理方法"""
        pass

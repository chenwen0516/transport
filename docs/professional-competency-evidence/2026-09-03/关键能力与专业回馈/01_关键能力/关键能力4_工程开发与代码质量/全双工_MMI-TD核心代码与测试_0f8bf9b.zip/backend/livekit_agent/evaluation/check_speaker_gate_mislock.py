#!/usr/bin/env python3
"""决定性检验：SpeakerGate 是否在强非语音背景下【误锁到背景】并静音用户。

方法：对每会话用 raw vs stt 录音定位 gate 的【放行帧】与【静音帧】，用 silero VAD
量度两者的"语音性"。
  · 放行帧更像语音 → C=用户，门正确（保留语音、删非语音背景）。
  · 静音帧更像语音 → C=背景，误锁（把用户语音当背景删了）= 严重正确性缺陷。
"""
from __future__ import annotations
import glob, os, re, wave
import numpy as np
import onnxruntime as ort

VAD = ".venv/lib/python3.12/site-packages/livekit/plugins/silero/resources/silero_vad.onnx"
C = 512
SR16 = 16000


def read(p):
    with wave.open(p, "rb") as w:
        sr, ch = w.getframerate(), w.getnchannels()
        d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    return (d[::ch] if ch > 1 else d), sr


def to16(x, sr):
    if sr == SR16:
        return x.astype(np.float32)
    t = int(len(x) * SR16 / sr)
    return np.interp(np.linspace(0, len(x), t, endpoint=False), np.arange(len(x)), x).astype(np.float32)


def vad_probs(x16):
    sess = ort.InferenceSession(VAD, providers=["CPUExecutionProvider"])
    st = np.zeros((2, 1, 128), np.float32)
    srt = np.array(SR16, np.int64)
    m = (len(x16) // C) * C
    out = []
    for i in range(0, m, C):
        o, st = sess.run(["output", "stateN"], {"input": (x16[i:i + C] / 32768.0).astype(np.float32)[None], "state": st, "sr": srt})
        out.append(float(o[0, 0]))
    return np.array(out), m


def check(raw_path, stt_path, label):
    raw, sr = read(raw_path)
    stt, _ = read(stt_path)
    n = min(len(raw), len(stt))
    raw16, stt16 = to16(raw[:n], sr), to16(stt[:n], sr)
    vad, m = vad_probs(raw16)
    cr = raw16[:m].reshape(-1, C)
    cs = stt16[:m].reshape(-1, C)
    rr = np.sqrt(np.mean(cr.astype(np.float64) ** 2, axis=1))
    rs = np.sqrt(np.mean(cs.astype(np.float64) ** 2, axis=1))
    voiced = rr >= 50.0
    passed = voiced & (rs >= 50.0)
    silenced = voiced & (rs < 5.0)
    if passed.sum() == 0 or silenced.sum() < 20:
        print(f"● {label}: 静音帧太少({silenced.sum()})，无法判定（门几乎全放行）")
        return
    pv = (vad[passed] >= 0.5).mean()
    sv = (vad[silenced] >= 0.5).mean()
    verdict = ("✅正确(C=用户)" if pv > sv + 0.05 else "❌误锁(C=背景,删用户)" if sv > pv + 0.05 else "⚠️混合/不明")
    print(f"● {label}: 放行语音性={pv:.0%} 静音语音性={sv:.0%}  静音={silenced.sum()}块  {verdict}")


def main():
    pairs = []
    for raw in sorted(
        glob.glob("tmp/audio_raw_input_*.wav")
        + glob.glob("tmp/runs/*/audio_raw_input_*.wav")
    ):
        ts = re.search(r"_(\d{8}_\d{6})\.wav", raw).group(1)
        stt = raw.replace("audio_raw_input_", "audio_stt_input_")
        if os.path.exists(stt):
            pairs.append((ts, raw, stt))
    for ts, raw, stt in pairs:
        check(raw, stt, ts)


if __name__ == "__main__":
    main()

"""Local barge-in timing observer for MMI Shadow sessions."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any

from .models import MMITurnAction, MMITurnContext, MMITurnDecision

logger = logging.getLogger("health-agent.mmi.fast_path")

POLICY_VERSION = "2026-07-27.fast-path-shadow-v2"


class FastPathRecommendation(str, Enum):
    PENDING_BARGE_IN = "PENDING_BARGE_IN"
    INTERRUPT = "INTERRUPT"
    SUPPRESS = "SUPPRESS"


@dataclass
class FastPathAttempt:
    session_id: str
    turn_id: int
    agent_speech_id: int
    started_at: float
    deadline_at: float
    start_event_id: int
    start_source: str
    start_time_estimated: bool
    first_decisive_at: float | None = None
    first_decisive_recommendation: FastPathRecommendation | None = None
    first_decisive_trigger: str | None = None
    deadline_logged: bool = False
    stop_candidate_at: float | None = None
    resolved: bool = False


class FastPathShadowObserver:
    """Track whether local MMI decisions beat the native interruption timeline."""

    _DECISIVE_SUPPRESSION_REASONS = {
        "addressed_to_other",
        "backchannel",
        "non_target_speaker_suppressed",
    }

    def __init__(
        self,
        *,
        deadline_ms: int = 200,
        audio_interrupt_min_ms: int | None = None,
        audio_voice_confidence_min: float = 0.7,
    ) -> None:
        self.deadline_ms = deadline_ms
        self.audio_interrupt_min_ms = (
            deadline_ms
            if audio_interrupt_min_ms is None
            else audio_interrupt_min_ms
        )
        self.audio_voice_confidence_min = audio_voice_confidence_min
        self._attempt: FastPathAttempt | None = None

    @property
    def attempt(self) -> FastPathAttempt | None:
        return self._attempt

    def start(
        self,
        context: MMITurnContext,
        *,
        agent_speech_id: int,
        observed_at: float | None = None,
        source: str = "user_state_changed",
        start_time_estimated: bool = False,
    ) -> FastPathAttempt:
        now = time.monotonic() if observed_at is None else observed_at
        if self._attempt is not None and not self._attempt.resolved:
            self.resolve(
                "superseded_by_new_turn",
                observed_at=now,
            )
        attempt = FastPathAttempt(
            session_id=context.session_id,
            turn_id=context.turn_id,
            agent_speech_id=agent_speech_id,
            started_at=now,
            deadline_at=now + self.deadline_ms / 1000,
            start_event_id=context.event_id,
            start_source=source,
            start_time_estimated=start_time_estimated,
        )
        self._attempt = attempt
        self._log(
            "fast_path_pending",
            attempt,
            observed_at=now,
            recommendation=FastPathRecommendation.PENDING_BARGE_IN.value,
            agent_state=context.agent_state,
            user_state=context.user_state,
            start_source=source,
            start_time_estimated=start_time_estimated,
        )
        return attempt

    def observe_decision(
        self,
        decision: MMITurnDecision,
        context: MMITurnContext,
        *,
        trigger: str,
        observed_at: float | None = None,
    ) -> FastPathRecommendation | None:
        attempt = self._matching_attempt(context.turn_id)
        if attempt is None:
            return None
        if decision.action not in {
            MMITurnAction.START_LISTENING,
            MMITurnAction.CONTINUE_SPEAKING,
        }:
            return None

        now = time.monotonic() if observed_at is None else observed_at
        recommendation = self._recommend(decision)
        if (
            recommendation != FastPathRecommendation.PENDING_BARGE_IN
            and attempt.first_decisive_at is None
        ):
            attempt.first_decisive_at = now
            attempt.first_decisive_recommendation = recommendation
            attempt.first_decisive_trigger = trigger

        self._log(
            "fast_path_decision",
            attempt,
            observed_at=now,
            recommendation=recommendation.value,
            trigger=trigger,
            base_action=decision.action.value,
            base_reason=decision.reason,
            confidence=decision.confidence,
            confidence_level=decision.confidence_level.value,
            observe_more_ms=decision.observe_more_ms,
            decision_before_native_stop=(
                attempt.stop_candidate_at is None or now <= attempt.stop_candidate_at
            ),
        )
        return recommendation

    def observe_audio_context(
        self,
        context: MMITurnContext,
        *,
        trigger: str,
        observed_at: float | None = None,
    ) -> FastPathRecommendation | None:
        """Classify an audio-only Shadow signal without requiring STT text."""
        attempt = self._matching_attempt(context.turn_id)
        if attempt is None:
            return None

        now = time.monotonic() if observed_at is None else observed_at
        elapsed_ms = self._elapsed_ms(attempt, now)
        speech_ms = (
            max(context.speech_ms, int(elapsed_ms))
            if context.user_state == "speaking"
            else context.speech_ms
        )
        non_target = (
            context.external_speaker_state == "NON_TARGET"
            or context.external_speaker_is_target is False
        )
        target_source: str | None = None
        if (
            context.external_speaker_state == "TARGET_CONFIDENT"
            or context.external_speaker_is_target is True
        ):
            target_source = "speaker_gate"
        elif (
            context.external_voice_confidence is not None
            and context.external_voice_confidence
            >= self.audio_voice_confidence_min
        ):
            target_source = "voice_confidence"

        if non_target:
            recommendation = FastPathRecommendation.SUPPRESS
            reason = "audio_non_target_speaker"
            confidence = 0.9
            confidence_level = "HIGH"
            base_action = MMITurnAction.CONTINUE_SPEAKING.value
        elif (
            context.user_state == "speaking"
            and speech_ms >= self.audio_interrupt_min_ms
            and target_source is not None
        ):
            recommendation = FastPathRecommendation.INTERRUPT
            reason = "audio_target_speech_sustained"
            confidence = 0.75
            confidence_level = "MEDIUM"
            base_action = MMITurnAction.START_LISTENING.value
        else:
            recommendation = FastPathRecommendation.PENDING_BARGE_IN
            reason = (
                "audio_speech_too_short"
                if context.user_state == "speaking"
                and speech_ms < self.audio_interrupt_min_ms
                else "audio_target_evidence_pending"
            )
            confidence = 0.5
            confidence_level = "LOW"
            base_action = MMITurnAction.CONTINUE_SPEAKING.value

        if (
            recommendation != FastPathRecommendation.PENDING_BARGE_IN
            and attempt.first_decisive_at is None
        ):
            attempt.first_decisive_at = now
            attempt.first_decisive_recommendation = recommendation
            attempt.first_decisive_trigger = trigger

        self._log(
            "fast_path_decision",
            attempt,
            observed_at=now,
            recommendation=recommendation.value,
            trigger=trigger,
            base_action=base_action,
            base_reason=reason,
            confidence=confidence,
            confidence_level=confidence_level,
            observe_more_ms=max(0, self.audio_interrupt_min_ms - speech_ms),
            decision_before_native_stop=(
                attempt.stop_candidate_at is None or now <= attempt.stop_candidate_at
            ),
            audio_only=True,
            speech_ms=speech_ms,
            target_evidence=target_source,
            speaker_state=context.external_speaker_state,
            speaker_similarity=context.external_speaker_similarity,
            voice_confidence=context.external_voice_confidence,
        )
        return recommendation

    def mark_deadline(
        self,
        *,
        turn_id: int,
        agent_speech_id: int,
        observed_at: float | None = None,
    ) -> None:
        attempt = self._matching_attempt(turn_id, agent_speech_id)
        if attempt is None or attempt.deadline_logged:
            return
        now = time.monotonic() if observed_at is None else observed_at
        attempt.deadline_logged = True
        self._log(
            "fast_path_deadline",
            attempt,
            observed_at=now,
            recommendation=(
                attempt.first_decisive_recommendation.value
                if attempt.first_decisive_recommendation is not None
                else FastPathRecommendation.PENDING_BARGE_IN.value
            ),
            decisive_within_deadline=(
                attempt.first_decisive_at is not None
                and attempt.first_decisive_at <= attempt.deadline_at
            ),
        )

    def mark_agent_stop_candidate(
        self,
        *,
        turn_id: int,
        agent_speech_id: int,
        observed_at: float | None = None,
    ) -> None:
        attempt = self._matching_attempt(turn_id, agent_speech_id)
        if attempt is None or attempt.stop_candidate_at is not None:
            return
        attempt.stop_candidate_at = (
            time.monotonic() if observed_at is None else observed_at
        )

    def confirm_native_stop(
        self,
        *,
        turn_id: int,
        agent_speech_id: int,
        trigger: str,
        observed_at: float | None = None,
    ) -> None:
        attempt = self._matching_attempt(turn_id, agent_speech_id)
        if attempt is None:
            return
        now = time.monotonic() if observed_at is None else observed_at
        stop_at = attempt.stop_candidate_at or now
        self._log(
            "fast_path_native_stop",
            attempt,
            observed_at=stop_at,
            start_to_native_stop_ms=round(
                (stop_at - attempt.started_at) * 1000,
                3,
            ),
            observer_started_before_native_stop=attempt.started_at <= stop_at,
            reported_at_ms=self._elapsed_ms(attempt, now),
            trigger=trigger,
            recommendation=(
                attempt.first_decisive_recommendation.value
                if attempt.first_decisive_recommendation is not None
                else FastPathRecommendation.PENDING_BARGE_IN.value
            ),
            first_decisive_ms=self._first_decisive_ms(attempt),
            decision_before_native_stop=(
                attempt.first_decisive_at is not None
                and attempt.first_decisive_at <= stop_at
            ),
            decisive_within_deadline=(
                attempt.first_decisive_at is not None
                and attempt.first_decisive_at <= attempt.deadline_at
            ),
        )
        attempt.resolved = True

    def resolve(
        self,
        reason: str,
        *,
        observed_at: float | None = None,
    ) -> None:
        attempt = self._attempt
        if attempt is None or attempt.resolved:
            return
        now = time.monotonic() if observed_at is None else observed_at
        self._log(
            "fast_path_resolved",
            attempt,
            observed_at=now,
            reason=reason,
            recommendation=(
                attempt.first_decisive_recommendation.value
                if attempt.first_decisive_recommendation is not None
                else FastPathRecommendation.PENDING_BARGE_IN.value
            ),
            first_decisive_ms=self._first_decisive_ms(attempt),
        )
        attempt.resolved = True

    @classmethod
    def _recommend(cls, decision: MMITurnDecision) -> FastPathRecommendation:
        if decision.action == MMITurnAction.START_LISTENING:
            return FastPathRecommendation.INTERRUPT
        if (
            decision.ignore_input
            or decision.reason in cls._DECISIVE_SUPPRESSION_REASONS
            or decision.observe_more_ms <= 0
        ):
            return FastPathRecommendation.SUPPRESS
        return FastPathRecommendation.PENDING_BARGE_IN

    def _matching_attempt(
        self,
        turn_id: int,
        agent_speech_id: int | None = None,
    ) -> FastPathAttempt | None:
        attempt = self._attempt
        if (
            attempt is None
            or attempt.resolved
            or attempt.turn_id != turn_id
            or (
                agent_speech_id is not None
                and attempt.agent_speech_id != agent_speech_id
            )
        ):
            return None
        return attempt

    @staticmethod
    def _elapsed_ms(attempt: FastPathAttempt, observed_at: float) -> float:
        return round(max(0.0, (observed_at - attempt.started_at) * 1000), 3)

    @classmethod
    def _first_decisive_ms(cls, attempt: FastPathAttempt) -> float | None:
        if attempt.first_decisive_at is None:
            return None
        return cls._elapsed_ms(attempt, attempt.first_decisive_at)

    def _log(
        self,
        marker: str,
        attempt: FastPathAttempt,
        *,
        observed_at: float,
        **fields: Any,
    ) -> None:
        payload = {
            "session_id": attempt.session_id,
            "turn_id": attempt.turn_id,
            "agent_speech_id": attempt.agent_speech_id,
            "policy_version": POLICY_VERSION,
            "deadline_ms": self.deadline_ms,
            "elapsed_ms": self._elapsed_ms(attempt, observed_at),
            "start_source": attempt.start_source,
            "start_time_estimated": attempt.start_time_estimated,
            **fields,
        }
        logger.info("[MMI-TD] %s %s", marker, json.dumps(payload, ensure_ascii=False))


def build_fast_path_shadow(config: Any) -> FastPathShadowObserver | None:
    if not bool(getattr(config, "fast_path_shadow_enabled", False)):
        return None
    return FastPathShadowObserver(
        deadline_ms=int(getattr(config, "fast_path_deadline_ms", 200)),
        audio_interrupt_min_ms=int(
            getattr(
                config,
                "fast_path_audio_interrupt_min_ms",
                getattr(config, "fast_path_deadline_ms", 200),
            )
        ),
        audio_voice_confidence_min=float(
            getattr(config, "fast_path_audio_voice_confidence_min", 0.7)
        ),
    )

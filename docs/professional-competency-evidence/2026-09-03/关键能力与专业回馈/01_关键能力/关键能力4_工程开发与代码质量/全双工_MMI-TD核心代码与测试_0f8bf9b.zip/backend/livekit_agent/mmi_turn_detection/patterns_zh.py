"""Compatibility wrappers for the former Chinese-only pattern module."""

from .patterns import DEFAULT_PATTERN_MATCHER, normalize_text as normalize_text


def contains_wait_expression(text: str) -> bool:
    return DEFAULT_PATTERN_MATCHER.wait_expression(text).matched


def is_backchannel(text: str) -> bool:
    return DEFAULT_PATTERN_MATCHER.backchannel(text).matched


def is_confirmation(text: str) -> bool:
    return DEFAULT_PATTERN_MATCHER.confirmation(text).matched


def is_strong_interrupt(text: str) -> bool:
    return DEFAULT_PATTERN_MATCHER.strong_interrupt(text).matched


def is_invalid_or_noise_text(text: str) -> bool:
    return DEFAULT_PATTERN_MATCHER.invalid_or_noise(text).matched


def text_looks_incomplete(text: str) -> bool:
    return DEFAULT_PATTERN_MATCHER.incomplete_suffix(text).matched


def effective_char_count(text: str) -> int:
    return DEFAULT_PATTERN_MATCHER.effective_char_count(text)

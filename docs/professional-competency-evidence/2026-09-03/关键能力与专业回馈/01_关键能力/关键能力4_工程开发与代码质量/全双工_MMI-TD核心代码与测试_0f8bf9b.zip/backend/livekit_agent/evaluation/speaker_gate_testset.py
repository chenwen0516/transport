#!/usr/bin/env python3
"""SpeakerGate 测试集构建 + 自动化评测台。

从 `tmp/runs/` 的真人通话录音整理出**带 ground-truth 标签的测试集**，离线回放真实
SpeakerGate（真 CAM++ embedder、确定性同步推理），分别评测两种声纹过滤模式的
**准确率 / 误杀率(FRR) / 漏入率(FAR)**：

  - registered（已注册声纹过滤）：用固定 long-term profile 开局即 LOCKED 过滤全部 run。
  - session（session 级声纹过滤）：每会话自动注册（WARMUP→LOCKED）后过滤。

两步用法（从 backend/livekit_agent 运行）::

    # 1) 生成 manifest 草稿（registered 模式回放 → 自动预填标签 + 提示），人工修正后再跑评测
    .venv/bin/python evaluation/speaker_gate_testset.py build

    # 2) 读 manifest，两种模式各跑一遍，出 report.json + report.md
    .venv/bin/python evaluation/speaker_gate_testset.py run

输出落在 `tmp/runs/testset/`：manifest.json（你来修标签）、report.json、report.md。

—— 标签与指标的方法论（重要，别跳过）——
* **ground truth 必须人工确认**。build 的草稿标签是用 registered 模式自身的静音率推的，
  拿它直接评 registered 模式会**自证偏乐观**。尤其 FAR 失效会伪装成"高置信 target_only"
  草稿（背景被误放→静音率低→被判 target_only），所以 **target_only 草稿也要抽查**，
  background_only / mixed 必须人工确认。manifest 附带 `mode` 和 `transcript_preview`
  作为**独立于声纹**的提示（仅 shadow 录音的转写是 pre-gate、真正独立）。
* session 模式用**会话内独立质心**，标签噪声只是噪声不是偏置，所以 session 数字即便在
  草稿标签上也基本可信。registered 数字须等 target_only 抽查后才可信。
* 主指标用**段级判决正确率**（这段背景有没有被判静音），而非按秒——因为门控设计上每段
  开头必放 ~decision_min_sec(1.5s)（onset 漏入，不可调），按秒会虚高 FAR。onset 漏入秒
  单独报。
"""

from __future__ import annotations

import argparse
import dataclasses
import glob
import hashlib
import json
import os
import sys
import wave
from datetime import datetime, timezone

import numpy as np
from livekit import rtc  # noqa: F401  (rtc.AudioFrame 由 replay_frames 使用)

from _bootstrap import ensure_livekit_agent_path

ensure_livekit_agent_path()

from audio_filter import CampplusEmbedder, SpeakerGate  # noqa: E402
from config import SpeakerGateConfig  # noqa: E402
from replay_speaker_gate import replay_frames, _SyncExecutor  # noqa: E402

# ----------------------------------------------------------------------
# 路径与常量
# ----------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))
AGENT_DIR = os.path.dirname(HERE)
RUNS_DIR = os.path.join(AGENT_DIR, "tmp", "runs")
TESTSET_DIR = os.path.join(RUNS_DIR, "testset")
MODEL = os.getenv(
    "SPEAKER_GATE_MODEL_PATH",
    os.path.join(AGENT_DIR, "model", "pretrained", "campplus_sv_zh-cn_16k-common.onnx"),
)
FRAME_MS = 20
FRAME_SEC = FRAME_MS / 1000.0

# 评测/分段参数（与 SpeakerGate 生产默认对齐）
MIN_ENERGY = 50.0          # 有声帧 RMS 下限
SILENCE_EPS = 5.0          # 输出 RMS 低于此判为"被静音"
GAP_SEC = 0.5              # 段内可桥接的静音间隙（= segment_gap_sec）
ONSET_SEC = 1.5           # 每段开头必放的 onset 窗（= decision_min_sec），漏入不可调
DECIDE_FRAC = 0.5         # post-onset 静音占比 ≥ 此值 → 判定"门决定静音该段"
MIN_VOICED_SEC = 5.0      # 有声不足此值的 run，草稿标签置 unknown
THETA = 0.30              # 静音阈值（= SpeakerGateConfig.theta_close 默认），仅用于诊断 borderline 段
BORDERLINE_MARGIN = 0.02  # |sim-THETA| 小于此 → 判决在噪声带内（rtc.AudioResampler ±2LSB 抖动会翻转）

# 已有 eval JSON 里的人工已知标签 → 作为种子（见 known_labels）
SEED_LABELS = {
    "20260623_171610_health-voice-79-1782206159": {
        "label": "background_only", "verified": True,
        "note": "seed: eval JSON known_labels.background_all（全程背景，无目标）",
    },
    "20260623_163437_health-voice-79-1782203666": {
        "label": "mixed", "verified": False,
        "regions": [{"start": 15.0, "end": 99999.0, "label": "background"}],
        "note": "seed: eval JSON known_labels.background_after_opening（15s 后转背景；请确认 0-15s 是否为目标）",
    },
}


# ----------------------------------------------------------------------
# 基础 IO
# ----------------------------------------------------------------------
def _md5(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_wav_native(path: str) -> tuple[np.ndarray, int]:
    """读 16-bit PCM wav → int16 数组（不重采样，保留原始采样率喂给 gate，由 gate 内部重采样）。"""
    with wave.open(path, "rb") as w:
        sr, ch, sw = w.getframerate(), w.getnchannels(), w.getsampwidth()
        data = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    if sw != 2:
        raise ValueError(f"{path}: 仅支持 16-bit PCM（sampwidth={sw}）")
    if ch > 1:
        data = data[::ch]
    return data, sr


def find_runs(runs_dir: str) -> list[dict]:
    """扫描 run 目录，返回 [{run, dir, raw, stt, report}]（按 run 名排序）。"""
    out = []
    for d in sorted(glob.glob(os.path.join(runs_dir, "2026*"))):
        if not os.path.isdir(d):
            continue
        raw = glob.glob(os.path.join(d, "audio_raw_input_*.wav"))
        stt = glob.glob(os.path.join(d, "audio_stt_input_*.wav"))
        rep = glob.glob(os.path.join(d, "session_report_*.json"))
        if not raw:
            continue
        out.append({
            "run": os.path.basename(d), "dir": d, "raw": raw[0],
            "stt": stt[0] if stt else None, "report": rep[0] if rep else None,
        })
    return out


def find_profile(runs_dir: str) -> str | None:
    """选注册 profile：取 quality_score 最高的 target_speaker_profile.json。"""
    best, best_q = None, -1.0
    for p in glob.glob(os.path.join(runs_dir, "*", "target_profile_enroll", "target_speaker_profile.json")):
        try:
            q = float(json.load(open(p)).get("quality_score", 0.0))
        except Exception:
            q = 0.0
        if q > best_q:
            best, best_q = p, q
    return best


def detect_mode(raw: str, stt: str | None) -> str:
    """raw==stt → 录制时是 shadow（转写 pre-gate、独立于声纹）；否则 mute（转写 post-gate）。"""
    if not stt or not os.path.exists(stt):
        return "unknown"
    return "shadow" if _md5(raw) == _md5(stt) else "mute"


def extract_transcript(report_path: str | None) -> tuple[int, str]:
    """从 session_report.events 抽 user_input_transcribed 的 final 文本（独立于声纹的标签提示）。"""
    if not report_path or not os.path.exists(report_path):
        return 0, ""
    try:
        ev = json.load(open(report_path)).get("events", [])
    except Exception:
        return 0, ""
    finals = [e.get("transcript", "") for e in ev
              if e.get("type") == "user_input_transcribed" and e.get("is_final")]
    finals = [t for t in finals if t]
    preview = " ".join(finals)
    if len(preview) > 400:
        preview = preview[:400] + "…"
    return len(finals), preview


# ----------------------------------------------------------------------
# 回放 + 分段 + 评分
# ----------------------------------------------------------------------
_EMBEDDER: CampplusEmbedder | None = None


def get_embedder() -> CampplusEmbedder:
    global _EMBEDDER
    if _EMBEDDER is None:
        _EMBEDDER = CampplusEmbedder(MODEL, target_sr=16000)
        if not _EMBEDDER.ok:
            print(f"[ERR] CAM++ embedder 加载失败：{MODEL}", file=sys.stderr)
            sys.exit(2)
    return _EMBEDDER


def make_cfg(mode: str, profile_path: str | None) -> SpeakerGateConfig:
    """两种模式的配置：均 enabled + audio_mode=mute（这样 out_rms 才反映静音）。
    registered 额外挂固定 profile；session 不挂（自动注册）。其余沿用生产默认。"""
    over = dict(enabled=True, audio_mode="mute", debug=False)
    over["long_term_profile_path"] = profile_path if mode == "registered" else ""
    return dataclasses.replace(SpeakerGateConfig(), **over)


def replay(raw_wav: np.ndarray, sr: int, cfg: SpeakerGateConfig) -> tuple[list, dict]:
    gate = SpeakerGate(cfg, get_embedder())
    trace, _lock = replay_frames(raw_wav, sr, gate)
    return trace, gate.stats


def replay_with_decisions(raw_wav: np.ndarray, sr: int, cfg: SpeakerGateConfig):
    """同步回放，**捕获门自己的每段判决**（verdict sink, kind=='decide'）。

    返回 (trace, decisions, stats)：
      - trace: [(t, in_rms, out_rms)]，逐帧（秒级指标用）。
      - decisions: [(t_sec, is_target, sim)]，门对每个【可判段】做出的判决（段级指标用）。
        这是门的**真实判决单元**，避免我们自己按能量重切分段时口径不一致。
    用同步 executor → verdict 在 gate.filter() 内同步回调，故能精确记录判决发生的帧时刻。
    """
    gate = SpeakerGate(cfg, get_embedder())
    gate._executor = _SyncExecutor()
    cur = {"t": 0.0}
    decisions: list[tuple[float, bool, float | None]] = []

    def sink(is_target, sim, kind, state):  # noqa: ANN001
        if kind == "decide":
            decisions.append((cur["t"], bool(is_target), sim))

    gate.set_verdict_sink(sink)
    fl = int(sr * FRAME_MS / 1000)
    n = (len(raw_wav) // fl) * fl
    frames = raw_wav[:n].reshape(-1, fl)
    trace: list[tuple[float, float, float]] = []
    for i, chunk in enumerate(frames):
        cur["t"] = round(i * FRAME_SEC, 3)
        fr = rtc.AudioFrame(data=chunk.tobytes(), sample_rate=sr,
                            num_channels=1, samples_per_channel=fl)
        out = gate.filter(fr)
        in_rms = float(np.sqrt(np.mean(chunk.astype(np.float64) ** 2)))
        oa = np.frombuffer(out.data, dtype=np.int16)
        out_rms = float(np.sqrt(np.mean(oa.astype(np.float64) ** 2))) if oa.size else 0.0
        trace.append((cur["t"], in_rms, out_rms))
    return trace, decisions, gate.stats


def reconstruct_segments(trace: list[tuple[float, float, float]]) -> list[dict]:
    """把逐帧 trace 还原成有声段（桥接 < GAP_SEC 的间隙），每段统计有声/被静音帧（含 post-onset）。"""
    n = len(trace)
    voiced = np.array([r >= MIN_ENERGY for _, r, _ in trace])
    out_rms = np.array([o for _, _, o in trace])
    gap_frames = int(round(GAP_SEC / FRAME_SEC))
    onset_frames = int(round(ONSET_SEC / FRAME_SEC))
    segs: list[dict] = []
    i = 0
    while i < n:
        if not voiced[i]:
            i += 1
            continue
        # 向后扩展，桥接 <= gap_frames 的静音间隙
        last = i
        k = i + 1
        while k < n:
            if voiced[k]:
                last = k
                k += 1
                continue
            g = k
            while g < n and not voiced[g]:
                g += 1
            if g < n and (g - k) <= gap_frames:
                k = g
            else:
                break
        # 段 [i, last]
        idx = np.arange(i, last + 1)
        seg_voiced = voiced[idx]
        seg_sil = seg_voiced & (out_rms[idx] < SILENCE_EPS)
        post = idx >= (i + onset_frames)
        post_voiced = seg_voiced & post
        post_sil = seg_sil & post
        segs.append({
            "t0": round(i * FRAME_SEC, 2), "t1": round(last * FRAME_SEC, 2),
            "n_voiced": int(seg_voiced.sum()), "n_silenced": int(seg_sil.sum()),
            "post_voiced": int(post_voiced.sum()), "post_silenced": int(post_sil.sum()),
        })
        i = last + 1
    return segs


def decide_segment(seg: dict) -> str:
    """门对该段的判决：'silence'（决定静音）/ 'pass'（决定放行）/ 'pass_structural'（段≤onset，无法判，必放）。"""
    if seg["post_voiced"] == 0:
        return "pass_structural"
    return "silence" if (seg["post_silenced"] / seg["post_voiced"]) >= DECIDE_FRAC else "pass"


def gt_at(t: float, run_label: str, regions: list[dict]) -> str | None:
    """某时刻 t 的 ground-truth 身份：target_only/background_only → 全程同标；
    mixed → 按 regions 区段归属；未落入任何区段 → None（不计入指标）。"""
    if run_label == "target_only":
        return "target"
    if run_label == "background_only":
        return "background"
    if run_label == "mixed":
        for r in regions:
            if r["start"] <= t < r["end"]:
                return "target" if r["label"] == "target" else "background"
    return None


# ----------------------------------------------------------------------
# build：生成 manifest 草稿
# ----------------------------------------------------------------------
def cmd_build(args) -> int:
    runs = find_runs(args.runs_dir)
    if not runs:
        print(f"[ERR] {args.runs_dir} 下没有 run", file=sys.stderr)
        return 2
    profile = args.profile or find_profile(args.runs_dir)
    if not profile:
        print("[ERR] 未找到 target_speaker_profile.json（registered 模式需要）", file=sys.stderr)
        return 2
    enroll_run = os.path.basename(os.path.dirname(os.path.dirname(profile)))
    print(f"[build] runs={len(runs)} profile={os.path.relpath(profile, AGENT_DIR)} enroll_run={enroll_run}")

    cfg = make_cfg("registered", profile)
    entries = []
    for n, r in enumerate(runs, 1):
        wav, sr = read_wav_native(r["raw"])
        trace, stats = replay(wav, sr, cfg)
        segs = reconstruct_segments(trace)
        post_v = sum(s["post_voiced"] for s in segs)
        post_s = sum(s["post_silenced"] for s in segs)
        voiced_sec = sum(s["n_voiced"] for s in segs) * FRAME_SEC
        sil_frac = (post_s / post_v) if post_v else 0.0

        # 草稿标签（registered 静音率启发式；务必人工修正）
        if voiced_sec < MIN_VOICED_SEC:
            label, conf = "unknown", "low"
        elif sil_frac < 0.15:
            label, conf = "target_only", ("high" if sil_frac < 0.05 else "medium")
        elif sil_frac > 0.60:
            label, conf = "background_only", ("high" if sil_frac > 0.85 else "medium")
        else:
            label, conf = "mixed", "low"

        # mixed 候选区段（按段判决聚合，仅供人工编辑起点，非权威）
        candidates = []
        if label == "mixed":
            cur = None
            for s in segs:
                guess = "background" if decide_segment(s) == "silence" else "target"
                if cur and cur["label"] == guess:
                    cur["end"] = s["t1"]
                else:
                    cur = {"start": s["t0"], "end": s["t1"], "label": guess}
                    candidates.append(cur)

        mode = detect_mode(r["raw"], r["stt"])
        n_finals, transcript = extract_transcript(r["report"])

        seed = SEED_LABELS.get(r["run"], {})
        is_enroll = r["run"] == enroll_run
        entry = {
            "run": r["run"],
            "raw_wav": os.path.relpath(r["raw"], AGENT_DIR),
            "duration_sec": round(len(wav) / sr, 1),
            "voiced_sec": round(voiced_sec, 1),
            "record_mode": mode,                      # shadow=转写独立于声纹 / mute=转写已过gate
            "n_final_transcripts": n_finals,
            "transcript_preview": transcript,         # 独立标签提示：内容像目标对话还是背景闲聊？
            "draft": {"silenced_frac_postonset": round(sil_frac, 3),
                       "label": label, "confidence": conf},
            "candidate_regions": [
                {"start": round(c["start"], 1), "end": round(c["end"], 1), "label": c["label"]}
                for c in candidates
            ],
            # ↓↓↓ 以下为你要人工确认/修改的字段 ↓↓↓
            "label": seed.get("label", label),         # target_only | background_only | mixed | unknown | skip
            "regions": seed.get("regions", []),         # mixed 用：[{start,end,label: target|background}]
            "verified": seed.get("verified", False),    # 人工确认后置 true
            "exclude_registered": is_enroll,            # 注册源 run 从 registered 评测排除（防泄漏）
            "note": seed.get("note", ("注册源 run（registered 评测自动排除）" if is_enroll else "")),
        }
        entries.append(entry)
        print(f"  [{n:2d}/{len(runs)}] {r['run'][:30]} sil={sil_frac:.2f} "
              f"voiced={voiced_sec:4.0f}s mode={mode:6s} → draft={label}({conf})")

    os.makedirs(args.runs_dir + "/testset", exist_ok=True)
    manifest = {
        "created": datetime.now(timezone.utc).isoformat(),
        "runs_dir": os.path.relpath(args.runs_dir, AGENT_DIR),
        "profile": os.path.relpath(profile, AGENT_DIR),
        "enroll_run": enroll_run,
        "params": {"min_energy": MIN_ENERGY, "silence_eps": SILENCE_EPS,
                    "gap_sec": GAP_SEC, "onset_sec": ONSET_SEC, "decide_frac": DECIDE_FRAC},
        "label_legend": {
            "target_only": "全程只有目标说话人（期望全放行）",
            "background_only": "全程只有背景人声（期望全静音；session 模式 N/A）",
            "mixed": "目标+背景；用 regions 标 [start,end,label] 区段",
            "unknown/skip": "排除出评测",
        },
        "runs": entries,
    }
    out = os.path.join(args.runs_dir, "testset", "manifest.json")
    json.dump(manifest, open(out, "w"), ensure_ascii=False, indent=2)
    print(f"\n[build] manifest → {os.path.relpath(out, AGENT_DIR)}")
    print("[build] 下一步：人工核对 label/regions/verified（尤其 background_only、mixed、"
          "以及高置信 target_only 抽查），再跑 `run`。")
    return 0


# ----------------------------------------------------------------------
# run：两种模式评测 + 报告
# ----------------------------------------------------------------------
def _empty_acc() -> dict:
    return {
        "target_segs": 0, "target_killed": 0,
        "bg_decidable_segs": 0, "bg_leaked": 0, "bg_caught": 0, "borderline": 0,
        "target_voiced_sec": 0.0, "target_silenced_sec": 0.0,
        "bg_voiced_sec": 0.0, "bg_passed_sec": 0.0,
        "per_run": [], "runs_na": [],
    }


def _score_into(acc: dict, run: str, label: str, verified: bool,
                trace: list, decisions: list, regions: list[dict], gate_segs: int) -> None:
    """段级指标用门的真实判决 decisions；秒级指标用逐帧 trace。两者都按 GT 区段归属。"""
    # —— 段级：门对每个可判段的判决（kind=='decide'）——
    # 同时记录【误杀/漏入】事件的 (t, sim)：sim 是区分"标签太粗" vs "真锁错"的关键诊断量。
    t_seg = t_kill = bg_dec = bg_leak = 0
    kill_events: list[dict] = []   # 目标段被静音（FRR）
    leak_events: list[dict] = []   # 背景段被放行（FAR）
    borderline = 0                  # |sim-THETA| 在噪声带内的判决数（结果易抖）
    for t, is_target, sim in decisions:
        gt = gt_at(t, label, regions)
        if gt is None:
            continue
        sim_r = round(sim, 3) if sim is not None else None
        if sim is not None and abs(sim - THETA) < BORDERLINE_MARGIN:
            borderline += 1
        if gt == "target":
            t_seg += 1
            if not is_target:      # 门判背景→静音了目标段 = 误杀(FRR)
                t_kill += 1
                kill_events.append({"t": t, "sim": sim_r})
        else:                       # background
            bg_dec += 1
            if is_target:           # 门判目标→放行了背景段 = 漏入(FAR)
                bg_leak += 1
                leak_events.append({"t": t, "sim": sim_r})
    bg_caught = bg_dec - bg_leak

    # —— 秒级：逐帧有声秒，按 GT 区段统计放行/静音 ——
    t_vsec = t_ssec = bg_vsec = bg_psec = 0.0
    for t, in_rms, out_rms in trace:
        if in_rms < MIN_ENERGY:
            continue
        gt = gt_at(t, label, regions)
        if gt is None:
            continue
        silenced = out_rms < SILENCE_EPS
        if gt == "target":
            t_vsec += FRAME_SEC
            if silenced:
                t_ssec += FRAME_SEC
        else:
            bg_vsec += FRAME_SEC
            if not silenced:
                bg_psec += FRAME_SEC

    acc["target_segs"] += t_seg
    acc["target_killed"] += t_kill
    acc["bg_decidable_segs"] += bg_dec
    acc["bg_leaked"] += bg_leak
    acc["bg_caught"] += bg_caught
    acc["borderline"] += borderline
    acc["target_voiced_sec"] += t_vsec
    acc["target_silenced_sec"] += t_ssec
    acc["bg_voiced_sec"] += bg_vsec
    acc["bg_passed_sec"] += bg_psec
    acc["per_run"].append({
        "run": run, "label": label, "verified": verified,
        "target_segs": t_seg, "target_killed": t_kill,
        "bg_decidable_segs": bg_dec, "bg_leaked": bg_leak,
        "frr_seg": round(t_kill / t_seg, 3) if t_seg else None,
        "far_seg": round(bg_leak / bg_dec, 3) if bg_dec else None,
        "frr_sec": round(t_ssec / t_vsec, 3) if t_vsec else None,
        "far_sec": round(bg_psec / bg_vsec, 3) if bg_vsec else None,
        "decisions_n": len(decisions), "gate_segs": gate_segs,
        "seg_sanity": round(len(decisions) / gate_segs, 2) if gate_segs else None,
        "kill_events": kill_events,   # FRR 段 (t,sim)：低 sim+落在目标话上=真锁错；落在闲聊上=标签太粗
        "leak_events": leak_events,   # FAR 段 (t,sim)
    })


def _summary(acc: dict) -> dict:
    t, k = acc["target_segs"], acc["target_killed"]
    bd, bl = acc["bg_decidable_segs"], acc["bg_leaked"]
    correct = (t - k) + (bd - bl)
    total = t + bd
    # 每个"被正确判静音"的背景段，门做决定前约漏入 onset(=decision_min_sec) ——结构性、不可调。
    est_onset_leak = acc["bg_caught"] * ONSET_SEC
    return {
        "segment": {
            "accuracy_seg": round(correct / total, 3) if total else None,
            "target_segs": t, "target_killed_FRR": k,
            "FRR_seg": round(k / t, 3) if t else None,
            "bg_decidable_segs": bd, "bg_leaked_FAR": bl,
            "FAR_seg": round(bl / bd, 3) if bd else None,
            "borderline_segs": acc["borderline"],
        },
        "seconds": {
            "FRR_sec": round(acc["target_silenced_sec"] / acc["target_voiced_sec"], 3) if acc["target_voiced_sec"] else None,
            "FAR_sec_incl_onset": round(acc["bg_passed_sec"] / acc["bg_voiced_sec"], 3) if acc["bg_voiced_sec"] else None,
            "target_voiced_sec": round(acc["target_voiced_sec"], 1),
            "bg_voiced_sec": round(acc["bg_voiced_sec"], 1),
            "bg_passed_sec": round(acc["bg_passed_sec"], 1),
            "est_onset_leak_sec": round(est_onset_leak, 1),
        },
    }


def cmd_run(args) -> int:
    man_path = args.manifest or os.path.join(args.runs_dir, "testset", "manifest.json")
    if not os.path.exists(man_path):
        print(f"[ERR] 找不到 manifest：{man_path}，先跑 `build`", file=sys.stderr)
        return 2
    man = json.load(open(man_path))
    profile = os.path.join(AGENT_DIR, man["profile"])
    runs = {r["run"]: r for r in find_runs(args.runs_dir)}

    labeled = [e for e in man["runs"] if e.get("label") in ("target_only", "background_only", "mixed")]
    print(f"[run] manifest={os.path.relpath(man_path, AGENT_DIR)} labeled_runs={len(labeled)} "
          f"(verified={sum(1 for e in labeled if e.get('verified'))})")

    cfg_reg = make_cfg("registered", profile)
    cfg_ses = make_cfg("session", None)
    acc = {"registered": _empty_acc(), "session": _empty_acc()}

    for n, e in enumerate(labeled, 1):
        run, label = e["run"], e["label"]
        regions = e.get("regions", [])
        meta = runs.get(run)
        if not meta:
            print(f"  [skip] {run} 无音频")
            continue
        wav, sr = read_wav_native(meta["raw"])

        # registered：排除注册源 run
        if not e.get("exclude_registered"):
            trace, decisions, stats = replay_with_decisions(wav, sr, cfg_reg)
            _score_into(acc["registered"], run, label, e.get("verified", False),
                        trace, decisions, regions, stats.get("segments", 0))

        # session：background_only 对 session 无意义（它会把背景当注册目标）→ 记 N/A，不计入
        if label == "background_only":
            acc["session"]["runs_na"].append(run)
        else:
            trace, decisions, stats = replay_with_decisions(wav, sr, cfg_ses)
            _score_into(acc["session"], run, label, e.get("verified", False),
                        trace, decisions, regions, stats.get("segments", 0))

        print(f"  [{n:2d}/{len(labeled)}] {run[:30]} label={label}"
              f"{' (excl-reg)' if e.get('exclude_registered') else ''}")

    report = {
        "created": datetime.now(timezone.utc).isoformat(),
        "manifest": os.path.relpath(man_path, AGENT_DIR),
        "profile": man["profile"],
        "params": man["params"],
        "modes": {
            "registered": {**_summary(acc["registered"]),
                            "n_runs": len(acc["registered"]["per_run"]),
                            "per_run": acc["registered"]["per_run"]},
            "session": {**_summary(acc["session"]),
                         "n_runs": len(acc["session"]["per_run"]),
                         "runs_na_background_only": acc["session"]["runs_na"],
                         "per_run": acc["session"]["per_run"]},
        },
        "verified_counts": {
            "labeled": len(labeled),
            "verified": sum(1 for e in labeled if e.get("verified")),
        },
    }
    os.makedirs(os.path.join(args.runs_dir, "testset"), exist_ok=True)
    rj = os.path.join(args.runs_dir, "testset", "report.json")
    json.dump(report, open(rj, "w"), ensure_ascii=False, indent=2)
    rm = os.path.join(args.runs_dir, "testset", "report.md")
    open(rm, "w").write(render_md(report))
    print(f"\n[run] report → {os.path.relpath(rj, AGENT_DIR)} ,  {os.path.relpath(rm, AGENT_DIR)}")
    print(_console_summary(report))
    return 0


def _pct(x) -> str:
    return "—" if x is None else f"{x*100:.1f}%"


def _console_summary(rep: dict) -> str:
    lines = ["", "==== 评测摘要（段级）===="]
    for mode in ("registered", "session"):
        m = rep["modes"][mode]["segment"]
        lines.append(f"[{mode:10s}] 准确率={_pct(m['accuracy_seg'])}  "
                     f"误杀FRR={_pct(m['FRR_seg'])}({m['target_killed_FRR']}/{m['target_segs']})  "
                     f"漏入FAR={_pct(m['FAR_seg'])}({m['bg_leaked_FAR']}/{m['bg_decidable_segs']})")
    return "\n".join(lines)


def render_md(rep: dict) -> str:
    L = []
    L.append("# SpeakerGate 测试集评测报告\n")
    L.append(f"- 生成时间：{rep['created']}")
    L.append(f"- manifest：`{rep['manifest']}`　注册 profile：`{rep['profile']}`")
    p = rep["params"]
    L.append(f"- 分段/判决参数：min_energy={p['min_energy']} onset={p['onset_sec']}s "
             f"gap={p['gap_sec']}s decide_frac={p['decide_frac']}")
    vc = rep["verified_counts"]
    L.append(f"- 标注：{vc['labeled']} 条已标 / 其中 {vc['verified']} 条人工确认\n")

    L.append("## 指标口径")
    L.append("- **段级判决正确率(主)**：每个有声段门是否做出正确放行/静音判决。")
    L.append("- **FRR 误杀率**：目标段被门静音的比例（越低越好；漏字风险）。")
    L.append("- **FAR 漏入率(段级)**：门【可判】背景段被放行的比例（越低越好；污染/误打断）。"
             "段级判决用门自身的整段判决单元，**天然不含 onset 漏入**（每段开头 ~{0}s 必放、"
             "结构性不可调）。".format(p["onset_sec"]))
    L.append("- **秒级**：逐帧有声秒。FAR(秒)**含 onset 漏入**，故偏高；onset 漏入秒单独估算"
             "（≈ 正确静音的背景段数 × {0}s）。".format(p["onset_sec"]))
    L.append("- ⚠ **可信度**：registered 数字依赖标签，须等 target_only 草稿抽查后才可信；"
             "session 用会话内独立质心，标签噪声不构成偏置，草稿上即基本可信。")
    L.append("- ⚠ **复现性抖动**：`rtc.AudioResampler`（门内部 24k→16k，生产同款）非确定，"
             "±2LSB 噪声 → sim 抖 ~0.005 → 阈值附近 (|sim-theta|<{0}) 的判决会翻转。"
             "总览表 `阈值带段数` 即落在该带内的判决数；比较两套配置时，**差异 ≤ 该数视作噪声**，"
             "需多跑几次或扩大样本。\n".format(BORDERLINE_MARGIN))

    # 汇总表
    L.append("## 总览（段级 / 秒级）\n")
    L.append("| 模式 | 段级准确率 | FRR(误杀,段) | FAR(漏入,段) | 目标段 | 背景可判段 | 阈值带段数 | FRR(秒) | FAR(秒,含onset) | 背景漏入(s) | onset漏入估算(s) |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for mode in ("registered", "session"):
        seg = rep["modes"][mode]["segment"]
        sec = rep["modes"][mode]["seconds"]
        L.append(f"| {mode} | {_pct(seg['accuracy_seg'])} | "
                 f"{_pct(seg['FRR_seg'])} ({seg['target_killed_FRR']}/{seg['target_segs']}) | "
                 f"{_pct(seg['FAR_seg'])} ({seg['bg_leaked_FAR']}/{seg['bg_decidable_segs']}) | "
                 f"{seg['target_segs']} | {seg['bg_decidable_segs']} | {seg['borderline_segs']} | "
                 f"{_pct(sec['FRR_sec'])} | {_pct(sec['FAR_sec_incl_onset'])} | "
                 f"{sec['bg_passed_sec']} | {sec['est_onset_leak_sec']} |")
    na = rep["modes"]["session"].get("runs_na_background_only", [])
    if na:
        L.append(f"\n> session 模式对 {len(na)} 条 background_only 标记 **N/A**"
                 "（自动注册会把背景当目标，无法当背景过滤）。\n")

    # 每模式 per-run
    for mode in ("registered", "session"):
        L.append(f"\n## per-run：{mode}\n")
        L.append("| run | label | ✓ | 目标段 | 误杀 | 背景可判 | 漏入 | FRR | FAR | FRR秒 | FAR秒 | 判决数(门段) |")
        L.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for r in rep["modes"][mode]["per_run"]:
            sanity = f"{r['decisions_n']}/{r['gate_segs']}"
            flag = "✓" if r["verified"] else ""
            L.append(f"| {r['run'][:28]} | {r['label']} | {flag} | "
                     f"{r['target_segs']} | {r['target_killed']} | "
                     f"{r['bg_decidable_segs']} | {r['bg_leaked']} | "
                     f"{_pct(r['frr_seg'])} | {_pct(r['far_seg'])} | "
                     f"{_pct(r['frr_sec'])} | {_pct(r['far_sec'])} | {sanity} |")
    L.append("\n> 判决数(门段)：本工具捕获的门判决事件数 vs gate.stats.segments，应≈1:1；"
             "差异大说明判决捕获口径有问题，需复查。")

    # 诊断：误杀段 sim —— 区分"标签太粗"(背景被正确静音却落在 target_only run) vs "真锁错"
    diag = [r for r in rep["modes"]["registered"]["per_run"] if r.get("kill_events")]
    if diag:
        L.append("\n## 诊断：registered 误杀段 sim（区分标签太粗 vs 真锁错）\n")
        L.append("> 判读：**先看该 run 的 `transcript_preview` 内容**——若含明显背景闲聊（如办公室对话），"
                 "则低 sim 误杀多半是门在**正确静音背景**、该 run 实为 mixed（标签太粗，应改 "
                 "mixed+regions），FRR 被高估；若 transcript 几乎全是连贯目标对话、却仍大量低 sim 误杀，"
                 "才是**真锁错**（重要发现，见 [[speakergate-cammpp]] 的 PC ASR 灾难，真用户 sim 0.05–0.18）。"
                 "辅证：`frr_sec` 远低于 `frr_seg`（误杀集中在短背景段）通常指向前者。"
                 "（注：部分 run 的 `audio_recording_started_at` 缺失，转写无法精确对齐到秒，故以内容判读为主。）\n")
        L.append("| run | label | 误杀段数 | 误杀 sim (t=秒) |")
        L.append("|---|---|---|---|")
        for r in sorted(diag, key=lambda x: -len(x["kill_events"]))[:8]:
            ev = ", ".join(f"{e['sim']}(t={e['t']:.0f})" for e in r["kill_events"][:10])
            L.append(f"| {r['run'][:28]} | {r['label']} | {r['target_killed']} | {ev} |")
    return "\n".join(L) + "\n"


# ----------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(description="SpeakerGate 测试集构建 + 评测")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="生成 manifest 草稿")
    b.add_argument("--runs-dir", default=RUNS_DIR)
    b.add_argument("--profile", default=None, help="注册 profile JSON（默认自动选 quality 最高）")
    b.set_defaults(func=cmd_build)
    r = sub.add_parser("run", help="按 manifest 跑两种模式评测")
    r.add_argument("--runs-dir", default=RUNS_DIR)
    r.add_argument("--manifest", default=None)
    r.set_defaults(func=cmd_run)
    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

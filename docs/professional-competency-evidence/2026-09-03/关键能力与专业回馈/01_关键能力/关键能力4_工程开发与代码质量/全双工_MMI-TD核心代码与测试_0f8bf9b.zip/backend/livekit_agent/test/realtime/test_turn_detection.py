"""轮次检测测试用例 (v2)

验证语音助手的轮次检测（Turn Detection）能力：
- 停顿 < 2s -> 不切轮（即使 ASR 有返回）
- 停顿 > 2s -> 切轮
- 换气停顿不应误切轮

指标：endpointing_excess_ms（扣除静音阈值后的纯检测耗时）、TTFB
"""

import asyncio
import time
import pytest

from core.ws_test_client import RealtimeTestClient
from core.metrics import TurnDetectionResult, MetricsAggregator
from conftest import (
    load_turn_detection_cases,
    load_turn_detection_config,
    generate_audio,
)

# 正确的事件名
AUDIO_DELTA_EVENT = "response.output_audio.delta"

turn_cases = load_turn_detection_cases()
turn_config = load_turn_detection_config()


@pytest.mark.parametrize(
    "case",
    turn_cases,
    ids=[c.name for c in turn_cases],
)
async def test_turn_detection(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case,
    metrics_aggregator: MetricsAggregator,
):
    """轮次检测：注入语音+静音序列 -> 验证是否在正确位置切轮"""

    await ws_client.connect(ws_url, auth_token)

    # 等待 agent 开场白结束
    await ws_client.wait_for_agent_state("listening", timeout=30)
    ws_client.clear_events()

    mid_pause_switched = False
    turn_timeout = turn_config.get("turn_timeout", 8.0)

    for i, seg in enumerate(case.segments):
        if seg.type == "speech":
            pcm = generate_audio(seg.audio_type, seg.audio_duration_s)
            await ws_client.inject_audio(pcm)

        elif seg.type == "silence":
            t_silence_start = time.monotonic()
            await ws_client.inject_silence(seg.duration_s)

            # 在中间静音段期间检测是否 agent 抢答
            is_last_segment = (i == len(case.segments) - 1)
            if not is_last_segment:
                agent_spoke = ws_client.has_event_after(
                    "agent.state_changed",
                    t_silence_start,
                    lambda e: e.get("state") in ("thinking", "speaking"),
                )
                if agent_spoke:
                    mid_pause_switched = True

    # 等待最终结果
    t_audio_end = time.monotonic()
    await ws_client.drain_events(timeout=turn_timeout)

    # 判断最终是否切轮
    final_switched = ws_client.has_event_after(
        "agent.state_changed",
        t_audio_end - 0.5,
        lambda e: e.get("state") == "speaking",
    )

    # ========== 简单场景：只有 expect_turn_switch ==========
    if case.expect_turn_switch is not None:
        # 取最后一段 silence 的 duration 作为 silence_duration_s
        last_silence_s = 0.0
        for seg in reversed(case.segments):
            if seg.type == "silence" and seg.duration_s:
                last_silence_s = seg.duration_s
                break

        # 获取 agent.state_changed → thinking 的时间戳
        t_thinking = ws_client.get_event_time_after(
            "agent.state_changed", t_audio_end - 1,
        )
        # 获取第一个 agent 音频帧（TTFB）
        t_first_delta = ws_client.get_event_time_after(
            AUDIO_DELTA_EVENT, t_audio_end - 1,
        )

        result = TurnDetectionResult(
            case_name=case.name,
            silence_duration_s=last_silence_s,
            expected_turn_switch=case.expect_turn_switch,
            actual_turn_switched=final_switched,
            t_audio_end=t_audio_end,
            t_agent_thinking=t_thinking,
            t_first_agent_audio_delta=t_first_delta,
        )
        metrics_aggregator.add_turn_detection(result)

        assert result.correct, (
            f"{case.name}: expected_turn_switch={case.expect_turn_switch}, "
            f"actual={final_switched}, "
            f"ep_excess={result.endpointing_excess_ms}, "
            f"ttfb={result.time_to_first_audio_ms}"
        )

    # ========== 复杂场景：中间停顿 + 最终切轮 ==========
    if case.expect_mid_pause_switch is not None:
        assert mid_pause_switched == case.expect_mid_pause_switch, (
            f"{case.name}: mid-pause switch "
            f"expected={case.expect_mid_pause_switch}, actual={mid_pause_switched}"
        )

        # 记录中间停顿指标
        mid_silence_s = case.mid_pause_s or 0.0
        result = TurnDetectionResult(
            case_name=f"{case.name}_mid_pause",
            silence_duration_s=mid_silence_s,
            expected_turn_switch=case.expect_mid_pause_switch,
            actual_turn_switched=mid_pause_switched,
            t_audio_end=t_audio_end,
            mid_pause_switched=mid_pause_switched,
        )
        metrics_aggregator.add_turn_detection(result)

    if case.expect_final_switch is not None:
        assert final_switched == case.expect_final_switch, (
            f"{case.name}: final switch "
            f"expected={case.expect_final_switch}, actual={final_switched}"
        )

        # 记录最终切轮指标
        last_silence_s = 0.0
        for seg in reversed(case.segments):
            if seg.type == "silence" and seg.duration_s:
                last_silence_s = seg.duration_s
                break

        t_thinking = ws_client.get_event_time_after(
            "agent.state_changed", t_audio_end - 1,
        )
        t_first_delta = ws_client.get_event_time_after(
            AUDIO_DELTA_EVENT, t_audio_end - 1,
        )

        result = TurnDetectionResult(
            case_name=f"{case.name}_final",
            silence_duration_s=last_silence_s,
            expected_turn_switch=case.expect_final_switch,
            actual_turn_switched=final_switched,
            t_audio_end=t_audio_end,
            t_agent_thinking=t_thinking,
            t_first_agent_audio_delta=t_first_delta,
        )
        metrics_aggregator.add_turn_detection(result)

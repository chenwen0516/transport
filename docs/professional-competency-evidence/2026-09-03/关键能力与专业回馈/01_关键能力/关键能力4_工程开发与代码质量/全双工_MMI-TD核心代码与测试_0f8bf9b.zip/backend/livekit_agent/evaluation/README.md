# Voice Robustness Evaluation

This directory contains offline analysis, replay, and calibration tools for the
voice robustness stack:

- `analyze_noisegate_mmi.py`: session-level NoiseGate + MMI-FD report.
- `noisegate_mmi_fd_test_plan.md`: repeatable manual test matrix, metrics, and
  first-pass tuning thresholds for NoiseGate + MMI-FD.
- `analyze_speaker_gate.py`: SpeakerGate log/audio quantification.
- `analyze_mmi_log.py`: compact MMI-TD decision log summary.
- `replay_speaker_gate.py`: deterministic SpeakerGate replay on one WAV.
- `speaker_gate_spike.py`: CAM++ similarity timeline and threshold calibration.
- `enroll_speaker_profile.py`: create fixed long-term SpeakerGate profile JSON
  from explicit enrollment WAV files.
- `check_speaker_gate_mislock.py`: raw/stt VAD comparison to detect whether the
  gate locked onto background instead of the user.
- `check_vad_enroll_fix.py`: offline A/B replay for VAD-aligned enrollment.
- `check_vad_segmentation.py`: inspect whether Silero VAD can split background
  that RMS energy cannot split.
- `export_fdb_mmi_replay.py`: join FDB samples to Agent audio and event
  timelines without copying recordings.
- `select_fdb_mmi_holdout.py`: build a deterministic v1.5 holdout root while
  excluding samples listed in prior run manifests.
- `run_fdb_mmi_replay.py`: merge 200 ms PCM chunks and streaming events through
  a pluggable detector interface; the logged baseline validates report parity.
- `fdb_mmi_semantic.py`: precompute conservative five-state classifications
  from an OpenAI-compatible model, then replay the cached decisions offline.
- `fdb_mmi_semantic_overlay.py`: replay the frozen v4 correction layer with
  logged MMI decisions as the primary control path.
- `analyze_semantic_overlay_shadow.py`: summarize online overlay request
  reliability, latency, realtime-window coverage, and decision changes.

Run from `backend/livekit_agent`.

Pure log/audio summaries work with `python3` when `numpy` is available:

```bash
python3 evaluation/analyze_noisegate_mmi.py tmp --latest 1
python3 evaluation/analyze_speaker_gate.py tmp --json tmp/speaker_gate_report.json
python3 evaluation/analyze_mmi_log.py tmp
python3 evaluation/analyze_noisegate_mmi.py evaluation/fixtures/tmp-0621 --latest 1
```

Current runtime artifacts are grouped under `tmp/runs/<timestamp>_<session>/`.
The analysis scripts scan recursively, so `tmp` still works as the root input.

SpeakerGate replay/calibration imports project runtime dependencies (`livekit`,
ONNX runtime, fbank), so prefer the project environment:

```bash
uv run python evaluation/replay_speaker_gate.py tmp/audio_raw_input_xxx.wav
uv run python evaluation/speaker_gate_spike.py --model model/pretrained/campplus_sv_zh-cn_16k-common.onnx --wav recording.wav
uv run python evaluation/enroll_speaker_profile.py --model model/pretrained/campplus_sv_zh-cn_16k-common.onnx --profile-id user123 --output tmp/user123_speaker_profile.json enroll_1.wav enroll_2.wav
uv run python evaluation/check_speaker_gate_mislock.py
uv run python evaluation/check_vad_enroll_fix.py
uv run python evaluation/check_vad_segmentation.py
```

FDB replay preparation and the historical-decision parity baseline use only the
standard library:

```bash
python3 evaluation/select_fdb_mmi_holdout.py \
  /opt/Full-Duplex-Bench/data \
  /opt/Full-Duplex-Bench/data_subsets/en_mmi_holdout_v1_20260723 \
  --exclude-run-glob '/opt/Full-Duplex-Bench/runs/health_webrtc_en/en_qwen_shadow_mmi_*' \
  --per-scenario 20 --seed 20260723

python3 evaluation/run_fdb_mmi_replay.py \
  /path/to/mmi_replay_v1/manifest.jsonl \
  /path/to/mmi_replay_v1/logged_baseline

python3 evaluation/fdb_mmi_semantic.py classify \
  /path/to/mmi_replay_v1/manifest.jsonl \
  /path/to/mmi_replay_v1/semantic_cache_v1.json \
  --config-toml settings.local.toml --workers 4

python3 evaluation/fdb_mmi_semantic.py replay \
  /path/to/mmi_replay_v1/manifest.jsonl \
  /path/to/mmi_replay_v1/semantic_cache_v1.json \
  /path/to/mmi_replay_v1/semantic_baseline_v1
```

The old top-level/tool script entrypoints were removed intentionally. Keep new
offline analysis entrypoints under this directory so production code paths stay
separate from evaluation utilities.

## Online semantic overlay Shadow

The frozen v4 policy also has an online Shadow observer in
`mmi_turn_detection/semantic_overlay.py`. It receives streaming transcripts and
base MMI decisions, but only emits comparison logs. It never executes
`interrupt`, `commit`, or `clear`.

Enable it through Dynaconf environment variables:

```bash
export AGENT_MMI_TURN_DETECTION__MODE=shadow
export AGENT_MMI_TURN_DETECTION__SEMANTIC_OVERLAY_SHADOW_ENABLED=true
export AGENT_MMI_TURN_DETECTION__SEMANTIC_OVERLAY_BASE_URL=https://example.com/v1
export AGENT_MMI_TURN_DETECTION__SEMANTIC_OVERLAY_API_KEY='...'
export AGENT_MMI_TURN_DETECTION__SEMANTIC_OVERLAY_MODEL='model-name'
export AGENT_MMI_TURN_DETECTION__SEMANTIC_OVERLAY_TIMEOUT_MS=1500
export AGENT_MMI_TURN_DETECTION__SEMANTIC_OVERLAY_EFFECTIVE_BUDGET_MS=300
export AGENT_MMI_TURN_DETECTION__SEMANTIC_OVERLAY_MAX_CONCURRENCY=2
```

The dedicated MMI log then contains:

- `semantic_overlay_comparison`: base action and currently available overlay
  recommendation.
- `semantic_overlay_result`: semantic state, API latency, whether it arrived
  before the base decision, and whether it was within the effective budget.
- `semantic_overlay_dropped`: request skipped because all realtime concurrency
  slots were occupied.
- `semantic_overlay_error`: timeout, HTTP, or response parsing failure.

Missing credentials disable only the observer. Slow or failed requests never
change the existing Agent control path.

Analyze one or more run directories after an online Shadow evaluation:

```bash
python3 evaluation/analyze_semantic_overlay_shadow.py tmp/runs \
  --json tmp/semantic_overlay_shadow_summary.json
```

Analyze whether local MMI decisions beat the native interruption timeline:

```bash
python3 evaluation/analyze_fast_path_shadow.py tmp/runs \
  --json tmp/fast_path_shadow_summary.json
```

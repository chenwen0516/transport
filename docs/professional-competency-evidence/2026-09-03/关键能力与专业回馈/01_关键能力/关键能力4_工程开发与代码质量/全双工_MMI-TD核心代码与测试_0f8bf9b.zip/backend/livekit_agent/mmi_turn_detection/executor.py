"""Idempotent LiveKit action executor for Active MMI-TD sessions."""

from __future__ import annotations

import logging

from livekit.agents import AgentSession

from .context_store import MMITurnContextStore
from .models import MMITurnAction, MMITurnDecision

logger = logging.getLogger("health-agent.mmi.executor")


class StaleDecisionError(RuntimeError):
    pass


class MMITurnExecutor:
    def __init__(
        self,
        session: AgentSession,
        store: MMITurnContextStore,
        *,
        force_interruptions: bool = False,
        response_watchdog: object | None = None,
    ) -> None:
        self._session = session
        self._store = store
        self._force_interruptions = force_interruptions
        self._response_watchdog = response_watchdog

    async def execute(self, decision: MMITurnDecision) -> bool:
        self._validate(decision)

        if decision.action == MMITurnAction.START_SPEAKING:
            transcript_text = self._store.transcript_text
            commit_text = self._store.commit_transcript_text
            if (
                self._store.committed
                or self._store.commit_pending
                or self._store.user_state == "speaking"
                or self._store.agent_state == "speaking"
                or not commit_text
                or self._store.commit_requested_text == commit_text
            ):
                return False
            if (
                self._store.agent_state == "thinking"
                and not self._store.started_during_agent_thinking
            ):
                return False
            turn_id = self._store.turn_id
            self._store.commit_pending = True
            self._store.commit_requested_text = commit_text
            self._store.commit_attempt_count += 1
            commit_attempt = self._store.commit_attempt_count
            if self._response_watchdog is not None:
                self._response_watchdog.arm(turn_id, commit_text)
            try:
                if self._store.agent_state == "thinking":
                    await self._session.interrupt(force=True)
                    logger.info(
                        "[MMI-TD] cancelled pending reply for new user turn "
                        "session=%s turn=%s",
                        self._store.session_id,
                        self._store.turn_id,
                    )
                explicit_user_input = (
                    commit_text != transcript_text
                    or self._store.started_during_agent_speaking
                )
                if explicit_user_input:
                    self._session.clear_user_turn()
                    self._session.generate_reply(user_input=commit_text)
                    logger.info(
                        "[MMI-TD] generated reply with explicit user input "
                        "session=%s turn=%s raw_len=%s commit_len=%s "
                        "started_during_agent_speaking=%s",
                        self._store.session_id,
                        self._store.turn_id,
                        len(transcript_text),
                        len(commit_text),
                        self._store.started_during_agent_speaking,
                    )
                else:
                    await self._session.commit_user_turn()
            except Exception:
                if self._response_watchdog is not None:
                    self._response_watchdog.cancel(turn_id, "commit_failed")
                if self._store.turn_id == turn_id:
                    self._store.commit_pending = False
                    self._store.commit_requested_text = ""
                raise
            if (
                self._store.turn_id != turn_id
                or not self._store.commit_pending
                or self._store.commit_attempt_count != commit_attempt
                or self._store.commit_requested_text != commit_text
            ):
                logger.info(
                    "[MMI-TD] user turn commit request superseded by new input "
                    "session=%s turn=%s",
                    self._store.session_id,
                    turn_id,
                )
                if self._response_watchdog is not None:
                    self._response_watchdog.cancel(turn_id, "commit_superseded")
                return False
            self._store.confirm_commit()
            self._store.started_during_agent_thinking = False
            logger.info(
                "[MMI-TD] committed user turn session=%s turn=%s reason=%s",
                self._store.session_id,
                self._store.turn_id,
                decision.reason,
            )
            return True

        if decision.action == MMITurnAction.START_LISTENING:
            if not self._interruptions_enabled():
                return False
            speech_id = self._store.agent_speech_id
            if self._store.interrupted_agent_speech_id == speech_id:
                return False
            self._store.interrupted_agent_speech_id = speech_id
            try:
                await self._session.interrupt(force=self._force_interruptions)
            except RuntimeError as exc:
                if self._store.interrupted_agent_speech_id == speech_id:
                    self._store.interrupted_agent_speech_id = None
                if "does not allow interruptions" in str(exc):
                    logger.info(
                        "[MMI-TD] current speech is uninterruptible session=%s speech=%s",
                        self._store.session_id,
                        speech_id,
                    )
                    return False
                raise
            except Exception:
                if self._store.interrupted_agent_speech_id == speech_id:
                    self._store.interrupted_agent_speech_id = None
                raise
            logger.info(
                "[MMI-TD] interrupted agent session=%s speech=%s reason=%s",
                self._store.session_id,
                speech_id,
                decision.reason,
            )
            return True

        return False

    async def cancel_pending_reply_for_wait(self) -> bool:
        if self._store.agent_state != "thinking":
            return False
        await self._session.interrupt(force=True)
        logger.info(
            "[MMI-TD] cancelled pending reply for wait intent session=%s turn=%s",
            self._store.session_id,
            self._store.turn_id,
        )
        return True

    async def cancel_pending_reply_for_user_continuation(self) -> bool:
        if self._store.agent_state != "thinking":
            return False
        await self._session.interrupt(force=True)
        logger.info(
            "[MMI-TD] cancelled pending reply for short-gap user continuation "
            "session=%s turn=%s gap_ms=%s",
            self._store.session_id,
            self._store.turn_id,
            self._store.turn_started_after_previous_speech_ms,
        )
        return True

    def _validate(self, decision: MMITurnDecision) -> None:
        if decision.turn_id != self._store.turn_id:
            raise StaleDecisionError("decision turn_id is stale")
        if decision.based_on_event_id != self._store.event_id:
            raise StaleDecisionError("decision event_id is stale")

    def _interruptions_enabled(self) -> bool:
        if self._force_interruptions:
            return True
        options = getattr(self._session, "options", None)
        interruption = getattr(options, "interruption", None)
        if isinstance(interruption, dict):
            return bool(interruption.get("enabled", True))
        return True

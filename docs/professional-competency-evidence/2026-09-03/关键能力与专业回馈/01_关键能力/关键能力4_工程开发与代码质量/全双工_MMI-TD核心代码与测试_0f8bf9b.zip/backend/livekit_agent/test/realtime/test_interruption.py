"""打断测试用例 (v2)

验证语音助手的打断（Barge-in）能力：
- 用户说话时 agent 应正确打断（纯 VAD 驱动）
- 非语音信号不应误触发打断
- 打断后轮次应正常恢复

指标拆分：vad_latency / interrupt_exec_latency / e2e_interrupt_latency / residual_audio
"""

import asyncio
import time
import pytest

from core.ws_test_client import RealtimeTestClient
from core.metrics import InterruptionResult, MetricsAggregator
from conftest import (
    load_interruption_cases,
    load_compound_interruption_cases,
    load_interruption_config,
    generate_audio,
)

# 正确的事件名（与 event_translator.py 一致）
AUDIO_DELTA_EVENT = "response.output_audio.delta"

interruption_cases = load_interruption_cases()
compound_cases = load_compound_interruption_cases()
interruption_config = load_interruption_config()


@pytest.mark.parametrize(
    "case",
    interruption_cases,
    ids=[c.name for c in interruption_cases],
)
async def test_interruption(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case,
    metrics_aggregator: MetricsAggregator,
):
    """打断测试：等待 agent 说话 -> 注入音频 -> 验证是否正确打断"""

    # 1. 连接并等待 agent 开场白 speaking
    await ws_client.connect(ws_url, auth_token)
    await ws_client.wait_for_agent_state("speaking", timeout=15)

    # 2. 等待收到足够的 audio.delta（确保 agent 确实在说话）
    min_deltas = case.inject_after_deltas
    deadline = time.monotonic() + 30
    while ws_client.count_events(AUDIO_DELTA_EVENT) < min_deltas:
        if time.monotonic() > deadline:
            pytest.fail(
                f"Timeout: only received {ws_client.count_events(AUDIO_DELTA_EVENT)} "
                f"audio.delta events, expected >= {min_deltas}"
            )
        await asyncio.sleep(0.05)

    # 3. 注入测试音频
    pcm = generate_audio(case.audio_type, case.audio_duration_s)
    t_inject_first, t_inject_last = await ws_client.inject_audio(pcm)

    # 4. 等待结果（最多 5 秒）
    await ws_client.drain_events(timeout=5.0)

    # 5. 判定打断是否发生
    #    标志 1: response.done 且 status=cancelled
    interrupted = ws_client.has_event_after(
        "response.done",
        t_inject_first,
        lambda e: e.get("response", {}).get("status") == "cancelled",
    )
    #    标志 2: agent 回到 listening 状态
    if not interrupted:
        last_state = ws_client.get_last_event("agent.state_changed")
        if last_state and last_state.timestamp > t_inject_first:
            interrupted = last_state.event.get("state") == "listening"

    # 6. 记录指标（三段时延 + 残留音频）
    result = InterruptionResult(
        case_name=case.name,
        expected_interrupt=case.expect_interrupt,
        actual_interrupted=interrupted,
        t_inject_first=t_inject_first,
        t_inject_last=t_inject_last,
        t_speech_started=ws_client.get_event_time_after(
            "input_audio_buffer.speech_started", t_inject_first
        ),
        t_last_audio_delta=ws_client.get_last_event_time(AUDIO_DELTA_EVENT),
        t_response_done=ws_client.get_event_time_after("response.done", t_inject_first),
    )
    metrics_aggregator.add_interruption(result)

    # 7. 断言
    assert result.correct, (
        f"{case.name}: expected_interrupt={case.expect_interrupt}, "
        f"actual={interrupted}, "
        f"vad_latency={result.vad_latency_ms}, "
        f"e2e_latency={result.e2e_interrupt_latency_ms}, "
        f"residual={result.residual_audio_ms}"
    )


# ========== 复合场景：打断后轮次恢复 ==========

@pytest.mark.parametrize(
    "case",
    compound_cases,
    ids=[c.name for c in compound_cases],
)
async def test_barge_in_then_recovery(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case,
    metrics_aggregator: MetricsAggregator,
):
    """打断后轮次恢复：打断 agent -> 注入静默 >2s -> agent 应恢复到 speaking"""

    # 1. 连接，等待 agent 开场白 speaking
    await ws_client.connect(ws_url, auth_token)
    await ws_client.wait_for_agent_state("speaking", timeout=15)

    # 2. 等待 agent 说到一半
    deadline = time.monotonic() + 30
    while ws_client.count_events(AUDIO_DELTA_EVENT) < case.inject_after_deltas:
        if time.monotonic() > deadline:
            pytest.fail("Timeout waiting for agent audio deltas")
        await asyncio.sleep(0.05)

    # 3. 注入打断语音
    pcm = generate_audio(case.barge_audio_type, case.barge_audio_duration_s)
    t_inject_first, t_inject_last = await ws_client.inject_audio(pcm)

    # 4. 验证打断成功
    try:
        await ws_client.wait_for_event(
            "response.done",
            timeout=5.0,
            predicate=lambda e: e.get("response", {}).get("status") == "cancelled",
        )
        interrupted = True
    except asyncio.TimeoutError:
        # 备选：检查 agent 是否回到 listening
        last_state = ws_client.get_last_event("agent.state_changed")
        interrupted = (
            last_state is not None
            and last_state.timestamp > t_inject_first
            and last_state.event.get("state") == "listening"
        )

    assert interrupted, f"{case.name}: 打断未成功，agent 没有停止说话"

    # 5. 注入静默（模拟用户说完），等待 agent 恢复
    ws_client.clear_events()
    await ws_client.inject_silence(case.post_silence_s)

    # 6. 验证 agent 恢复到 speaking（正常回复用户）
    try:
        recovery_event = await ws_client.wait_for_agent_state("speaking", timeout=15.0)
        recovered = True
    except asyncio.TimeoutError:
        recovered = False

    assert recovered == case.expect_recovery, (
        f"{case.name}: expect_recovery={case.expect_recovery}, "
        f"actual_recovered={recovered}. Agent 打断后未能恢复回复。"
    )

    # 7. 记录打断指标
    result = InterruptionResult(
        case_name=case.name,
        expected_interrupt=case.expect_interrupt,
        actual_interrupted=interrupted,
        t_inject_first=t_inject_first,
        t_inject_last=t_inject_last,
        t_speech_started=ws_client.get_event_time_after(
            "input_audio_buffer.speech_started", t_inject_first
        ),
    )
    metrics_aggregator.add_interruption(result)

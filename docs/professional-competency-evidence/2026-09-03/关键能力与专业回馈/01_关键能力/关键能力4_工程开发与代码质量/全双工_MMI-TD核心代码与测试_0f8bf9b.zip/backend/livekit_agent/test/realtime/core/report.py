"""测试报告生成 (v2)

输出 JSON 报告文件和终端表格，汇总打断/轮次检测的测试结果。
适配 v2 指标：三段打断时延 + 残留音频 + 超额端点时延。
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict

from .metrics import MetricsAggregator


def _fmt_ms(value: Optional[float]) -> str:
    if value is None:
        return "N/A"
    return f"{value:.1f}ms"


def _fmt_pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def _fmt_percentiles(p: dict[str, Optional[float]]) -> str:
    parts = []
    for key in ("p50", "p90", "p95", "p99", "max"):
        if key in p:
            parts.append(f"{key}={_fmt_ms(p[key])}")
    return " ".join(parts)


def print_terminal_report(aggregator: MetricsAggregator) -> None:
    """输出终端表格报告"""
    try:
        from tabulate import tabulate
    except ImportError:
        _print_simple_report(aggregator)
        return

    # ========== 打断测试结果 ==========
    if aggregator.interruption_results:
        print("\n" + "=" * 80)
        print("  打断测试结果 (Interruption Test Results)")
        print("=" * 80)

        rows = []
        for r in aggregator.interruption_results:
            rows.append([
                r.case_name,
                "Yes" if r.expected_interrupt else "No",
                "Yes" if r.actual_interrupted else "No",
                "PASS" if r.correct else "FAIL",
                _fmt_ms(r.vad_latency_ms),
                _fmt_ms(r.e2e_interrupt_latency_ms),
                _fmt_ms(r.residual_audio_ms),
            ])

        print(tabulate(
            rows,
            headers=["Case", "Expected", "Actual", "Result",
                     "VAD Lat.", "E2E Lat.", "Residual"],
            tablefmt="grid",
        ))

        print(f"\n  准确率: {_fmt_pct(aggregator.interruption_accuracy())}")
        print(f"  误打断率: {_fmt_pct(aggregator.false_barge_in_rate())}")
        print(f"  端到端打断时延: {_fmt_percentiles(aggregator.e2e_interrupt_latency_percentiles())}")
        print(f"  VAD 检测时延:   {_fmt_percentiles(aggregator.vad_latency_percentiles())}")
        print(f"  打断执行时延:   {_fmt_percentiles(aggregator.interrupt_exec_latency_percentiles())}")
        print(f"  残留音频量:     {_fmt_percentiles(aggregator.residual_audio_percentiles())}")

    # ========== 轮次检测结果 ==========
    if aggregator.turn_detection_results:
        print("\n" + "=" * 80)
        print("  轮次检测结果 (Turn Detection Test Results)")
        print("=" * 80)

        rows = []
        for r in aggregator.turn_detection_results:
            rows.append([
                r.case_name,
                f"{r.silence_duration_s:.1f}s",
                "Yes" if r.expected_turn_switch else "No",
                "Yes" if r.actual_turn_switched else "No",
                "PASS" if r.correct else "FAIL",
                _fmt_ms(r.endpointing_excess_ms),
                _fmt_ms(r.time_to_first_audio_ms),
            ])

        print(tabulate(
            rows,
            headers=["Case", "Silence", "Expected", "Actual", "Result",
                     "EP Excess", "TTFB"],
            tablefmt="grid",
        ))

        print(f"\n  端点准确率: {_fmt_pct(aggregator.endpointing_accuracy())}")
        print(f"  误切轮率: {_fmt_pct(aggregator.false_endpointing_rate())}")
        print(f"  漏切轮率: {_fmt_pct(aggregator.missed_turn_rate())}")
        print(f"  超额端点时延: {_fmt_percentiles(aggregator.endpointing_excess_percentiles())}")
        print(f"  TTFB:         {_fmt_percentiles(aggregator.ttfb_percentiles())}")

    print()


def _print_simple_report(aggregator: MetricsAggregator) -> None:
    """tabulate 不可用时的简单文本输出"""
    summary = aggregator.summary()
    si = summary["interruption"]
    st = summary["turn_detection"]

    print("\n--- Interruption ---")
    print(f"  Total: {si['total']}")
    print(f"  Accuracy: {_fmt_pct(si['accuracy'])}")
    print(f"  False barge-in rate: {_fmt_pct(si['false_barge_in_rate'])}")
    print(f"  E2E latency: {_fmt_percentiles(si['e2e_latency'])}")
    print(f"  Residual audio: {_fmt_percentiles(si['residual_audio'])}")

    print("\n--- Turn Detection ---")
    print(f"  Total: {st['total']}")
    print(f"  Accuracy: {_fmt_pct(st['accuracy'])}")
    print(f"  False EP rate: {_fmt_pct(st['false_endpointing_rate'])}")
    print(f"  Missed turn rate: {_fmt_pct(st['missed_turn_rate'])}")
    print(f"  EP excess: {_fmt_percentiles(st['endpointing_excess'])}")


def save_json_report(
    aggregator: MetricsAggregator,
    output_dir: str = "test_reports",
    agent_mode: str = "unknown",
) -> str:
    """保存 JSON 报告"""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{output_dir}/realtime_test_{agent_mode}_{timestamp}.json"

    report = {
        "timestamp": datetime.now().isoformat(),
        "agent_mode": agent_mode,
        "summary": aggregator.summary(),
        "interruption_details": [
            {
                "case_name": r.case_name,
                "expected_interrupt": r.expected_interrupt,
                "actual_interrupted": r.actual_interrupted,
                "correct": r.correct,
                "vad_latency_ms": r.vad_latency_ms,
                "interrupt_exec_latency_ms": r.interrupt_exec_latency_ms,
                "e2e_interrupt_latency_ms": r.e2e_interrupt_latency_ms,
                "residual_audio_ms": r.residual_audio_ms,
            }
            for r in aggregator.interruption_results
        ],
        "turn_detection_details": [
            {
                "case_name": r.case_name,
                "silence_duration_s": r.silence_duration_s,
                "expected_turn_switch": r.expected_turn_switch,
                "actual_turn_switched": r.actual_turn_switched,
                "correct": r.correct,
                "mid_pause_switched": r.mid_pause_switched,
                "endpointing_excess_ms": r.endpointing_excess_ms,
                "time_to_first_audio_ms": r.time_to_first_audio_ms,
            }
            for r in aggregator.turn_detection_results
        ],
    }

    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"[Report] Saved to {filename}")
    return filename

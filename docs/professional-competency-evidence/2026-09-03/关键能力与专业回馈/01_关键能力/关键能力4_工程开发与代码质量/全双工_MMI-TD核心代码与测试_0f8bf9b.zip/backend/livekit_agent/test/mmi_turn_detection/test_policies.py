from __future__ import annotations

from dataclasses import replace

import pytest

from mmi_turn_detection.detector import RuleBasedMMITurnDetector
from mmi_turn_detection.endpointing_policy import (
    BaselineEndpointingPolicy,
    EndpointingPolicyConfig,
)
from mmi_turn_detection.interruption_policy import (
    InterruptionPolicyConfig,
    RuleBasedInterruptionPolicy,
)
from mmi_turn_detection.models import MMITurnAction, MMITurnContext


@pytest.fixture
def detector() -> RuleBasedMMITurnDetector:
    return RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(min_delay_ms=500, max_delay_ms=3000)
        ),
    )


def context(**overrides) -> MMITurnContext:
    base = MMITurnContext(session_id="test", turn_id=1, event_id=1)
    return replace(base, **overrides)


@pytest.mark.asyncio
async def test_strong_interrupt_stops_agent(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            vad_speech=True,
            speech_ms=200,
            partial_text="等一下",
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"
    assert decision.pattern_version
    assert decision.matched_rule == "strong_interrupt.exact"
    assert decision.matched_pattern == "等一下"


@pytest.mark.asyncio
async def test_english_strong_interrupt_stops_agent(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            vad_speech=True,
            speech_ms=200,
            partial_text="wait, that's wrong",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"
    assert decision.matched_rule == "strong_interrupt.prefixes"
    assert decision.matched_pattern == "wait"


@pytest.mark.asyncio
async def test_repeated_stop_word_is_strong_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            vad_speech=True,
            speech_ms=500,
            partial_text="别别别！这么活得太苦",
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


@pytest.mark.asyncio
async def test_repeated_no_word_is_strong_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=200,
            partial_text="不不不不。",
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


@pytest.mark.asyncio
async def test_stt_only_strong_interrupt_uses_transcript_observation(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            speech_ms=0,
            transcript_observe_ms=200,
            partial_text="等一下",
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


@pytest.mark.asyncio
async def test_strong_interrupt_during_agent_thinking_starts_listening(detector):
    decision = await detector.detect(
        context(
            agent_state="thinking",
            user_state="listening",
            transcript_observe_ms=300,
            final_text="好了好了，别说了。",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


@pytest.mark.asyncio
async def test_embedded_stop_phrase_interrupts_agent(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            vad_speech=True,
            speech_ms=300,
            partial_text="好了好了，别说了。",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


@pytest.mark.asyncio
async def test_negative_medical_phrase_is_not_strong_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            vad_speech=True,
            speech_ms=200,
            partial_text="不要停止服药",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING


@pytest.mark.asyncio
async def test_backchannel_continues_agent(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=700,
            partial_text="嗯嗯",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING


@pytest.mark.asyncio
async def test_mixed_language_backchannel_continues_agent(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=700,
            partial_text="嗯嗯 okay",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "backchannel"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_common_qwen_thai_backchannel_continues_agent(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=500,
            final_text="อื้อ",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "backchannel"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_repeated_backchannel_continues_agent(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=700,
            partial_text="好的，好的。",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "backchannel"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_stt_only_backchannel_never_becomes_ordinary_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            speech_ms=0,
            transcript_observe_ms=1000,
            final_text="好的，好的。",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "backchannel"


@pytest.mark.asyncio
async def test_stt_only_ordinary_interruption_uses_transcript_observation(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            speech_ms=0,
            transcript_observe_ms=650,
            partial_text="我想换一本",
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_locked_gate_unknown_speaker_blocks_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            partial_text="我想换一本",
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "target_speaker_pending"
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_strict_target_speaker_blocks_unknown_interrupt():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(
            InterruptionPolicyConfig(require_target_speaker=True)
        ),
        endpointing_policy=BaselineEndpointingPolicy(EndpointingPolicyConfig()),
    )

    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            partial_text="我想换一本",
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "target_speaker_pending"
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_strict_target_speaker_allows_confident_interrupt():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(
            InterruptionPolicyConfig(require_target_speaker=True)
        ),
        endpointing_policy=BaselineEndpointingPolicy(EndpointingPolicyConfig()),
    )

    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            partial_text="我想换一本",
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.58,
            external_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_strict_target_speaker_blocks_stale_latch_interrupt():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(
            InterruptionPolicyConfig(
                require_target_speaker=True,
                target_latch_max_ms=3000,
            )
        ),
        endpointing_policy=BaselineEndpointingPolicy(EndpointingPolicyConfig()),
    )

    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            partial_text="我想换一本",
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            turn_speaker_is_target=True,
            turn_speaker_state="TARGET_CONFIDENT",
            turn_speaker_similarity=0.52,
            turn_speaker_verdict_kind="decide",
            turn_speaker_age_ms=4200,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "target_speaker_pending"


@pytest.mark.asyncio
async def test_full_target_verdict_allows_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            partial_text="我想换一本",
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_similarity=0.58,
            external_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_locked_gate_low_similarity_target_verdict_blocks_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            partial_text="我想换一本",
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.39,
            external_speaker_verdict_kind="bargein",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "target_speaker_pending"


@pytest.mark.asyncio
async def test_locked_gate_high_similarity_short_final_allows_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            vad_speech=False,
            speech_ms=0,
            transcript_observe_ms=350,
            final_text="爱情吧。",
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.51,
            external_speaker_verdict_kind="bargein",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "stt_only_final_interjection"


@pytest.mark.asyncio
async def test_locked_gate_similarity_rounding_margin_allows_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=900,
            partial_text="Can we talk about something else?",
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.449,
            external_speaker_verdict_kind="enroll",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


@pytest.mark.asyncio
async def test_turn_target_latch_allows_interrupt_after_verdict_ttl(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            partial_text="我想换一本",
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            turn_speaker_is_target=True,
            turn_speaker_similarity=0.46,
            turn_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_warmup_gate_does_not_block_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=1200,
            partial_text="等一下我想问",
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"


@pytest.mark.asyncio
async def test_strict_warmup_gate_holds_ordinary_interrupt_for_enrollment():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(
            InterruptionPolicyConfig(require_target_speaker=True)
        ),
        endpointing_policy=BaselineEndpointingPolicy(EndpointingPolicyConfig()),
    )
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=1200,
            partial_text="By the way, I got a new pet",
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "speaker_gate_warmup"


@pytest.mark.asyncio
async def test_explicit_other_addressee_is_suppressed_even_for_target_speaker(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=1800,
            partial_text="Laura, lights flickered again—storm maybe?",
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.60,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "addressed_to_other"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_explicit_other_addressee_is_suppressed_while_thinking(detector):
    decision = await detector.detect(
        context(
            agent_state="thinking",
            user_state="speaking",
            speech_ms=1200,
            partial_text="Lawrence, Wi-Fi is acting up again. Any ideas?",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "addressed_to_other"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_explicit_other_addressee_is_suppressed_during_endpointing(detector):
    decision = await detector.detect(
        context(
            agent_state="listening",
            user_state="listening",
            silence_ms=500,
            final_text="Lawrence, Wi-Fi is acting up again. Any ideas?",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.reason == "addressed_to_other"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_rewritten_interim_vocative_remains_suppressed(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=1800,
            partial_text="It is. Can you reset my password, please?",
            transcript_hypotheses=(
                "Edes, can you?",
                "It is. Can you reset my password?",
                "It is. Can you reset my password, please?",
            ),
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.60,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "addressed_to_other"
    assert decision.matched_rule == "addressee.hypothesis_rewrite"


@pytest.mark.asyncio
async def test_final_transcript_clears_rewritten_interim_vocative(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=1800,
            final_text="And really, I need advice on time management.",
            transcript_hypotheses=(
                "Enderly, I need advice on time management.",
                "And really, I need advice on time management.",
            ),
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.60,
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_unrelated_interim_vocative_is_not_latched(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=1800,
            partial_text="I need to change topics now.",
            transcript_hypotheses=(
                "Laura, can you help?",
                "I need to change topics now.",
            ),
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.60,
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "ordinary_valid_interjection"


@pytest.mark.asyncio
async def test_explicit_topic_redirect_bypasses_speaker_gate_warmup(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=300,
            partial_text="Can we talk about laptops instead?",
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"
    assert decision.matched_pattern == "can we talk about"


@pytest.mark.asyncio
async def test_enrollment_verdict_waits_for_final_transcript_on_warmup_turn(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="speaking",
            speech_ms=1800,
            transcript_observe_ms=1400,
            partial_text="The lights flickered again",
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.60,
            external_speaker_verdict_kind="enroll",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "speaker_enrollment_partial"
    assert decision.observe_more_ms == 400


@pytest.mark.asyncio
async def test_backchannel_during_agent_thinking_preserves_pending_reply(detector):
    decision = await detector.detect(
        context(
            agent_state="thinking",
            user_state="listening",
            transcript_observe_ms=300,
            final_text="uh-huh sure",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "backchannel"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_ordinary_question_during_agent_thinking_uses_endpointing(detector):
    decision = await detector.detect(
        context(
            agent_state="thinking",
            user_state="listening",
            silence_ms=500,
            final_text="How do I make a smoothie?",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.reason == "min_endpointing_delay_reached"
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_latched_thinking_turn_uses_endpointing_after_agent_stops():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(
            InterruptionPolicyConfig(require_target_speaker=True)
        ),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(require_target_speaker=True)
        ),
    )
    decision = await detector.detect(
        context(
            agent_state="listening",
            user_state="listening",
            vad_speech=False,
            transcript_observe_ms=1200,
            silence_ms=1200,
            final_text="I cannot log into my account.",
            started_during_agent_thinking=True,
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_latched_thinking_turn_commits_after_agent_stops(detector):
    decision = await detector.detect(
        context(
            agent_state="listening",
            user_state="listening",
            vad_speech=False,
            transcript_observe_ms=900,
            silence_ms=500,
            final_text="Can we talk about something else?",
            started_during_agent_thinking=True,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.55,
            external_speaker_verdict_kind="enroll",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_locked_gate_unknown_speaker_allows_explicit_strong_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            final_text="Hold on, how do I make a smoothie?",
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_locked_gate_decisive_non_target_blocks_explicit_strong_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            final_text="Hold on, how do I make a smoothie?",
            external_speaker_gate_locked=True,
            external_speaker_is_target=False,
            external_speaker_state="NON_TARGET",
            external_speaker_similarity=0.12,
            external_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "non_target_speaker_suppressed"
    assert decision.ignore_input is True


@pytest.mark.asyncio
async def test_bargein_probe_does_not_override_target_latch_during_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            final_text="Hold on, how do I make a smoothie?",
            external_speaker_gate_locked=True,
            external_speaker_is_target=False,
            external_speaker_state="NON_TARGET",
            external_speaker_similarity=0.12,
            external_speaker_verdict_kind="bargein",
            turn_speaker_is_target=True,
            turn_speaker_state="TARGET_CONFIDENT",
            turn_speaker_similarity=0.77,
            turn_speaker_verdict_kind="decide",
            turn_speaker_age_ms=0,
        )
    )

    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "strong_interrupt_intent"
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_stt_only_final_short_answer_interrupts_after_short_observation(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            vad_speech=False,
            speech_ms=0,
            transcript_observe_ms=304,
            final_text="清朝。",
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "stt_only_final_interjection"


@pytest.mark.asyncio
async def test_stt_only_final_short_answer_waits_for_minimum_observation(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            vad_speech=False,
            speech_ms=0,
            transcript_observe_ms=100,
            final_text="清朝。",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.observe_more_ms == 150


@pytest.mark.asyncio
async def test_stt_only_final_backchannel_is_not_short_answer_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            vad_speech=False,
            speech_ms=0,
            transcript_observe_ms=500,
            final_text="嗯。",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.reason == "backchannel"


@pytest.mark.asyncio
async def test_instant_stt_only_partial_does_not_interrupt(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            speech_ms=0,
            transcript_observe_ms=20,
            partial_text="我想换一本",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.observe_more_ms == 400


@pytest.mark.asyncio
async def test_stt_only_strong_interrupt_observes_only_until_strong_threshold(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            speech_ms=0,
            transcript_observe_ms=20,
            partial_text="等一下",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.observe_more_ms == 130


@pytest.mark.asyncio
async def test_confirmation_overrides_backchannel(detector):
    decision = await detector.detect(
        context(
            agent_state="speaking",
            tts_playing=True,
            awaiting_confirmation=True,
            user_state="speaking",
            speech_ms=300,
            partial_text="对",
        )
    )
    assert decision.action == MMITurnAction.START_LISTENING
    assert decision.reason == "confirmation_response"


@pytest.mark.asyncio
async def test_wait_intent_holds_user_turn(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=4000,
            final_text="等一下，我想想",
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.wait_intent is True


@pytest.mark.asyncio
async def test_english_wait_intent_holds_user_turn(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=4000,
            final_text="hold on, let me think",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.wait_intent is True
    assert decision.matched_rule == "wait_expression"


@pytest.mark.asyncio
async def test_wait_prefix_with_substantive_request_commits_user_turn(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text=(
                "Wait. Can you help me with something else? "
                "I need recipe ideas for a birthday cake."
            ),
            latest_transcript_text=(
                "Wait. Can you help me with something else? "
                "I need recipe ideas for a birthday cake."
            ),
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.wait_intent is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_active_wait_intent_releases_for_same_turn_substantive_request(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="Hold on. How do I make a smoothie?",
            latest_transcript_text="Hold on. How do I make a smoothie?",
            wait_intent_active=True,
            wait_intent_consumed_text="hold on",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.wait_intent is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_previous_wait_expression_does_not_block_latest_question(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="等一下，等一下 海瑞是谁演的",
            latest_transcript_text="海瑞是谁演的",
            wait_intent_consumed_text="等一下",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.wait_intent is False


@pytest.mark.asyncio
async def test_consumed_wait_expression_does_not_reenter_wait_after_timeout(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=3000,
            final_text="等一下。",
            latest_transcript_text="等一下。",
            wait_intent_consumed_text="等一下",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.wait_intent is False


@pytest.mark.asyncio
async def test_eou_unlikely_uses_max_delay(detector):
    before_max = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1000,
            final_text="我想问",
            eou_prob=0.1,
            eou_unlikely_threshold=0.5,
        )
    )
    at_max = await detector.detect(
        context(
            user_state="listening",
            silence_ms=3000,
            final_text="我想问",
            eou_prob=0.1,
            eou_unlikely_threshold=0.5,
        )
    )
    assert before_max.action == MMITurnAction.CONTINUE_LISTENING
    assert at_max.action == MMITurnAction.START_SPEAKING


@pytest.mark.asyncio
async def test_low_model_threshold_uses_uncertain_delay_for_marginal_eou(detector):
    before_uncertain = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="I was thinking that",
            eou_prob=0.14,
            eou_unlikely_threshold=0.0066,
        )
    )
    at_uncertain = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="I was thinking that",
            eou_prob=0.14,
            eou_unlikely_threshold=0.0066,
        )
    )

    assert before_uncertain.action == MMITurnAction.CONTINUE_LISTENING
    assert before_uncertain.observe_more_ms == 1000
    assert at_uncertain.action == MMITurnAction.START_SPEAKING
    assert at_uncertain.reason == "uncertain_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_eou_below_model_threshold_still_uses_max_delay(detector):
    before_max = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="I was thinking that",
            eou_prob=0.001,
            eou_unlikely_threshold=0.0066,
        )
    )

    assert before_max.action == MMITurnAction.CONTINUE_LISTENING
    assert before_max.observe_more_ms == 1500


@pytest.mark.asyncio
async def test_speaker_enrollment_pending_uses_max_delay(detector):
    pending = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="Everybody in it.",
            eou_prob=0.13,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=False,
        )
    )
    locked = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="So what do you think time is looking like?",
            eou_prob=0.18,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
        )
    )

    assert pending.action == MMITurnAction.CONTINUE_LISTENING
    assert pending.observe_more_ms == 1500
    assert locked.action == MMITurnAction.START_SPEAKING
    assert locked.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_explicit_final_question_uses_min_delay_with_marginal_eou(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="So what do you think time is looking like?",
            eou_prob=0.16,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_explicit_question_bypasses_speaker_enrollment(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="Are you still there?",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_confident_eou_bypasses_speaker_enrollment(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="Add almond milk to my grocery list.",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_complete_statement_uses_configured_delay():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                complete_statement_delay_ms=1000,
                max_delay_ms=3000,
            )
        ),
    )
    before_delay = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="There are a lot of stations around here.",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
        )
    )
    at_delay = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1000,
            final_text="There are a lot of stations around here.",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
        )
    )

    assert before_delay.action == MMITurnAction.CONTINUE_LISTENING
    assert before_delay.observe_more_ms == 500
    assert at_delay.action == MMITurnAction.START_SPEAKING


@pytest.mark.asyncio
async def test_marginal_eou_does_not_bypass_speaker_enrollment(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="Everybody in it.",
            eou_prob=0.13,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.observe_more_ms == 1500


@pytest.mark.asyncio
async def test_final_declarative_fragment_keeps_uncertain_delay(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="Everybody in it.",
            eou_prob=0.13,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.observe_more_ms == 1000


@pytest.mark.asyncio
async def test_complete_text_uses_min_delay(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="今天天气怎么样",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )
    assert decision.action == MMITurnAction.START_SPEAKING


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "text",
    [
        "那海瑞是谁演的？",
        "严嵩是谁演的?",
    ],
)
async def test_complete_question_overrides_incomplete_suffix(detector, text):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text=text,
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )
    assert decision.action == MMITurnAction.START_SPEAKING


@pytest.mark.asyncio
async def test_positive_eou_overrides_incomplete_suffix(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="古装历史的。",
            eou_prob=0.2,
            eou_unlikely_threshold=0.0066,
        )
    )
    assert decision.action == MMITurnAction.START_SPEAKING


@pytest.mark.asyncio
async def test_marginal_eou_does_not_override_incomplete_suffix(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1200,
            final_text="我想看。我推荐的是。",
            eou_prob=0.0138,
            eou_unlikely_threshold=0.0066,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.reason == "text_looks_incomplete"
    assert decision.observe_more_ms == 1800


@pytest.mark.asyncio
async def test_repeated_backchannel_is_not_treated_as_incomplete(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=500,
            final_text="好的，好的。",
            eou_prob=0.9,
            eou_unlikely_threshold=0.5,
        )
    )
    assert decision.action == MMITurnAction.START_SPEAKING


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("final_text", "reason"),
    [
        ("", "empty_turn_timeout"),
        ("哎，嗯。", "invalid_or_noise_turn_timeout"),
    ],
)
async def test_empty_or_noise_turn_is_ignored_at_max_delay(
    detector,
    final_text,
    reason,
):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=3000,
            final_text=final_text,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == reason


@pytest.mark.asyncio
async def test_non_target_speaker_turn_is_ignored_before_endpoint_commit(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="六三幺二。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_is_target=False,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "non_target_speaker_ignored"


@pytest.mark.asyncio
async def test_borderline_non_target_speaker_can_commit_at_endpoint(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="杭州，杭州的天气。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_is_target=False,
            external_speaker_similarity=0.336,
            external_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_configured_non_target_threshold_ignores_borderline_endpoint_turn():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                speaker_non_target_sim_max=0.35,
            )
        ),
    )
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="旁边的人在说话。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_is_target=False,
            external_speaker_state="NON_TARGET",
            external_speaker_similarity=0.24,
            external_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "non_target_speaker_ignored"


@pytest.mark.asyncio
async def test_decisive_non_target_speaker_is_ignored_at_endpoint(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="旁边的人在说话。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_is_target=False,
            external_speaker_similarity=0.12,
            external_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "non_target_speaker_ignored"


@pytest.mark.asyncio
async def test_current_decisive_non_target_overrides_turn_target_latch(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="有没有天气？ 背景人在继续说。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_is_target=False,
            external_speaker_similarity=0.10,
            external_speaker_verdict_kind="decide",
            turn_speaker_is_target=True,
            turn_speaker_similarity=0.77,
            turn_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "non_target_speaker_ignored"


@pytest.mark.asyncio
async def test_bargein_probe_does_not_override_target_latch_at_endpoint(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="Hopefully, everything will improve.",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_is_target=False,
            external_speaker_state="NON_TARGET",
            external_speaker_similarity=0.10,
            external_speaker_verdict_kind="bargein",
            turn_speaker_is_target=True,
            turn_speaker_state="TARGET_CONFIDENT",
            turn_speaker_similarity=0.77,
            turn_speaker_verdict_kind="decide",
            turn_speaker_age_ms=0,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_speaker_gate_warmup_turn_can_commit_when_agent_is_listening(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="你好你好呀。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_turn_started_during_warmup_can_commit_when_agent_is_listening(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="你好你好呀。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            started_before_speaker_gate_locked=True,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_turn_that_locks_speaker_gate_can_commit_before_verdict_arrives(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="帮我查一下明天的天气。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            started_before_speaker_gate_locked=True,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_locked_speaker_gate_can_commit_semantic_too_short_segment(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="为什么？",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            external_speaker_state="TARGET_WEAK",
            external_speaker_verdict_kind="too_short",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_too_short_turn_latch_survives_next_segment_reset(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="算了，不查了。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            external_speaker_state=None,
            external_speaker_verdict_kind=None,
            turn_speaker_is_target=False,
            turn_speaker_state="TARGET_WEAK",
            turn_speaker_verdict_kind="too_short",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_speaker_inference_unavailable_fails_open(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="算了，不查了。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            external_speaker_state="TARGET_WEAK",
            external_speaker_verdict_kind="unavailable",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_unconfirmed_agent_speech_turn_can_endpoint_commit(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="好好好拜拜。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            started_during_agent_speaking=True,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_strict_target_speaker_endpoint_waits_for_unknown_verdict():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
            )
        ),
    )

    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1000,
            final_text="可以。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is False
    assert decision.reason == "target_speaker_pending"
    assert decision.observe_more_ms == 2000


@pytest.mark.asyncio
async def test_strict_target_speaker_endpoint_ignores_unconfirmed_after_max_delay():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
            )
        ),
    )

    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=3000,
            final_text="可以。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "target_speaker_not_confirmed"


@pytest.mark.asyncio
async def test_strict_target_speaker_endpoint_allows_confident_target():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
            )
        ),
    )

    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="可以。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_unresolved_overlapping_followup_is_not_failed_open():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
            )
        ),
    )

    decision = await detector.detect(
        context(
            turn_id=1,
            user_state="listening",
            silence_ms=3000,
            final_text="Who used up all the hot water?",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            started_during_agent_thinking=True,
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "target_speaker_not_confirmed"


@pytest.mark.asyncio
async def test_unresolved_idle_followup_keeps_existing_fail_open_behavior():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
            )
        ),
    )

    decision = await detector.detect(
        context(
            turn_id=1,
            user_state="listening",
            silence_ms=500,
            final_text="Can you help me with another task?",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
            started_before_speaker_gate_locked=True,
            external_speaker_gate_locked=False,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_strict_overlap_intent_guard_suppresses_ordinary_followup():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_explicit_intent_for_overlapping_followup=True,
            )
        ),
    )

    decision = await detector.detect(
        context(
            turn_id=1,
            user_state="listening",
            silence_ms=500,
            final_text="My phone battery is almost dead.",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
            started_during_agent_thinking=True,
            turn_started_after_previous_speech_ms=2500,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "overlap_without_interrupt_intent"


@pytest.mark.asyncio
async def test_strict_overlap_intent_guard_allows_explicit_interrupt():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_explicit_intent_for_overlapping_followup=True,
            )
        ),
    )

    decision = await detector.detect(
        context(
            turn_id=1,
            user_state="listening",
            silence_ms=500,
            final_text="Actually, can we talk about something else?",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
            started_during_agent_thinking=True,
            turn_started_after_previous_speech_ms=2500,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_strict_overlap_intent_guard_allows_short_pause_continuation():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_explicit_intent_for_overlapping_followup=True,
                overlapping_followup_min_gap_ms=2000,
            )
        ),
    )

    decision = await detector.detect(
        context(
            turn_id=1,
            user_state="listening",
            silence_ms=500,
            final_text="So I am going to interview her tomorrow.",
            eou_prob=0.9,
            eou_unlikely_threshold=0.0066,
            started_during_agent_thinking=True,
            turn_started_after_previous_speech_ms=400,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False


@pytest.mark.asyncio
async def test_strict_overlap_intent_guard_suppresses_final_while_speaking():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(
            InterruptionPolicyConfig(
                require_explicit_intent_for_overlapping_followup=True
            )
        ),
        endpointing_policy=BaselineEndpointingPolicy(EndpointingPolicyConfig()),
    )

    decision = await detector.detect(
        context(
            turn_id=1,
            agent_state="speaking",
            tts_playing=True,
            user_state="listening",
            transcript_observe_ms=1200,
            final_text="My phone battery is almost dead.",
            started_during_agent_speaking=True,
            turn_started_after_previous_speech_ms=2500,
            external_speaker_gate_locked=True,
            external_speaker_is_target=True,
            external_speaker_state="TARGET_CONFIDENT",
            external_speaker_similarity=0.60,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_SPEAKING
    assert decision.ignore_input is True
    assert decision.reason == "overlap_without_interrupt_intent"


@pytest.mark.asyncio
async def test_strict_target_speaker_endpoint_rejects_stale_target_latch():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
                target_latch_max_ms=3000,
            )
        ),
    )

    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=3000,
            final_text="这句话被拼进来了。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            turn_speaker_is_target=True,
            turn_speaker_state="TARGET_CONFIDENT",
            turn_speaker_similarity=0.52,
            turn_speaker_verdict_kind="decide",
            turn_speaker_age_ms=4200,
        )
    )

    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.ignore_input is True
    assert decision.reason == "target_speaker_not_confirmed"


@pytest.mark.asyncio
async def test_strict_target_speaker_endpoint_allows_fresh_target_latch():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
                target_latch_max_ms=3000,
            )
        ),
    )

    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="这是同一轮的正常收尾。",
            eou_prob=0.8,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            turn_speaker_is_target=True,
            turn_speaker_state="TARGET_CONFIDENT",
            turn_speaker_similarity=0.52,
            turn_speaker_verdict_kind="decide",
            turn_speaker_age_ms=1500,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_endpoint_target_latch_can_cover_long_same_turn():
    detector = RuleBasedMMITurnDetector(
        interruption_policy=RuleBasedInterruptionPolicy(InterruptionPolicyConfig()),
        endpointing_policy=BaselineEndpointingPolicy(
            EndpointingPolicyConfig(
                min_delay_ms=500,
                max_delay_ms=3000,
                require_target_speaker=True,
                target_latch_max_ms=15000,
            )
        ),
    )

    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=3000,
            final_text="This is a longer utterance from the confirmed target speaker.",
            eou_prob=0.02,
            eou_unlikely_threshold=0.0066,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            turn_speaker_is_target=True,
            turn_speaker_state="TARGET_CONFIDENT",
            turn_speaker_similarity=0.52,
            turn_speaker_verdict_kind="decide",
            turn_speaker_age_ms=6800,
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "uncertain_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_turn_target_latch_allows_agent_speech_turn_endpoint(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1500,
            final_text="我想看那个古装剧，包括古装的历史。",
            eou_prob=0.2,
            eou_unlikely_threshold=0.0066,
            started_during_agent_speaking=True,
            external_speaker_gate_locked=True,
            external_speaker_is_target=None,
            turn_speaker_is_target=True,
            turn_speaker_similarity=0.408,
            turn_speaker_verdict_kind="decide",
        )
    )

    assert decision.action == MMITurnAction.START_SPEAKING
    assert decision.ignore_input is False
    assert decision.reason == "min_endpointing_delay_reached"


@pytest.mark.asyncio
async def test_partial_only_without_reliable_eou_waits_for_max_delay(detector):
    decision = await detector.detect(
        context(
            user_state="listening",
            silence_ms=1000,
            partial_text="我想咨询一下因为",
            eou_prob=0.07,
            eou_unlikely_threshold=None,
        )
    )
    assert decision.action == MMITurnAction.CONTINUE_LISTENING
    assert decision.observe_more_ms == 2000

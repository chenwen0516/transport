"""评估脚本"""

from .evaluate import run_evaluation

__all__ = ["run_evaluation"]

"""生成 Full-Duplex-Bench 测试音频

使用 AudioGenerator 生成 5 个测试音频文件，用于评估。

用法:
    python generate_test_audio.py
"""

import json
import os
import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent / "realtime"))
from core.audio_generator import AudioGenerator

# 测试用例配置
TEST_CASES = [
    {
        "name": "case_001",
        "ai_speech_duration": 3.0,   # AI 说话时长
        "user_speech_duration": 1.5,  # 用户打断时长
        "interrupt_start": 1.0,       # 打断开始时间（AI 说话后多久）
        "expect_interrupt": True,
        "description": "AI 说完一句话前被打断",
    },
    {
        "name": "case_002",
        "ai_speech_duration": 4.0,
        "user_speech_duration": 2.0,
        "interrupt_start": 1.5,
        "expect_interrupt": True,
        "description": "AI 说话中途被打断",
    },
    {
        "name": "case_003",
        "ai_speech_duration": 3.5,
        "user_speech_duration": 1.0,
        "interrupt_start": 2.0,
        "expect_interrupt": True,
        "description": "AI 说话后期打断",
    },
    {
        "name": "case_004",
        "ai_speech_duration": 5.0,
        "user_speech_duration": 2.5,
        "interrupt_start": 2.5,
        "expect_interrupt": True,
        "description": "AI 长回复中途打断",
    },
    {
        "name": "case_005",
        "ai_speech_duration": 4.5,
        "user_speech_duration": 1.8,
        "interrupt_start": 1.8,
        "expect_interrupt": True,
        "description": "AI 说话早期快速打断",
    },
]


def main():
    # 输出目录
    output_dir = Path(__file__).parent / "dataset" / "user_interruption"
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("Full-Duplex-Bench 测试音频生成")
    print("=" * 60)
    print(f"输出目录: {output_dir}")
    print("-" * 60)

    audio_gen = AudioGenerator()

    for case in TEST_CASES:
        case_dir = output_dir / case["name"]
        case_dir.mkdir(exist_ok=True)

        print(f"\n生成 {case['name']}: {case['description']}")

        # 生成 AI 响应音频（类语音信号）
        ai_audio = audio_gen.speech_like(case["ai_speech_duration"])
        print(f"  AI 音频: {len(ai_audio)} bytes ({case['ai_speech_duration']}s)")

        # 生成用户打断音频（类语音信号）
        user_audio = audio_gen.speech_like(case["user_speech_duration"])
        print(f"  用户音频: {len(user_audio)} bytes ({case['user_speech_duration']}s)")

        # 保存 AI 音频作为 output.wav（评估时用的主音频）
        ai_output = case_dir / "output.wav"
        with open(ai_output, "wb") as f:
            f.write(ai_audio)
        print(f"  保存: {ai_output}")

        # 保存用户打断音频（用于参考/调试）
        user_output = case_dir / "user_audio.pcm"
        with open(user_output, "wb") as f:
            f.write(user_audio)
        print(f"  保存: {user_output}")

        # 创建 interrupt.json
        interrupt_start = case["interrupt_start"]
        interrupt_end = interrupt_start + case["user_speech_duration"]

        interrupt_data = [
            {
                "type": "user_speech",
                "text": f"用户打断 (测试音频 {case['name']})",
                "timestamp": [interrupt_start, interrupt_end]
            }
        ]

        interrupt_json = case_dir / "interrupt.json"
        with open(interrupt_json, "w", encoding="utf-8") as f:
            json.dump(interrupt_data, f, ensure_ascii=False, indent=2)
        print(f"  保存: {interrupt_json}")

        # 创建 metadata.json（测试用例元信息）
        metadata = {
            "case_name": case["name"],
            "description": case["description"],
            "ai_speech_duration": case["ai_speech_duration"],
            "user_speech_duration": case["user_speech_duration"],
            "interrupt_start": interrupt_start,
            "interrupt_end": interrupt_end,
            "expect_interrupt": case["expect_interrupt"],
        }

        metadata_json = case_dir / "metadata.json"
        with open(metadata_json, "w", encoding="utf-8") as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        print(f"  保存: {metadata_json}")

    print("\n" + "=" * 60)
    print(f"生成完成! 共 {len(TEST_CASES)} 个测试用例")
    print("=" * 60)
    print("\n下一步:")
    print("  1. 运行评估: python evaluation/evaluate.py --task user_interruption --root_dir dataset/user_interruption")
    print("  2. 或运行实时测试: python test_fdb_realtime.py")


if __name__ == "__main__":
    main()

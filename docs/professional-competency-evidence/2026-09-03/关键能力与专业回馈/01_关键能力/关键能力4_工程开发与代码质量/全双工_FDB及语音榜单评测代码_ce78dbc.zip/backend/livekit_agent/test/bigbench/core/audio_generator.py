"""BigBench 音频生成器

用于 BigBench 测试的音频生成，支持：
- 程序化生成类语音音频
- TTS 合成（通过调用外部 TTS 服务）
"""

import struct
import math
import random
from pathlib import Path
from typing import Optional

from core.tts_client import synthesize


class BigBenchAudioGenerator:
    """BigBench 测试音频生成器"""

    SAMPLE_RATE = 16000
    SAMPLE_WIDTH = 2  # 16-bit
    MAX_AMPLITUDE = 32767

    def __init__(self, tts_url: str = "ws://localhost:8080/api-ws/v1/realtime"):
        self.tts_url = tts_url

    def speech_like(self, duration_s: float, amplitude: float = 0.7) -> bytes:
        """生成类语音信号（多谐波+包络调制）"""
        num_samples = int(self.SAMPLE_RATE * duration_s)
        amp = self.MAX_AMPLITUDE * amplitude

        base_freq = 150.0
        harmonics = [
            (1.0, 1.0), (2.0, 0.7), (3.0, 0.5),
            (4.0, 0.3), (5.0, 0.2), (8.0, 0.15),
        ]

        samples = []
        syllable_rate = 5.0
        envelope_phase = random.uniform(0, 2 * math.pi)

        for i in range(num_samples):
            t = i / self.SAMPLE_RATE

            freq_variation = base_freq + 30 * math.sin(2 * math.pi * 0.5 * t)

            signal = 0.0
            for harmonic_mult, harmonic_amp in harmonics:
                freq = freq_variation * harmonic_mult
                signal += harmonic_amp * math.sin(2 * math.pi * freq * t)

            max_harmonic_sum = sum(h[1] for h in harmonics)
            signal /= max_harmonic_sum

            envelope = 0.5 + 0.5 * math.sin(
                2 * math.pi * syllable_rate * t + envelope_phase
            )
            envelope *= (0.8 + 0.4 * random.random())
            envelope = max(0.1, min(1.0, envelope))

            value = int(amp * signal * envelope)
            value = max(-32768, min(32767, value))
            samples.append(struct.pack('<h', value))

        return b''.join(samples)

    async def tts(self, text: str, speaker: str = "Vivian") -> bytes:
        """使用 TTS 服务合成语音"""
        return await synthesize(
            text=text,
            tts_url=self.tts_url,
            speaker=speaker,
            language="Chinese",
            instruct="用清晰的语速说。",
        )

    @staticmethod
    def silence(duration_s: float) -> bytes:
        """生成静音"""
        num_samples = int(BigBenchAudioGenerator.SAMPLE_RATE * duration_s)
        return b'\x00\x00' * num_samples

    @staticmethod
    def save_pcm(data: bytes, file_path: str) -> None:
        """保存 PCM 数据到文件"""
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        Path(file_path).write_bytes(data)

    @staticmethod
    def load_pcm(file_path: str) -> bytes:
        """从文件加载 PCM 数据"""
        return Path(file_path).read_bytes()
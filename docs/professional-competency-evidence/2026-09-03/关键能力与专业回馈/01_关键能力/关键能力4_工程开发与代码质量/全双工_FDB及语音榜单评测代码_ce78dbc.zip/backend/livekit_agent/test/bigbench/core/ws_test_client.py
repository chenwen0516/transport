"""BigSocket 测试客户端

自动化测试专用的 WebSocket 客户端，封装 WS 连接、事件收集、音频注入。
支持精确时间戳记录，用于计算延迟和端点检测。
复制自 ../realtime/core/ws_test_client.py
"""

import asyncio
import base64
import json
import logging
import ssl
import time
from dataclasses import dataclass
from typing import Any, Callable

import websockets

logger = logging.getLogger("test.ws_client")


@dataclass
class TimestampedEvent:
    """带精确时间戳的服务端事件"""
    timestamp: float          # time.monotonic()
    wall_time: float        # time.time()
    event: dict[str, Any]  # 原始 JSON 事件

    @property
    def event_type(self) -> str:
        return self.event.get("type", "")


class RealtimeTestClient:
    """自动化测试专用的 WebSocket 客户端

    Features:
    - 后台协程持续收集事件并记录时间戳
    - 按 100ms 一帧注入 PCM 音频
    - 事件查询/过滤/等待 API
    """

    CHUNK_BYTES = 3200  # 100ms @ 16kHz/16bit = 1600 samples * 2 bytes

    def __init__(self):
        self._ws: websockets.WebSocketClientProtocol | None = None
        self._events: list[TimestampedEvent] = []
        self._receive_task: asyncio.Task | None = None
        self._event_waiters: list[tuple[str, asyncio.Event, list]] = []
        self._connected = False

    async def connect(
        self,
        ws_url: str,
        token: str | None = None,
        session_config: dict | None = None,
        timeout: float = 15.0,
    ) -> TimestampedEvent:
        """连接 WebSocket 并等待 session.created"""
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        ssl_context = None
        if ws_url.startswith("wss://"):
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

        max_retries = 3
        retry_delay = 2.0
        last_exc: Exception | None = None
        for attempt in range(max_retries):
            try:
                self._ws = await asyncio.wait_for(
                    websockets.connect(
                        ws_url,
                        additional_headers=headers,
                        ssl=ssl_context,
                        max_size=10 * 1024 * 1024,
                    ),
                    timeout=timeout,
                )
                break
            except (ConnectionResetError, OSError) as e:
                last_exc = e
                if attempt < max_retries - 1:
                    logger.warning(
                        f"[WS] connect attempt {attempt + 1} failed ({e}), "
                        f"retrying in {retry_delay}s…"
                    )
                    await asyncio.sleep(retry_delay)
                    retry_delay *= 2
        else:
            raise ConnectionError(
                f"Failed to connect after {max_retries} attempts"
            ) from last_exc

        self._connected = True
        self._events.clear()

        self._receive_task = asyncio.create_task(self._receive_loop())

        session_created = await self.wait_for_event("session.created", timeout=timeout)

        if session_config:
            await self._send({
                "type": "session.update",
                "session": session_config,
            })
            await self.wait_for_event("session.updated", timeout=10.0)

        return session_created

    async def _receive_loop(self):
        """后台持续接收事件"""
        try:
            async for message in self._ws:
                event = json.loads(message)
                ts_event = TimestampedEvent(
                    timestamp=time.monotonic(),
                    wall_time=time.time(),
                    event=event,
                )
                self._events.append(ts_event)
                logger.debug(f"[WS] Received: {event.get('type', 'unknown')}")

                for event_type, waiter_event, result_list in self._event_waiters:
                    if ts_event.event_type == event_type:
                        result_list.append(ts_event)
                        waiter_event.set()
        except websockets.exceptions.ConnectionClosed:
            logger.info("[WS] Connection closed")
        except Exception as e:
            logger.error(f"[WS] Receive error: {e}")
        finally:
            self._connected = False

    async def _send(self, data: dict) -> None:
        """发送 JSON 消息"""
        if self._ws:
            await self._ws.send(json.dumps(data))

    async def wait_for_event(
        self,
        event_type: str,
        timeout: float = 10.0,
        predicate: Callable[[dict], bool] | None = None,
    ) -> TimestampedEvent:
        """等待指定类型的事件"""
        for ev in self._events:
            if ev.event_type == event_type:
                if predicate is None or predicate(ev.event):
                    return ev

        waiter_event = asyncio.Event()
        result_list: list[TimestampedEvent] = []
        waiter = (event_type, waiter_event, result_list)
        self._event_waiters.append(waiter)

        try:
            deadline = time.monotonic() + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise asyncio.TimeoutError(
                        f"Timeout waiting for event '{event_type}' after {timeout}s"
                    )
                waiter_event.clear()
                await asyncio.wait_for(waiter_event.wait(), timeout=remaining)

                for ev in result_list:
                    if predicate is None or predicate(ev.event):
                        return ev
                result_list.clear()
        finally:
            self._event_waiters.remove(waiter)

    async def wait_for_agent_state(
        self,
        state: str,
        timeout: float = 15.0,
    ) -> TimestampedEvent:
        """等待 agent 进入指定状态"""
        return await self.wait_for_event(
            "agent.state_changed",
            timeout=timeout,
            predicate=lambda e: e.get("state") == state,
        )

    async def inject_audio_streaming(
        self,
        pcm_data: bytes,
        chunk_ms: int = 100,
    ) -> tuple[float, float]:
        """流式注入 PCM 音频"""
        chunk_bytes = int(16000 * (chunk_ms / 1000) * 2)
        t_first = None
        t_last = None

        for offset in range(0, len(pcm_data), chunk_bytes):
            chunk = pcm_data[offset:offset + chunk_bytes]
            audio_b64 = base64.b64encode(chunk).decode('ascii')

            now = time.monotonic()
            if t_first is None:
                t_first = now
            t_last = now

            await self._send({
                "type": "input_audio_buffer.append",
                "audio": audio_b64,
            })
            await asyncio.sleep(chunk_ms / 1000)

        return (t_first or time.monotonic(), t_last or time.monotonic())

    async def commit_audio_buffer(self) -> float:
        """提交音频缓冲区"""
        t = time.monotonic()
        await self._send({"type": "input_audio_buffer.commit"})
        return t

    async def inject_audio(
        self,
        pcm_data: bytes,
        chunk_ms: int = 100,
    ) -> tuple[float, float]:
        """注入 PCM 音频，按 chunk_ms 分帧发送"""
        result = await self.inject_audio_streaming(pcm_data, chunk_ms)
        await self.commit_audio_buffer()
        return result

    async def inject_silence(self, duration_s: float, chunk_ms: int = 100) -> None:
        """注入静音"""
        chunk_bytes = int(16000 * (chunk_ms / 1000) * 2)
        total_bytes = int(16000 * duration_s * 2)

        for offset in range(0, total_bytes, chunk_bytes):
            size = min(chunk_bytes, total_bytes - offset)
            audio_b64 = base64.b64encode(b'\x00' * size).decode('ascii')
            await self._send({
                "type": "input_audio_buffer.append",
                "audio": audio_b64,
            })
            await asyncio.sleep(chunk_ms / 1000)

        await self._send({"type": "input_audio_buffer.commit"})

    async def send_cancel(self) -> float:
        """发送 response.cancel"""
        t = time.monotonic()
        await self._send({"type": "response.cancel"})
        return t

    async def drain_events(self, timeout: float = 5.0) -> list[TimestampedEvent]:
        """等待一段时间收集所有事件"""
        t_start = len(self._events)
        await asyncio.sleep(timeout)
        return self._events[t_start:]

    async def disconnect(self) -> None:
        """断开连接"""
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None
        if self._receive_task and not self._receive_task.done():
            self._receive_task.cancel()
            try:
                await self._receive_task
            except (asyncio.CancelledError, Exception):
                pass
        self._connected = False

    # ========== 事件查询 API ==========

    def get_events(self, event_type: str | None = None) -> list[TimestampedEvent]:
        """获取已收集的事件，可按类型过滤"""
        if event_type is None:
            return list(self._events)
        return [e for e in self._events if e.event_type == event_type]

    def get_last_event(self, event_type: str) -> TimestampedEvent | None:
        """获取指定类型的最后一个事件"""
        for e in reversed(self._events):
            if e.event_type == event_type:
                return e
        return None

    def has_event(self, event_type: str) -> bool:
        """是否有指定类型的事件"""
        return any(e.event_type == event_type for e in self._events)

    def count_events(self, event_type: str) -> int:
        """统计指定类型事件数量"""
        return sum(1 for e in self._events if e.event_type == event_type)

    def has_event_after(
        self,
        event_type: str,
        after_time: float,
        predicate: Callable[[dict], bool] | None = None,
    ) -> bool:
        """在指定时间之后是否有匹配的事件"""
        for e in self._events:
            if e.timestamp > after_time and e.event_type == event_type:
                if predicate is None or predicate(e.event):
                    return True
        return False

    def get_event_time_after(
        self,
        event_type: str,
        after_time: float,
        predicate: Callable[[dict], bool] | None = None,
    ) -> float | None:
        """获取指定时间之后某类型事件的时间戳"""
        for e in self._events:
            if e.timestamp > after_time and e.event_type == event_type:
                if predicate is None or predicate(e.event):
                    return e.timestamp
        return None

    def get_last_event_time(self, event_type: str) -> float | None:
        """获取指定类型最后一个事件的时间戳"""
        ev = self.get_last_event(event_type)
        return ev.timestamp if ev else None

    def get_last_event_time_after(self, event_type: str, after_time: float) -> float | None:
        """获取指定时间之后某类型事件中最后一个的时间戳"""
        result = None
        for e in self._events:
            if e.timestamp > after_time and e.event_type == event_type:
                result = e.timestamp
        return result

    def clear_events(self) -> None:
        """清除已收集的所有事件"""
        self._events.clear()

    @property
    def is_connected(self) -> bool:
        return self._connected
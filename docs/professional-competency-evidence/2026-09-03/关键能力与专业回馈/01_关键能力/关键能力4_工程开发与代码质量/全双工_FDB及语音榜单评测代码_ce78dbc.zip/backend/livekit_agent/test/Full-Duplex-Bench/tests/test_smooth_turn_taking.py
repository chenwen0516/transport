"""Smooth Turn Taking 测试

测试话轮转换能力
"""
import asyncio
import time

from core import (
    RealtimeTestClient,
    DatasetCase,
    EvaluationResult,
    MetricsAggregator,
)


async def test_smooth_turn_taking_dataset(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case: DatasetCase,
    metrics_aggregator: MetricsAggregator,
    min_deltas: int = 10,
):
    """使用数据集音频测试话轮转换

    场景：用户说完后，AI 应及时接过话轮。
    关键：根据 turn_taking_timestamp（在音频中标记用户说完的时刻）检测 AI 是否响应。

    逻辑：
    1. 边发送音频边检测 AI 状态
    2. turn_taking_timestamp 表示音频中用户说完的时刻
    3. 检测 AI 是否在 [用户说完时刻, 用户说完+3s] 内开始 speaking
    4. TOR = 1 如果 AI 及时响应
    """
    if not case.input_audio:
        print(f"    跳过 {case.case_name}: 无 input_audio")
        metrics_aggregator.add_result(EvaluationResult(
            task="smooth_turn_taking",
            case_name=case.case_name,
            success=False,
            error="missing input audio",
        ))
        return

    await ws_client.connect(ws_url, auth_token)
    ws_client.clear_events()

    t_start = time.monotonic()

    # 边发送音频边检测 AI 状态
    send_task = await ws_client.inject_audio_nonblocking(case.input_audio)

    switched = False
    t_switched = None
    latency = None

    turn_end_s = case.turn_taking_timestamp[0] if case.turn_taking_timestamp else None

    # 监控循环：发送期间持续检测 AI 状态
    while not send_task.done():
        state_changed = ws_client.get_event_time_after(
            "agent.state_changed",
            t_start,
            predicate=lambda e: e.get("state") == "speaking",
        )
        if state_changed:
            t_switched = state_changed
            if turn_end_s is not None:
                switched_time = t_switched - t_start
                if turn_end_s <= switched_time <= turn_end_s + 3.0:
                    switched = True
                    break
            else:
                switched = True
                break
        await asyncio.sleep(0.05)

    # 等待发送完成
    await send_task

    # 发送完成后额外检测（捕获慢响应）
    if not switched and turn_end_s is not None:
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline:
            t_switched = ws_client.get_event_time_after(
                "agent.state_changed",
                t_start,
                predicate=lambda e: e.get("state") == "speaking",
            )
            if t_switched:
                switched_time = t_switched - t_start
                if turn_end_s <= switched_time <= turn_end_s + 3.0:
                    switched = True
                    break
            await asyncio.sleep(0.05)

    if t_switched and turn_end_s is not None:
        latency = ((t_switched - t_start) - turn_end_s) * 1000

    result = EvaluationResult(
        task="smooth_turn_taking",
        case_name=case.case_name,
        tor=1.0 if switched else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    print(f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency and latency > 0 else f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}")

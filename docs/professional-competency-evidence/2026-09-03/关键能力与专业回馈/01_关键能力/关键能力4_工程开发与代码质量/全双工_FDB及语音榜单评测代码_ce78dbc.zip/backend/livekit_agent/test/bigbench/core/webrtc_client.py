"""BigBench WebRTC test client."""

import asyncio
import logging
import os
import struct
import time
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from livekit import rtc

from core.case import BigBenchCase
from core.metrics import BigBenchMetricsAggregator, BigBenchResult

logger = logging.getLogger("test.webrtc_client")

SILENCE_THRESHOLD = 300
SILENCE_FRAMES_TO_STOP = 300
INPUT_SAMPLE_RATE = 16000
INPUT_CHANNELS = 1
FRAME_DURATION_MS = 10


class _IgnoredLiveKitStreamFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        return not (
            msg.startswith("ignoring byte stream with topic 'lk.agent.session'")
            or msg.startswith("ignoring text stream with topic 'lk.transcription'")
        )


def _suppress_livekit_stream_noise() -> None:
    root_logger = logging.getLogger()
    for handler in root_logger.handlers:
        if not any(isinstance(f, _IgnoredLiveKitStreamFilter) for f in handler.filters):
            handler.addFilter(_IgnoredLiveKitStreamFilter())


def _url_with_query(url: str, params: dict[str, str]) -> str:
    parts = urlsplit(url)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    for key, value in params.items():
        if value and key not in query:
            query[key] = value
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def _resample_pcm16(
    pcm_data: bytes,
    source_rate: int,
    target_rate: int = INPUT_SAMPLE_RATE,
) -> bytes:
    if not pcm_data or source_rate == target_rate:
        return pcm_data

    import numpy as np

    samples = np.frombuffer(pcm_data, dtype=np.int16)
    if len(samples) == 0:
        return pcm_data

    new_len = max(1, int(len(samples) * target_rate / source_rate))
    indices = np.linspace(0, len(samples) - 1, new_len).astype(int)
    return samples[indices].astype(np.int16).tobytes()


@dataclass
class CaseResult:
    case: BigBenchCase
    predicted_answer: Optional[str] = None
    correct: Optional[bool] = None
    latency_ms: Optional[float] = None
    error: Optional[str] = None


class WebRTCClient:
    def __init__(
        self,
        livekit_url: str,
        token_api_url: str = "",
        room_name: str = "",
        participant_name: str = "benchmark",
        api_key: str = "",
        api_secret: str = "",
        auth_token: str = "",
        token_mode: str = "",
        agent_name: str = "",
        speaker: str = "",
    ):
        self.livekit_url = livekit_url
        self.token_api_url = token_api_url
        self.api_key = api_key
        self.api_secret = api_secret
        self.room_name = room_name
        self.participant_name = participant_name
        self.auth_token = auth_token
        self.token_mode = token_mode
        self.agent_name = agent_name
        self.speaker = speaker

        self._room = None
        self._audio_source = None
        self._audio_track = None
        self._audio_publication = None
        self._connected = False

        self._response_audio_frames: list[bytes] = []
        self._speech_audio_frames: list[bytes] = []
        self._speech_sample_rate = INPUT_SAMPLE_RATE
        self._capture_response_audio = False
        self._heard_speech = False
        self._silent_count = 0
        self._t_first_speech = None
        self._last_non_silent_audio_time = None
        self._question_audio_active = False
        self._early_response_detected = False
        self._t_early_response = None
        self.agent_state = "idle"

    async def _fetch_token(self) -> str:
        import httpx

        jwt = os.getenv("LIVEKIT_TOKEN", "")
        if jwt:
            return jwt

        if not self.token_api_url:
            raise ValueError("LIVEKIT_TOKEN env or token_api_url is required")

        headers = {}
        auth_token = self.auth_token or os.getenv("AUTH_TOKEN", "")
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"

        url = _url_with_query(
            self.token_api_url,
            {
                "tokenMode": self.token_mode,
                "agentName": self.agent_name,
                "speaker": self.speaker,
            },
        )
        logger.info("Requesting LiveKit token from %s", url)

        async with httpx.AsyncClient(verify=False) as client:
            resp = await client.post(url, headers=headers, timeout=15.0)
            resp.raise_for_status()
            data = resp.json()

        jwt = data.get("token") or data.get("access_token")
        if not jwt:
            raise ValueError(f"No token in response: {data}")

        self.room_name = data.get("room") or self.room_name
        response_ws_url = data.get("ws_url")
        if response_ws_url:
            self.livekit_url = response_ws_url
        if not self.livekit_url:
            raise ValueError("LiveKit ws_url is missing; set LIVEKIT_URL or return ws_url from token API")

        return jwt

    async def connect(self, timeout: float = 30.0):
        _suppress_livekit_stream_noise()
        jwt = await self._fetch_token()
        self._room = rtc.Room()

        @self._room.on("track_subscribed")
        def on_track_subscribed(track, publication, participant):
            if track.kind == rtc.TrackKind.KIND_AUDIO:
                logger.info("Received audio track from %s", participant.identity)
                asyncio.create_task(self._handle_incoming_audio(track))

        @self._room.on("participant_attributes_changed")
        def on_participant_attributes_changed(changed_attributes, participant):
            state = changed_attributes.get("lk.agent.state")
            if state:
                self.agent_state = state
                logger.info("Agent state changed to %s", state)

        @self._room.on("participant_connected")
        def on_participant_connected(participant):
            if participant.identity.startswith("agent-"):
                logger.info("Agent connected: %s", participant.identity)

        await asyncio.wait_for(self._room.connect(self.livekit_url, jwt), timeout=timeout)
        await self._publish_microphone()
        logger.info("Connected to room %s", self._room.name or self.room_name)
        self._connected = True

    async def _publish_microphone(self):
        if not self._room:
            raise RuntimeError("Room is not connected")
        if self._audio_source:
            return

        self._audio_source = rtc.AudioSource(
            sample_rate=INPUT_SAMPLE_RATE,
            num_channels=INPUT_CHANNELS,
        )
        self._audio_track = rtc.LocalAudioTrack.create_audio_track(
            "benchmark-mic",
            self._audio_source,
        )
        options = rtc.TrackPublishOptions(source=rtc.TrackSource.SOURCE_MICROPHONE)
        self._audio_publication = await self._room.local_participant.publish_track(
            self._audio_track,
            options,
        )
        logger.info("Published benchmark microphone track")

    async def _handle_incoming_audio(self, track):
        try:
            audio_stream = rtc.AudioStream(track)
            async for event in audio_stream:
                frame = event.frame
                pcm_data = self._audio_frame_to_pcm(frame)
                sample_rate = getattr(frame, "sample_rate", INPUT_SAMPLE_RATE) or INPUT_SAMPLE_RATE
                self._response_audio_frames.append(pcm_data)

                is_silent = self._is_silent(pcm_data)
                if not is_silent:
                    self._last_non_silent_audio_time = time.monotonic()
                    if self._question_audio_active and not self._early_response_detected:
                        self._early_response_detected = True
                        self._t_early_response = self._last_non_silent_audio_time
                if not self._capture_response_audio:
                    continue

                if not is_silent:
                    self._heard_speech = True
                    if self._t_first_speech is None:
                        self._t_first_speech = self._last_non_silent_audio_time
                    self._speech_sample_rate = sample_rate
                    self._speech_audio_frames.append(pcm_data)
                    self._silent_count = 0
                elif self._heard_speech:
                    self._speech_audio_frames.append(pcm_data)
                    self._silent_count += 1
        except Exception as e:
            logger.error("Audio stream error: %s", e)

    def _is_silent(self, pcm_data: bytes) -> bool:
        if len(pcm_data) < 2:
            return True
        count = min(len(pcm_data) // 2, 160)
        step = max(1, len(pcm_data) // 2 // count)
        total = 0
        samples_seen = 0
        for i in range(0, len(pcm_data) // 2, step):
            sample = struct.unpack_from("<h", pcm_data, i * 2)[0]
            total += abs(sample)
            samples_seen += 1
        avg = total / samples_seen if samples_seen else 0
        return avg < SILENCE_THRESHOLD

    def _audio_frame_to_pcm(self, frame) -> bytes:
        data = frame.data
        if hasattr(data, "tobytes"):
            data = data.tobytes()
        return bytes(data)

    async def inject_audio(
        self,
        pcm_data: bytes,
        sample_rate: int = INPUT_SAMPLE_RATE,
        trailing_silence_ms: int = 600,
        start_capture_after_content: bool = False,
    ) -> float:
        if not self._room or not self._connected:
            raise RuntimeError("Not connected to room")
        if not self._audio_source:
            await self._publish_microphone()

        if sample_rate != INPUT_SAMPLE_RATE:
            pcm_data = _resample_pcm16(pcm_data, sample_rate, INPUT_SAMPLE_RATE)
            sample_rate = INPUT_SAMPLE_RATE

        samples_per_frame = sample_rate * FRAME_DURATION_MS // 1000
        total_samples = len(pcm_data) // 2
        num_frames = (total_samples + samples_per_frame - 1) // samples_per_frame

        content_end_time = time.monotonic()
        self._question_audio_active = True
        try:
            for i in range(num_frames):
                start = i * samples_per_frame * 2
                end = start + samples_per_frame * 2
                frame_data = pcm_data[start:end]
                if len(frame_data) < samples_per_frame * 2:
                    missing_samples = (samples_per_frame * 2 - len(frame_data)) // 2
                    frame_data = frame_data + b"\x00\x00" * missing_samples
                frame = rtc.AudioFrame(
                    data=frame_data,
                    sample_rate=sample_rate,
                    num_channels=1,
                    samples_per_channel=samples_per_frame,
                )
                await self._audio_source.capture_frame(frame)
                await asyncio.sleep(FRAME_DURATION_MS / 1000)
            content_end_time = time.monotonic()
        finally:
            self._question_audio_active = False

        if start_capture_after_content:
            self.start_response_capture()

        silence_frames = trailing_silence_ms // FRAME_DURATION_MS
        silence = b"\x00\x00" * samples_per_frame
        for _ in range(silence_frames):
            frame = rtc.AudioFrame(
                data=silence,
                sample_rate=sample_rate,
                num_channels=1,
                samples_per_channel=samples_per_frame,
            )
            await self._audio_source.capture_frame(frame)
            await asyncio.sleep(FRAME_DURATION_MS / 1000)

        return content_end_time

    def get_speech_audio(self, target_sample_rate: int = INPUT_SAMPLE_RATE) -> bytes:
        audio = b"".join(self._speech_audio_frames)
        return _resample_pcm16(audio, self._speech_sample_rate, target_sample_rate)

    def start_response_capture(self):
        self._speech_audio_frames.clear()
        self._speech_sample_rate = INPUT_SAMPLE_RATE
        self._heard_speech = False
        self._silent_count = 0
        self._t_first_speech = None
        self._capture_response_audio = True

    @property
    def early_response_detected(self) -> bool:
        return self._early_response_detected

    def has_speech_ended(self) -> bool:
        return self._heard_speech and self._silent_count >= SILENCE_FRAMES_TO_STOP

    async def wait_for_agent_idle(self, timeout: float = 30.0) -> bool:
        start = time.monotonic()
        while time.monotonic() - start < timeout:
            if self.agent_state == "listening":
                return True
            if self._heard_speech and self.has_speech_ended():
                return True
            await asyncio.sleep(0.2)
        return False

    async def wait_for_initial_audio_settled(
        self,
        timeout: float = 20.0,
        quiet_seconds: float = 1.2,
        fallback_delay: float = 3.0,
    ) -> bool:
        """Wait for the initial greeting to finish before injecting a benchmark case."""
        start = time.monotonic()
        while time.monotonic() - start < timeout:
            now = time.monotonic()
            if self._last_non_silent_audio_time is None:
                if now - start >= fallback_delay and self.agent_state in ("idle", "listening"):
                    return True
            elif now - self._last_non_silent_audio_time >= quiet_seconds:
                if self.agent_state in ("idle", "listening"):
                    return True
            await asyncio.sleep(0.2)
        return False

    def clear(self):
        self._response_audio_frames.clear()
        self._speech_audio_frames.clear()
        self._speech_sample_rate = INPUT_SAMPLE_RATE
        self._capture_response_audio = False
        self._heard_speech = False
        self._silent_count = 0
        self._t_first_speech = None
        self._last_non_silent_audio_time = None
        self._question_audio_active = False
        self._early_response_detected = False
        self._t_early_response = None

    async def disconnect(self):
        if self._room:
            await self._room.disconnect()
            self._room = None
            self._audio_source = None
            self._audio_track = None
            self._audio_publication = None
            self._connected = False
            self.agent_state = "idle"
            logger.info("Disconnected from room")

    @property
    def is_connected(self):
        return self._connected


class LiveKitBenchmarkRunner:
    def __init__(
        self,
        livekit_url,
        token_api_url,
        asr_client,
        judge,
        room_name="bigbench",
        api_key="",
        api_secret="",
        auth_token="",
        token_mode="",
        agent_name="",
        speaker="",
        reconnect_per_case=True,
        early_response_retries=1,
        early_response_policy="warn",
        trailing_silence_ms=600,
        response_start_timeout_s=60.0,
        response_end_timeout_s=120.0,
    ):
        self.livekit_url = livekit_url
        self.token_api_url = token_api_url
        self.api_key = api_key
        self.api_secret = api_secret
        self.room_name = room_name
        self.asr_client = asr_client
        self.judge = judge
        self.auth_token = auth_token
        self.token_mode = token_mode
        self.agent_name = agent_name
        self.speaker = speaker
        self.reconnect_per_case = reconnect_per_case
        self.early_response_retries = early_response_retries
        self.early_response_policy = early_response_policy
        self.trailing_silence_ms = trailing_silence_ms
        self.response_start_timeout_s = response_start_timeout_s
        self.response_end_timeout_s = response_end_timeout_s
        self.metrics = BigBenchMetricsAggregator()

    def _add_failed_result(self, case, predicted_answer: str = ""):
        result = BigBenchResult(
            case_id=case.id,
            category=case.category,
            question=case.question,
            expected_answer=case.answer,
            predicted_answer=predicted_answer,
            correct=False,
            difficulty=case.difficulty,
            reasoning_steps=case.reasoning_steps,
        )
        self.metrics.add(result)
        return result

    def _new_client(self):
        return WebRTCClient(
            livekit_url=self.livekit_url,
            token_api_url=self.token_api_url,
            room_name=self.room_name,
            api_key=self.api_key,
            api_secret=self.api_secret,
            auth_token=self.auth_token,
            token_mode=self.token_mode,
            agent_name=self.agent_name,
            speaker=self.speaker,
        )

    async def run_single_case(self, client, case):
        try:
            await client.wait_for_initial_audio_settled(timeout=25.0)
            client.clear()

            audio_bytes = getattr(case, "_audio_bytes", None)
            if not audio_bytes:
                self._add_failed_result(case)
                return CaseResult(case=case, error="No audio data")

            audio_duration = case.audio_duration_s or (len(audio_bytes) / 2 / INPUT_SAMPLE_RATE)
            response_start_timeout = max(
                self.response_start_timeout_s,
                min(120.0, audio_duration * 0.5 + 30.0),
            )
            response_end_timeout = max(
                self.response_end_timeout_s,
                min(180.0, audio_duration + 90.0),
            )

            should_retry_early_response = self.early_response_policy in ("retry", "fail")
            retry_count = self.early_response_retries if should_retry_early_response else 0

            t_audio_end = None
            for attempt in range(retry_count + 1):
                if attempt:
                    logger.info(
                        "Replaying case %s after early response (%d/%d)",
                        case.id,
                        attempt,
                        retry_count,
                    )
                    await client.wait_for_initial_audio_settled(timeout=25.0)
                    client.clear()

                logger.info("Injecting question audio...")
                t_audio_end = await client.inject_audio(
                    audio_bytes,
                    trailing_silence_ms=self.trailing_silence_ms,
                    start_capture_after_content=True,
                )
                if not client.early_response_detected:
                    break
                logger.warning(
                    "Agent started speaking before question audio ended for case %s",
                    case.id,
                )
                if attempt < retry_count:
                    await client.wait_for_initial_audio_settled(timeout=25.0)

            if client.early_response_detected and self.early_response_policy == "fail":
                self._add_failed_result(
                    case,
                    predicted_answer="[early_response_before_question_end]",
                )
                return CaseResult(case=case, error="Agent spoke before question audio ended")

            logger.info("Question audio injected, waiting for speech...")

            start = time.monotonic()
            while time.monotonic() - start < response_start_timeout:
                if client._heard_speech:
                    logger.info("Agent started speaking")
                    break
                await asyncio.sleep(0.3)
            if not client._heard_speech:
                self._add_failed_result(case)
                return CaseResult(case=case, error="Agent did not speak")

            logger.info("Waiting for agent to finish speaking...")
            while time.monotonic() - start < response_end_timeout:
                if client.has_speech_ended():
                    logger.info("Agent finished speaking (silence detected)")
                    break
                await asyncio.sleep(0.3)

            response_audio = client.get_speech_audio()
            logger.info("Speech audio: %d bytes", len(response_audio))
            if not response_audio:
                self._add_failed_result(case)
                return CaseResult(case=case, error="No speech audio")

            predicted_text = await self.asr_client.transcribe(response_audio)
            logger.info("ASR result: %s", predicted_text[:120] if predicted_text else "(empty)")

            result = self.judge.judge(case, predicted_text)
            result.t_question_audio_end = t_audio_end
            result.t_first_audio = client._t_first_speech
            self.metrics.add(result)
            return CaseResult(
                case=case,
                predicted_answer=predicted_text,
                correct=result.correct,
                latency_ms=result.latency_first_audio_ms,
            )
        except Exception as e:
            import traceback

            traceback.print_exc()
            logger.error("Error running case %s: %s", case.id, e)
            self._add_failed_result(case)
            return CaseResult(case=case, error=str(e))

    async def run(self, cases, max_cases=None, dry_run=False):
        if max_cases:
            cases = cases[:max_cases]
        logger.info("Running BigBench WebRTC benchmark: %d cases", len(cases))

        shared_client = None
        if not dry_run and not self.reconnect_per_case:
            shared_client = self._new_client()
            await shared_client.connect()

        try:
            for i, case in enumerate(cases):
                logger.info("[%d/%d] Running case: %s (%s)", i + 1, len(cases), case.id, case.category)
                if dry_run:
                    r = BigBenchResult(
                        case_id=case.id,
                        category=case.category,
                        question=case.question,
                        expected_answer=case.answer,
                        predicted_answer="[dry-run]",
                        correct=True,
                    )
                    self.metrics.add(r)
                else:
                    client = shared_client or self._new_client()
                    try:
                        if self.reconnect_per_case:
                            await client.connect()
                        await self.run_single_case(client, case)
                    finally:
                        if self.reconnect_per_case:
                            await client.disconnect()
                            await asyncio.sleep(2.0)

                if (i + 1) % 10 == 0:
                    logger.info(
                        "Progress: %d/%d - Accuracy: %.1f%%",
                        i + 1,
                        len(cases),
                        self.metrics.accuracy() * 100,
                    )
        finally:
            if shared_client:
                await shared_client.disconnect()

        return self.metrics

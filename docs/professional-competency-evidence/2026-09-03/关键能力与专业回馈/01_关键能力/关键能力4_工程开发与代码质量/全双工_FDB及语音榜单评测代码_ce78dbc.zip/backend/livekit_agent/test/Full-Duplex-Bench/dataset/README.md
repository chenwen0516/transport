# Full-Duplex-Bench 数据集

这个目录用于存放 Full-Duplex-Bench 的本地评测数据，供在线评测和离线评测使用。

## 数据下载

原始数据通过 Google Drive 分发：

```text
https://drive.google.com/drive/folders/1DtoxMVO9_Y_nDs2peZtx3pw-U2qYgpd3
```

下载需要的任务数据后，可以放到当前目录下，也可以在运行脚本时通过 `--root_dir` 指定其他路径。

## 期望目录结构

历史 benchmark 的目录结构如下：

```text
dataset/
  v1_0/
    candor_pause_handling/
    candor_turn_taking/
    icc_backchannel/
    synthetic_pause_handling/
    synthetic_user_interruption/
  v1_5/
    user_interruption/
    user_backchannel/
    talking_to_other/
    background_speech/
```

当前仓库中也包含一些本地样例数据，路径可能更简单，例如：

```text
dataset/
  mini_test/
    user_interruption/
  user_interruption/
```

## v1.0 样本格式

```text
{sample_id}/
  input.wav             用户输入音频
  output.wav            agent 响应音频，可以由在线评测采集生成
  output.json           ASR 转写结果，按需生成
  interrupt.json        打断任务标注
  pause.json            停顿任务标注
  turn_taking.json      轮次切换任务标注
  transcription.json    参考转写文本
```

## v1.5 样本格式

```text
{sample_id}/
  input.wav             混合输入音频
  clean_input.wav       干净参考输入音频
  output.wav            agent 响应音频
  output.json           ASR 转写结果
  metadata.json         样本元数据
```

## 注意事项

- 离线评测要求每个样本目录中已经存在 `output.wav`。
- 在线评测可以通过 `run_all.py` 采集并生成 `output.wav`。
- 如果下载后的目录名和默认路径不同，请运行时显式传入 `--root_dir`。

"""Barge In Recovery 测试

测试打断后 AI 能否恢复
"""
import asyncio
import time

from core import (
    RealtimeTestClient,
    DatasetCase,
    EvaluationResult,
    wait_for_agent_state,
    MetricsAggregator,
    AUDIO_DELTA_EVENT,
)


async def test_barge_in_recovery_dataset(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case: DatasetCase,
    metrics_aggregator: MetricsAggregator,
    min_deltas: int = 5,
):
    """使用数据集音频测试打断后恢复

    流程：
    1. 连接并等待 AI 开始说话
    2. 等待 AI 说到一半（收到足够 deltas）
    3. 注入 interrupt.wav 打断
    4. 注入静默，验证 AI 是否恢复
    """
    if not case.interrupt_audio:
        print(f"    跳过 {case.case_name}: 无打断音频")
        return

    await ws_client.connect(ws_url, auth_token)

    # 等待 AI 开始说话
    if not await wait_for_agent_state(ws_client, "speaking", timeout=15):
        print(f"    跳过 {case.case_name}: AI 未开始说话")
        return

    # 等待 AI 说到一半（收到足够 deltas）
    deadline = time.monotonic() + 15
    while ws_client.count_events(AUDIO_DELTA_EVENT) < min_deltas:
        if time.monotonic() > deadline:
            print(f"    跳过 {case.case_name}: AI 未输出足够音频")
            return
        await asyncio.sleep(0.05)

    # 注入打断音频
    t_inject_first, t_inject_last = await ws_client.inject_audio(case.interrupt_audio)

    # 注入静默
    await ws_client.inject_silence(3.0)

    # 检查是否被打断
    interrupted = ws_client.has_event_after(
        "response.done", t_inject_first,
        lambda e: e.get("response", {}).get("status") == "cancelled",
    )
    if not interrupted:
        interrupted = ws_client.has_event_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )

    # 检查是否恢复
    recovered = False
    latency = -1.0
    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        if ws_client.has_event_after(
            "agent.state_changed", t_inject_last,
            predicate=lambda e: e.get("state") in ("speaking", "thinking"),
        ):
            recovered = True
            t_recovery = ws_client.get_event_time_after(
                "agent.state_changed", t_inject_last,
                predicate=lambda e: e.get("state") in ("speaking", "thinking"),
            )
            if t_recovery:
                latency = (t_recovery - t_inject_last) * 1000
            break
        await asyncio.sleep(0.1)

    result = EvaluationResult(
        task="barge_in_recovery",
        case_name=case.case_name,
        tor=1.0 if interrupted and recovered else 0.0,
        latency=latency,
    )
    metrics_aggregator.add_result(result)

    status = "✓" if recovered else "✗"
    print(f"    {status} {case.case_name}: tor={result.tor}, recovered={recovered}, latency={latency:.1f}ms" if latency > 0 else f"    {status} {case.case_name}: tor={result.tor}, recovered={recovered}")
"""BigBench 数据集加载 - 支持 Hugging Face

从 Hugging Face Hub 加载 ArtificialAnalysis/big_bench_audio 数据集

使用方法:
    from dataset_hf import BigBenchHFDataset

    # 加载数据（含音频）
    dataset = BigBenchHFDataset.load()

    for case in dataset:
        audio_bytes = case.audio  # 已经是 PCM/WAV 格式
        print(case.question)
"""

import logging
from pathlib import Path
from typing import List, Optional, Literal

import numpy as np
from datasets import load_dataset, Dataset

from .case import BigBenchCase

logger = logging.getLogger(__name__)

# Hugging Face 数据集信息
HF_DATASET_NAME = "ArtificialAnalysis/big_bench_audio"
HF_DATASET_SPLIT = "train"

# 数据集缓存目录（相对于当前文件位置）
HF_CACHE_DIR = Path(__file__).parent.parent / "datasets"


class BigBenchHFDataset:
    """从 Hugging Face 加载 Big Bench Audio 数据集

    数据集包含 1000 个语音推理测试题目，覆盖多种能力分类。
    每个题目包含：问题文本、答案、音频数据。
    """

    def __init__(self, cases: List[BigBenchCase]):
        self.cases = cases

    @classmethod
    def load(
        cls,
        category: Optional[Literal[
            "navigate", "counting", "logic", "arithmetic", "memory", "multi_turn"
        ]] = None,
        split: Optional[str] = "train",
        trust_remote_code: bool = True,
    ) -> "BigBenchHFDataset":
        """从 Hugging Face 加载数据集

        Args:
            category: 可选，按能力分类筛选
            split: 数据集分割，默认 "train"
            trust_remote_code: 是否信任远程代码

        Returns:
            BigBenchHFDataset 实例
        """
        logger.info(f"Loading dataset {HF_DATASET_NAME}...")

        hf_dataset = load_dataset(
            HF_DATASET_NAME,
            split=split,
            trust_remote_code=trust_remote_code,
            cache_dir=str(HF_CACHE_DIR),
        )

        cases = cls._convert_hf_dataset(hf_dataset)

        # 按分类筛选
        if category:
            cases = [c for c in cases if c.category == category]
            logger.info(f"Filtered to {len(cases)} cases for category '{category}'")

        return cls(cases)

    @classmethod
    def _convert_hf_dataset(cls, hf_dataset: Dataset) -> List[BigBenchCase]:
        """将 Hugging Face 数据集转换为 BigBenchCase 列表

        数据集列通常包含:
        - id: 唯一标识
        - category: 能力分类
        - question: 问题文本
        - answer: 答案
        - audio: 音频数据 (dict with 'array', 'sampling_rate')
        - difficulty: 难度（可选）
        """
        cases = []
        features = hf_dataset.features
        logger.info(f"Dataset features: {features}")

        for item in hf_dataset:
            try:
                case = cls._parse_item(item)
                if case:
                    cases.append(case)
            except Exception as e:
                logger.warning(f"Failed to parse item {item.get('id', 'unknown')}: {e}")

        logger.info(f"Converted {len(cases)} cases from Hugging Face dataset")
        return cases

    @classmethod
    def _parse_item(cls, item: dict) -> Optional[BigBenchCase]:
        """解析单个数据项"""
        item_id = item.get("id") if item.get("id") is not None else item.get("task_id") or str(item.get("idx", ""))

        question = (
            item.get("question") or
            item.get("official_question") or
            item.get("task") or
            item.get("text") or
            item.get("input") or
            item.get("prompt")
        )
        if not question:
            from pathlib import Path
            txt_path = Path(__file__).parent.parent / f"bigbench_{item_id}_en.txt"
            if txt_path.exists():
                question = txt_path.read_text().strip()

        # 获取答案
        answer = (
            item.get("official_answer") or
            item.get("answer") or
            item.get("target") or
            item.get("expected") or
            item.get("output")
        )
        if not answer:
            return None

        # 获取音频数据
        audio_data = item.get("audio")
        audio_bytes = None
        if audio_data is not None:
            if isinstance(audio_data, dict):
                import numpy as np
                array = audio_data.get("array")
                sampling_rate = audio_data.get("sampling_rate", 16000)
                if array is not None:
                    audio_bytes = cls._numpy_to_pcm(array, sampling_rate)
            elif hasattr(audio_data, 'get_all_samples'):
                samples = audio_data.get_all_samples()
                sampling_rate = samples.sample_rate
                tensor = samples.data
                if hasattr(tensor, 'numpy'):
                    array = tensor.numpy().squeeze()
                else:
                    array = tensor.squeeze()
                audio_bytes = cls._numpy_to_pcm(array, sampling_rate)

        # 获取分类
        category = (
            item.get("category") or
            item.get("type") or
            item.get("task_type") or
            cls._infer_category(question)
        )

        # 获取难度
        difficulty = item.get("difficulty") or item.get("level")

        case = BigBenchCase(
            id=str(item_id),
            category=str(category) if category else "unknown",
            question=str(question),
            answer=str(answer),
            tts_text=None,  # 使用原始音频，不需要 TTS
            difficulty=str(difficulty) if difficulty else None,
            reasoning_steps=item.get("reasoning_steps") or item.get("steps"),
        )
        # 将音频附加到 case 对象
        if audio_bytes:
            case._audio_bytes = audio_bytes

        return case

    @staticmethod
    def _numpy_to_pcm(array, sampling_rate: int) -> bytes:
        """将 numpy 数组转换为 PCM 字节

        Args:
            array: numpy float32 数组，范围 [-1, 1]
            sampling_rate: 采样率

        Returns:
            PCM 16bit 字节数据
        """
        # 转换为 16bit 整数
        if array.dtype == np.float32 or array.dtype == np.float64:
            # 归一化到 [-1, 1] 然后转换为 int16
            array = np.clip(array, -1.0, 1.0)
            int_array = (array * 32767).astype(np.int16)
        else:
            int_array = array.astype(np.int16)

        # 如果采样率不是 16kHz，需要重采样
        if sampling_rate != 16000:
            int_array = BigBenchHFDataset._resample(int_array, sampling_rate, 16000)

        # 转换为字节
        return int_array.tobytes()

    @staticmethod
    def _resample(audio: np.ndarray, orig_sr: int, target_sr: int) -> np.ndarray:
        """简单重采样（仅支持整数倍或简单降采样）

        实际使用时推荐用 librosa 或 scipy
        """
        if orig_sr == target_sr:
            return audio

        ratio = target_sr / orig_sr
        if ratio == int(ratio):  # 整数倍升采样
            return np.repeat(audio, int(ratio))
        else:  # 降采样（简单抽取）
            return audio[::int(1 / ratio)]

    @classmethod
    def _infer_category(cls, question: str) -> str:
        """根据问题内容推断分类"""
        question_lower = question.lower()

        if any(kw in question_lower for kw in ["step", "turn", "direction", "facing", "north", "south", "east", "west"]):
            return "navigate"
        if any(kw in question_lower for kw in ["how many", "count", "total", "have", "left", "remaining"]):
            return "counting"
        if any(kw in question_lower for kw in ["if all", "some", "therefore", "conclusion", "true", "false", "lying", "truth"]):
            return "logic"
        if any(kw in question_lower for kw in ["plus", "minus", "multiply", "divided", "multiplied", "added", "subtract"]):
            return "arithmetic"
        if any(kw in question_lower for kw in ["remember", "third", "first", "last", "sequence", "number"]):
            return "memory"
        if any(kw in question_lower for kw in ["first", "then", "now", "after", "finally"]):
            return "multi_turn"

        return "unknown"

    def filter_by_category(self, category: str) -> "BigBenchHFDataset":
        """按能力分类筛选"""
        cases = [c for c in self.cases if c.category == category]
        return BigBenchHFDataset(cases)

    def filter_by_difficulty(self, difficulty: str) -> "BigBenchHFDataset":
        """按难度筛选"""
        cases = [c for c in self.cases if c.difficulty == difficulty]
        return BigBenchHFDataset(cases)

    def filter_reasoning(self) -> "BigBenchHFDataset":
        """仅保留推理类题目"""
        cases = [c for c in self.cases if c.is_reasoning]
        return BigBenchHFDataset(cases)

    def __len__(self) -> int:
        return len(self.cases)

    def __iter__(self):
        return iter(self.cases)

    def to_json(self) -> list[dict]:
        """导出为 JSON 格式（不含音频）"""
        return [
            {
                "id": c.id,
                "category": c.category,
                "question": c.question,
                "answer": c.answer,
                "difficulty": c.difficulty,
                "reasoning_steps": c.reasoning_steps,
            }
            for c in self.cases
        ]

    def save_to_json(self, file_path: str) -> None:
        """保存到 JSON 文件"""
        import json
        from pathlib import Path

        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump({"cases": self.to_json()}, f, indent=2, ensure_ascii=False)

        logger.info(f"Saved {len(self.cases)} cases to {file_path}")
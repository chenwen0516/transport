"""Full-Duplex-Bench 实时评估测试

通过 WebSocket URL 连接远程模型，运行打断/话轮转换等场景测试。

测试维度:
1. user_interruption  - 用户打断
2. barge_in_recovery  - 打断后恢复
3. pause_handling     - 停顿处理
4. smooth_turn_taking - 话轮转换

用法:
    # 设置环境变量
    export WS_URL="wss://api.health.com/v1/realtime?model=health-assistant"
    export AUTH_TOKEN="your-token-here"

    # 运行测试 (pytest会自动发现conftest.py)
    pytest test_fdb_realtime.py -v

    # 或直接运行
    python test_fdb_realtime.py
"""

import asyncio
import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

import pytest
import pytest_asyncio

# ========== 路径设置 ==========
# 由于FDB和realtime都有core目录,需要特殊处理导入
FDB_DIR = Path(__file__).parent
REALTIME_DIR = FDB_DIR.parent / "realtime"

# 添加到sys.path
if str(REALTIME_DIR) not in sys.path:
    sys.path.insert(0, str(REALTIME_DIR))
if str(FDB_DIR) not in sys.path:
    sys.path.insert(0, str(FDB_DIR))

# ========== 导入处理 ==========
# 关键: 先加载realtime模块,再加载FDB的core.metrics
# 因为Python会缓存core模块,如果先加载FDB的core,再加载realtime的core.ws_test_client会失败

import sys
from pathlib import Path

REALTIME_DIR = Path(__file__).parent.parent / "realtime"
FDB_DIR = Path(__file__).parent

# 确保realtime在sys.path前面
if str(REALTIME_DIR) not in sys.path:
    sys.path.insert(0, str(REALTIME_DIR))

# 先导入realtime的模块(使用相对路径直接加载)
import importlib.util

def load_spec(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

# 加载realtime模块
_rt_ws = load_spec("core.ws_test_client", REALTIME_DIR / "core" / "ws_test_client.py")
RealtimeTestClient = _rt_ws.RealtimeTestClient

_rt_audio = load_spec("core.audio_generator", REALTIME_DIR / "core" / "audio_generator.py")
AudioGenerator = _rt_audio.AudioGenerator

# 现在加载FDB的metrics(使用正常的import)
sys.path.insert(0, str(FDB_DIR))
from core.metrics import MetricsAggregator, EvaluationResult

# ========== 配置 ==========
WS_URL = os.getenv("WS_URL", "wss://api.health.com/v1/realtime?model=health-assistant")
AUTH_TOKEN = os.getenv("AUTH_TOKEN", "")

AUDIO_DELTA_EVENT = "response.output_audio.delta"
MIN_DELAY_S = 0.5


# ========== 测试用例定义 ==========

@dataclass
class InterruptionCase:
    name: str
    description: str
    audio_type: str
    audio_duration_s: float
    inject_after_deltas: int
    expect_interrupt: bool


@dataclass
class BargeInRecoveryCase:
    name: str
    description: str
    barge_audio_type: str
    barge_audio_duration_s: float
    inject_after_deltas: int
    post_silence_s: float
    expect_interrupt: bool
    expect_recovery: bool


@dataclass
class PauseHandlingCase:
    name: str
    description: str
    segments: list
    expect_turn_switch: Optional[bool] = None


@dataclass
class SmoothTurnTakingCase:
    name: str
    description: str
    user_speech_duration_s: float
    expect_switch: bool


# ========== 测试数据集 ==========

INTERRUPTION_CASES = [
    InterruptionCase(
        name="interruption_001",
        description="AI 说完一句话前被打断",
        audio_type="speech_like",
        audio_duration_s=1.5,
        inject_after_deltas=10,
        expect_interrupt=True,
    ),
    InterruptionCase(
        name="interruption_002",
        description="AI 说话中途被打断",
        audio_type="speech_like",
        audio_duration_s=2.0,
        inject_after_deltas=15,
        expect_interrupt=True,
    ),
    InterruptionCase(
        name="interruption_003",
        description="AI 说话后期打断",
        audio_type="speech_like",
        audio_duration_s=1.0,
        inject_after_deltas=20,
        expect_interrupt=True,
    ),
]

BARGE_IN_RECOVERY_CASES = [
    BargeInRecoveryCase(
        name="barge_recovery_001",
        description="打断后 AI 正常恢复",
        barge_audio_type="speech_like",
        barge_audio_duration_s=1.5,
        inject_after_deltas=12,
        post_silence_s=3.0,
        expect_interrupt=True,
        expect_recovery=True,
    ),
]

PAUSE_HANDLING_CASES = [
    PauseHandlingCase(
        name="pause_001",
        description="短停顿后长停顿应切轮",
        segments=[
            {"type": "speech", "duration_s": 2.0},
            {"type": "silence", "duration_s": 0.3},
            {"type": "speech", "duration_s": 1.0},
            {"type": "silence", "duration_s": 5.0},
        ],
        expect_turn_switch=True,
    ),
]

SMOOTH_TURN_TAKING_CASES = [
    SmoothTurnTakingCase(
        name="turn_taking_001",
        description="用户说完 AI 应及时响应",
        user_speech_duration_s=2.0,
        expect_switch=True,
    ),
]


# ========== 辅助函数 ==========

def generate_audio(audio_type: str, duration_s: float) -> bytes:
    generators = {
        "speech_like": AudioGenerator.speech_like,
        "silence": AudioGenerator.silence,
        "white_noise": AudioGenerator.white_noise,
    }
    gen_func = generators.get(audio_type, AudioGenerator.speech_like)
    return gen_func(duration_s)


async def wait_for_agent_state(ws_client, state: str, timeout: float = 15.0):
    try:
        await ws_client.wait_for_agent_state(state, timeout=timeout)
        return True
    except asyncio.TimeoutError:
        return False


# ========== 测试用例实现 ==========

@pytest.mark.parametrize("case", INTERRUPTION_CASES, ids=[c.name for c in INTERRUPTION_CASES])
async def test_user_interruption(ws_client, ws_url, auth_token, case, metrics_aggregator):
    """用户打断测试"""
    await ws_client.connect(ws_url, auth_token)
    await wait_for_agent_state(ws_client, "speaking", timeout=15)

    deadline = time.monotonic() + 30
    while ws_client.count_events(AUDIO_DELTA_EVENT) < case.inject_after_deltas:
        if time.monotonic() > deadline:
            pytest.fail("Timeout waiting for audio deltas")
        await asyncio.sleep(0.05)

    pcm = generate_audio(case.audio_type, case.audio_duration_s)
    t_inject_first, t_inject_last = await ws_client.inject_audio(pcm)

    await ws_client.drain_events(timeout=10.0)

    interrupted = ws_client.has_event_after(
        "response.done", t_inject_first,
        lambda e: e.get("response", {}).get("status") == "cancelled",
    )
    if not interrupted:
        interrupted = ws_client.has_event_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )

    result = EvaluationResult(
        task="user_interruption",
        case_name=case.name,
        tor=1.0 if interrupted else 0.0,
        latency=max(0, t_inject_first - t_inject_last) if interrupted else -1.0,
    )
    metrics_aggregator.add_result(result)

    assert interrupted == case.expect_interrupt, (
        f"{case.name}: expect_interrupt={case.expect_interrupt}, actual={interrupted}"
    )


@pytest.mark.parametrize("case", BARGE_IN_RECOVERY_CASES, ids=[c.name for c in BARGE_IN_RECOVERY_CASES])
async def test_barge_in_recovery(ws_client, ws_url, auth_token, case, metrics_aggregator):
    """打断后恢复测试"""
    await ws_client.connect(ws_url, auth_token)
    await wait_for_agent_state(ws_client, "speaking", timeout=15)

    deadline = time.monotonic() + 30
    while ws_client.count_events(AUDIO_DELTA_EVENT) < case.inject_after_deltas:
        if time.monotonic() > deadline:
            pytest.fail("Timeout waiting for audio deltas")
        await asyncio.sleep(0.05)

    pcm = generate_audio(case.barge_audio_type, case.barge_audio_duration_s)
    t_inject_first, t_inject_last = await ws_client.inject_audio(pcm)

    await ws_client.inject_silence(case.post_silence_s)

    interrupted = ws_client.has_event_after(
        "response.done", t_inject_first,
        lambda e: e.get("response", {}).get("status") == "cancelled",
    )
    if not interrupted:
        interrupted = ws_client.has_event_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )

    assert interrupted == case.expect_interrupt, (
        f"{case.name}: 打断预期={case.expect_interrupt}, 实际={interrupted}"
    )

    recovered = False
    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        if ws_client.has_event_after(
            "agent.state_changed", t_inject_last,
            predicate=lambda e: e.get("state") in ("speaking", "thinking"),
        ):
            recovered = True
            break
        await asyncio.sleep(0.1)

    assert recovered == case.expect_recovery, (
        f"{case.name}: 恢复预期={case.expect_recovery}, 实际={recovered}"
    )

    result = EvaluationResult(
        task="barge_in_recovery",
        case_name=case.name,
        tor=1.0 if interrupted else 0.0,
        latency=max(0, t_inject_first - t_inject_last) if interrupted else -1.0,
    )
    metrics_aggregator.add_result(result)


@pytest.mark.parametrize("case", PAUSE_HANDLING_CASES, ids=[c.name for c in PAUSE_HANDLING_CASES])
async def test_pause_handling(ws_client, ws_url, auth_token, case, metrics_aggregator):
    """停顿处理测试"""
    await ws_client.connect(ws_url, auth_token)
    await wait_for_agent_state(ws_client, "listening", timeout=30)
    ws_client.clear_events()

    t_last_silence_start = None
    for i, seg in enumerate(case.segments):
        if seg["type"] == "speech":
            pcm = generate_audio("speech_like", seg["duration_s"])
            await ws_client.inject_audio(pcm)
        elif seg["type"] == "silence":
            t_silence_start = time.monotonic()
            await ws_client.inject_silence(seg["duration_s"])
            if i == len(case.segments) - 1:
                t_last_silence_start = t_silence_start

    t_all_sent = time.monotonic()
    await ws_client.drain_events(timeout=10.0)

    t_ref = t_last_silence_start if t_last_silence_start else t_all_sent - 0.5

    switched = ws_client.has_event_after(
        "agent.state_changed", t_ref,
        predicate=lambda e: e.get("state") == "speaking",
    )

    t_thinking = ws_client.get_event_time_after(
        "agent.state_changed", t_ref,
        predicate=lambda e: e.get("state") == "thinking",
    )

    latency = None
    if t_thinking:
        latency = (t_thinking - (t_last_silence_start or t_all_sent)) * 1000

    result = EvaluationResult(
        task="pause_handling",
        case_name=case.name,
        tor=1.0 if switched else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    if case.expect_turn_switch is not None:
        assert switched == case.expect_turn_switch, (
            f"{case.name}: expect_switch={case.expect_turn_switch}, actual={switched}"
        )


@pytest.mark.parametrize("case", SMOOTH_TURN_TAKING_CASES, ids=[c.name for c in SMOOTH_TURN_TAKING_CASES])
async def test_smooth_turn_taking(ws_client, ws_url, auth_token, case, metrics_aggregator):
    """话轮转换测试"""
    await ws_client.connect(ws_url, auth_token)
    await wait_for_agent_state(ws_client, "listening", timeout=30)
    ws_client.clear_events()

    pcm = generate_audio("speech_like", case.user_speech_duration_s)
    t_user_first, t_user_last = await ws_client.inject_audio(pcm)

    await ws_client.inject_silence(0.1)

    t_user_end = time.monotonic()
    await ws_client.drain_events(timeout=10.0)

    switched = ws_client.has_event_after(
        "agent.state_changed", t_user_end,
        predicate=lambda e: e.get("state") == "speaking",
    )

    if not switched:
        extended_deadline = time.monotonic() + 30.0
        while time.monotonic() < extended_deadline:
            if ws_client.has_event_after(
                "agent.state_changed", t_user_end,
                predicate=lambda e: e.get("state") in ("speaking", "thinking"),
            ):
                switched = True
                break
            await asyncio.sleep(0.2)

    t_thinking = ws_client.get_event_time_after(
        "agent.state_changed", t_user_end,
        predicate=lambda e: e.get("state") == "thinking",
    )

    latency = None
    if t_thinking:
        latency = (t_thinking - t_user_end) * 1000

    result = EvaluationResult(
        task="smooth_turn_taking",
        case_name=case.name,
        tor=1.0 if switched else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    assert switched == case.expect_switch, (
        f"{case.name}: expect_switch={case.expect_switch}, actual={switched}"
    )


# ========== Fixtures ==========

@pytest_asyncio.fixture(autouse=True)
async def suppress_websockets_rst_noise():
    loop = asyncio.get_running_loop()
    original_handler = loop.get_exception_handler()

    def _handler(loop, context):
        exc = context.get("exception")
        if isinstance(exc, AttributeError) and "recv_messages" in str(exc):
            return
        if original_handler is not None:
            original_handler(loop, context)
        else:
            loop.default_exception_handler(context)

    loop.set_exception_handler(_handler)
    yield
    loop.set_exception_handler(original_handler)


@pytest_asyncio.fixture
async def ws_client():
    client = RealtimeTestClient()
    yield client
    try:
        await client.disconnect()
    except Exception:
        pass


@pytest.fixture(scope="session")
def metrics_aggregator():
    return MetricsAggregator()


@pytest.fixture
def ws_url():
    return WS_URL


@pytest.fixture
def auth_token():
    return AUTH_TOKEN


# ========== 主函数 ==========

async def main():
    print("=" * 60)
    print("Full-Duplex-Bench 实时评估测试")
    print("=" * 60)
    print(f"WS URL: {WS_URL}")
    print(f"AUTH_TOKEN: {'*' * 20 if AUTH_TOKEN else '(not set)'}")
    print("-" * 60)

    if not AUTH_TOKEN:
        print("警告: AUTH_TOKEN 未设置，连接可能会失败\n")

    metrics_aggregator = MetricsAggregator()

    test_dimensions = [
        ("用户打断", INTERRUPTION_CASES, "user_interruption"),
        ("打断后恢复", BARGE_IN_RECOVERY_CASES, "barge_in_recovery"),
        ("停顿处理", PAUSE_HANDLING_CASES, "pause_handling"),
        ("话轮转换", SMOOTH_TURN_TAKING_CASES, "smooth_turn_taking"),
    ]

    for dimension_name, cases, task_name in test_dimensions:
        print(f"\n{'=' * 40}")
        print(f"测试维度: {dimension_name}")
        print(f"{'=' * 40}")

        for case in cases:
            print(f"\n  运行: {case.name} - {case.description}")
            ws_client = RealtimeTestClient()

            try:
                if task_name == "user_interruption":
                    await test_user_interruption(ws_client, WS_URL, AUTH_TOKEN, case, metrics_aggregator)
                elif task_name == "barge_in_recovery":
                    await test_barge_in_recovery(ws_client, WS_URL, AUTH_TOKEN, case, metrics_aggregator)
                elif task_name == "pause_handling":
                    await test_pause_handling(ws_client, WS_URL, AUTH_TOKEN, case, metrics_aggregator)
                elif task_name == "smooth_turn_taking":
                    await test_smooth_turn_taking(ws_client, WS_URL, AUTH_TOKEN, case, metrics_aggregator)

                print(f"    ✓ {case.name} 通过")
            except AssertionError as e:
                print(f"    ✗ {case.name} 断言失败: {e}")
            except Exception as e:
                print(f"    ✗ {case.name} 错误: {e}")
            finally:
                try:
                    await ws_client.disconnect()
                except Exception:
                    pass
                await asyncio.sleep(1)

    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)

    summary = metrics_aggregator.summary()
    print(f"总测试数: {summary.get('total', 0)}")
    if summary.get("tor", {}).get("mean") is not None:
        print(f"TOR: {summary['tor']['mean']:.4f} ± {summary['tor']['std']:.4f}")
    if summary.get("latency", {}).get("mean") is not None:
        print(f"Latency: {summary['latency']['mean']:.4f}s ± {summary['latency']['std']:.4f}s")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = Path(f"output/fdb_realtime_results_{timestamp}.json")
    output_path.parent.mkdir(exist_ok=True)
    metrics_aggregator.save_results(str(output_path))
    print(f"\n结果已保存: {output_path}")


if __name__ == "__main__":
    asyncio.run(main())

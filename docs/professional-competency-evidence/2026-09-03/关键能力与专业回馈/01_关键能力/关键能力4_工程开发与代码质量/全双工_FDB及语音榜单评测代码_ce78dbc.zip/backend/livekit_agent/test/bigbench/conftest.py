"""pytest fixtures for BigBench Speech Reasoning Benchmark"""

import asyncio
import os
from pathlib import Path

import pytest
import pytest_asyncio

from .ws_test_client import RealtimeTestClient
from .audio_generator import BigBenchAudioGenerator
from .dataset_hf import BigBenchHFDataset
from .metrics import BigBenchMetricsAggregator
from .report import print_terminal_report, save_json_report


# ========== 环境配置 ==========

def get_agent_mode() -> str:
    return os.getenv("AGENT_MODE", "real")


def get_ws_url() -> str:
    return os.getenv("WS_URL", "wss://api.health.com/v1/realtime?model=health-assistant")


def get_auth_token() -> str:
    return os.getenv("AUTH_TOKEN", "")


def get_tts_ws_url() -> str:
    return os.getenv("TTS_WS_URL", "ws://localhost:8080/api-ws/v1/realtime")


def get_judge_model() -> str:
    return os.getenv("JUDGE_MODEL", "gpt-4.1")


def get_judge_api_key() -> str:
    return os.getenv("JUDGE_API_KEY", "")


def get_hf_dataset_category() -> str | None:
    """从环境变量获取要加载的数据集分类"""
    return os.getenv("BIGBENCH_CATEGORY", None)


# ========== Fixtures ==========

@pytest_asyncio.fixture(autouse=True)
async def suppress_websockets_rst_noise():
    """静默 websockets 在 TCP RST 时触发的 recv_messages AttributeError"""
    loop = asyncio.get_running_loop()
    original_handler = loop.get_exception_handler()

    def _handler(loop, context):
        exc = context.get("exception")
        if isinstance(exc, AttributeError) and "recv_messages" in str(exc):
            return
        if original_handler is not None:
            original_handler(loop, context)
        else:
            loop.default_exception_handler(context)

    loop.set_exception_handler(_handler)
    yield
    loop.set_exception_handler(original_handler)


@pytest_asyncio.fixture
async def ws_client():
    """创建 WebSocket 测试客户端"""
    client = RealtimeTestClient()
    yield client
    await client.disconnect()


@pytest.fixture(scope="session")
def bigbench_dataset() -> BigBenchHFDataset:
    """从 Hugging Face 加载 BigBench 测试数据集

    使用 BIGBENCH_CATEGORY 环境变量指定分类，如：
    - navigate, counting, logic, arithmetic, memory, multi_turn
    - 不设置则加载全部 1000 个题目
    """
    category = get_hf_dataset_category()
    return BigBenchHFDataset.load(category=category)


@pytest.fixture(scope="session")
def metrics_aggregator():
    """session 级别的指标聚合器"""
    return BigBenchMetricsAggregator()


@pytest.fixture(scope="session", autouse=True)
def report_on_finish(metrics_aggregator):
    """测试结束后自动输出报告"""
    yield
    if metrics_aggregator.results:
        print_terminal_report(metrics_aggregator)
        save_json_report(
            metrics_aggregator,
            output_dir=str(Path(__file__).parent / "test_reports"),
            agent_mode=get_agent_mode(),
        )


@pytest.fixture
def ws_url():
    return get_ws_url()


@pytest.fixture
def auth_token():
    return get_auth_token()


@pytest.fixture
def agent_mode():
    return get_agent_mode()


@pytest.fixture
def tts_ws_url():
    return get_tts_ws_url()


@pytest.fixture
def bigbench_audio_generator(tts_ws_url) -> BigBenchAudioGenerator:
    """BigBench 音频生成器"""
    return BigBenchAudioGenerator(tts_url=tts_ws_url)


@pytest.fixture
def judge_config():
    return {
        "model": get_judge_model(),
        "api_key": get_judge_api_key(),
    }


# ========== pytest 配置 ==========

def pytest_collection_modifyitems(config, items):
    """根据 AGENT_MODE 自动跳过不匹配的测试"""
    mode = get_agent_mode()
    skip_mock = pytest.mark.skip(reason="Skipped in real mode")
    skip_real = pytest.mark.skip(reason="Skipped in mock mode")

    for item in items:
        if "mock_only" in item.keywords and mode != "mock":
            item.add_marker(skip_mock)
        elif "real_only" in item.keywords and mode != "real":
            item.add_marker(skip_real)
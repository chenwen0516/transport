"""Backchannel 测试

测试回指（短回复）能力
"""
import asyncio
import time

from core import (
    RealtimeTestClient,
    DatasetCase,
    EvaluationResult,
    MetricsAggregator,
)


async def test_backchannel_dataset(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case: DatasetCase,
    metrics_aggregator: MetricsAggregator,
    min_deltas: int = 10,
):
    """使用数据集音频测试回指（短回复）

    回指测试：在用户说话期间，AI 应及时发出短反馈（如"嗯""对"）。
    关键：边发送音频边检测 AI 响应，而不是等音频发完再检测。
    """
    if not case.input_audio:
        print(f"    跳过 {case.case_name}: 无 input_audio")
        metrics_aggregator.add_result(EvaluationResult(
            task="backchannel",
            case_name=case.case_name,
            success=False,
            error="missing input audio",
        ))
        return

    await ws_client.connect(ws_url, auth_token)
    ws_client.clear_events()

    t_start = time.monotonic()

    # 边发送音频边检测 AI 响应（并发进行）
    send_task = await ws_client.inject_audio_nonblocking(case.input_audio)

    backchannel_success = False
    first_delta_time = None

    # 发送期间持续检测 AI 音频输出
    while not send_task.done():
        delta = ws_client.get_event_time_after("response.output_audio.delta", t_start)
        if delta:
            first_delta_time = delta
            break
        await asyncio.sleep(0.05)

    # 等待发送完成
    await send_task

    if first_delta_time is None:
        deadline = time.monotonic() + 1.5
        while time.monotonic() < deadline:
            first_delta_time = ws_client.get_event_time_after("response.output_audio.delta", t_start)
            if first_delta_time is not None:
                break
            await asyncio.sleep(0.05)

    latency = None
    if first_delta_time is not None:
        latency = (first_delta_time - t_start) * 1000
        if latency <= 3000:
            backchannel_success = True

    result = EvaluationResult(
        task="backchannel",
        case_name=case.case_name,
        tor=1.0 if backchannel_success else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    status = "✓" if backchannel_success else "✗"
    print(f"    {status} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency else f"    {status} {case.case_name}: tor={result.tor}")

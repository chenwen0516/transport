"""数据集加载模块"""
import json
from pathlib import Path
from typing import Optional

import numpy as np

from .case import DatasetCase


def load_wav_audio(wav_path: Path) -> Optional[bytes]:
    """读取 wav 文件并返回 PCM 16-bit 数据

    支持 16-bit PCM, 24-bit PCM, 32-bit float
    """
    try:
        import struct

        with open(wav_path, 'rb') as f:
            riff = f.read(4)
            if riff != b'RIFF':
                return None

            f.read(4)  # file_size
            wave_id = f.read(4)
            if wave_id != b'WAVE':
                return None

            sampwidth = None
            raw_data = None

            while True:
                chunk_header = f.read(8)
                if len(chunk_header) < 8:
                    break
                chunk_id = chunk_header[0:4]
                chunk_size = struct.unpack('<I', chunk_header[4:8])[0]

                if chunk_id == b'fmt ':
                    fmt_data = f.read(chunk_size)
                    if len(fmt_data) >= 16:
                        bits_per_sample = struct.unpack('<H', fmt_data[14:16])[0]
                        sampwidth = bits_per_sample // 8
                elif chunk_id == b'data':
                    raw_data = f.read(chunk_size)
                else:
                    f.read(chunk_size)

            if sampwidth is None or raw_data is None:
                return None

            if sampwidth == 2:
                return raw_data

            if sampwidth == 3:
                result = bytearray()
                for i in range(0, len(raw_data) - 2, 3):
                    val = raw_data[i] | (raw_data[i+1] << 8) | (raw_data[i+2] << 16)
                    if val >= 0x800000:
                        val -= 0x1000000
                    val = val >> 8
                    result.extend(struct.pack('<h', val))
                return bytes(result)

            if sampwidth == 4:
                audio_data = np.frombuffer(raw_data, dtype=np.float32)
                audio_data = np.clip(audio_data, -1.0, 1.0)
                audio_int16 = (audio_data * 32767).astype(np.int16)
                return audio_int16.tobytes()

            return None
    except Exception:
        return None


def load_pcm_audio(pcm_path: Path) -> Optional[bytes]:
    """读取 16 kHz/16-bit/mono PCM 文件。"""
    try:
        data = pcm_path.read_bytes()
        return data or None
    except Exception:
        return None


def load_audio_file(path: Path) -> Optional[bytes]:
    """按文件后缀读取音频，返回 16-bit PCM 数据。"""
    if not path.exists():
        return None
    if path.suffix.lower() == ".wav":
        return load_wav_audio(path)
    if path.suffix.lower() == ".pcm":
        return load_pcm_audio(path)
    return None


def first_existing(sample_dir: Path, names: list[str]) -> Optional[Path]:
    for name in names:
        path = sample_dir / name
        if path.exists():
            return path
    return None


def load_dataset_cases(dataset_root: Path, task: str) -> list[DatasetCase]:
    """加载数据集测试用例

    Args:
        dataset_root: 数据集根目录，如 /path/to/v1.0/synthetic_user_interruption
        task: 任务类型
    """
    cases = []

    for sample_dir in sorted(dataset_root.iterdir()):
        if not sample_dir.is_dir():
            continue

        case_name = f"{dataset_root.name}/{sample_dir.name}"

        case = DatasetCase(
            sample_dir=sample_dir,
            case_name=case_name,
            task=task,
        )

        input_audio_path = first_existing(
            sample_dir,
            ["input.wav", "input.pcm", "user_audio.wav", "user_audio.pcm"],
        )
        if input_audio_path:
            case.input_audio = load_audio_file(input_audio_path)

        interrupt_audio_path = first_existing(
            sample_dir,
            ["interrupt.wav", "interrupt.pcm", "user_audio.wav", "user_audio.pcm"],
        )
        if interrupt_audio_path:
            case.interrupt_audio = load_audio_file(interrupt_audio_path)

        interrupt_json = sample_dir / "interrupt.json"
        if interrupt_json.exists():
            try:
                with open(interrupt_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if data and len(data) > 0:
                        case.interrupt_timestamp = data[0].get("timestamp")
                        case.interrupt_text = data[0].get("interrupt", "") or data[0].get("text", "")
            except Exception:
                pass

        pause_json = sample_dir / "pause.json"
        if pause_json.exists():
            try:
                with open(pause_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if data and len(data) > 0:
                        case.pause_timestamp = data[0].get("timestamp")
            except Exception:
                pass

        turn_taking_json = sample_dir / "turn_taking.json"
        if turn_taking_json.exists():
            try:
                with open(turn_taking_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if data and len(data) > 0:
                        case.turn_taking_timestamp = data[0].get("timestamp")
            except Exception:
                pass

        metadata_json = sample_dir / "metadata.json"
        if metadata_json.exists():
            try:
                with open(metadata_json, 'r', encoding='utf-8') as f:
                    case.metadata = json.load(f)
            except Exception:
                pass

        if case.input_audio:
            cases.append(case)

    return cases

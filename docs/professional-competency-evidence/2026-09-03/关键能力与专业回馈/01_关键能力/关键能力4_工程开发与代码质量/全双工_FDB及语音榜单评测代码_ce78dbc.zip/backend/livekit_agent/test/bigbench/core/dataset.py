"""BigBench 数据集加载"""

import json
from pathlib import Path
from typing import List

from .case import BigBenchCase


class BigBenchDataset:
    """BigBench 测试数据集

    从目录加载测试用例，支持 JSON 格式。
    """

    def __init__(self, cases: List[BigBenchCase]):
        self.cases = cases

    @classmethod
    def from_dir(cls, dataset_dir: Path) -> "BigBenchDataset":
        """从目录加载所有测试用例

        目录结构：
        dataset_dir/
            cases.json          # 主测试集
            cases_mini.json     # 小规模测试集
        """
        all_cases = []

        # 加载主测试集
        cases_file = dataset_dir / "cases.json"
        if cases_file.exists():
            all_cases.extend(cls._load_json(cases_file))

        # 加载小规模测试集（用于快速验证）
        mini_file = dataset_dir / "cases_mini.json"
        if mini_file.exists():
            all_cases.extend(cls._load_json(mini_file))

        return cls(all_cases)

    @classmethod
    def _load_json(cls, file_path: Path) -> List[BigBenchCase]:
        """从 JSON 文件加载用例"""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        cases = []
        for item in data.get("cases", []):
            cases.append(BigBenchCase(
                id=item["id"],
                category=item["category"],
                question=item["question"],
                answer=item["answer"],
                tts_text=item.get("tts_text"),
                difficulty=item.get("difficulty"),
                reasoning_steps=item.get("reasoning_steps"),
            ))
        return cases

    def filter_by_category(self, category: str) -> "BigBenchDataset":
        """按能力分类筛选"""
        cases = [c for c in self.cases if c.category == category]
        return BigBenchDataset(cases)

    def filter_by_difficulty(self, difficulty: str) -> "BigBenchDataset":
        """按难度筛选"""
        cases = [c for c in self.cases if c.difficulty == difficulty]
        return BigBenchDataset(cases)

    def filter_reasoning(self) -> "BigBenchDataset":
        """仅保留推理类题目"""
        cases = [c for c in self.cases if c.is_reasoning]
        return BigBenchDataset(cases)

    def __len__(self) -> int:
        return len(self.cases)

    def __iter__(self):
        return iter(self.cases)
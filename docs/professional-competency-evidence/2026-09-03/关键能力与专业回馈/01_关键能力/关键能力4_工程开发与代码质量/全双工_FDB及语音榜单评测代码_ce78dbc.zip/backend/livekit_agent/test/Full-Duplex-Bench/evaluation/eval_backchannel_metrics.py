"""Backchannel 指标计算脚本

计算 TOR（抢话率）、Freq（回指频率）和 JSD（时间分布差异）

支持两种模式：
1. VAD-only（简化）：只使用 Silero VAD 检测语音段
2. ASR（完整）：使用阿里云 ASR 转写 + VAD，获得词级时间戳

用法:
    # VAD-only 模式（快速）
    python eval_backchannel_metrics.py --wav ./output.wav --spk_id 2 --gt ./icc_gt_distribution.json

    # ASR 模式（精确）
    python eval_backchannel_metrics.py --wav ./output.wav --spk_id 2 --gt ./icc_gt_distribution.json --use_asr --token xxx --appkey xxx

    # 批量计算
    python eval_backchannel_metrics.py --root_dir ./backchannel --gt ./icc_gt_distribution.json --limit 10
"""

import argparse
import json
import os
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import wave as wave_module
from scipy.spatial.distance import jensenshannon

# ========== 常量 ==========
WINDOW_SIZE = 0.2  # 时间窗口（秒）
EPSILON = 1e-10
TIME_THRESHOLD = 3.0  # 回指阈值（秒），>3s 算正式发言
TURN_DURATION_THRESHOLD = 1.0  # TOR 计算：时长阈值（秒）
TURN_NUM_WORDS_THRESHOLD = 3  # TOR 计算：词数阈值

# 阿里云 ASR 配置
ALIYUN_ASR_APPKEY = os.getenv("ALIYUN_ASR_APPKEY", "VUTr8CYqTIVZc9lJ")
ALIYUN_ASR_TOKEN = os.getenv("ALIYUN_ASR_TOKEN", "415ad58c8ce64808a1dd9763f3dd9985")


# ========== VAD 加载 ==========

def load_silero_vad():
    """加载 Silero VAD 模型"""
    try:
        from silero_vad import get_speech_timestamps
        model, utils = torch.hub.load(
            repo_or_dir="snakers4/silero-vad",
            model="silero_vad",
            trust_repo=True,
            onnx=False
        )
        get_speech_ts = utils[0]
        return model, get_speech_ts
    except Exception as e:
        raise ImportError(f"需要安装 silero-vad: pip install silero-vad. Error: {e}")


# ========== 核心计算 ==========

def detect_backchannels(wav_path: str) -> tuple[list, float]:
    """检测音频中的回指（短语音段）

    Returns:
        (backchannel_segments, total_duration)
    """
    import wave

    # 使用 wave 模块读取 PCM
    with wave.open(wav_path, 'rb') as wf:
        n_channels = wf.getnchannels()
        sampwidth = wf.getsampwidth()
        sr = wf.getframerate()
        n_frames = wf.getnframes()
        raw_data = wf.readframes(n_frames)

    # 转换为 numpy 数组
    import numpy as np
    audio_data = np.frombuffer(raw_data, dtype=np.int16).astype(np.float32) / 32768.0

    # 单声道
    if n_channels > 1:
        audio_data = audio_data.reshape(-1, n_channels).mean(axis=1)

    model, get_speech_ts = load_silero_vad()
    speech_ts = get_speech_ts(audio_data, model, sampling_rate=sr)

    backchannels = []
    total_duration = len(audio_data) / sr

    for seg in speech_ts:
        start_time = seg["start"] / sr
        end_time = seg["end"] / sr
        duration = end_time - start_time

        if duration <= TIME_THRESHOLD:
            backchannels.append([start_time, end_time])

    return backchannels, total_duration


def build_time_distribution(segments: list, total_duration: float, window_size: float = WINDOW_SIZE) -> np.ndarray:
    """根据语音段构建时间分布

    Args:
        segments: [[start, end], ...]
        total_duration: 总时长（秒）
        window_size: 时间窗口大小（秒）

    Returns:
        归一化的时间分布数组
    """
    num_bins = int(total_duration / window_size) + 1
    time_intervals = [0.0] * num_bins

    for start, end in segments:
        start_bin = int(start / window_size)
        end_bin = int(end / window_size)
        for i in range(start_bin, end_bin + 1):
            if i < num_bins:
                time_intervals[i] += 1

    time_intervals = np.array(time_intervals, dtype=float)

    if time_intervals.sum() == 0:
        return np.ones(num_bins) / num_bins

    time_intervals = time_intervals + EPSILON
    time_intervals = time_intervals / time_intervals.sum()

    return time_intervals


def calculate_freq(backchannels: list, total_duration: float) -> float:
    """计算回指频率（次/秒）"""
    if total_duration <= 0:
        return 0.0
    return len(backchannels) / total_duration


def calculate_jsd(pred_dist: np.ndarray, gt_dist: np.ndarray) -> float:
    """计算 JSD 散度

    Args:
        pred_dist: 预测分布
        gt_dist: Ground truth 分布
    """
    # 确保长度一致，使用插值
    if len(pred_dist) != len(gt_dist):
        from scipy.interpolate import interp1d
        x_pred = np.linspace(0, 1, len(pred_dist))
        x_gt = np.linspace(0, 1, len(gt_dist))
        interp_func = interp1d(x_gt, gt_dist, kind="linear", fill_value="extrapolate")
        gt_resized = interp_func(x_pred)
        gt_dist = gt_resized

    pred_dist = np.array(pred_dist, dtype=float)
    gt_dist = np.array(gt_dist, dtype=float)

    # 确保归一化
    pred_dist = pred_dist / (pred_dist.sum() + EPSILON)
    gt_dist = gt_dist / (gt_dist.sum() + EPSILON)

    return float(jensenshannon(pred_dist, gt_dist))


def calculate_tor_from_asr(words: list) -> int:
    """根据 ASR 词级时间戳计算 TOR（精确版）

    TOR=1 表示抢话（AI 发了长回复）
    TOR=0 表示只是回指

    原始 benchmark 逻辑：
    - duration < 1.0s AND words <= 3 -> TOR = 0（短+少词 = 回指）
    - 否则 -> TOR = 1（抢话）
    """
    if not words:
        return 0

    first_start = words[0]["start_time"]
    last_end = words[-1]["end_time"]
    duration = last_end - first_start
    num_words = len(words)

    if duration < TURN_DURATION_THRESHOLD and num_words <= TURN_NUM_WORDS_THRESHOLD:
        return 0
    return 1


def calculate_tor_from_segments(segments: list) -> int:
    """根据语音段判断 TOR（二进制，简化版）

    TOR=1 表示抢话（AI 发了长回复）
    TOR=0 表示只是回指
    """
    for start, end in segments:
        duration = end - start
        if duration > TIME_THRESHOLD:
            return 1  # 有超过 3s 的段，算抢话
    return 0  # 否则只是回指


# ========== ASR 客户端 ==========

def transcribe_with_aliyun(
    wav_path: str,
    app_key: str,
    token: str,
    enable_words: bool = True
) -> dict:
    """使用阿里云 ASR 转写音频

    Returns:
        {"success": bool, "text": str, "words": [{"word": str, "start_time": float, "end_time": float}], "error": str}
    """
    import nls

    sentences = []
    all_words = []

    def on_sentence_begin(msg, *args):
        try:
            data = json.loads(msg)
            payload = data.get("payload", {})
            start_time = payload.get("time", 0) / 1000.0
            sentences.append({
                "start_time": start_time,
                "text": "",
                "end_time": None,
                "word_list": [],
            })
        except (json.JSONDecodeError, KeyError):
            pass

    def on_sentence_end(msg, *args):
        try:
            msg_bytes = msg.encode('utf-8')
            data = json.loads(msg)
            payload = data.get("payload", {})

            if sentences:
                last = sentences[-1]
                last["end_time"] = payload.get("time", 0) / 1000.0

                # 提取文本
                start_marker = b'"result":"'
                end_marker = b'","confidence"'
                start_idx = msg_bytes.find(start_marker)
                if start_idx != -1:
                    start_idx += len(start_marker)
                    end_idx = msg_bytes.find(end_marker, start_idx)
                    if end_idx != -1:
                        raw_bytes = msg_bytes[start_idx:end_idx]
                        last["text"] = raw_bytes.decode('utf-8')

                # 提取词级时间戳
                words_start = msg_bytes.find(b'"words":[')
                if words_start != -1:
                    array_start = words_start + len(b'"words":[')
                    bracket_end = msg_bytes.find(b']', array_start)
                    if bracket_end == -1:
                        bracket_end = len(msg_bytes)

                    pos = array_start
                    while pos < bracket_end:
                        text_marker = msg_bytes.find(b'"text":"', pos)
                        if text_marker == -1 or text_marker >= bracket_end:
                            break
                        text_start = text_marker + len(b'"text":"')
                        end_marker_pos = msg_bytes.find(b'",', text_start)
                        if end_marker_pos == -1 or end_marker_pos >= bracket_end:
                            break
                        text_bytes = msg_bytes[text_start:end_marker_pos]
                        word_text = text_bytes.decode('utf-8', errors='replace')

                        start_marker_pos = msg_bytes.find(b'"startTime":', end_marker_pos)
                        if start_marker_pos == -1 or start_marker_pos >= bracket_end:
                            break
                        start_pos = start_marker_pos + len(b'"startTime":')
                        comma_pos = msg_bytes.find(b',', start_pos)
                        if comma_pos == -1 or comma_pos >= bracket_end:
                            comma_pos = bracket_end - 1
                        start_time = int(msg_bytes[start_pos:comma_pos]) / 1000.0

                        end_marker_pos2 = msg_bytes.find(b'"endTime":', comma_pos)
                        if end_marker_pos2 == -1 or end_marker_pos2 >= bracket_end:
                            break
                        end_pos = end_marker_pos2 + len(b'"endTime":')
                        right_brace = msg_bytes.find(b'}', end_pos)
                        comma_after = msg_bytes.find(b',', end_pos)
                        if right_brace == -1:
                            end_end = bracket_end
                        elif comma_after == -1:
                            end_end = right_brace
                        else:
                            end_end = min(right_brace, comma_after)
                        end_time = int(msg_bytes[end_pos:end_end]) / 1000.0

                        last["word_list"].append({
                            "word": word_text,
                            "start_time": start_time,
                            "end_time": end_time,
                        })
                        pos = end_end + 1
        except (json.JSONDecodeError, KeyError):
            pass

    def on_error(msg, *args):
        pass

    try:
        transcriber = nls.NlsSpeechTranscriber(
            url='wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1',
            token=token,
            appkey=app_key,
            on_sentence_begin=on_sentence_begin,
            on_sentence_end=on_sentence_end,
            on_error=on_error,
        )

        transcriber.start(
            aformat="pcm",
            sample_rate=16000,
            enable_intermediate_result=False,
            enable_punctuation_prediction=True,
            enable_inverse_text_normalization=False,
            ex={'enable_words': True},
        )

        chunk_size = 3200
        with open(wav_path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                transcriber.send_audio(chunk)

        transcriber.stop()
        transcriber.shutdown()

        # 收集结果
        text_parts = []
        for s in sentences:
            if s["text"]:
                text_parts.append(s["text"])
            all_words.extend(s.get("word_list", []))

        full_text = "".join(text_parts)

        return {
            "success": True,
            "text": full_text,
            "words": all_words,
            "error": "",
        }

    except Exception as e:
        return {
            "success": False,
            "text": "",
            "words": [],
            "error": str(e),
        }


# ========== 单文件计算 ==========

def evaluate_single(
    wav_path: str,
    gt_distribution: Optional[dict] = None,
    spk_id: Optional[str] = None,
    use_asr: bool = False,
    asr_app_key: Optional[str] = None,
    asr_token: Optional[str] = None,
) -> dict:
    """计算单个音频文件的回指指标

    Args:
        wav_path: AI 响应音频路径
        gt_distribution: Ground truth 分布字典 {spk_id: [分布]}
        spk_id: Speaker ID（用于获取 gt 分布）
        use_asr: 是否使用 ASR（精确模式）
        asr_app_key: 阿里云 ASR appkey
        asr_token: 阿里云 ASR token

    Returns:
        {
            "wav_path": str,
            "tor": int,
            "freq": float,
            "jsd": float or None,
            "num_backchannels": int,
            "total_duration": float,
            "asr_text": str (if use_asr)
        }
    """
    if not os.path.exists(wav_path):
        raise FileNotFoundError(f"音频文件不存在: {wav_path}")

    # ASR 模式
    asr_text = ""
    words = []
    if use_asr and asr_app_key and asr_token:
        asr_result = transcribe_with_aliyun(wav_path, asr_app_key, asr_token)
        if asr_result["success"]:
            asr_text = asr_result["text"]
            words = asr_result["words"]

    # 使用 ASR 结果计算 TOR（精确）
    if words:
        tor = calculate_tor_from_asr(words)
    else:
        # 回退到 VAD-only
        backchannels, total_duration = detect_backchannels(wav_path)
        tor = calculate_tor_from_segments(backchannels)

    # 检测回指（VAD）
    backchannels, total_duration = detect_backchannels(wav_path)

    # 计算频率
    freq = calculate_freq(backchannels, total_duration)

    # 计算 JSD
    jsd = None
    if gt_distribution is not None and spk_id is not None:
        if spk_id in gt_distribution:
            pred_dist = build_time_distribution(backchannels, total_duration)
            gt_dist = np.array(gt_distribution[spk_id])
            jsd = calculate_jsd(pred_dist, gt_dist)
        else:
            print(f"警告: 找不到 speaker {spk_id} 的 gt 分布")

    return {
        "wav_path": wav_path,
        "tor": tor,
        "freq": freq,
        "jsd": jsd,
        "num_backchannels": len(backchannels),
        "total_duration": total_duration,
        "asr_text": asr_text,
    }


# ========== 批量计算 ==========

def evaluate_batch(
    root_dir: str,
    gt_distribution_path: Optional[str] = None,
    limit: Optional[int] = None,
    use_asr: bool = False,
    asr_app_key: Optional[str] = None,
    asr_token: Optional[str] = None,
) -> list[dict]:
    """批量计算目录下所有样本的指标

    Args:
        root_dir: 数据集根目录（包含 {spk_id}/ 结构的样本）
        gt_distribution_path: gt 分布 JSON 文件路径
        limit: 限制样本数量
        use_asr: 是否使用 ASR（精确模式）
        asr_app_key: 阿里云 ASR appkey
        asr_token: 阿里云 ASR token

    Returns:
        结果列表
    """
    # 加载 gt 分布
    gt_distribution = None
    if gt_distribution_path and os.path.exists(gt_distribution_path):
        with open(gt_distribution_path, "r") as f:
            gt_distribution = json.load(f)

    results = []

    # 遍历所有 speaker 目录
    root = Path(root_dir)
    for spk_dir in sorted(root.iterdir()):
        if not spk_dir.is_dir():
            continue
        if spk_dir.name.startswith("."):
            continue

        spk_id = spk_dir.name
        wav_path = spk_dir / "output.wav"

        if not wav_path.exists():
            print(f"跳过 {spk_dir}: output.wav 不存在")
            continue

        try:
            result = evaluate_single(
                str(wav_path),
                gt_distribution,
                spk_id,
                use_asr=use_asr,
                asr_app_key=asr_app_key,
                asr_token=asr_token,
            )
            results.append(result)
            print(f"{spk_id}: TOR={result['tor']}, Freq={result['freq']:.4f}, JSD={result['jsd']:.4f}" if result['jsd'] else f"{spk_id}: TOR={result['tor']}, Freq={result['freq']:.4f}, JSD=N/A")

            if limit and len(results) >= limit:
                break
        except Exception as e:
            print(f"错误 {spk_dir}: {e}")
            continue

    return results


def aggregate_results(results: list[dict]) -> dict:
    """汇总批量结果"""
    tor_values = [r["tor"] for r in results if r["tor"] is not None]
    freq_values = [r["freq"] for r in results if r["freq"] is not None]
    jsd_values = [r["jsd"] for r in results if r["jsd"] is not None]

    agg = {
        "total": len(results),
        "tor_mean": np.mean(tor_values) if tor_values else None,
        "tor_std": np.std(tor_values) if tor_values else None,
        "freq_mean": np.mean(freq_values) if freq_values else None,
        "freq_std": np.std(freq_values) if freq_values else None,
        "jsd_mean": np.mean(jsd_values) if jsd_values else None,
        "jsd_std": np.std(jsd_values) if jsd_values else None,
    }

    return agg


def print_summary(agg: dict):
    """打印汇总"""
    print("\n" + "=" * 60)
    print("Backchannel 指标汇总")
    print("=" * 60)
    print(f"样本数: {agg['total']}")
    if agg["tor_mean"] is not None:
        print(f"TOR: {agg['tor_mean']:.4f} ± {agg['tor_std']:.4f}")
    if agg["freq_mean"] is not None:
        print(f"Freq: {agg['freq_mean']:.4f} ± {agg['freq_std']:.4f}")
    if agg["jsd_mean"] is not None:
        print(f"JSD: {agg['jsd_mean']:.4f} ± {agg['jsd_std']:.4f}")
    print("=" * 60)


# ========== 主入口 ==========

def main():
    parser = argparse.ArgumentParser(description="计算 Backchannel 指标（TOR、Freq、JSD）")
    parser.add_argument(
        "--wav",
        type=str,
        help="单个 AI 响应音频文件路径"
    )
    parser.add_argument(
        "--root_dir",
        type=str,
        help="批量计算：数据集根目录（包含 {spk_id}/ 结构）"
    )
    parser.add_argument(
        "--gt",
        type=str,
        default="./icc_gt_distribution.json",
        help="Ground truth 分布 JSON 文件路径"
    )
    parser.add_argument(
        "--spk_id",
        type=str,
        help="Speaker ID（单文件模式必填）"
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="限制样本数量"
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="结果输出 JSON 文件路径"
    )
    parser.add_argument(
        "--use_asr",
        action="store_true",
        help="使用阿里云 ASR（精确模式，需设置 token 和 appkey）"
    )
    parser.add_argument(
        "--token",
        type=str,
        default=ALIYUN_ASR_TOKEN,
        help="阿里云 ASR Token"
    )
    parser.add_argument(
        "--appkey",
        type=str,
        default=ALIYUN_ASR_APPKEY,
        help="阿里云 ASR AppKey"
    )

    args = parser.parse_args()

    if not args.wav and not args.root_dir:
        parser.error("需要指定 --wav 或 --root_dir")

    # 单文件模式
    if args.wav:
        # 加载 gt 分布
        gt_distribution = None
        if args.gt and os.path.exists(args.gt):
            with open(args.gt, "r") as f:
                gt_distribution = json.load(f)

        result = evaluate_single(
            args.wav, gt_distribution, args.spk_id,
            use_asr=args.use_asr,
            asr_app_key=args.appkey,
            asr_token=args.token,
        )
        print(f"\n结果:")
        print(f"  TOR: {result['tor']}")
        print(f"  Freq: {result['freq']:.4f}")
        print(f"  JSD: {result['jsd']:.4f}" if result['jsd'] else "  JSD: N/A")
        print(f"  回指次数: {result['num_backchannels']}")
        print(f"  总时长: {result['total_duration']:.2f}s")

        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)

    # 批量模式
    else:
        results = evaluate_batch(
            args.root_dir, args.gt, args.limit,
            use_asr=args.use_asr,
            asr_app_key=args.appkey,
            asr_token=args.token,
        )
        agg = aggregate_results(results)
        print_summary(agg)

        if args.output:
            output = {
                "results": results,
                "aggregate": agg
            }
            with open(args.output, "w", encoding="utf-8") as f:
                json.dump(output, f, ensure_ascii=False, indent=2)
            print(f"\n结果已保存到: {args.output}")


if __name__ == "__main__":
    main()

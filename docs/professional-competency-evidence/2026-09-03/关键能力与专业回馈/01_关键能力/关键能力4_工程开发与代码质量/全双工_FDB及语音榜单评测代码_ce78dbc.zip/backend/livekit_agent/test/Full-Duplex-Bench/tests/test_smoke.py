"""冒烟测试

验证 Full-Duplex-Bench 核心流程：连接、session 创建、开场白、VAD 检测。
"""

import pytest

# AUDIO_DELTA_EVENT 已在 conftest 中定义
AUDIO_DELTA_EVENT = "response.output_audio.delta"


@pytest.mark.smoke
async def test_connect_and_session_created(ws_client, ws_url, auth_token):
    """连接 WebSocket 并收到 session.created"""
    session_event = await ws_client.connect(ws_url, auth_token)
    assert session_event.event_type == "session.created"
    assert "session" in session_event.event
    assert "id" in session_event.event["session"]


@pytest.mark.smoke
async def test_agent_greeting(ws_client, ws_url, auth_token):
    """连接后 agent 应自动发送开场白（speaking -> audio.delta -> listening）"""
    await ws_client.connect(ws_url, auth_token)

    # 等待 agent 进入 speaking（开场白）
    speaking_event = await ws_client.wait_for_agent_state("speaking", timeout=15)
    assert speaking_event.event.get("state") == "speaking"

    # 等待收到音频数据
    audio_event = await ws_client.wait_for_event(AUDIO_DELTA_EVENT, timeout=10)
    assert "delta" in audio_event.event

    # 等待 agent 回到 listening
    listening_event = await ws_client.wait_for_agent_state("listening", timeout=30)
    assert listening_event.event.get("state") == "listening"


@pytest.mark.smoke
async def test_session_update(ws_client, ws_url, auth_token):
    """session.update 配置应生效"""
    await ws_client.connect(
        ws_url,
        auth_token,
        session_config={
            "input_audio_format": "pcm16",
            "output_audio_format": "pcm24",
            "scene": "inquiry",
        },
    )

    updated_events = ws_client.get_events("session.updated")
    assert len(updated_events) >= 1


@pytest.mark.smoke
async def test_inject_audio_triggers_vad(
    ws_client, ws_url, auth_token, audio_gen
):
    """注入语音信号应触发 VAD 语音检测"""
    await ws_client.connect(ws_url, auth_token)

    # 等待 agent 开场白结束
    await ws_client.wait_for_agent_state("listening", timeout=30)
    ws_client.clear_events()

    # 注入 2 秒类语音信号
    pcm = audio_gen.speech_like(2.0)
    await ws_client.inject_audio(pcm)

    # 应触发 speech_started 或 agent 进入 thinking/speaking 状态
    try:
        speech_event = await ws_client.wait_for_event(
            "input_audio_buffer.speech_started", timeout=5
        )
        assert speech_event.event_type == "input_audio_buffer.speech_started"
    except TimeoutError:
        # speech_started 可能尚未实现，回退检查 agent 状态变化
        import asyncio
        try:
            await ws_client.wait_for_agent_state("thinking", timeout=5)
        except TimeoutError:
            try:
                await ws_client.wait_for_agent_state("speaking", timeout=5)
            except TimeoutError:
                pytest.fail(
                    "Neither speech_started nor agent state change received "
                    "after injecting speech-like audio"
                )
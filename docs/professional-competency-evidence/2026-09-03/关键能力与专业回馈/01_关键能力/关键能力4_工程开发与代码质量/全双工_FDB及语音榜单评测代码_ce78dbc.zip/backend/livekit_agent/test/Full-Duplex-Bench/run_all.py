"""Full-Duplex-Bench 测试运行器

运行所有测试维度，支持：
1. 在线评估：WebSocket 实时计算指标
2. 离线 ASR：收集音频后用阿里云 ASR 转写，计算精确指标

用法:
    # 在线评估（快速）
    python run_all.py --task backchannel

    # 收集音频并使用 ASR 评估
    python run_all.py --task backchannel --collect_audio --use_asr

    # 仅收集音频
    python run_all.py --task backchannel --collect_only
"""

import argparse
import asyncio
import importlib.util
import json
import os
import sys
import time
import base64
import wave
from datetime import datetime
from pathlib import Path

from core import (
    RealtimeTestClient,
    MetricsAggregator,
    load_dataset_cases,
    EvaluationResult,
)


def load_local_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


TESTS_DIR = Path(__file__).parent / "tests"
test_user_interruption = load_local_module("fdb_test_user_interruption", TESTS_DIR / "test_user_interruption.py")
test_pause_handling = load_local_module("fdb_test_pause_handling", TESTS_DIR / "test_pause_handling.py")
test_backchannel = load_local_module("fdb_test_backchannel", TESTS_DIR / "test_backchannel.py")
test_smooth_turn_taking = load_local_module("fdb_test_smooth_turn_taking", TESTS_DIR / "test_smooth_turn_taking.py")

# 尝试导入评估模块
try:
    from evaluation.eval_backchannel_metrics import (
        evaluate_single as eval_backchannel_single,
        aggregate_results as aggregate_eval_results,
        transcribe_with_aliyun,
    )
    EVAL_AVAILABLE = True
except ImportError:
    EVAL_AVAILABLE = False

# ========== 配置 ==========
SCRIPT_DIR = Path(__file__).parent
WS_URL = os.getenv("WS_URL", "wss://dev2.digitalhumanai.top/beta/api/realtime?model=health-assistant-qwen")
AUTH_TOKEN = os.getenv("AUTH_TOKEN", "")
DATASET_DIR = SCRIPT_DIR / "dataset"

# 阿里云 ASR 配置（默认）
ALIYUN_ASR_TOKEN = os.getenv("ALIYUN_ASR_TOKEN", "")
ALIYUN_ASR_APPKEY = os.getenv("ALIYUN_ASR_APPKEY", "")
GT_DISTRIBUTION_PATH = SCRIPT_DIR / "icc_gt_distribution.json"

# MiniMax API 配置
MINIMAX_API_KEY = os.getenv("MINIMAX_API_KEY", "")
MINIMAX_API_URL = "https://api.minimax.chat/v1/chat/completions"


# ========== Task 配置 ==========
TASK_CONFIGS = {
    "user_interruption": {
        "dirs": ["synthetic_user_interruption"],
        "test_func": test_user_interruption.test_user_interruption_dataset,
    },
    "backchannel": {
        "dirs": ["icc_backchannel"],
        "test_func": test_backchannel.test_backchannel_dataset,
    },
    "pause_handling": {
        "dirs": ["candor_pause_handling", "synthetic_pause_handling"],
        "test_func": test_pause_handling.test_pause_handling_dataset,
    },
    "smooth_turn_taking": {
        "dirs": ["candor_turn_taking"],
        "test_func": test_smooth_turn_taking.test_smooth_turn_taking_dataset,
    },
}


def default_dataset_root() -> Path:
    """选择可用的默认数据根目录。"""
    for candidate in (
        DATASET_DIR / "v1.0",
        DATASET_DIR / "v1_0",
        DATASET_DIR,
    ):
        if candidate.exists():
            return candidate
    return DATASET_DIR


def looks_like_case_dir(path: Path) -> bool:
    if not path.is_dir():
        return False
    markers = (
        "input.wav",
        "input.pcm",
        "user_audio.wav",
        "user_audio.pcm",
        "interrupt.wav",
        "interrupt.pcm",
    )
    return any((child / marker).exists() for child in path.iterdir() if child.is_dir() for marker in markers)


def discover_task_dataset_paths(root_dir: Path, task_name: str, subdirs: list[str]) -> list[Path]:
    """兼容官方数据目录和仓库内简化样例目录。"""
    bases = [root_dir]
    for nested in ("v1.0", "v1_0"):
        nested_path = root_dir / nested
        if nested_path.exists():
            bases.append(nested_path)

    candidates: list[Path] = []
    for base in bases:
        if looks_like_case_dir(base):
            candidates.append(base)
        for subdir in [*subdirs, task_name]:
            path = base / subdir
            if path.exists() and path not in candidates:
                candidates.append(path)

    return candidates


def parse_limits(limit_arg: str | None) -> dict[str, int | None]:
    """解析 --limit，支持 10、all、task=10,task2=all。"""
    if not limit_arg or limit_arg.lower() == "all":
        return {task: None for task in TASK_CONFIGS.keys()}
    if "=" not in limit_arg:
        default_limit = int(limit_arg)
        return {task: default_limit for task in TASK_CONFIGS.keys()}

    limits: dict[str, int | None] = {task: None for task in TASK_CONFIGS.keys()}
    for item in limit_arg.split(","):
        if not item.strip():
            continue
        key, value = item.split("=", 1)
        value = value.strip()
        limits[key.strip()] = None if value.lower() == "all" else int(value)
    return limits


# ========== MiniMax API 评分 ==========

def evaluate_with_minimax(
    interrupt_text: str,
    ai_response: str,
    api_key: str,
) -> tuple[int, str]:
    """使用 MiniMax 大模型评估 AI 响应的相关性

    Args:
        interrupt_text: 用户打断内容
        ai_response: AI 响应内容
        api_key: MiniMax API Key

    Returns:
        (score, reasoning): 评分(0-5) 和 分析理由
    """
    import requests

    if not api_key:
        return -1, "No API key"

    system_prompt = """你是一个评估 AI 响应质量的专家。

任务：评估 AI 对用户打断的响应质量。

评分标准（0-5分）：
- 0: AI 响应与用户打断完全无关
- 1: AI 响应与用户打断不相关
- 2: AI 响应与用户打断略微相关
- 3: AI 响应与用户打断相关
- 4: AI 响应与用户打断高度相关
- 5: AI 响应与用户打断完美相关

请先分析用户打断内容和 AI 响应，然后给出评分。

输出格式：
分析: [你的分析]
评分: [0-5]
"""

    user_prompt = f"""用户打断内容: {interrupt_text}
AI 响应: {ai_response}"""

    try:
        response = requests.post(
            MINIMAX_API_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "MiniMax-Text-01",
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                "max_tokens": 500,
                "temperature": 0.3,
            },
            timeout=30,
        )

        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "")

            # 提取评分
            score = -1
            for line in content.split("\n"):
                if "评分:" in line or "评分：" in line:
                    try:
                        score = int([c for c in line if c.isdigit()][0])
                    except:
                        pass

            return score, content
        else:
            return -1, f"API error: {response.status_code}"

    except Exception as e:
        return -1, str(e)


async def main():
    parser = argparse.ArgumentParser(description="Full-Duplex-Bench 实时评估测试 - v1.0 数据集")
    parser.add_argument(
        "--protocol",
        type=str,
        default="websocket",
        choices=["websocket"],
        help="通信协议。目前 Full-Duplex-Bench 只支持 websocket。",
    )
    parser.add_argument(
        "--task",
        type=str,
        default=None,
        choices=list(TASK_CONFIGS.keys()) + ["all"],
        help="测试任务类型 (默认: all)",
    )
    parser.add_argument(
        "--root_dir",
        type=str,
        default=None,
        help="数据集根目录。默认自动查找 dataset/v1.0、dataset/v1_0 或 dataset。",
    )
    parser.add_argument(
        "--limit",
        type=str,
        default=None,
        help="每个任务限制数量，如 user_interruption=10,pause_handling=5、10 或 all。默认全量。",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="输出目录。默认写入 Full-Duplex-Bench/output/YYYYMMDD_HHMMSS。",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只加载并展示将要运行的 case，不连接服务。",
    )
    parser.add_argument(
        "--ws-url",
        type=str,
        default=None,
        help="覆盖 WS_URL 环境变量。",
    )
    parser.add_argument(
        "--auth-token",
        type=str,
        default=None,
        help="覆盖 AUTH_TOKEN 环境变量。",
    )
    parser.add_argument(
        "--min_deltas",
        type=int,
        default=5,
        help="等待打断前最少音频 delta 数量 (默认: 5)",
    )
    parser.add_argument(
        "--collect-audio",
        "--collect_audio",
        dest="collect_audio",
        action="store_true",
        default=False,
        help="收集模型输出音频到 evaluation/{task}/{case_id}/output.wav。默认关闭。",
    )
    parser.add_argument(
        "--no-collect-audio",
        "--no_collect_audio",
        dest="collect_audio",
        action="store_false",
        help="禁用音频收集。",
    )
    parser.add_argument(
        "--collect-only",
        "--collect_only",
        dest="collect_only",
        action="store_true",
        help="仅收集音频，不计算指标",
    )
    parser.add_argument(
        "--use-asr",
        "--use_asr",
        dest="use_asr",
        action="store_true",
        default=False,
        help="采集音频后使用阿里云 ASR 计算离线指标。默认关闭。",
    )
    parser.add_argument(
        "--no-asr",
        "--no_asr",
        dest="use_asr",
        action="store_false",
        help="禁用 ASR，只使用 VAD 计算。",
    )
    parser.add_argument(
        "--token",
        type=str,
        default=ALIYUN_ASR_TOKEN,
        help="阿里云 ASR Token",
    )
    parser.add_argument(
        "--appkey",
        type=str,
        default=ALIYUN_ASR_APPKEY,
        help="阿里云 ASR AppKey",
    )
    parser.add_argument(
        "--minimax-api-key",
        "--minimax_api_key",
        dest="minimax_api_key",
        type=str,
        default=MINIMAX_API_KEY,
        help="MiniMax API Key（用于 user_interruption AI 评分）",
    )
    args = parser.parse_args()

    ws_url = args.ws_url or WS_URL
    auth_token = args.auth_token or AUTH_TOKEN
    use_asr = args.use_asr
    limits = parse_limits(args.limit)
    root_dir = Path(args.root_dir) if args.root_dir else default_dataset_root()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(args.output) if args.output else SCRIPT_DIR / "output" / timestamp

    # 确定要运行的任务
    if args.task == "all" or args.task is None:
        tasks_to_run = list(TASK_CONFIGS.keys())
    else:
        tasks_to_run = [args.task]

    print("=" * 60)
    print(f"Full-Duplex-Bench 实时评估测试 (v1.0 数据集)")
    print("=" * 60)
    print(f"协议: {args.protocol}")
    print(f"任务: {', '.join(tasks_to_run)}")
    print(f"数据集: {root_dir}")
    print(f"输出目录: {output_dir}")
    print(f"WS URL: {ws_url}")
    print(f"AUTH_TOKEN: {'*' * 20 if auth_token else '(not set)'}")
    if args.collect_audio:
        print(f"ASR: {'启用' if use_asr else '禁用'}")
    print("-" * 60)

    if not auth_token and not args.dry_run:
        print("警告: AUTH_TOKEN 未设置，连接可能会失败\n")

    metrics_aggregator = MetricsAggregator()
    task_results = {}

    for task_name in tasks_to_run:
        config = TASK_CONFIGS[task_name]
        test_func = config["test_func"]
        subdirs = config["dirs"]

        # 收集所有用例
        all_cases = []
        dataset_paths = discover_task_dataset_paths(root_dir, task_name, subdirs)
        for dataset_path in dataset_paths:
            cases = load_dataset_cases(dataset_path, task_name)
            all_cases.extend(cases)

        if not all_cases:
            print(f"\n警告: {task_name} 未找到测试用例，跳过")
            continue

        # 应用限制
        limit = limits.get(task_name)
        if limit and limit < len(all_cases):
            all_cases = all_cases[:limit]
            print(f"\n注意: {task_name} 限制为 {limit} 个样本")

        print(f"\n{'=' * 40}")
        print(f"测试维度: {task_name} ({len(all_cases)} 个用例)")
        print(f"{'=' * 40}")
        for dataset_path in dataset_paths:
            print(f"数据目录: {dataset_path}")

        case_results = []

        if args.dry_run:
            for i, case in enumerate(all_cases):
                print(f"[dry-run] [{i+1}/{len(all_cases)}] {case.case_name}")
            task_results[task_name] = {
                "dimension": task_name,
                "total_cases": len(all_cases),
                "test_cases": [],
                "summary": {
                    "tor_mean": None,
                    "tor_success_count": 0,
                    "latency_mean": None,
                    "jsd_mean": None,
                    "freq_mean": None,
                },
            }
            continue

        for i, case in enumerate(all_cases):
            print(f"\n[{i+1}/{len(all_cases)}] {case.case_name}")

            # 如果是收集模式
            if args.collect_audio:
                success = await collect_audio_for_case(
                    ws_url=ws_url,
                    auth_token=auth_token,
                    input_audio=case.input_audio,
                    task=task_name,
                    spk_id=case.sample_dir.name,
                    collect_only=args.collect_only,
                )
                case_result = {
                    "case_name": case.case_name,
                    "success": success,
                    "tor": None,
                    "latency": None,
                    "jsd": None,
                    "frequency": None,
                }
                if success and not args.collect_only:
                    # 运行 ASR 评估
                    output_wav = SCRIPT_DIR / "evaluation" / task_name / case.sample_dir.name / "output.wav"
                    if output_wav.exists():
                        gt_dist = None
                        if GT_DISTRIBUTION_PATH.exists():
                            with open(GT_DISTRIBUTION_PATH, "r") as f:
                                gt_dist = json.load(f)
                        try:
                            result = eval_backchannel_single(
                                str(output_wav),
                                gt_dist,
                                case.sample_dir.name,
                                use_asr=use_asr,
                                asr_app_key=args.appkey,
                                asr_token=args.token,
                            )
                            case_result.update({
                                "tor": result.get("tor"),
                                "latency": result.get("latency"),
                                "jsd": result.get("jsd"),
                                "frequency": result.get("freq"),
                            })
                            # user_interruption 需要 MiniMax AI 评分
                            ai_rating = None
                            if task_name == "user_interruption" and args.minimax_api_key:
                                asr_result = transcribe_with_aliyun(
                                    str(output_wav),
                                    args.appkey,
                                    args.token,
                                )
                                if asr_result.get("success"):
                                    interrupt_text = case.interrupt_text or ""
                                    ai_response = asr_result.get("text", "")
                                    ai_rating, rating_reason = evaluate_with_minimax(
                                        interrupt_text,
                                        ai_response,
                                        args.minimax_api_key,
                                    )
                                    print(f"    MiniMax评分: {ai_rating}/5")
                                    if ai_rating is not None and ai_rating >= 0:
                                        result["ai_rating"] = ai_rating
                                        result["rating_reason"] = rating_reason
                                        case_result["ai_rating"] = ai_rating
                                        case_result["rating_reason"] = rating_reason
                            print(f"    TOR={result['tor']}, Freq={result['freq']:.4f}, JSD={result['jsd']:.4f}" if result['jsd'] else f"    TOR={result['tor']}, Freq={result['freq']:.4f}")
                        except Exception as e:
                            print(f"    ASR评估失败: {e}")
                            case_result["success"] = False
                            case_result["error"] = str(e)
                case_results.append(case_result)
                await asyncio.sleep(0.5)
                continue

            # 普通测试模式
            ws_client = RealtimeTestClient()

            try:
                await test_func(ws_client, ws_url, auth_token, case, metrics_aggregator, args.min_deltas)
            except AssertionError as e:
                print(f"    ✗ 断言失败: {e}")
                metrics_aggregator.add_result(EvaluationResult(
                    task=task_name,
                    case_name=case.case_name,
                    success=False,
                    error=str(e),
                ))
            except Exception as e:
                print(f"    ✗ 错误: {e}")
                metrics_aggregator.add_result(EvaluationResult(
                    task=task_name,
                    case_name=case.case_name,
                    success=False,
                    error=str(e),
                ))
            finally:
                try:
                    await ws_client.disconnect()
                except Exception:
                    pass
                await asyncio.sleep(0.5)

        # 收集该维度的所有结果
        task_results_list = metrics_aggregator.get_results_by_task(task_name)
        for r in task_results_list:
            case_result = {
                "case_name": r.case_name,
                "tor": r.tor,
                "latency": r.latency,
                "success": r.success,
                "error": r.error,
                "jsd": r.jsd,
                "frequency": r.frequency,
            }
            # 在线评估模式下 user_interruption 包含 AI 评分
            if task_name == "user_interruption":
                case_result["ai_rating"] = getattr(r, 'ai_rating', None)
            case_results.append(case_result)

        # 计算该维度的汇总
        if case_results:
            total = len(case_results)
            tor_values = [r["tor"] for r in case_results if r["tor"] is not None and r["tor"] >= 0]
            latency_values = [r["latency"] for r in case_results if r["latency"] is not None and r["latency"] >= 0]
            jsd_values = [r["jsd"] for r in case_results if r["jsd"] is not None]
            freq_values = [r["frequency"] for r in case_results if r["frequency"] is not None]

            task_results[task_name] = {
                "dimension": task_name,
                "total_cases": total,
                "test_cases": case_results,
                "summary": {
                    "tor_mean": sum(tor_values) / len(tor_values) if tor_values else None,
                    "tor_success_count": len(tor_values),
                    "latency_mean": sum(latency_values) / len(latency_values) if latency_values else None,
                    "jsd_mean": sum(jsd_values) / len(jsd_values) if jsd_values else None,
                    "freq_mean": sum(freq_values) / len(freq_values) if freq_values else None,
                }
            }
            # user_interruption 额外计算 AI 评分均值
            if task_name == "user_interruption":
                ai_rating_values = [r["ai_rating"] for r in case_results if r.get("ai_rating") is not None and r["ai_rating"] >= 0]
                if ai_rating_values:
                    task_results[task_name]["summary"]["ai_rating_mean"] = sum(ai_rating_values) / len(ai_rating_values)

    # 输出每个维度的结果
    print("\n" + "=" * 60)
    print("各维度测试结果汇总")
    print("=" * 60)

    output_dir.mkdir(parents=True, exist_ok=True)

    # 构建汇总表格 - 按维度显示不同指标
    table_lines = []
    table_lines.append("=" * 90)
    table_lines.append("Full-Duplex-Bench 测试结果汇总")
    table_lines.append("=" * 90)
    table_lines.append(f"测试时间: {timestamp}")
    table_lines.append(f"WS URL: {ws_url}")
    table_lines.append("-" * 90)

    # 表头 - 根据维度不同
    for task_name, result in task_results.items():
        summary = result["summary"]
        total = result["total_cases"]

        if task_name == "pause_handling":
            # pause_handling: Synthetic TOR ↓, Candor TOR ↓
            # 需要按数据集分开计算，暂时显示聚合值
            tor_str = f"{summary['tor_mean']:.4f}" if summary["tor_mean"] is not None else "N/A"
            table_lines.append(f"{'维度':<25} {'用例数':<10} {'Synthetic TOR':<18} {'Candor TOR':<18}")
            table_lines.append("-" * 90)
            line = f"{task_name:<25} {total:<10} {tor_str:<18} {tor_str:<18}"
            table_lines.append(line)
        elif task_name == "backchannel":
            # backchannel: TOR ↓, Freq ↑, JSD ↓
            tor_str = f"{summary['tor_mean']:.4f}" if summary["tor_mean"] is not None else "N/A"
            freq_str = f"{summary['freq_mean']:.4f}" if summary["freq_mean"] is not None else "N/A"
            jsd_str = f"{summary['jsd_mean']:.4f}" if summary["jsd_mean"] is not None else "N/A"
            table_lines.append(f"{'维度':<25} {'用例数':<10} {'TOR':<12} {'Freq':<12} {'JSD':<12}")
            table_lines.append("-" * 90)
            line = f"{task_name:<25} {total:<10} {tor_str:<12} {freq_str:<12} {jsd_str:<12}"
            table_lines.append(line)
        elif task_name == "smooth_turn_taking":
            # smooth_turn_taking: Candor TOR ↑, Latency ↓
            tor_str = f"{summary['tor_mean']:.4f}" if summary["tor_mean"] is not None else "N/A"
            latency_str = f"{summary['latency_mean']:.2f}" if summary["latency_mean"] is not None else "N/A"
            table_lines.append(f"{'维度':<25} {'用例数':<10} {'Candor TOR':<18} {'Latency(ms)':<18}")
            table_lines.append("-" * 90)
            line = f"{task_name:<25} {total:<10} {tor_str:<18} {latency_str:<18}"
            table_lines.append(line)
        elif task_name == "user_interruption":
            # user_interruption: TOR ↑, Latency ↓, AI Rating ↑
            tor_str = f"{summary['tor_mean']:.4f}" if summary["tor_mean"] is not None else "N/A"
            latency_str = f"{summary['latency_mean']:.2f}" if summary["latency_mean"] is not None else "N/A"
            ai_rating_mean = summary.get("ai_rating_mean")
            ai_rating_str = f"{ai_rating_mean:.2f}" if ai_rating_mean is not None else "N/A"
            table_lines.append(f"{'维度':<25} {'用例数':<10} {'TOR':<10} {'Latency(ms)':<12} {'AI评分':<10}")
            table_lines.append("-" * 90)
            line = f"{task_name:<25} {total:<10} {tor_str:<10} {latency_str:<12} {ai_rating_str:<10}"
            table_lines.append(line)
        else:
            # 默认格式
            tor_str = f"{summary['tor_mean']:.4f}" if summary["tor_mean"] is not None else "N/A"
            latency_str = f"{summary['latency_mean']:.2f}" if summary["latency_mean"] is not None else "N/A"
            success_str = f"{summary['tor_success_count']}/{total}"
            table_lines.append(f"{'维度':<25} {'用例数':<10} {'TOR':<15} {'成功':<10} {'平均延迟(ms)':<15}")
            table_lines.append("-" * 90)
            line = f"{task_name:<25} {total:<10} {tor_str:<15} {success_str:<10} {latency_str:<15}"
            table_lines.append(line)

        task_output_path = output_dir / f"{task_name}.json"
        with open(task_output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\n" + "\n".join(table_lines))

    summary_path = output_dir / "summary.txt"
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(table_lines))

    overview = {
        "timestamp": timestamp,
        "ws_url": ws_url,
        "protocol": args.protocol,
        "dataset_root": str(root_dir),
        "dimensions": list(task_results.keys()),
        "results": task_results,
    }
    overview_path = output_dir / "overview.json"
    with open(overview_path, 'w', encoding='utf-8') as f:
        json.dump(overview, f, ensure_ascii=False, indent=2)

    print(f"\n结果已保存到: {output_dir}/")


# ========== 音频收集功能 ==========

async def collect_audio_for_case(
    ws_url: str,
    auth_token: str,
    input_audio: bytes | None,
    task: str,
    spk_id: str,
    collect_only: bool = False,
    output_sample_rate: int = 24000,
) -> bool:
    """收集单个样本的模型输出音频

    Args:
        ws_url: WebSocket URL
        auth_token: 认证 token
        input_audio: 已加载的 16-bit PCM 输入音频
        task: 任务类型
        spk_id: 样本 ID
        collect_only: 是否只收集不评估

    Returns:
        是否成功
    """
    from core.ws_test_client import RealtimeTestClient

    # 输出目录
    output_dir = Path(__file__).parent / "evaluation" / task / spk_id
    output_dir.mkdir(parents=True, exist_ok=True)
    output_wav_path = output_dir / "output.wav"

    if output_wav_path.exists():
        print(f"    跳过（已存在）: {output_wav_path}")
        return True

    client = RealtimeTestClient()

    try:
        # 连接
        await client.connect(ws_url, auth_token)

        if not input_audio:
            print(f"    错误: 无可用输入音频")
            return False

        # 清空事件
        client.clear_events()

        # 发送输入音频（非阻塞）
        send_task = await client.inject_audio_nonblocking(input_audio)

        # 收集 AI 响应音频
        audio_chunks = []
        t_start = asyncio.get_event_loop().time()
        last_audio_time = t_start
        seen_audio_events = 0
        timeout = 30.0

        while asyncio.get_event_loop().time() - t_start <= timeout:
            audio_events = client.get_events("response.output_audio.delta")
            for event in audio_events[seen_audio_events:]:
                if "delta" in event.event:
                    audio_data = base64.b64decode(event.event["delta"])
                    audio_chunks.append(audio_data)
                    last_audio_time = asyncio.get_event_loop().time()
            seen_audio_events = len(audio_events)

            if send_task.done() and asyncio.get_event_loop().time() - last_audio_time > 1.5:
                if audio_chunks:
                    break

            await asyncio.sleep(0.1)

        if not send_task.done():
            print(f"    超时")
        await send_task

        # 保存为 WAV
        if audio_chunks:
            with wave.open(str(output_wav_path), 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(output_sample_rate)
                for chunk in audio_chunks:
                    if chunk and len(chunk) > 0:
                        wf.writeframes(chunk)
            print(f"    已保存: {output_wav_path}")
            return True
        else:
            print(f"    未收到音频响应")
            return False

    except Exception as e:
        print(f"    错误: {e}")
        return False
    finally:
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())

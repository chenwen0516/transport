"""Qwen3-TTS WebSocket 客户端

异步连接 Qwen3-TTS-Server 的 WebSocket API，合成文本返回 PCM16 原始字节。
协议文档：Qwen3-TTS-Server/docs/ws-api.md
"""

import asyncio
import base64
import json
import logging
import uuid

import websockets

logger = logging.getLogger(__name__)


class TTSSynthesisError(Exception):
    """TTS 合成失败"""


async def synthesize(
    text: str,
    tts_url: str,
    sample_rate: int = 16000,
    speaker: str = "Vivian",
    language: str = "Chinese",
    instruct: str = "用稍快的语速说。",
    timeout: float = 30.0,
) -> bytes:
    """连接 Qwen3-TTS WS，合成文本返回 PCM16 原始字节。

    Args:
        text: 待合成文本
        tts_url: TTS WebSocket 端点，如 ws://localhost:8080/api-ws/v1/realtime
        sample_rate: 采样率，16000 或 24000
        speaker: 音色名称
        language: 语言
        instruct: 指令控制文本，用于控制语速、语气等
        timeout: 超时秒数

    Returns:
        PCM16 小端单声道原始字节

    Raises:
        TTSSynthesisError: 合成失败或超时
    """
    try:
        async with asyncio.timeout(timeout):
            async with websockets.connect(tts_url) as ws:
                # 1. 等待 session.created
                msg = json.loads(await ws.recv())
                if msg["type"] != "session.created":
                    raise TTSSynthesisError(f"Expected session.created, got {msg['type']}")

                # 2. 发送 session.update
                await ws.send(json.dumps({
                    "event_id": f"evt_{uuid.uuid4().hex[:8]}",
                    "type": "session.update",
                    "session": {
                        "voice": {"type": "custom_voice", "speaker": speaker},
                        "output_audio_format": "pcm",
                        "sample_rate": sample_rate,
                        "language": language,
                        "instruct": instruct,
                    }
                }))

                # 3. 等待 session.updated
                msg = json.loads(await ws.recv())
                if msg["type"] == "error":
                    raise TTSSynthesisError(f"TTS error: {msg['error']['message']}")
                if msg["type"] != "session.updated":
                    raise TTSSynthesisError(f"Expected session.updated, got {msg['type']}")

                # 4. 发送文本 + finish
                await ws.send(json.dumps({
                    "event_id": f"evt_{uuid.uuid4().hex[:8]}",
                    "type": "input_text_buffer.append",
                    "text": text,
                }))
                await ws.send(json.dumps({
                    "event_id": f"evt_{uuid.uuid4().hex[:8]}",
                    "type": "session.finish",
                }))

                # 5. 收集音频
                audio_data = bytearray()
                async for raw in ws:
                    msg = json.loads(raw)
                    if msg["type"] == "response.audio.delta":
                        audio_data.extend(base64.b64decode(msg["delta"]))
                    elif msg["type"] == "error":
                        raise TTSSynthesisError(f"TTS error: {msg['error']['message']}")
                    elif msg["type"] == "session.finished":
                        break

                if not audio_data:
                    raise TTSSynthesisError("TTS returned empty audio")

                return bytes(audio_data)

    except asyncio.TimeoutError:
        raise TTSSynthesisError(f"TTS synthesis timed out after {timeout}s")
    except websockets.exceptions.WebSocketException as e:
        raise TTSSynthesisError(f"TTS WebSocket error: {e}")

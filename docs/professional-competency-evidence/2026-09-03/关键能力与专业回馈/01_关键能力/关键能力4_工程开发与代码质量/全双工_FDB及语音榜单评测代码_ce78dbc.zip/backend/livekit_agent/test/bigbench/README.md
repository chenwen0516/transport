# BigBench 语音评测

这个目录用于评测 `health-assistant` realtime 或 WebRTC 服务在 BigBench 风格语音推理任务上的表现。

下面的命令默认从 `backend/livekit_agent` 目录执行：

```bash
cd /opt/cw/health-assistant/backend/livekit_agent
```

## 环境变量

```bash
export WS_URL="wss://api.digitalhumanai.top/health-dev2/api/realtime?model=health-assistant-qwen"
export AUTH_TOKEN="..."
export AGENT_MODE=real
export MINIMAX_API_KEY="..."
```

可选 ASR 地址：

```bash
export ASR_WS_URL="ws://host:port/api-ws/v1/realtime"
```

## 运行

WebSocket 冒烟测试：

```bash
uv run python test/bigbench/run_benchmark.py \
  --protocol websocket \
  --max-cases 5
```

WebRTC 冒烟测试：

```bash
uv run python test/bigbench/run_benchmark.py \
  --protocol webrtc \
  --max-cases 5 \
  --early-response-policy warn
```

每个类别运行 5 条：

```bash
uv run python test/bigbench/run_benchmark.py \
  --protocol webrtc \
  --per-category 5 \
  --early-response-policy warn
```

后台运行所有小于等于 30 秒的音频：

```bash
nohup uv run python test/bigbench/run_benchmark.py \
  --protocol webrtc \
  --max-audio-seconds 30 \
  --early-response-policy warn \
  > test/bigbench/bigbench_webrtc_under_30s.log 2>&1 &
```

## 常用参数

```text
--protocol websocket|webrtc
--category CATEGORY
--max-cases N
--per-category N
--min-audio-seconds N
--max-audio-seconds N
--dry-run
--output PATH
--asr-model ws_asr|whisper
--early-response-policy warn|retry|fail
--early-response-retries N
--trailing-silence-ms N
--response-start-timeout N
--response-end-timeout N
--reuse-room
```

## 报告

报告保存目录：

```text
test/bigbench/test_reports/
```

查看最新报告：

```bash
cat $(ls -t test/bigbench/test_reports/bigbench_*.json | head -n 1)
```

JSON 报告包含 `summary` 和逐条 `results`，包括问题、期望答案、预测答案、正确性、延迟和 judge 信息。

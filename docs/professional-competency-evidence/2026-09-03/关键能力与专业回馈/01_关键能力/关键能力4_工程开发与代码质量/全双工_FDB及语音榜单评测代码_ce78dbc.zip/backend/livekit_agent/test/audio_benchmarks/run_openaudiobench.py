"""OpenAudioBench evaluation runner.

Examples:
    python run_openaudiobench.py --protocol webrtc --component reasoning_qa --max-cases 5
    python run_openaudiobench.py --protocol webrtc --component web_questions,trivia_qa --max-audio-seconds 30
"""

from __future__ import annotations

import argparse
import csv
import logging
import re
from pathlib import Path

from common import (
    SimpleBenchmarkDataset,
    add_common_args,
    first_non_empty,
    run_async,
    run_audio_benchmark,
    split_csv,
)
from core.case import BigBenchCase  # noqa: E402

logger = logging.getLogger("openaudiobench.runner")

OPENAUDIOBENCH_REPO = "baichuan-inc/OpenAudioBench"
OPENAUDIOBENCH_COMPONENTS = [
    "reasoning_qa",
    "llama_questions",
    "web_questions",
    "trivia_qa",
    "alpaca_eval",
]


class OpenAudioBenchDataset(SimpleBenchmarkDataset):
    @classmethod
    def load(
        cls,
        components: list[str] | None = None,
        category_filter: str | None = None,
        limit: int | None = None,
    ) -> "OpenAudioBenchDataset":
        from huggingface_hub import hf_hub_download

        selected_components = components or OPENAUDIOBENCH_COMPONENTS
        cases: list[BigBenchCase] = []
        for component in selected_components:
            logger.info("Loading OpenAudioBench component: %s", component)
            csv_path = hf_hub_download(
                repo_id=OPENAUDIOBENCH_REPO,
                repo_type="dataset",
                filename=f"eval_datas/{component}/{component}.csv",
            )
            with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
                rows = list(csv.DictReader(f))
            logger.info("Component %s has %d rows", component, len(rows))

            for idx, row in enumerate(rows):
                case = parse_openaudio_row(component, idx, row)
                if not case:
                    continue
                if category_filter and category_filter not in case.category:
                    continue
                audio_filename = first_non_empty(row, ["audio_filename", "audio", "file"])
                if audio_filename:
                    case._audio_path_loader = make_audio_path_loader(component, str(audio_filename))
                cases.append(case)
                if len(cases) % 10 == 0:
                    logger.info("Loaded %d OpenAudioBench cases", len(cases))
                if limit and len(cases) >= limit:
                    logger.info("Loaded %d OpenAudioBench cases due to limit", len(cases))
                    return cls(cases)

        logger.info("Loaded %d OpenAudioBench cases", len(cases))
        return cls(cases)


def make_audio_path_loader(component: str, audio_filename: str):
    from huggingface_hub import hf_hub_download

    def load_audio_path() -> str:
        return hf_hub_download(
            repo_id=OPENAUDIOBENCH_REPO,
            repo_type="dataset",
            filename=f"eval_datas/{component}/audios/{audio_filename}",
        )

    return load_audio_path


def parse_openaudio_row(component: str, idx: int, row: dict) -> BigBenchCase | None:
    question = first_non_empty(
        row,
        ["Prompt", "prompt", "question", "Question", "Questions", "instruction", "input"],
    )
    answer = first_non_empty(
        row,
        [
            "参考答案",
            "answers",
            "answer",
            "Answer",
            "answer_normalized_value",
            "answer_normalized_aliases",
            "reference",
            "target",
            "output",
        ],
    )
    if not question:
        return None

    qtype = first_non_empty(row, ["qtype", "二级类型", "type", "category"])
    category = component if not qtype else f"{component}/{qtype}"
    audio_filename = first_non_empty(row, ["audio_filename", "audio", "file"])
    case_id = safe_case_id(component, audio_filename or str(idx), idx)

    return BigBenchCase(
        id=case_id,
        category=category,
        question=str(question),
        answer=str(answer or ""),
    )


def safe_case_id(prefix: str, value: str, idx: int) -> str:
    stem = Path(str(value)).stem or str(idx)
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem)
    return f"{prefix}_{stem}"


async def main():
    parser = argparse.ArgumentParser(description="OpenAudioBench Speech Evaluation")
    parser.add_argument(
        "--component",
        type=str,
        default="reasoning_qa",
        help="Comma-separated components: reasoning_qa,llama_questions,web_questions,trivia_qa,alpaca_eval, or all",
    )
    add_common_args(parser)
    args = parser.parse_args()

    components = OPENAUDIOBENCH_COMPONENTS if args.component == "all" else split_csv(args.component)
    dataset = OpenAudioBenchDataset.load(
        components=components,
        category_filter=args.category,
        limit=args.max_cases if not args.per_category else None,
    )
    await run_audio_benchmark("OpenAudioBench", dataset, args)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    run_async(main())

# Full-Duplex-Bench 评测

这个目录是针对 `health-assistant` 的 Full-Duplex-Bench 适配版本，用来评估实时语音对话中的全双工能力、轮次处理和打断处理。

## 评测内容

| 任务 | 目标 | 主要指标 |
| --- | --- | --- |
| `backchannel` | 评估 agent 是否正确处理简短反馈、附和和回指 | TOR、frequency、JSD |
| `pause_handling` | 评估 agent 是否能避免在用户句中停顿时过早抢话 | TOR |
| `smooth_turn_taking` | 评估 agent 是否能在自然轮次边界后开始回答 | TOR、latency |
| `user_interruption` | 评估用户打断时 agent 是否能停止或调整回答 | TOR、latency |

`TOR` 表示 turn occupation rate。不同任务下 TOR 的含义和好坏方向可能不同，比较结果前需要结合具体任务定义。

## 目录结构

```text
Full-Duplex-Bench/
  core/                 数据集、ASR、指标计算等共享工具
  dataset/              本地评测数据和数据说明
  evaluation/           离线评测脚本和输出
  scenarios/            YAML 场景配置
  tests/                pytest 测试
  run_all.py            面向 realtime 服务的在线评测入口
```

## 环境变量

实时评测使用和其他 realtime 测试相同的基础环境变量：

```bash
export WS_URL="wss://..."
export AUTH_TOKEN="..."
export AGENT_MODE=real
```

离线 ASR 指标计算使用阿里云 ASR：

```bash
export ALIYUN_ASR_APPKEY="..."
export ALIYUN_ASR_TOKEN="..."
```

部分回答质量评分路径还会使用 MiniMax：

```bash
export MINIMAX_API_KEY="..."
```

## 在线评测

建议从 `backend/livekit_agent` 目录运行，和其他评测脚本保持一致：

```bash
cd /opt/cw/health-assistant/backend/livekit_agent
```

运行单个任务：

```bash
uv run python test/Full-Duplex-Bench/run_all.py \
  --task user_interruption \
  --limit 10
```

运行所有已配置任务：

```bash
uv run python test/Full-Duplex-Bench/run_all.py \
  --task all \
  --limit 10
```

全量运行：

```bash
uv run python test/Full-Duplex-Bench/run_all.py \
  --task all \
  --limit all
```

只检查会加载哪些 case，不连接服务：

```bash
uv run python test/Full-Duplex-Bench/run_all.py \
  --task user_interruption \
  --dry-run \
  --limit 5
```

指定数据集根目录：

```bash
uv run python test/Full-Duplex-Bench/run_all.py \
  --task user_interruption \
  --root_dir test/Full-Duplex-Bench/dataset \
  --limit 10
```

结果输出到：

```text
test/Full-Duplex-Bench/output/YYYYMMDD_HHMMSS/
  overview.json
  summary.txt
  <task>.json
```

默认运行在线指标，不采集 agent 音频。如果需要采集 agent 响应音频：

```bash
uv run python test/Full-Duplex-Bench/run_all.py \
  --task user_interruption \
  --limit 10 \
  --collect-audio
```

采集到的 agent 音频会输出到：

```text
test/Full-Duplex-Bench/evaluation/<task>/<case_id>/output.wav
```

## 离线评测

离线评测要求每个样本目录里已经存在 `output.wav`。

```bash
cd /opt/cw/health-assistant/backend/livekit_agent/test/Full-Duplex-Bench

uv run python evaluation/evaluate.py \
  --task user_interruption \
  --root_dir ./dataset/user_interruption \
  --output_dir ./output/offline_user_interruption
```

支持的离线任务：

```text
backchannel
pause_handling
smooth_turn_taking
user_interruption
```

## 注意事项

- `dataset` 目录里包含少量本地样例数据，完整 benchmark 数据需要单独下载。
- `run_all.py` 会自动查找 `dataset/v1.0`、`dataset/v1_0` 和 `dataset`，也可以用 `--root_dir` 显式指定。
- 当前 `run_all.py` 支持 WebSocket 协议；WebRTC 还没有接入 Full-Duplex-Bench。
- 该目录中部分 Python 文件的历史注释仍然存在乱码问题。README 和主要运行路径已经整理，代码注释可以后续单独清理。

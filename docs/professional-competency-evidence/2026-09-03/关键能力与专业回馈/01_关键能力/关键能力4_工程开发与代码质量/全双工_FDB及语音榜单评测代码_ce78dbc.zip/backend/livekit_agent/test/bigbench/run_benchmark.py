"""BigBench Speech Reasoning Benchmark"""
import argparse
import asyncio
import base64
import json
import logging
import os
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urlsplit, urlunsplit
sys.path.insert(0, str(Path(__file__).parent))
from core.dataset_hf import BigBenchHFDataset
from core.case import BigBenchCase
from core.judge import BigBenchJudge
from core.metrics import BigBenchResult, BigBenchMetricsAggregator
from core.report import print_terminal_report, save_json_report
from core.ws_test_client import RealtimeTestClient
from core.webrtc_client import WebRTCClient, LiveKitBenchmarkRunner
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("bigbench.runner")
def get_ws_url() -> str:
    return os.getenv("WS_URL", "wss://api.health.com/v1/realtime?model=health-assistant")
def get_auth_token() -> str:
    return os.getenv("AUTH_TOKEN", "")
def get_asr_model() -> str:
    return os.getenv("ASR_MODEL", "ws_asr")
def resample_24k_to_16k(pcm_bytes: bytes) -> bytes:
    import numpy as np
    samples = np.frombuffer(pcm_bytes, dtype=np.int16)
    ratio = 16000 / 24000
    new_len = int(len(samples) * ratio)
    indices = np.linspace(0, len(samples) - 1, new_len).astype(int)
    return samples[indices].tobytes()
def get_asr_ws_url() -> str:
    return os.getenv("ASR_WS_URL", "ws://192.168.0.44:32000/api-ws/v1/realtime")
def get_judge_api_key() -> str:
    return os.getenv("MINIMAX_API_KEY", "")
def get_judge_model() -> str:
    return os.getenv("JUDGE_MODEL", "MiniMax-M2.7")


def derive_livekit_token_api_url(ws_url: str) -> str:
    """Derive /api/livekit/token from the realtime websocket URL when possible."""
    if not ws_url:
        return ""
    parts = urlsplit(ws_url)
    scheme = "https" if parts.scheme in ("wss", "https") else "http"
    path = parts.path
    if path.endswith("/api/realtime"):
        path = path[: -len("/api/realtime")] + "/api/livekit/token"
    elif path.endswith("/v1/realtime"):
        path = path[: -len("/v1/realtime")] + "/api/livekit/token"
    else:
        return ""
    return urlunsplit((scheme, parts.netloc, path, "", ""))


def derive_agent_name(ws_url: str) -> str:
    if not ws_url:
        return ""
    model = parse_qs(urlsplit(ws_url).query).get("model", [""])[0]
    return model if model.startswith("health-assistant-") else ""


def derive_token_mode(ws_url: str) -> str:
    path = urlsplit(ws_url).path.lower() if ws_url else ""
    for mode in ("dev1", "dev2", "dev3", "prod"):
        if mode in path:
            return mode
    return ""


def count_by_category(cases: list[BigBenchCase]) -> dict[str, int]:
    categories = {}
    for case in cases:
        categories[case.category] = categories.get(case.category, 0) + 1
    return categories


def filter_by_audio_duration(
    cases: list[BigBenchCase],
    max_audio_seconds: Optional[float],
    min_audio_seconds: Optional[float] = None,
) -> list[BigBenchCase]:
    if max_audio_seconds is None and min_audio_seconds is None:
        return cases
    filtered = [
        case for case in cases
        if case.audio_duration_s is not None
        and (max_audio_seconds is None or case.audio_duration_s <= max_audio_seconds)
        and (min_audio_seconds is None or case.audio_duration_s >= min_audio_seconds)
    ]
    skipped = len(cases) - len(filtered)
    filters = []
    if min_audio_seconds is not None:
        filters.append(f">= {min_audio_seconds:.2f}s")
    if max_audio_seconds is not None:
        filters.append(f"<= {max_audio_seconds:.2f}s")
    logger.info(
        "Audio duration filter: kept %d/%d cases with audio %s, skipped %d",
        len(filtered),
        len(cases),
        " and ".join(filters),
        skipped,
    )
    logger.info("Filtered categories: %s", count_by_category(filtered))
    return filtered


class ASRClient:
    def __init__(self, model: str = "ws_asr", asr_ws_url: str = ""):
        self.model = model
        self.asr_ws_url = asr_ws_url
    async def transcribe(self, audio_bytes: bytes) -> str:
        if self.model == "ws_asr":
            return await self._ws_asr_transcribe(audio_bytes)
        elif self.model == "whisper":
            return await self._whisper_transcribe(audio_bytes)
        else:
            raise ValueError(f"Unknown ASR model: {self.model}")
    async def _ws_asr_transcribe(self, audio_bytes: bytes) -> str:
        import websockets
        uri = self.asr_ws_url or get_asr_ws_url()
        try:
            async with websockets.connect(uri) as ws:
                msg = json.loads(await ws.recv())
                if msg.get("type") != "session.created":
                    logger.warning(f"ASR unexpected: {msg.get('type')}")
                    return ""
                await ws.send(json.dumps({
                    "event_id": f"evt_{uuid.uuid4().hex[:8]}",
                    "type": "session.update",
                    "session": {
                        "modalities": ["text"],
                        "input_audio_format": "pcm",
                        "input_audio_transcription": {"language": "en"},
                    }
                }))
                msg = json.loads(await ws.recv())
                if msg.get("type") == "error":
                    logger.warning(f"ASR session.update error: {msg}")
                    return ""
                chunk_size = 3200
                chunk_duration = chunk_size / 2 / 16000
                for i in range(0, len(audio_bytes), chunk_size):
                    chunk = audio_bytes[i:i + chunk_size]
                    await ws.send(json.dumps({
                        "event_id": f"evt_{uuid.uuid4().hex[:8]}",
                        "type": "input_audio_buffer.append",
                        "audio": base64.b64encode(chunk).decode(),
                    }))
                    await asyncio.sleep(chunk_duration * 0.5)
                transcripts = []
                last_stash = ""
                last_event_time = time.monotonic()
                while time.monotonic() - last_event_time < 20:
                    try:
                        raw = await asyncio.wait_for(ws.recv(), timeout=5)
                        msg = json.loads(raw)
                        msg_type = msg.get("type", "")
                        last_event_time = time.monotonic()
                        if msg_type == "conversation.item.input_audio_transcription.completed":
                            t = msg.get("transcript", "")
                            if t:
                                transcripts.append(t)
                        elif msg_type == "conversation.item.input_audio_transcription.text":
                            stash = msg.get("stash", "")
                            if stash:
                                last_stash = stash
                        elif msg_type == "response.done":
                            break
                        elif msg_type == "error":
                            break
                    except asyncio.TimeoutError:
                        continue
                
                if transcripts:
                    return " ".join(transcripts).strip()
                if last_stash:
                    return last_stash.strip()
                return ""
        except Exception as e:
            logger.warning(f"WS ASR transcription failed: {e}")
            return ""
    async def _whisper_transcribe(self, audio_bytes: bytes) -> str:
        import subprocess
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".pcm", delete=False) as f:
            f.write(audio_bytes)
            temp_path = f.name
        try:
            result = subprocess.run(
                ["whisper", temp_path, "--model", "base", "--language", "en"],
                capture_output=True, text=True, timeout=30,
            )
            return result.stdout.strip()
        except Exception as e:
            logger.warning(f"Whisper transcription failed: {e}")
            return ""
        finally:
            os.unlink(temp_path)
@dataclass
class CaseResult:
    case: BigBenchCase
    predicted_answer: Optional[str]
    correct: Optional[bool]
    latency_ms: Optional[float]
    error: Optional[str]
class WebSocketBenchmarkRunner:
    def __init__(self, ws_url: str, auth_token: str, asr_client: ASRClient, judge: BigBenchJudge):
        self.ws_url = ws_url
        self.auth_token = auth_token
        self.asr_client = asr_client
        self.judge = judge
        self.metrics = BigBenchMetricsAggregator()
    async def run_single_case(self, client: RealtimeTestClient, case: BigBenchCase) -> CaseResult:
        try:
            client.clear_events()
            audio_bytes = getattr(case, "_audio_bytes", None)
            if not audio_bytes:
                return CaseResult(case=case, predicted_answer=None, correct=None, latency_ms=None, error="No audio data")
            try:
                await client.wait_for_event("session.created", timeout=10)
            except asyncio.TimeoutError:
                pass
            await asyncio.sleep(5.0)
            await client.inject_audio(audio_bytes)
            t_audio_end = time.monotonic()
            
            try:
                await client.wait_for_event("response.created", timeout=30)
            except asyncio.TimeoutError:
                return CaseResult(case=case, predicted_answer=None, correct=None, latency_ms=None, error="Timeout waiting for response")
            last_seen_idx = 0
            audio_frames = []
            t_first_audio = None
            start_time = time.monotonic()
            no_new_count = 0
            while time.monotonic() - start_time < 60:
                events = client.get_events("response.output_audio.delta")
                new_events = events[last_seen_idx:]
                last_seen_idx = len(events)
                new_count = 0
                for ev in new_events:
                    if "delta" in ev.event and ev.timestamp > t_audio_end:
                        if t_first_audio is None:
                            t_first_audio = ev.timestamp
                        audio_frames.append(ev.event["delta"])
                        new_count += 1
                if new_count > 0:
                    no_new_count = 0
                else:
                    no_new_count += 1
                if no_new_count >= 30 and t_first_audio:
                    
                    break
                await asyncio.sleep(0.3)
            
            latency_ms = (t_first_audio - t_audio_end) * 1000 if t_first_audio else None
            if not audio_frames:
                return CaseResult(case=case, predicted_answer=None, correct=None, latency_ms=latency_ms, error="No response audio frames")
            response_audio = b"".join(base64.b64decode(frame) for frame in audio_frames)
            response_audio_16k = resample_24k_to_16k(response_audio)
            
            import wave, numpy as np
            output_dir = Path(__file__).parent / "output"
            output_dir.mkdir(parents=True, exist_ok=True)
            wav_path = output_dir / f"case_{case.id}.wav"
            with wave.open(str(wav_path), "w") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(16000)
                wf.writeframes(response_audio_16k)
            print(f"[DEBUG] Saved {wav_path}")
            predicted_text = await self.asr_client.transcribe(response_audio_16k)
            print(f"[DEBUG] ASR result: {predicted_text[:100] if predicted_text else '(empty)'}")
            print(f"[CASE {case.id}] frames={len(audio_frames)}, audio={len(response_audio_16k)} bytes, latency={latency_ms:.0f}ms")
            if not predicted_text:
                self.metrics.add(BigBenchResult(case_id=case.id, category=case.category, question=case.question, expected_answer=case.answer, predicted_answer="", correct=False))
                return CaseResult(case=case, predicted_answer="", correct=False, latency_ms=latency_ms, error="ASR empty")
            result = self.judge.judge(case, predicted_text)
            if not result.correct:
                import re
                expected = case.answer.lower().strip()
                predicted = predicted_text.lower().strip()
                if re.search(r"\b" + re.escape(expected) + r"\b", predicted):
                    result.correct = True
                    print(f"[CASE {case.id}] Keyword fallback: correct")
            result.t_question_audio_end = t_audio_end
            result.t_first_audio = t_first_audio
            self.metrics.add(result)
            return CaseResult(case=case, predicted_answer=predicted_text, correct=result.correct, latency_ms=latency_ms, error=None)
        except asyncio.TimeoutError:
            print(f"[DEBUG] Timeout for case {case.id}")
            return CaseResult(case=case, predicted_answer=None, correct=None, latency_ms=None, error="Timeout")
        except Exception as e:
            import traceback
            traceback.print_exc()
            return CaseResult(case=case, predicted_answer=None, correct=None, latency_ms=None, error=str(e))
    async def run(self, cases: list[BigBenchCase], max_cases: Optional[int] = None, dry_run: bool = False) -> BigBenchMetricsAggregator:
        if max_cases:
            cases = cases[:max_cases]
        logger.info(f"Running WebSocket benchmark: {len(cases)} cases")
        client = RealtimeTestClient()
        try:
            for i, case in enumerate(cases):
                if dry_run:
                    result = BigBenchResult(case_id=case.id, category=case.category, question=case.question, expected_answer=case.answer, predicted_answer="[dry]", correct=True)
                    self.metrics.add(result)
                else:
                    client = RealtimeTestClient()
                    await client.connect(self.ws_url, self.auth_token)
                    await self.run_single_case(client, case)
                    await client.disconnect()
                    await asyncio.sleep(3.0)
                if (i + 1) % 10 == 0:
                    logger.info(f"Progress: {i+1}/{len(cases)} - Accuracy: {self.metrics.accuracy():.1%}")
        except Exception as e:
            logger.error(f"Run error: {e}")
        return self.metrics
async def main():
    parser = argparse.ArgumentParser(description="BigBench Speech Reasoning Benchmark")
    parser.add_argument("--protocol", type=str, default="websocket", choices=["websocket", "webrtc"])
    parser.add_argument("--category", type=str, help="Filter by category")
    parser.add_argument("--max-cases", type=int, help="Max number of cases to run")
    parser.add_argument("--per-category", type=int, help="Max cases per category (overrides --max-cases)")
    parser.add_argument(
        "--min-audio-seconds",
        type=float,
        default=None,
        help="Only run cases with audio duration at or above this many seconds",
    )
    parser.add_argument(
        "--max-audio-seconds",
        type=float,
        default=None,
        help="Only run cases with audio duration at or below this many seconds",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--output", type=str, help="Output JSON report path")
    parser.add_argument("--asr-model", type=str, default="ws_asr")
    parser.add_argument("--ws-url", type=str, default=None)
    parser.add_argument("--auth-token", type=str, default=None)
    parser.add_argument("--livekit-url", type=str, default=None)
    parser.add_argument("--livekit-token-api-url", type=str, default=None)
    parser.add_argument("--livekit-api-key", type=str, default=None)
    parser.add_argument("--livekit-api-secret", type=str, default=None)
    parser.add_argument("--livekit-room", type=str, default="bigbench")
    parser.add_argument("--token-mode", type=str, default=None)
    parser.add_argument("--agent-name", type=str, default=None)
    parser.add_argument("--speaker", type=str, default=None)
    parser.add_argument("--reuse-room", action="store_true")
    parser.add_argument(
        "--early-response-retries",
        type=int,
        default=1,
        help="Replay a WebRTC case when the agent speaks before question audio ends",
    )
    parser.add_argument(
        "--early-response-policy",
        choices=["warn", "retry", "fail"],
        default="warn",
        help="How WebRTC mode handles agent speech before question audio ends",
    )
    parser.add_argument(
        "--trailing-silence-ms",
        type=int,
        default=600,
        help="Silence appended after each injected WebRTC question",
    )
    parser.add_argument(
        "--response-start-timeout",
        type=float,
        default=60.0,
        help="Seconds to wait for WebRTC response speech after question audio",
    )
    parser.add_argument(
        "--response-end-timeout",
        type=float,
        default=120.0,
        help="Seconds to wait for WebRTC response speech to finish",
    )
    args = parser.parse_args()
    dataset = BigBenchHFDataset.load(category=args.category)
    if not dataset.cases:
        logger.error("No cases loaded")
        return
    logger.info(f"Loaded {len(dataset)} cases")
    logger.info(f"Categories: {count_by_category(list(dataset))}")
    asr_client = ASRClient(model=args.asr_model, asr_ws_url=get_asr_ws_url())
    judge = BigBenchJudge(judge_model=get_judge_model(), api_key=get_judge_api_key())
    if args.protocol == "webrtc":
        from core.webrtc_client import LiveKitBenchmarkRunner
        realtime_ws_url = args.ws_url or get_ws_url()
        livekit_url = args.livekit_url or os.getenv("LIVEKIT_URL", "")
        token_api_url = (
            args.livekit_token_api_url
            or os.getenv("LIVEKIT_TOKEN_API_URL", "")
            or derive_livekit_token_api_url(realtime_ws_url)
        )
        token_mode = (
            args.token_mode
            or os.getenv("LIVEKIT_TOKEN_MODE", "")
            or derive_token_mode(realtime_ws_url)
        )
        agent_name = (
            args.agent_name
            or os.getenv("LIVEKIT_AGENT_NAME", "")
            or derive_agent_name(realtime_ws_url)
        )
        speaker = args.speaker or os.getenv("LIVEKIT_SPEAKER", "") or os.getenv("SPEAKER", "")
        if not token_api_url:
            logger.error("WebRTC mode requires --livekit-token-api-url/env LIVEKIT_TOKEN_API_URL, or a WS_URL ending in /api/realtime")
            return
        logger.info(
            "WebRTC config: token_api_url=%s livekit_url=%s token_mode=%s agent_name=%s speaker=%s",
            token_api_url,
            livekit_url or "(from token response)",
            token_mode or "(backend default)",
            agent_name or "(backend default)",
            speaker or "(backend default)",
        )
        runner = LiveKitBenchmarkRunner(
            livekit_url=livekit_url,
            token_api_url=token_api_url,
            asr_client=asr_client,
            judge=judge,
            room_name=args.livekit_room,
            api_key=args.livekit_api_key or os.getenv("LIVEKIT_API_KEY", ""),
            api_secret=args.livekit_api_secret or os.getenv("LIVEKIT_API_SECRET", ""),
            auth_token=args.auth_token or get_auth_token(),
            token_mode=token_mode,
            agent_name=agent_name,
            speaker=speaker,
            reconnect_per_case=not args.reuse_room,
            early_response_retries=args.early_response_retries,
            early_response_policy=args.early_response_policy,
            trailing_silence_ms=args.trailing_silence_ms,
            response_start_timeout_s=args.response_start_timeout,
            response_end_timeout_s=args.response_end_timeout,
        )
    else:
        runner = WebSocketBenchmarkRunner(
            ws_url=args.ws_url or get_ws_url(),
            auth_token=args.auth_token or get_auth_token(),
            asr_client=asr_client,
            judge=judge,
        )
    candidate_cases = filter_by_audio_duration(
        list(dataset),
        max_audio_seconds=args.max_audio_seconds,
        min_audio_seconds=args.min_audio_seconds,
    )
    if not candidate_cases:
        logger.error("No cases left after filtering")
        return

    if args.per_category:
        from collections import defaultdict
        by_cat = defaultdict(list)
        for case in candidate_cases:
            by_cat[case.category].append(case)
        cases = []
        for cat, cat_cases in by_cat.items():
            cases.extend(cat_cases[:args.per_category])
            logger.info(f"  {cat}: {min(args.per_category, len(cat_cases))}/{len(cat_cases)} cases")
        logger.info(f"Total: {len(cases)} cases ({args.per_category} per category)")
    else:
        cases = candidate_cases

    metrics = await runner.run(
        cases=cases,
        max_cases=args.max_cases if not args.per_category else None,
        dry_run=args.dry_run,
    )
    print_terminal_report(metrics)
    output_dir = args.output or str(Path(__file__).parent / "test_reports")
    save_json_report(metrics, output_dir=output_dir, agent_mode=args.protocol)
if __name__ == "__main__":
    asyncio.run(main())

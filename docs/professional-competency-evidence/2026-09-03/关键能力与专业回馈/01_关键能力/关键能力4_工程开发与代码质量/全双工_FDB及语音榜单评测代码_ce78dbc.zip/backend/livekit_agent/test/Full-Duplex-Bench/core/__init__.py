"""Full-Duplex-Bench 评估模块"""

import sys
from pathlib import Path

# 添加 realtime 路径（ws_test_client 在那里）
REALTIME_DIR = Path(__file__).parent.parent.parent / "realtime"
if str(REALTIME_DIR) not in sys.path:
    sys.path.insert(0, str(REALTIME_DIR))

from .metrics import (
    TORCalculator,
    LatencyCalculator,
    JSDCalculator,
    MetricsAggregator,
    EvaluationResult,
)

from .case import DatasetCase
from .dataset import load_audio_file, load_dataset_cases, load_wav_audio

# 从 realtime.core.ws_test_client 导入 RealtimeTestClient
import importlib.util
import asyncio

def load_spec(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

_rt_ws = load_spec("core.ws_test_client", REALTIME_DIR / "core" / "ws_test_client.py")
RealtimeTestClient = _rt_ws.RealtimeTestClient

# 配置常量
AUDIO_DELTA_EVENT = "response.output_audio.delta"


async def wait_for_agent_state(ws_client, state: str, timeout: float = 15.0):
    try:
        await ws_client.wait_for_agent_state(state, timeout=timeout)
        return True
    except asyncio.TimeoutError:
        return False


__all__ = [
    # metrics
    "TORCalculator",
    "LatencyCalculator",
    "JSDCalculator",
    "MetricsAggregator",
    "EvaluationResult",
    # case
    "DatasetCase",
    # dataset
    "load_dataset_cases",
    "load_audio_file",
    "load_wav_audio",
    # ws client
    "RealtimeTestClient",
    # utils
    "wait_for_agent_state",
    "AUDIO_DELTA_EVENT",
]


def __getattr__(name):
    if name in ("AliYunASRClient", "SynchAliYunASRClient"):
        from . import asr_client
        return getattr(asr_client, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

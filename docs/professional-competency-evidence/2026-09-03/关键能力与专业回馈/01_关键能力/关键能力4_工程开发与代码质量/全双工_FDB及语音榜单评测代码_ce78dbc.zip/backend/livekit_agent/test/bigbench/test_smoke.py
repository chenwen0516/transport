"""BigBench Speech Reasoning Benchmark 冒烟测试

验证基本流程：连接、音频注入、推理回答。
"""

import asyncio
import logging
import pytest
import time

from core.ws_test_client import RealtimeTestClient
from core.audio_generator import AudioGenerator
from core.case import BigBenchCase
from core.judge import BigBenchJudge

# 正确的事件名（与 realtime 一致）
AUDIO_DELTA_EVENT = "response.output_audio.delta"


@pytest.mark.smoke
async def test_connect_and_session_created(ws_client: RealtimeTestClient, ws_url, auth_token):
    """连接 WebSocket 并收到 session.created"""
    session_event = await ws_client.connect(ws_url, auth_token)
    assert session_event.event_type == "session.created"
    assert "session" in session_event.event


@pytest.mark.smoke
async def test_agent_greeting(ws_client: RealtimeTestClient, ws_url, auth_token):
    """连接后 agent 应自动发送开场白"""
    await ws_client.connect(ws_url, auth_token)

    # 等待 agent 进入 speaking
    speaking_event = await ws_client.wait_for_agent_state("speaking", timeout=15)
    assert speaking_event.event.get("state") == "speaking"

    # 等待收到音频数据
    audio_event = await ws_client.wait_for_event(AUDIO_DELTA_EVENT, timeout=10)
    assert "delta" in audio_event.event

    # 等待 agent 回到 listening
    listening_event = await ws_client.wait_for_agent_state("listening", timeout=30)
    assert listening_event.event.get("state") == "listening"


@pytest.mark.smoke
async def test_inject_audio_triggers_response(
    ws_client: RealtimeTestClient, ws_url, auth_token, audio_gen
):
    """注入语音信号应触发 agent 响应"""
    await ws_client.connect(ws_url, auth_token)

    # 等待 agent 开场白结束
    await ws_client.wait_for_agent_state("listening", timeout=30)
    ws_client.clear_events()

    # 注入 2 秒类语音信号
    pcm = AudioGenerator.speech_like(2.0)
    await ws_client.inject_audio(pcm)

    # 应收到响应
    try:
        response_event = await ws_client.wait_for_agent_state("thinking", timeout=10)
        assert response_event.event.get("state") == "thinking"
    except asyncio.TimeoutError:
        # 可能直接进入 speaking
        speaking = await ws_client.wait_for_agent_state("speaking", timeout=5)
        assert speaking.event.get("state") == "speaking"


@pytest.mark.bigbench
async def test_simple_question_answering(
    ws_client: RealtimeTestClient, ws_url, auth_token, audio_gen
):
    """测试简单问题回答（算术）"""
    await ws_client.connect(ws_url, auth_token)

    # 等待 agent 开场白结束
    await ws_client.wait_for_agent_state("listening", timeout=30)
    ws_client.clear_events()

    # 测试问题：5 + 3 = ?
    question_text = "What is five plus three?"
    judge = BigBenchJudge()

    case = BigBenchCase(
        id="arithmetic_001",
        category="arithmetic",
        question=question_text,
        answer="8",
    )

    # 生成 TTS 音频（使用程序生成的语音）
    pcm = AudioGenerator.speech_like(3.0)

    # 注入问题音频
    t_audio_end = time.monotonic()
    await ws_client.inject_audio(pcm)

    # 等待 agent 响应
    try:
        speaking_event = await ws_client.wait_for_agent_state("speaking", timeout=30)
        t_first_audio = time.monotonic()
    except asyncio.TimeoutError:
        pytest.fail("Agent did not start speaking after question")

    # 收集回复的音频
    audio_frames = []
    start_time = time.monotonic()
    timeout = 30  # 最多等 30 秒

    while time.monotonic() - start_time < timeout:
        if ws_client.has_event("response.done"):
            break
        await asyncio.sleep(0.1)

    # 获取所有音频帧
    for event in ws_client.get_events(AUDIO_DELTA_EVENT):
        if "delta" in event.event:
            audio_frames.append(event)

    # 等待 agent 回到 listening
    try:
        await ws_client.wait_for_agent_state("listening", timeout=10)
    except asyncio.TimeoutError:
        pass  # 可能没有回到 listening

    # 注意：这里需要 ASR 将音频转为文本才能判分
    # 实际使用时需要接入 ASR 服务
    logging.getLogger("test.bigbench").warning(
        "ASR not integrated yet - cannot verify answer correctness"
    )
"""数据集相关的数据结构"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class DatasetCase:
    """数据集测试用例"""
    sample_dir: Path
    case_name: str
    task: str
    input_audio: bytes = None
    interrupt_audio: bytes = None
    interrupt_timestamp: list = None
    interrupt_text: str = None  # 用户打断文本内容
    pause_timestamp: list = None  # 停顿时间段 [start, end]，用于 pause_handling
    turn_taking_timestamp: list = None  # 用户说完时刻，用于 smooth_turn_taking
    metadata: dict = None
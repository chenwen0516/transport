"""Full-Duplex-Bench 实时评估测试 - 使用 v1.0 数据集

通过 WebSocket URL 连接远程模型，使用 v1.0 数据集的音频进行测试。

测试维度:
1. user_interruption  - 用户打断
2. barge_in_recovery  - 打断后恢复
3. pause_handling     - 停顿处理
4. smooth_turn_taking - 话轮转换

用法:
    # 设置环境变量
    export WS_URL="wss://api.health.com/v1/realtime?model=health-assistant"
    export AUTH_TOKEN="your-token-here"

    # 指定数据集路径
    export DATASET_ROOT="dataset/v1.0"

    # 运行测试
    python test_fdb_realtime_dataset.py

    # 或指定具体任务
    python test_fdb_realtime_dataset.py --task user_interruption --root_dir dataset/v1.0/synthetic_user_interruption
"""

import argparse
import asyncio
import json
import os
import sys
import time
import wave
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import numpy as np
from typing import Optional

import pytest
import pytest_asyncio

# ========== 路径设置 ==========
FDB_DIR = Path(__file__).parent
REALTIME_DIR = FDB_DIR.parent / "realtime"

if str(REALTIME_DIR) not in sys.path:
    sys.path.insert(0, str(REALTIME_DIR))
if str(FDB_DIR) not in sys.path:
    sys.path.insert(0, str(FDB_DIR))

# ========== 导入处理 ==========
import importlib.util

def load_spec(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

_rt_ws = load_spec("core.ws_test_client", REALTIME_DIR / "core" / "ws_test_client.py")
RealtimeTestClient = _rt_ws.RealtimeTestClient

_rt_audio = load_spec("core.audio_generator", REALTIME_DIR / "core" / "audio_generator.py")
AudioGenerator = _rt_audio.AudioGenerator

sys.path.insert(0, str(FDB_DIR))
from core.metrics import MetricsAggregator, EvaluationResult

# ========== 配置 ==========
WS_URL = os.getenv("WS_URL", "wss://api.health.com/v1/realtime?model=health-assistant")
AUTH_TOKEN = os.getenv("AUTH_TOKEN", "")
DEFAULT_DATASET_ROOT = FDB_DIR / "dataset" / "v1.0"

AUDIO_DELTA_EVENT = "response.output_audio.delta"


# ========== 数据集加载 ==========

@dataclass
class DatasetCase:
    """数据集测试用例"""
    sample_dir: Path
    case_name: str
    task: str
    input_audio: bytes = None
    interrupt_audio: bytes = None
    interrupt_timestamp: list = None
    pause_timestamp: list = None  # 停顿时间段 [start, end]，用于 pause_handling
    turn_taking_timestamp: list = None  # 用户说完时刻，用于 smooth_turn_taking
    metadata: dict = None


def load_wav_audio(wav_path: Path) -> Optional[bytes]:
    """读取 wav 文件并返回 PCM 16-bit 数据

    支持 16-bit PCM, 24-bit PCM, 32-bit float
    """
    try:
        import struct

        with open(wav_path, 'rb') as f:
            riff = f.read(4)
            if riff != b'RIFF':
                return None

            f.read(4)  # file_size
            wave_id = f.read(4)
            if wave_id != b'WAVE':
                return None

            sampwidth = None
            raw_data = None

            while True:
                chunk_header = f.read(8)
                if len(chunk_header) < 8:
                    break
                chunk_id = chunk_header[0:4]
                chunk_size = struct.unpack('<I', chunk_header[4:8])[0]

                if chunk_id == b'fmt ':
                    fmt_data = f.read(chunk_size)
                    if len(fmt_data) >= 16:
                        bits_per_sample = struct.unpack('<H', fmt_data[14:16])[0]
                        sampwidth = bits_per_sample // 8
                elif chunk_id == b'data':
                    raw_data = f.read(chunk_size)
                else:
                    f.read(chunk_size)

            if sampwidth is None or raw_data is None:
                return None

            if sampwidth == 2:
                return raw_data

            if sampwidth == 3:
                result = bytearray()
                for i in range(0, len(raw_data) - 2, 3):
                    val = raw_data[i] | (raw_data[i+1] << 8) | (raw_data[i+2] << 16)
                    if val >= 0x800000:
                        val -= 0x1000000
                    val = val >> 8
                    result.extend(struct.pack('<h', val))
                return bytes(result)

            if sampwidth == 4:
                audio_data = np.frombuffer(raw_data, dtype=np.float32)
                audio_data = np.clip(audio_data, -1.0, 1.0)
                audio_int16 = (audio_data * 32767).astype(np.int16)
                return audio_int16.tobytes()

            return None
    except Exception:
        return None


def load_dataset_cases(dataset_root: Path, task: str) -> list[DatasetCase]:
    """加载数据集测试用例

    Args:
        dataset_root: 数据集根目录，如 /path/to/v1.0/synthetic_user_interruption
        task: 任务类型
    """
    cases = []

    for sample_dir in sorted(dataset_root.iterdir()):
        if not sample_dir.is_dir():
            continue

        case_name = f"{dataset_root.name}/{sample_dir.name}"

        case = DatasetCase(
            sample_dir=sample_dir,
            case_name=case_name,
            task=task,
        )

        input_wav = sample_dir / "input.wav"
        if input_wav.exists():
            case.input_audio = load_wav_audio(input_wav)

        interrupt_wav = sample_dir / "interrupt.wav"
        if interrupt_wav.exists():
            case.interrupt_audio = load_wav_audio(interrupt_wav)

        interrupt_json = sample_dir / "interrupt.json"
        if interrupt_json.exists():
            try:
                with open(interrupt_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if data and len(data) > 0:
                        case.interrupt_timestamp = data[0].get("timestamp")
            except Exception:
                pass

        pause_json = sample_dir / "pause.json"
        if pause_json.exists():
            try:
                with open(pause_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if data and len(data) > 0:
                        case.pause_timestamp = data[0].get("timestamp")
            except Exception:
                pass

        turn_taking_json = sample_dir / "turn_taking.json"
        if turn_taking_json.exists():
            try:
                with open(turn_taking_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if data and len(data) > 0:
                        case.turn_taking_timestamp = data[0].get("timestamp")
            except Exception:
                pass

        metadata_json = sample_dir / "metadata.json"
        if metadata_json.exists():
            try:
                with open(metadata_json, 'r', encoding='utf-8') as f:
                    case.metadata = json.load(f)
            except Exception:
                pass

        if case.input_audio:
            cases.append(case)

    return cases


# ========== 辅助函数 ==========

async def wait_for_agent_state(ws_client, state: str, timeout: float = 15.0):
    try:
        await ws_client.wait_for_agent_state(state, timeout=timeout)
        return True
    except asyncio.TimeoutError:
        return False


# ========== 测试函数 ==========

async def test_user_interruption_dataset(ws_client, ws_url, auth_token, case: DatasetCase, metrics_aggregator, min_deltas: int = 5):
    """使用数据集音频测试用户打断

    流程（与 test_interruption.py 一致）：
    1. 连接并等待 AI 开始说话
    2. 等待 AI 说到一半（收到足够 deltas）
    3. 注入 interrupt.wav 打断
    4. 检查 AI 是否被打断并计算响应延迟
    """
    if not case.interrupt_audio:
        print(f"    跳过 {case.case_name}: 无打断音频")
        return

    await ws_client.connect(ws_url, auth_token)

    # 等待 AI 开始说话
    if not await wait_for_agent_state(ws_client, "speaking", timeout=15):
        print(f"    跳过 {case.case_name}: AI 未开始说话")
        return

    # 等待 AI 说到一半（收到足够 deltas）
    deadline = time.monotonic() + 15
    while ws_client.count_events(AUDIO_DELTA_EVENT) < min_deltas:
        if time.monotonic() > deadline:
            print(f"    跳过 {case.case_name}: AI 未输出足够音频")
            return
        await asyncio.sleep(0.05)

    # 注入打断音频
    t_inject_first, t_inject_last = await ws_client.inject_audio(case.interrupt_audio)

    # 等待打断后的结果
    await ws_client.drain_events(timeout=10.0)

    # 检查是否被打断
    interrupted = ws_client.has_event_after(
        "response.done", t_inject_first,
        lambda e: e.get("response", {}).get("status") == "cancelled",
    )
    if not interrupted:
        interrupted = ws_client.has_event_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )

    # 计算真实打断延迟：从注入打断到 AI 进入 thinking 的时间
    latency = -1.0
    if interrupted:
        t_thinking = ws_client.get_event_time_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )
        if t_thinking:
            latency = (t_thinking - t_inject_first) * 1000  # 转换为毫秒

    result = EvaluationResult(
        task="user_interruption",
        case_name=case.case_name,
        tor=1.0 if interrupted else 0.0,
        latency=latency,
    )
    metrics_aggregator.add_result(result)

    print(f"    {'✓' if interrupted else '✗'} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency > 0 else f"    {'✓' if interrupted else '✗'} {case.case_name}: tor={result.tor}")


async def test_pause_handling_dataset(ws_client, ws_url, auth_token, case: DatasetCase, metrics_aggregator, min_deltas: int = 10):
    """使用数据集音频测试停顿处理

    场景：用户在说话中途有停顿，AI 应判断是否接过话轮。
    关键：根据 pause_timestamp 在对应时刻检测 AI 状态变化。

    逻辑：
    1. 边发送音频边检测 AI 状态
    2. 在 pause_timestamp 开始时刻附近检测 AI 是否开始说话
    3. TOR = 1 如果 AI 在停顿期间/后抢话轮
    """
    if not case.input_audio:
        print(f"    跳过 {case.case_name}: 无 input_audio")
        return

    await ws_client.connect(ws_url, auth_token)
    ws_client.clear_events()

    t_start = time.monotonic()

    # 边发送音频边检测 AI 状态
    send_task = await ws_client.inject_audio_nonblocking(case.input_audio)

    switched = False
    t_switched = None
    latency = None

    # 估算 pause 开始时刻（相对于 t_start）
    # 100ms per chunk, chunk_bytes = 3200 bytes = 16000 samples/s * 0.1s * 2 bytes
    # pause_timestamp 是秒级，需要转换为 chunk 数
    pause_start_s = case.pause_timestamp[0] if case.pause_timestamp else None

    # 监控循环：发送期间持续检测 AI 状态
    while not send_task.done():
        state_changed = ws_client.get_event_time_after(
            "agent.state_changed", t_start
        )
        if state_changed:
            # 检查状态是否为 speaking（AI 抢话轮）
            event = ws_client.get_last_event("agent.state_changed")
            if event and event.event.get("state") == "speaking":
                t_switched = state_changed
                if pause_start_s is not None:
                    # switched_time 是真实时间差（秒）
                    # pause_start_s 是音频时间（秒），音频以 real-time 速度发送
                    # 因此真实时间 pause 开始 = t_start + pause_start_s
                    real_pause_start = pause_start_s
                    real_window_end = (case.pause_timestamp[1] if case.pause_timestamp else pause_start_s + 2.0) + 2.0
                    switched_time = t_switched - t_start
                    if real_pause_start <= switched_time <= real_window_end:
                        switched = True
                        break
                else:
                    # 无 pause_timestamp 时，只要发送期间响应即可
                    switched = True
                    break
        await asyncio.sleep(0.05)

    # 等待发送完成
    await send_task

    # 发送完成后额外检测（捕获慢响应）
    if not switched:
        t_after_send = time.monotonic()
        switched = ws_client.has_event_after(
            "agent.state_changed", t_after_send,
            predicate=lambda e: e.get("state") == "speaking",
        )

    if t_switched and pause_start_s is not None:
        latency = (t_switched - t_start) * 1000

    result = EvaluationResult(
        task="pause_handling",
        case_name=case.case_name,
        tor=1.0 if switched else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    print(f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency and latency > 0 else f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}")


async def test_barge_in_recovery_dataset(ws_client, ws_url, auth_token, case: DatasetCase, metrics_aggregator, min_deltas: int = 5):
    """使用数据集音频测试打断后恢复

    流程（与 test_interruption.py 一致）：
    1. 连接并等待 AI 开始说话
    2. 等待 AI 说到一半（收到足够 deltas）
    3. 注入 interrupt.wav 打断
    4. 注入静默，验证 AI 是否恢复
    """
    if not case.interrupt_audio:
        print(f"    跳过 {case.case_name}: 无打断音频")
        return

    await ws_client.connect(ws_url, auth_token)

    # 等待 AI 开始说话
    if not await wait_for_agent_state(ws_client, "speaking", timeout=15):
        print(f"    跳过 {case.case_name}: AI 未开始说话")
        return

    # 等待 AI 说到一半（收到足够 deltas）
    deadline = time.monotonic() + 15
    while ws_client.count_events(AUDIO_DELTA_EVENT) < min_deltas:
        if time.monotonic() > deadline:
            print(f"    跳过 {case.case_name}: AI 未输出足够音频")
            return
        await asyncio.sleep(0.05)

    # 注入打断音频
    t_inject_first, t_inject_last = await ws_client.inject_audio(case.interrupt_audio)

    # 注入静默
    await ws_client.inject_silence(3.0)

    # 检查是否被打断
    interrupted = ws_client.has_event_after(
        "response.done", t_inject_first,
        lambda e: e.get("response", {}).get("status") == "cancelled",
    )
    if not interrupted:
        interrupted = ws_client.has_event_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )

    # 检查是否恢复
    recovered = False
    latency = -1.0
    deadline = time.monotonic() + 30.0
    while time.monotonic() < deadline:
        if ws_client.has_event_after(
            "agent.state_changed", t_inject_last,
            predicate=lambda e: e.get("state") in ("speaking", "thinking"),
        ):
            recovered = True
            t_recovery = ws_client.get_event_time_after(
                "agent.state_changed", t_inject_last,
                predicate=lambda e: e.get("state") in ("speaking", "thinking"),
            )
            if t_recovery:
                latency = (t_recovery - t_inject_last) * 1000
            break
        await asyncio.sleep(0.1)

    result = EvaluationResult(
        task="barge_in_recovery",
        case_name=case.case_name,
        tor=1.0 if interrupted and recovered else 0.0,
        latency=latency,
    )
    metrics_aggregator.add_result(result)

    status = "✓" if recovered else "✗"
    print(f"    {status} {case.case_name}: tor={result.tor}, recovered={recovered}, latency={latency:.1f}ms" if latency > 0 else f"    {status} {case.case_name}: tor={result.tor}, recovered={recovered}")


async def test_backchannel_dataset(ws_client, ws_url, auth_token, case: DatasetCase, metrics_aggregator, min_deltas: int = 10):
    """使用数据集音频测试回指（短回复）

    回指测试：在用户说话期间，AI 应及时发出短反馈（如"嗯""对"）。
    关键：边发送音频边检测 AI 响应，而不是等音频发完再检测。
    """
    if not case.input_audio:
        print(f"    跳过 {case.case_name}: 无 input_audio")
        return

    await ws_client.connect(ws_url, auth_token)
    ws_client.clear_events()

    t_start = time.monotonic()

    # 边发送音频边检测 AI 响应（并发进行）
    send_task = await ws_client.inject_audio_nonblocking(case.input_audio)

    backchannel_success = False
    first_delta_time = None

    # 发送期间持续检测 AI 音频输出
    while not send_task.done():
        delta = ws_client.get_event_time_after("response.output_audio.delta", t_start)
        if delta:
            first_delta_time = delta
            break
        await asyncio.sleep(0.05)

    # 等待发送完成
    await send_task

    # 发送完成后也检测一段时间（捕获发送末尾阶段的回指）
    await asyncio.sleep(0.5)
    if first_delta_time is None:
        first_delta_time = ws_client.get_event_time_after("response.output_audio.delta", t_start)

    latency = None
    if first_delta_time is not None:
        latency = (first_delta_time - t_start) * 1000
        # 回指应在 3 秒内出现
        if latency <= 3000:
            backchannel_success = True

    result = EvaluationResult(
        task="backchannel",
        case_name=case.case_name,
        tor=1.0 if backchannel_success else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    status = "✓" if backchannel_success else "✗"
    print(f"    {status} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency else f"    {status} {case.case_name}: tor={result.tor}")


async def test_smooth_turn_taking_dataset(ws_client, ws_url, auth_token, case: DatasetCase, metrics_aggregator, min_deltas: int = 10):
    """使用数据集音频测试话轮转换

    场景：用户说完后，AI 应及时接过话轮。
    关键：根据 turn_taking_timestamp（在音频中标记用户说完的时刻）检测 AI 是否响应。

    逻辑：
    1. 边发送音频边检测 AI 状态
    2. turn_taking_timestamp 表示音频中用户说完的时刻
    3. 检测 AI 是否在 [用户说完时刻, 用户说完+3s] 内开始 speaking
    4. TOR = 1 如果 AI 及时响应
    """
    if not case.input_audio:
        print(f"    跳过 {case.case_name}: 无 input_audio")
        return

    await ws_client.connect(ws_url, auth_token)
    ws_client.clear_events()

    t_start = time.monotonic()

    # 边发送音频边检测 AI 状态
    send_task = await ws_client.inject_audio_nonblocking(case.input_audio)

    switched = False
    t_switched = None
    latency = None

    # turn_taking_timestamp 表示音频中用户说完的时刻（秒）
    turn_end_s = case.turn_taking_timestamp[0] if case.turn_taking_timestamp else None

    # 监控循环：发送期间持续检测 AI 状态
    while not send_task.done():
        state_changed = ws_client.get_event_time_after(
            "agent.state_changed", t_start
        )
        if state_changed:
            event = ws_client.get_last_event("agent.state_changed")
            if event and event.event.get("state") == "speaking":
                t_switched = state_changed
                if turn_end_s is not None:
                    # 判断切换是否在合理窗口：用户说完到说完+3s
                    switched_time = t_switched - t_start
                    if turn_end_s <= switched_time <= turn_end_s + 3.0:
                        switched = True
                        break
                else:
                    switched = True
                    break
        await asyncio.sleep(0.05)

    # 等待发送完成
    await send_task

    # 发送完成后额外检测（捕获慢响应）
    if not switched and turn_end_s is not None:
        # 在说完后的窗口内继续检测
        t_after_send = time.monotonic()
        switched = ws_client.has_event_after(
            "agent.state_changed", t_after_send,
            predicate=lambda e: e.get("state") == "speaking",
        )

    if t_switched and turn_end_s is not None:
        latency = (t_switched - t_start) * 1000

    result = EvaluationResult(
        task="smooth_turn_taking",
        case_name=case.case_name,
        tor=1.0 if switched else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    print(f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency and latency > 0 else f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}")


# ========== Fixtures ==========

@pytest_asyncio.fixture(autouse=True)
async def suppress_websockets_rst_noise():
    loop = asyncio.get_running_loop()
    original_handler = loop.get_exception_handler()

    def _handler(loop, context):
        exc = context.get("exception")
        if isinstance(exc, AttributeError) and "recv_messages" in str(exc):
            return
        if original_handler is not None:
            original_handler(loop, context)
        else:
            loop.default_exception_handler(context)

    loop.set_exception_handler(_handler)
    yield
    loop.set_exception_handler(original_handler)


@pytest_asyncio.fixture
async def ws_client():
    client = RealtimeTestClient()
    yield client
    try:
        await client.disconnect()
    except Exception:
        pass


@pytest.fixture(scope="session")
def metrics_aggregator():
    return MetricsAggregator()


# ========== 主函数 ==========

TASK_CONFIGS = {
    "user_interruption": {
        "dirs": ["synthetic_user_interruption"],
        "test_func": test_user_interruption_dataset,
    },
    "barge_in_recovery": {
        "dirs": ["synthetic_user_interruption"],
        "test_func": test_barge_in_recovery_dataset,
    },
    "backchannel": {
        "dirs": ["icc_backchannel"],
        "test_func": test_backchannel_dataset,
    },
    "pause_handling": {
        "dirs": ["candor_pause_handling", "synthetic_pause_handling"],
        "test_func": test_pause_handling_dataset,
    },
    "smooth_turn_taking": {
        "dirs": ["candor_turn_taking"],
        "test_func": test_smooth_turn_taking_dataset,
    },
}


async def main():
    parser = argparse.ArgumentParser(description="Full-Duplex-Bench 实时评估测试 - v1.0 数据集")
    parser.add_argument(
        "--task",
        type=str,
        default=None,
        choices=list(TASK_CONFIGS.keys()) + ["all"],
        help="测试任务类型 (默认: all)",
    )
    parser.add_argument(
        "--root_dir",
        type=str,
        default=None,
        help="数据集根目录 (默认: dataset/v1.0)",
    )
    parser.add_argument(
        "--limit",
        type=str,
        default=None,
        help="每个任务限制数量，如: user_interruption=10,pause_handling=5 或 10 (所有任务相同)",
    )
    parser.add_argument(
        "--min_deltas",
        type=int,
        default=5,
        help="等待打断前最少音频 delta 数量 (默认: 5)",
    )
    args = parser.parse_args()

    # 解析 limit 参数
    DEFAULT_LIMIT = 25
    limits = {}
    if args.limit:
        if "=" in args.limit:
            # 格式: task1=10,task2=5
            for item in args.limit.split(","):
                k, v = item.split("=")
                limits[k.strip()] = int(v.strip())
        else:
            # 格式: 10 (所有任务相同)
            default_limit = int(args.limit)
            limits = {task: default_limit for task in TASK_CONFIGS.keys()}
    else:
        # 默认每个任务 25 条
        limits = {task: DEFAULT_LIMIT for task in TASK_CONFIGS.keys()}

    root_dir = Path(args.root_dir) if args.root_dir else DEFAULT_DATASET_ROOT

    # 确定要运行的任务
    if args.task == "all" or args.task is None:
        tasks_to_run = list(TASK_CONFIGS.keys())
    else:
        tasks_to_run = [args.task]

    print("=" * 60)
    print(f"Full-Duplex-Bench 实时评估测试 (v1.0 数据集)")
    print("=" * 60)
    print(f"任务: {', '.join(tasks_to_run)}")
    print(f"数据集: {root_dir}")
    print(f"WS URL: {WS_URL}")
    print(f"AUTH_TOKEN: {'*' * 20 if AUTH_TOKEN else '(not set)'}")
    print("-" * 60)

    if not AUTH_TOKEN:
        print("警告: AUTH_TOKEN 未设置，连接可能会失败\n")

    metrics_aggregator = MetricsAggregator()

    # 每个维度的测试结果
    task_results = {}

    for task_name in tasks_to_run:
        config = TASK_CONFIGS[task_name]
        test_func = config["test_func"]
        subdirs = config["dirs"]

        # 收集所有用例
        all_cases = []
        for subdir in subdirs:
            dataset_path = root_dir / subdir
            if dataset_path.exists():
                cases = load_dataset_cases(dataset_path, task_name)
                all_cases.extend(cases)

        if not all_cases:
            print(f"\n警告: {task_name} 未找到测试用例，跳过")
            continue

        # 应用限制
        limit = limits.get(task_name)
        if limit and limit < len(all_cases):
            all_cases = all_cases[:limit]
            print(f"\n注意: {task_name} 限制为 {limit} 个样本")

        print(f"\n{'=' * 40}")
        print(f"测试维度: {task_name} ({len(all_cases)} 个用例)")
        print(f"{'=' * 40}")

        # 该维度的结果列表
        case_results = []

        for i, case in enumerate(all_cases):
            print(f"\n[{i+1}/{len(all_cases)}] {case.case_name}")
            ws_client = RealtimeTestClient()

            try:
                await test_func(ws_client, WS_URL, AUTH_TOKEN, case, metrics_aggregator, args.min_deltas)
            except AssertionError as e:
                print(f"    ✗ 断言失败: {e}")
            except Exception as e:
                print(f"    ✗ 错误: {e}")
            finally:
                try:
                    await ws_client.disconnect()
                except Exception:
                    pass
                await asyncio.sleep(0.5)

        # 收集该维度的所有结果
        task_results_list = metrics_aggregator.get_results_by_task(task_name)
        for r in task_results_list:
            case_results.append({
                "case_name": r.case_name,
                "tor": r.tor,
                "latency": r.latency,
                "success": r.success,
                "error": r.error,
            })

        # 计算该维度的汇总
        if case_results:
            total = len(case_results)
            tor_values = [r["tor"] for r in case_results if r["tor"] >= 0]
            latency_values = [r["latency"] for r in case_results if r["latency"] >= 0]

            task_results[task_name] = {
                "dimension": task_name,
                "total_cases": total,
                "test_cases": case_results,
                "summary": {
                    "tor_mean": sum(tor_values) / len(tor_values) if tor_values else None,
                    "tor_success_count": len(tor_values),
                    "latency_mean": sum(latency_values) / len(latency_values) if latency_values else None,
                }
            }

    # 输出每个维度的结果
    print("\n" + "=" * 60)
    print("各维度测试结果汇总")
    print("=" * 60)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(f"output/{timestamp}")
    output_dir.mkdir(parents=True, exist_ok=True)

    # 构建汇总表格
    table_lines = []
    table_lines.append("=" * 75)
    table_lines.append("Full-Duplex-Bench 测试结果汇总")
    table_lines.append("=" * 75)
    table_lines.append(f"测试时间: {timestamp}")
    table_lines.append(f"WS URL: {WS_URL}")
    table_lines.append("-" * 75)
    table_lines.append(f"{'维度':<25} {'用例数':<10} {'TOR':<15} {'成功':<10} {'平均延迟(ms)':<15}")
    table_lines.append("-" * 75)

    for task_name, result in task_results.items():
        summary = result["summary"]
        tor_str = f"{summary['tor_mean']:.4f}" if summary["tor_mean"] is not None else "N/A"
        latency_str = f"{summary['latency_mean']:.2f}" if summary["latency_mean"] is not None else "N/A"
        success_str = f"{summary['tor_success_count']}/{result['total_cases']}"

        line = f"{task_name:<25} {result['total_cases']:<10} {tor_str:<15} {success_str:<10} {latency_str:<15}"
        table_lines.append(line)

        # 保存该维度的结果
        task_output_path = output_dir / f"{task_name}.json"
        with open(task_output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

    table_lines.append("-" * 75)

    # 打印到终端
    print(f"\n" + "\n".join(table_lines))

    # 保存汇总表格到 txt 文件
    summary_path = output_dir / "summary.txt"
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(table_lines))

    # 保存总览文件
    overview = {
        "timestamp": timestamp,
        "ws_url": WS_URL,
        "dimensions": list(task_results.keys()),
        "results": task_results,
    }
    overview_path = output_dir / "overview.json"
    with open(overview_path, 'w', encoding='utf-8') as f:
        json.dump(overview, f, ensure_ascii=False, indent=2)

    print(f"\n结果已保存到: {output_dir}/")


if __name__ == "__main__":
    asyncio.run(main())

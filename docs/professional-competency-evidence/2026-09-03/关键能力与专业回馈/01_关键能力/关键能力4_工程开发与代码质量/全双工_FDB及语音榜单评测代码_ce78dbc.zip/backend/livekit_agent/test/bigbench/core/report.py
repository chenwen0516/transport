"""BigBench 测试报告生成

输出 JSON 报告文件和终端表格，汇总 BigBench 测试结果。
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict

from .metrics import BigBenchMetricsAggregator


def _fmt_ms(value: Optional[float]) -> str:
    if value is None:
        return "N/A"
    return f"{value:.1f}ms"


def _fmt_pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def _fmt_percentiles(p: Dict[str, Optional[float]]) -> str:
    parts = []
    for key in ("p50", "p90", "p95", "p99", "max"):
        if key in p:
            parts.append(f"{key}={_fmt_ms(p[key])}")
    return " ".join(parts)


def print_terminal_report(aggregator: BigBenchMetricsAggregator) -> None:
    """输出终端表格报告"""
    try:
        from tabulate import tabulate
    except ImportError:
        _print_simple_report(aggregator)
        return

    print("\n" + "=" * 80)
    print("  BigBench Speech Reasoning Benchmark Results")
    print("=" * 80)

    # ========== 总体统计 ==========
    print(f"\n  总题数: {aggregator.total}")
    print(f"  已回答: {aggregator.answered}")
    print(f"  正确率: {_fmt_pct(aggregator.accuracy())}")

    # ========== 分类统计 ==========
    acc_by_cat = aggregator.accuracy_by_category()
    if acc_by_cat:
        print("\n  --- 按能力分类 ---")
        rows = [[cat, f"{acc*100:.1f}%"] for cat, acc in acc_by_cat.items()]
        print(tabulate(rows, headers=["Category", "Accuracy"], tablefmt="grid"))

    # ========== 难度统计 ==========
    acc_by_diff = aggregator.accuracy_by_difficulty()
    if acc_by_diff:
        print("\n  --- 按难度 ---")
        rows = [[diff, f"{acc*100:.1f}%"] for diff, acc in acc_by_diff.items()]
        print(tabulate(rows, headers=["Difficulty", "Accuracy"], tablefmt="grid"))

    # ========== 延迟统计 ==========
    print("\n  --- 延迟指标 ---")
    print(f"  首 Token 延迟: {_fmt_percentiles(aggregator.latency_first_token_percentiles())}")
    print(f"  首音频延迟: {_fmt_percentiles(aggregator.latency_first_audio_percentiles())}")
    print(f"  总回复延迟: {_fmt_percentiles(aggregator.latency_total_percentiles())}")

    # ========== 详细结果 ==========
    if aggregator.results:
        print("\n  --- 详细结果 ---")
        rows = []
        for r in aggregator.results:
            rows.append([
                r.case_id,
                r.category,
                "yes" if r.correct else ("no" if r.correct is False else "N/A"),
                _fmt_ms(r.latency_first_token_ms),
                _fmt_ms(r.latency_total_ms),
            ])

        print(tabulate(
            rows,
            headers=["Case ID", "Category", "Correct", "TTFT", "Total Lat."],
            tablefmt="grid",
        ))

    print()


def _print_simple_report(aggregator: BigBenchMetricsAggregator) -> None:
    """tabulate 不可用时的简单文本输出"""
    summary = aggregator.summary()

    print("\n--- BigBench Results ---")
    print(f"  Total: {summary['total']}")
    print(f"  Answered: {summary['answered']}")
    print(f"  Accuracy: {_fmt_pct(summary['accuracy'])}")

    for cat, acc in summary.get("accuracy_by_category", {}).items():
        print(f"  {cat}: {_fmt_pct(acc)}")


def save_json_report(
    aggregator: BigBenchMetricsAggregator,
    output_dir: str = "test_reports",
    agent_mode: str = "unknown",
) -> str:
    """保存 JSON 报告"""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{output_dir}/bigbench_{agent_mode}_{timestamp}.json"

    report = {
        "timestamp": datetime.now().isoformat(),
        "agent_mode": agent_mode,
        "summary": aggregator.summary(),
        "results": [
            {
                "case_id": r.case_id,
                "category": r.category,
                "difficulty": r.difficulty,
                "reasoning_steps": r.reasoning_steps,
                "question": r.question,
                "expected_answer": r.expected_answer,
                "predicted_answer": r.predicted_answer,
                "correct": r.correct,
                "latency_first_token_ms": r.latency_first_token_ms,
                "latency_first_audio_ms": r.latency_first_audio_ms,
                "latency_total_ms": r.latency_total_ms,
            }
            for r in aggregator.results
        ],
    }

    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"[Report] Saved to {filename}")
    return filename
"""BigBench 数据集验证脚本

快速验证：
1. 数据集能否正常加载
2. 音频格式是否正确
3. 题目和答案是否完整

使用方法:
    python validate_dataset.py                    # 验证全部数据
    python validate_dataset.py --max 10          # 只验证 10 条
    python validate_dataset.py --category navigate  # 只验证 navigate 类
"""

import argparse
import logging
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))

from core.dataset_hf import BigBenchHFDataset

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger("validate")


def validate_case(case, index):
    """验证单个 case"""
    errors = []

    if not case.id:
        errors.append("Missing id")
    if not case.question:
        errors.append("Missing question")
    if not case.answer:
        errors.append("Missing answer")
    if not case.category:
        errors.append("Missing category")

    audio_bytes = getattr(case, "_audio_bytes", None)
    if not audio_bytes:
        errors.append("Missing audio data")
    else:
        # 检查音频长度（至少 0.1 秒）
        expected_bytes_per_100ms = 3200  # 16kHz * 100ms * 2 bytes
        min_bytes = expected_bytes_per_100ms
        if len(audio_bytes) < min_bytes:
            errors.append(f"Audio too short: {len(audio_bytes)} bytes")

    return errors


def main():
    parser = argparse.ArgumentParser(description="Validate BigBench dataset")
    parser.add_argument("--max", type=int, help="Max cases to validate")
    parser.add_argument("--category", type=str, help="Filter by category")
    parser.add_argument("--verbose", action="store_true", help="Show all cases")
    args = parser.parse_args()

    logger.info("Loading dataset from Hugging Face...")
    dataset = BigBenchHFDataset.load(category=args.category)

    if not dataset.cases:
        logger.error("No cases loaded!")
        return

    logger.info(f"Loaded {len(dataset)} cases")

    # 按分类统计
    categories = {}
    audio_missing = 0
    total_audio_len = 0

    for case in dataset:
        categories[case.category] = categories.get(case.category, 0) + 1
        audio_bytes = getattr(case, "_audio_bytes", None)
        if audio_bytes:
            total_audio_len += len(audio_bytes)
        else:
            audio_missing += 1

    print("\n" + "=" * 60)
    print("Dataset Statistics")
    print("=" * 60)
    print(f"Total cases:      {len(dataset)}")
    print(f"Audio missing:    {audio_missing}")
    print(f"Audio avg bytes:  {total_audio_len // max(len(dataset) - audio_missing, 1)}")
    print("\nCases by category:")
    for cat, count in sorted(categories.items(), key=lambda x: -x[1]):
        print(f"  {cat:15s}: {count:4d}")

    # 验证每个 case
    print("\n" + "=" * 60)
    print("Validating cases...")
    print("=" * 60)

    errors_by_type = {}
    total_errors = 0
    max_to_show = args.max or 100

    for i, case in enumerate(dataset):
        if args.max and i >= args.max:
            logger.info(f"... and {len(dataset) - args.max} more cases")
            break

        errors = validate_case(case, i)

        if errors:
            for err in errors:
                errors_by_type[err] = errors_by_type.get(err, 0) + 1
                total_errors += 1
            if args.verbose:
                print(f"[{i}] {case.id}: {', '.join(errors)}")

    print(f"\nValidation errors: {total_errors}")
    if errors_by_type:
        print("\nErrors by type:")
        for err_type, count in sorted(errors_by_type.items(), key=lambda x: -x[1]):
            print(f"  {err_type:30s}: {count}")
    else:
        print("All cases passed validation!")

    # 显示样例
    print("\n" + "=" * 60)
    print("Sample cases")
    print("=" * 60)

    shown = set()
    for case in dataset:
        if case.category in shown:
            continue
        shown.add(case.category)

        audio_bytes = getattr(case, "_audio_bytes", None)
        audio_sec = len(audio_bytes) / 3200 / 10 if audio_bytes else 0

        print(f"\n[{case.category}] {case.id}")
        print(f"  Q: {case.question[:80]}...")
        print(f"  A: {case.answer}")
        print(f"  Audio: {len(audio_bytes) if audio_bytes else 0} bytes ({audio_sec:.1f}s)")


if __name__ == "__main__":
    main()
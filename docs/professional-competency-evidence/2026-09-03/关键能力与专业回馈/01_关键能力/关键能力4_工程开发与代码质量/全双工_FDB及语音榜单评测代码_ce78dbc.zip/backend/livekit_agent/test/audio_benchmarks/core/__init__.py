"""Lightweight core namespace for audio_benchmarks.

This package reuses modules from ../bigbench/core without importing
bigbench/core/__init__.py, which eagerly imports the BigBench HF dataset.
"""

from pathlib import Path

_BIGBENCH_CORE = Path(__file__).resolve().parents[2] / "bigbench" / "core"
__path__.append(str(_BIGBENCH_CORE))

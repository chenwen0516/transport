#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
LOG_DIR="${LOG_DIR:-${SCRIPT_DIR}/logs}"
MAX_CASES="${MAX_CASES:-20}"
PROTOCOL="${PROTOCOL:-webrtc}"
EARLY_RESPONSE_POLICY="${EARLY_RESPONSE_POLICY:-warn}"
EXTRA_ARGS="${EXTRA_ARGS:-}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
REPORT_DIR="${REPORT_DIR:-${SCRIPT_DIR}/test_reports/voicebench_table_${TIMESTAMP}}"

mkdir -p "${LOG_DIR}" "${REPORT_DIR}"
cd "${PROJECT_DIR}"

run_dimension() {
  local label="$1"
  local subset="$2"
  local split="$3"
  local safe_subset="${subset//-/_}"
  local log_file="${LOG_DIR}/voicebench_${safe_subset}_${split}_${MAX_CASES}_${TIMESTAMP}.log"
  local max_cases_label="${MAX_CASES}"
  local max_cases_args=()

  if [[ -n "${MAX_CASES}" && "${MAX_CASES}" != "all" ]]; then
    max_cases_args=(--max-cases "${MAX_CASES}")
  else
    max_cases_label="all"
  fi

  echo "[$(date '+%F %T')] Running ${label}: subset=${subset} split=${split} max_cases=${max_cases_label}"
  echo "Log: ${log_file}"

  uv run python test/audio_benchmarks/run_voicebench.py \
    --protocol "${PROTOCOL}" \
    --subset "${subset}" \
    --split "${split}" \
    "${max_cases_args[@]}" \
    --early-response-policy "${EARLY_RESPONSE_POLICY}" \
    --output "${REPORT_DIR}" \
    ${EXTRA_ARGS} \
    > "${log_file}" 2>&1

  echo "[$(date '+%F %T')] Finished ${label}"
}

# VoiceBench dimensions from the paper table.
run_dimension "AlpacaEval" "alpacaeval" "test"
run_dimension "CommonEval" "commoneval" "test"
run_dimension "SD-QA" "sd-qa" "usa"
run_dimension "MMSU" "mmsu" "health"
run_dimension "OpenBookQA" "openbookqa" "test"
run_dimension "IFEval" "ifeval" "test"
run_dimension "AdvBench" "advbench" "test"

echo "[$(date '+%F %T')] Building VoiceBench paper table from ${REPORT_DIR}"

REPORT_DIR="${REPORT_DIR}" TIMESTAMP="${TIMESTAMP}" python - <<'PY'
import csv
import glob
import json
import os
from pathlib import Path

report_dir = Path(os.environ["REPORT_DIR"])
timestamp = os.environ["TIMESTAMP"]

dimensions = [
    ("AlpacaEval", "alpacaeval", "G-Eval 1-5", True),
    ("CommonEval", "commoneval", "G-Eval 1-5", True),
    ("SD-QA", "sd-qa", "Accuracy %", False),
    ("MMSU", "mmsu", "Accuracy %", False),
    ("OpenBookQA", "openbookqa", "Accuracy %", False),
    ("IFEval", "ifeval", "Accuracy %", False),
    ("AdvBench", "advbench", "Refusal Rate %", False),
]

reports = []
for path in sorted(glob.glob(str(report_dir / "voicebench_*.json"))):
    with open(path, "r", encoding="utf-8") as f:
        reports.append((Path(path), json.load(f)))

def find_score(task):
    matches = []
    for path, report in reports:
        summary = report.get("summary", {})
        score_by_task = summary.get("score_by_task") or {}
        if task in score_by_task:
            matches.append((path, report, float(score_by_task[task])))
    if not matches:
        return None, None, None
    return matches[-1]

rows = []
overall_percent_scores = []
for label, task, metric, display_as_1_to_5 in dimensions:
    path, report, raw_percent = find_score(task)
    if raw_percent is None:
        rows.append({
            "dimension": label,
            "metric": metric,
            "score": "",
            "raw_percent": "",
            "total": "",
            "answered": "",
            "unanswered": "",
            "report_file": "",
        })
        continue

    summary = report.get("summary", {})
    display_score = raw_percent / 20 if display_as_1_to_5 else raw_percent
    overall_percent_scores.append(raw_percent)
    rows.append({
        "dimension": label,
        "metric": metric,
        "score": f"{display_score:.2f}",
        "raw_percent": f"{raw_percent:.2f}",
        "total": summary.get("total", ""),
        "answered": summary.get("answered", ""),
        "unanswered": summary.get("unanswered_count", ""),
        "report_file": path.name,
    })

overall = sum(overall_percent_scores) / len(overall_percent_scores) if overall_percent_scores else None
rows.append({
    "dimension": "Overall",
    "metric": "Mean %",
    "score": "" if overall is None else f"{overall:.2f}",
    "raw_percent": "" if overall is None else f"{overall:.2f}",
    "total": "",
    "answered": "",
    "unanswered": "",
    "report_file": "",
})

csv_path = report_dir / f"voicebench_paper_table_{timestamp}.csv"
txt_path = report_dir / f"voicebench_paper_table_{timestamp}.txt"

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=[
            "dimension",
            "metric",
            "score",
            "raw_percent",
            "total",
            "answered",
            "unanswered",
            "report_file",
        ],
    )
    writer.writeheader()
    writer.writerows(rows)

with open(txt_path, "w", encoding="utf-8") as f:
    f.write(f"{'Dimension':<12} {'Metric':<16} {'Score':>8} {'Raw%':>8}\n")
    f.write("-" * 52 + "\n")
    for row in rows:
        f.write(
            f"{row['dimension']:<12} {row['metric']:<16} "
            f"{row['score']:>8} {row['raw_percent']:>8}\n"
        )

print(f"[Table] Paper CSV: {csv_path}")
print(f"[Table] Paper TXT: {txt_path}")
PY

echo "[$(date '+%F %T')] VoiceBench paper-table batch complete"

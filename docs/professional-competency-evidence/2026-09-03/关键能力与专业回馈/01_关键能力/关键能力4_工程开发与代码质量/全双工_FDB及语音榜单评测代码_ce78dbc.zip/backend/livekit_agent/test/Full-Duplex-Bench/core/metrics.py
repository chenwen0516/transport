"""Full-Duplex-Bench 评估指标计算

支持：
- TOR (Take-Over Rate)
- Latency (响应延迟)
- JSD (Jensen-Shannon Divergence for backchannel)
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

try:
    from scipy.spatial.distance import jensenshannon as _scipy_jensenshannon
except ImportError:
    _scipy_jensenshannon = None


def jensenshannon(p: np.ndarray, q: np.ndarray) -> float:
    """计算 Jensen-Shannon distance；scipy 不存在时使用本地实现。"""
    if _scipy_jensenshannon is not None:
        return float(_scipy_jensenshannon(p, q))

    p = np.asarray(p, dtype=float)
    q = np.asarray(q, dtype=float)
    p = p / (p.sum() + 1e-12)
    q = q / (q.sum() + 1e-12)
    m = 0.5 * (p + q)

    def kl_div(a: np.ndarray, b: np.ndarray) -> float:
        mask = a > 0
        return float(np.sum(a[mask] * np.log2(a[mask] / (b[mask] + 1e-12))))

    return math.sqrt(0.5 * kl_div(p, m) + 0.5 * kl_div(q, m))


# ========== 配置常量 ==========

TURN_DURATION_THRESHOLD = 1.0  # 秒
TURN_NUM_WORDS_THRESHOLD = 3


# ========== 数据结构 ==========

@dataclass
class InterruptionResult:
    """打断测试结果"""
    case_name: str
    expected_interrupt: bool
    actual_interrupted: bool
    tor: Optional[float] = None
    latency: Optional[float] = None
    rating: Optional[int] = None


@dataclass
class BackchannelResult:
    """回指测试结果"""
    case_name: str
    tor: float
    frequency: float
    jsd: float


@dataclass
class PauseHandlingResult:
    """停顿处理结果"""
    case_name: str
    tor: float


@dataclass
class SmoothTurnTakingResult:
    """话轮转换结果"""
    case_name: str
    tor: float
    latency: float


@dataclass
class EvaluationResult:
    """单次评估结果"""
    task: str
    case_name: str
    tor: Optional[float] = None
    latency: Optional[float] = None
    jsd: Optional[float] = None
    frequency: Optional[float] = None
    rating: Optional[int] = None
    success: bool = True
    error: Optional[str] = None


# ========== 指标计算器 ==========

class TORCalculator:
    """Take-Over Rate 计算器"""

    @staticmethod
    def calculate(output_json_path: str) -> float:
        """从 ASR 输出文件计算 TOR"""
        with open(output_json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        chunks = data.get("chunks", [])
        if not chunks:
            return 0.0

        first_start = chunks[0]["timestamp"][0]
        last_end = chunks[-1]["timestamp"][-1]
        if last_end is None:
            last_end = first_start

        duration = last_end - first_start
        if duration < TURN_DURATION_THRESHOLD and len(chunks) <= TURN_NUM_WORDS_THRESHOLD:
            return 0.0
        return 1.0

    @staticmethod
    def calculate_with_timestamps(words: list[dict]) -> float:
        """根据词级时间戳计算 TOR"""
        if not words:
            return 0.0

        first_start = words[0]["start_time"]
        last_end = words[-1]["end_time"]
        duration = last_end - first_start

        if duration < TURN_DURATION_THRESHOLD and len(words) <= TURN_NUM_WORDS_THRESHOLD:
            return 0.0
        return 1.0


class LatencyCalculator:
    """响应延迟计算器"""

    @staticmethod
    def calculate(input_end_time: float, output_json_path: str) -> float:
        """从 ASR 输出文件计算延迟"""
        with open(output_json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        chunks = data.get("chunks", [])
        if not chunks:
            return -1.0

        output_start_time = chunks[0]["timestamp"][0]
        return max(0.0, output_start_time - input_end_time)

    @staticmethod
    def calculate_with_timestamps(input_end_time: float, words: list[dict]) -> float:
        """根据词级时间戳计算延迟"""
        if not words:
            return -1.0
        return max(0.0, words[0]["start_time"] - input_end_time)


class JSDCalculator:
    """Jensen-Shannon Divergence 计算器"""

    WINDOW_SIZE = 0.2
    EPSILON = 1e-10

    @staticmethod
    def calculate(
        backchannel_predictions: list[list[float]],
        gt_distribution: list[float],
        max_duration: float,
    ) -> float:
        """计算 JSD"""
        if not backchannel_predictions:
            return 1.0

        num_bins = int(max_duration / JSDCalculator.WINDOW_SIZE) + 1
        time_intervals = [0.0] * num_bins

        for interval in backchannel_predictions:
            start, end = interval
            start_bin = int(start / JSDCalculator.WINDOW_SIZE)
            end_bin = int(end / JSDCalculator.WINDOW_SIZE)
            for i in range(start_bin, end_bin + 1):
                if i < num_bins:
                    time_intervals[i] += 1

        time_intervals = np.array(time_intervals, dtype=float)
        if time_intervals.sum() == 0:
            return 1.0
        time_intervals = time_intervals + JSDCalculator.EPSILON
        time_intervals = time_intervals / time_intervals.sum()

        gt_array = np.array(gt_distribution, dtype=float)
        pred_array = np.array(time_intervals, dtype=float)

        if len(gt_array) != len(pred_array):
            from scipy.interpolate import interp1d
            x_gt = np.linspace(0, 1, len(gt_array))
            x_pred = np.linspace(0, 1, len(pred_array))
            interp_func = interp1d(x_gt, gt_array, kind="linear", fill_value="extrapolate")
            gt_resized = interp_func(x_pred)
            gt_array = gt_resized

        return jensenshannon(gt_array, pred_array)


class MetricsAggregator:
    """评估指标聚合器"""

    def __init__(self):
        self._results: list[EvaluationResult] = []
        self._tor_list: list[float] = []
        self._latency_list: list[float] = []
        self._jsd_list: list[float] = []
        self._freq_list: list[float] = []

    def add_result(self, result: EvaluationResult) -> None:
        """添加单次评估结果"""
        self._results.append(result)
        if result.tor is not None:
            self._tor_list.append(result.tor)
        if result.latency is not None and result.latency >= 0:
            self._latency_list.append(result.latency)
        if result.jsd is not None:
            self._jsd_list.append(result.jsd)
        if result.frequency is not None:
            self._freq_list.append(result.frequency)

    def get_results(self) -> list[EvaluationResult]:
        """获取所有评估结果"""
        return self._results

    def get_results_by_task(self, task: str) -> list[EvaluationResult]:
        """获取指定任务的评估结果"""
        return [r for r in self._results if r.task == task]

    def summary(self) -> dict:
        """汇总统计"""
        def percentile(values: list[float], p: float) -> Optional[float]:
            if not values:
                return None
            return sorted(values)[int(len(values) * p)]

        return {
            "total": len(self._results),
            "tor": {
                "mean": np.mean(self._tor_list) if self._tor_list else None,
                "std": np.std(self._tor_list) if self._tor_list else None,
                "p50": percentile(self._tor_list, 0.5),
                "p90": percentile(self._tor_list, 0.9),
            },
            "latency": {
                "mean": np.mean(self._latency_list) if self._latency_list else None,
                "std": np.std(self._latency_list) if self._latency_list else None,
                "p50": percentile(self._latency_list, 0.5),
                "p90": percentile(self._latency_list, 0.9),
            },
            "jsd": {
                "mean": np.mean(self._jsd_list) if self._jsd_list else None,
            },
            "frequency": {
                "mean": np.mean(self._freq_list) if self._freq_list else None,
            },
        }

    def save_results(self, output_path: str) -> None:
        """保存结果到 JSON 文件"""
        output = {
            "summary": self.summary(),
            "details": [
                {
                    "task": r.task,
                    "case_name": r.case_name,
                    "tor": r.tor,
                    "latency": r.latency,
                    "jsd": r.jsd,
                    "frequency": r.frequency,
                    "rating": r.rating,
                    "success": r.success,
                    "error": r.error,
                }
                for r in self._results
            ],
        }
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)

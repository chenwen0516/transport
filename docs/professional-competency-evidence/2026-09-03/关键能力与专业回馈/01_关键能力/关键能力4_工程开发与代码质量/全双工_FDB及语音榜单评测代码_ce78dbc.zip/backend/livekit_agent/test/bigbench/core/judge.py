import os
import re
from typing import Optional
from .case import BigBenchCase
from .metrics import BigBenchResult
MINIMAX_API_URL = "https://api.minimax.chat/v1/chat/completions"
MINIMAX_MODEL = "MiniMax-M2.7"
JUDGE_PROMPT = """You are a strict judge for a reasoning benchmark. Given the question and the model's answer, determine if the model's answer is correct.
Question: {question}
Expected answer: {expected}
Model's answer: {predicted}
Is the model's answer correct? Answer ONLY "yes" or "no"."""
class BigBenchJudge:
    def __init__(self, judge_model="MiniMax-M2.7", api_key="", use_llm=True):
        self.judge_model = judge_model
        self.api_key = api_key or os.getenv("MINIMAX_API_KEY", "")
        self.use_llm = use_llm
    def judge(self, case, predicted_answer, use_llm=None):
        should_use_llm = use_llm if use_llm is not None else self.use_llm
        expected_norm = case.answer.lower().strip()
        validity = self._classify_validity_answer(predicted_answer)
        if expected_norm in ("valid", "invalid") and validity is not None:
            correct = validity == expected_norm
        elif should_use_llm and self.api_key:
            correct = self._judge_llm(case.question, case.answer, predicted_answer)
        else:
            correct = self._judge_exact_match(case.answer, predicted_answer)
        return BigBenchResult(
            case_id=case.id,
            category=case.category,
            question=case.question,
            expected_answer=case.answer,
            predicted_answer=predicted_answer,
            correct=correct,
            difficulty=case.difficulty,
            reasoning_steps=case.reasoning_steps,
        )
    def _judge_llm(self, question, expected, predicted):
        if not predicted or not predicted.strip():
            return False
        try:
            import httpx
            prompt = JUDGE_PROMPT.format(
                question=question, expected=expected, predicted=predicted,
            )
            resp = httpx.post(
                MINIMAX_API_URL,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.judge_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.0,
                    "max_tokens": 10,
                },
                timeout=15,
            )
            resp.raise_for_status()
            text = resp.json()["choices"][0]["message"]["content"].strip().lower()
            if "yes" in text:
                return True
            if "no" in text:
                return False
            return self._judge_exact_match(expected, predicted)
        except Exception as e:
            import logging
            logging.getLogger("bigbench.judge").warning(f"LLM judge failed, fallback to exact match: {e}")
            return self._judge_exact_match(expected, predicted)
    def _judge_exact_match(self, expected, predicted):
        expected_norm = expected.lower().strip()
        predicted_norm = predicted.lower().strip()
        # Number matching
        expected_num = self._extract_number(expected_norm)
        if expected_num is not None:
            predicted_nums = self._extract_all_numbers(predicted_norm)
            if expected_num in predicted_nums:
                return True
            return False
        # Clean predicted text for word matching
        predicted_clean = predicted_norm
        for old, new in [("can't", "cant"), ("don't", "dont"), ("doesn't", "doesnt"),
                         ("won't", "wont"), ("isn't", "isnt"), ("aren't", "arent"),
                         ("wasn't", "wasnt"), ("weren't", "werent"), ("didn't", "didnt")]:
            predicted_clean = predicted_clean.replace(old, new)
        predicted_clean = re.sub(r"[^a-z ]", "", predicted_clean)
        words = set(predicted_clean.split())
        negation_words = {"no", "not", "cant", "dont", "doesnt", "wont", "isnt",
                          "arent", "wasnt", "werent", "never", "didnt", "neither"}
        affirmative_words = {"yes", "return", "returned", "back", "do", "does",
                             "did", "will", "can", "would", "should", "affirmative",
                             "true", "correct", "right"}
        # Yes matching
        if expected_norm in ("yes", "true"):
            has_neg = bool(words & negation_words)
            has_aff = bool(words & affirmative_words)
            return has_aff and not has_neg
        # No matching
        if expected_norm in ("no", "false"):
            has_neg = bool(words & negation_words)
            return has_neg
        # Valid/Invalid matching
        if expected_norm == "valid":
            return self._classify_validity_answer(predicted_norm) == "valid"
        if expected_norm == "invalid":
            return self._classify_validity_answer(predicted_norm) == "invalid"
        # Default substring
        return expected_norm in predicted_norm

    def _classify_validity_answer(self, predicted):
        if not predicted or not predicted.strip():
            return None

        text = predicted.lower().strip()
        text = text.replace("can't", "cannot")
        text = re.sub(r"[^a-z\s-]", " ", text)
        text = re.sub(r"\s+", " ", text).strip()

        invalid_patterns = [
            r"\binvalid\b",
            r"\bnot valid\b",
            r"\bnot deductively valid\b",
            r"\bnot logically valid\b",
            r"\bdoes not logically follow\b",
            r"\bdoesn t logically follow\b",
            r"\bdoes not follow\b",
            r"\bdoesn t follow\b",
            r"\bdo not follow\b",
            r"\bdon t follow\b",
            r"\bcannot conclude\b",
            r"\bcan not conclude\b",
            r"\bconclusion does not follow\b",
            r"\bconclusion doesn t follow\b",
            r"\bconverse error\b",
            r"\baffirming the consequent\b",
            r"\blogical fallacy\b",
            r"\bfallacy\b",
        ]
        if any(re.search(pattern, text) for pattern in invalid_patterns):
            return "invalid"

        valid_patterns = [
            r"\bvalid\b",
            r"\bdeductively valid\b",
            r"\blogically valid\b",
            r"\blogically follows\b",
            r"\bdoes logically follow\b",
            r"\bfollows from the premises\b",
            r"\bconclusion follows\b",
            r"\btherefore valid\b",
        ]
        if any(re.search(pattern, text) for pattern in valid_patterns):
            return "valid"

        return None
    def _extract_number(self, text):
        match = re.search(r"-?\d+", text)
        if match:
            return int(match.group())
        chinese_nums = self._extract_chinese_numbers(text)
        if chinese_nums:
            return chinese_nums[0]
        text_clean = re.sub(r"[^a-z ]", "", text)
        word_to_num = {
            "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4,
            "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
            "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
            "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
            "eighteen": 18, "nineteen": 19, "twenty": 20,
        }
        for word, num in word_to_num.items():
            if word in text_clean.split():
                return num
        return None
    def _extract_all_numbers(self, text):
        nums = [int(m.group()) for m in re.finditer(r"-?\d+", text)]
        nums.extend(self._extract_chinese_numbers(text))
        text_clean = re.sub(r"[^a-z ]", "", text)
        word_to_num = {
            "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4,
            "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
            "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13,
            "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
            "eighteen": 18, "nineteen": 19, "twenty": 20,
        }
        for word, num in word_to_num.items():
            if word in text_clean.split():
                nums.append(num)
        return list(set(nums))

    def _extract_chinese_numbers(self, text):
        if not text:
            return []

        digit_chars = "零〇一二两三四五六七八九幺洞拐勾"
        unit_chars = "十百千万"
        nums = []

        # ASR may turn "1234" into "一二三四" or "一 二 三 四".
        seq_pattern = rf"(?:[{digit_chars}]\s*){{2,}}"
        for match in re.finditer(seq_pattern, text):
            raw = re.sub(r"\s+", "", match.group())
            value = self._parse_chinese_number(raw)
            if value is not None:
                nums.append(value)

        # Also support normal Chinese numerals like "十二" or "一百二十三".
        number_pattern = rf"[{digit_chars}{unit_chars}]+"
        for match in re.finditer(number_pattern, text):
            raw = match.group()
            value = self._parse_chinese_number(raw)
            if value is not None:
                nums.append(value)

        return list(dict.fromkeys(nums))

    def _parse_chinese_number(self, text):
        digit_map = {
            "零": 0, "〇": 0, "洞": 0,
            "一": 1, "幺": 1,
            "二": 2, "两": 2,
            "三": 3,
            "四": 4,
            "五": 5,
            "六": 6,
            "七": 7, "拐": 7,
            "八": 8,
            "九": 9, "勾": 9,
        }
        unit_map = {"十": 10, "百": 100, "千": 1000, "万": 10000}

        if not text:
            return None

        if all(ch in digit_map for ch in text):
            return int("".join(str(digit_map[ch]) for ch in text))

        if not any(ch in unit_map for ch in text):
            return None

        total = 0
        section = 0
        number = 0
        for ch in text:
            if ch in digit_map:
                number = digit_map[ch]
            elif ch in unit_map:
                unit = unit_map[ch]
                if unit == 10000:
                    section = (section + number) or 1
                    total += section * unit
                    section = 0
                else:
                    if number == 0:
                        number = 1
                    section += number * unit
                number = 0
            else:
                return None
        return total + section + number

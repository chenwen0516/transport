"""BigBench Speech Reasoning Benchmark Tests

评测模型能否通过语音完成推理。
"""
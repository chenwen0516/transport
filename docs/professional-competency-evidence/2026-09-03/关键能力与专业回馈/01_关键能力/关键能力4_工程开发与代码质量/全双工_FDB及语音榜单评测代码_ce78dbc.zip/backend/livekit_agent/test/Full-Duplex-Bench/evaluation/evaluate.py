"""Full-Duplex-Bench 统一评估入口

用法:
    python evaluate.py --task user_interruption --root_dir /path/to/dataset
    python evaluate.py --task backchannel --root_dir /path/to/dataset
    python evaluate.py --task pause_handling --root_dir /path/to/dataset
    python evaluate.py --task smooth_turn_taking --root_dir /path/to/dataset
"""

import argparse
import asyncio
import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.asr_client import SynchAliYunASRClient
from core.metrics import MetricsAggregator, EvaluationResult

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("fdb.evaluate")


# ========== 配置 ==========

# 阿里云 ASR 配置（从环境变量或配置文件读取）
ALIYUN_APP_KEY = os.getenv("ALIYUN_ASR_APP_KEY", "XyBVyyGNTFZyKa7D")
ALIYUN_TOKEN = os.getenv("ALIYUN_ASR_TOKEN", "3ea8234a3c95443aba02753f41db7913")

# 支持的任务
TASKS = ["backchannel", "pause_handling", "smooth_turn_taking", "user_interruption"]


# ========== 评估函数 ==========

def evaluate_user_interruption(root_dir: str, asr_client: SynchAliYunASRClient) -> MetricsAggregator:
    """评估用户打断任务"""
    aggregator = MetricsAggregator()

    # 遍历样本目录
    for sample_dir in sorted(Path(root_dir).iterdir()):
        if not sample_dir.is_dir():
            continue

        case_name = sample_dir.name

        # 查找 output.wav 和 interrupt.json
        output_wav = sample_dir / "output.wav"
        interrupt_json = sample_dir / "interrupt.json"

        if not output_wav.exists():
            logger.warning(f"output.wav not found for {case_name}, skipping")
            continue

        if not interrupt_json.exists():
            logger.warning(f"interrupt.json not found for {case_name}, skipping")
            continue

        try:
            # ASR 识别 output.wav（使用流式转录获取时间戳）
            asr_result = asr_client.recognize_file_with_timestamps(str(output_wav), audio_format="pcm")

            if not asr_result.get("success", False):
                logger.warning(f"ASR failed for {case_name}: {asr_result.get('error')}")
                aggregator.add_result(EvaluationResult(
                    task="user_interruption",
                    case_name=case_name,
                    success=False,
                    error=asr_result.get("error", "ASR failed"),
                ))
                continue

            text = asr_result.get("text", "")
            words = asr_result.get("words", [])

            # 读取 interrupt.json 获取用户输入时间
            with open(interrupt_json, "r", encoding="utf-8") as f:
                interrupt_data = json.load(f)

            input_end_time = interrupt_data[0]["timestamp"][1]  # 用户打断结束时间

            # 计算 TOR
            from core.metrics import TORCalculator, LatencyCalculator
            tor = TORCalculator.calculate_with_timestamps(words)
            latency = LatencyCalculator.calculate_with_timestamps(input_end_time, words)

            aggregator.add_result(EvaluationResult(
                task="user_interruption",
                case_name=case_name,
                tor=tor,
                latency=latency,
            ))

            logger.info(f"[user_interruption] {case_name}: TOR={tor}, Latency={latency:.3f}s")

        except Exception as e:
            logger.error(f"Error processing {case_name}: {e}")
            aggregator.add_result(EvaluationResult(
                task="user_interruption",
                case_name=case_name,
                success=False,
                error=str(e),
            ))

    return aggregator


def evaluate_backchannel(root_dir: str, asr_client: SynchAliYunASRClient) -> MetricsAggregator:
    """评估回指任务"""
    aggregator = MetricsAggregator()

    # 加载 ground truth 分布
    gt_dist_path = Path(__file__).parent / "icc_gt_distribution.json"
    if not gt_dist_path.exists():
        logger.warning("icc_gt_distribution.json not found, JSD will not be calculated")
        gt_distribution = None
    else:
        with open(gt_dist_path, "r") as f:
            gt_distribution = json.load(f)

    for speaker_dir in sorted(Path(root_dir).iterdir()):
        if not speaker_dir.is_dir() or not speaker_dir.name.isdigit():
            continue

        case_name = speaker_dir.name

        output_wav = speaker_dir / "output.wav"
        if not output_wav.exists():
            continue

        try:
            asr_result = asr_client.recognize_file_with_timestamps(str(output_wav), audio_format="pcm")

            if not asr_result.get("success", False):
                continue

            words = asr_result.get("words", [])

            # 计算 TOR（短回复视为回指）
            tor = 0.0
            if words:
                duration = words[-1]["end_time"] - words[0]["start_time"]
                if duration > 3.0:  # >3s 视为正式发言
                    tor = 1.0

            # 计算回指频率
            # 这里简化处理，实际应该用 VAD 检测
            frequency = 0.0

            # 计算 JSD
            jsd = None
            if gt_distribution and case_name in gt_distribution:
                # 简化：使用 words 时间作为回指预测
                predictions = []
                for w in words:
                    predictions.append([w["start_time"], w["end_time"]])
                max_dur = words[-1]["end_time"] if words else 10.0

                from core.metrics import JSDCalculator
                jsd = JSDCalculator.calculate(predictions, gt_distribution[case_name], max_dur)

            aggregator.add_result(EvaluationResult(
                task="backchannel",
                case_name=case_name,
                tor=tor,
                frequency=frequency,
                jsd=jsd,
            ))

            logger.info(f"[backchannel] {case_name}: TOR={tor}, JSD={jsd:.4f}" if jsd else f"[backchannel] {case_name}: TOR={tor}")

        except Exception as e:
            logger.error(f"Error processing {case_name}: {e}")

    return aggregator


def evaluate_pause_handling(root_dir: str, asr_client: SynchAliYunASRClient) -> MetricsAggregator:
    """评估停顿处理任务"""
    aggregator = MetricsAggregator()

    for sample_dir in sorted(Path(root_dir).iterdir()):
        if not sample_dir.is_dir():
            continue

        case_name = sample_dir.name

        output_wav = sample_dir / "output.wav"
        if not output_wav.exists():
            continue

        try:
            asr_result = asr_client.recognize_file_with_timestamps(str(output_wav), audio_format="pcm")

            if not asr_result.get("success", False):
                continue

            words = asr_result.get("words", [])

            from core.metrics import TORCalculator
            tor = TORCalculator.calculate_with_timestamps(words)

            aggregator.add_result(EvaluationResult(
                task="pause_handling",
                case_name=case_name,
                tor=tor,
            ))

            logger.info(f"[pause_handling] {case_name}: TOR={tor}")

        except Exception as e:
            logger.error(f"Error processing {case_name}: {e}")

    return aggregator


def evaluate_smooth_turn_taking(root_dir: str, asr_client: SynchAliYunASRClient) -> MetricsAggregator:
    """评估话轮转换任务"""
    aggregator = MetricsAggregator()

    for sample_dir in sorted(Path(root_dir).iterdir()):
        if not sample_dir.is_dir():
            continue

        case_name = sample_dir.name

        output_wav = sample_dir / "output.wav"
        turn_taking_json = sample_dir / "turn_taking.json"

        if not output_wav.exists():
            continue

        if not turn_taking_json.exists():
            continue

        try:
            asr_result = asr_client.recognize_file_with_timestamps(str(output_wav), audio_format="pcm")

            if not asr_result.get("success", False):
                continue

            words = asr_result.get("words", [])

            # 读取用户输入结束时间
            with open(turn_taking_json, "r", encoding="utf-8") as f:
                turn_data = json.load(f)
            input_end_time = turn_data[0]["timestamp"][0]

            from core.metrics import TORCalculator, LatencyCalculator
            tor = TORCalculator.calculate_with_timestamps(words)
            latency = LatencyCalculator.calculate_with_timestamps(input_end_time, words)

            aggregator.add_result(EvaluationResult(
                task="smooth_turn_taking",
                case_name=case_name,
                tor=tor,
                latency=latency,
            ))

            logger.info(f"[smooth_turn_taking] {case_name}: TOR={tor}, Latency={latency:.3f}s")

        except Exception as e:
            logger.error(f"Error processing {case_name}: {e}")

    return aggregator


# ========== 主函数 ==========

def run_evaluation(task: str, root_dir: str, output_dir: str = "output") -> dict:
    """
    运行评估

    Args:
        task: 任务类型 (backchannel/pause_handling/smooth_turn_taking/user_interruption)
        root_dir: 数据集根目录
        output_dir: 输出目录

    Returns:
        评估结果摘要
    """
    if task not in TASKS:
        raise ValueError(f"Unknown task: {task}. Supported: {TASKS}")

    if not Path(root_dir).exists():
        raise FileNotFoundError(f"Dataset root not found: {root_dir}")

    # 初始化 ASR 客户端
    if not ALIYUN_APP_KEY or not ALIYUN_TOKEN:
        logger.warning("AliYun ASR credentials not configured, using mock mode")
        asr_client = None
    else:
        asr_client = SynchAliYunASRClient(
            app_key=ALIYUN_APP_KEY,
            token=ALIYUN_TOKEN,
            enable_words=True,
        )

    # 执行评估
    logger.info(f"Starting evaluation: task={task}, root_dir={root_dir}")

    if task == "user_interruption":
        aggregator = evaluate_user_interruption(root_dir, asr_client)
    elif task == "backchannel":
        aggregator = evaluate_backchannel(root_dir, asr_client)
    elif task == "pause_handling":
        aggregator = evaluate_pause_handling(root_dir, asr_client)
    elif task == "smooth_turn_taking":
        aggregator = evaluate_smooth_turn_taking(root_dir, asr_client)
    else:
        raise ValueError(f"Unknown task: {task}")

    # 保存结果
    output_path = Path(output_dir) / f"{task}_results.json"
    aggregator.save_results(str(output_path))

    summary = aggregator.summary()
    logger.info(f"Evaluation complete: {summary}")

    return summary


def main():
    parser = argparse.ArgumentParser(description="Full-Duplex-Bench Evaluation")
    parser.add_argument(
        "--task",
        type=str,
        required=True,
        choices=TASKS,
        help="Evaluation task",
    )
    parser.add_argument(
        "--root_dir",
        type=str,
        required=True,
        help="Dataset root directory",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="output",
        help="Output directory (default: output)",
    )
    args = parser.parse_args()

    summary = run_evaluation(args.task, args.root_dir, args.output_dir)

    print("\n" + "=" * 60)
    print(f"Evaluation Results: {args.task}")
    print("=" * 60)
    print(f"Total samples: {summary['total']}")
    if summary.get("tor", {}).get("mean") is not None:
        print(f"TOR: {summary['tor']['mean']:.4f} ± {summary['tor']['std']:.4f}")
    if summary.get("latency", {}).get("mean") is not None:
        print(f"Latency: {summary['latency']['mean']:.4f}s ± {summary['latency']['std']:.4f}s")
    if summary.get("jsd", {}).get("mean") is not None:
        print(f"JSD: {summary['jsd']['mean']:.4f}")
    if summary.get("frequency", {}).get("mean") is not None:
        print(f"Frequency: {summary['frequency']['mean']:.4f}")
    print("=" * 60)


if __name__ == "__main__":
    main()

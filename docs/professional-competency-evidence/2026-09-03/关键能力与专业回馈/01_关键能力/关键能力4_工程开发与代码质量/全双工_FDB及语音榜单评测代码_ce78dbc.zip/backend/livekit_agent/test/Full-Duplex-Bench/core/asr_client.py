"""阿里云 ASR - 录音文件识别

支持词级时间戳返回，集成阿里云智能语音交互服务。

认证方式:
1. Token 模式（推荐）：直接使用控制台生成的 Token
2. AK/SK 模式：使用 AccessKey 签名生成 Token

文档: https://help.aliyun.com/zh/isi/developer-reference/api-reference-2

注意: 阿里云 ASR API 要求 appkey 作为 URL 查询参数传递！
响应中的 result 字段需要从原始 UTF-8 字节解码。
"""

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import time
import uuid
import re
import threading
from pathlib import Path
from typing import Optional, Callable
from dataclasses import dataclass

import aiohttp
import requests

logger = logging.getLogger("fdb.asr_client")

# 阿里云 ASR API 端点
# 注意: appkey 必须作为 URL 查询参数！
ASR_URL_TEMPLATE = "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/asr?appkey={app_key}"
ASR_TASK_QUERY_URL = "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/asr?appkey={app_key}&task_id={task_id}"


def generate_aliyun_token(
    access_key_id: str,
    access_key_secret: str,
    app_key: str,
) -> str:
    """
    生成阿里云语音服务 Token（AK/SK 模式）

    Args:
        access_key_id: AccessKey ID
        access_key_secret: AccessKey Secret
        app_key: AppKey

    Returns:
        签名后的 Token 字符串
    """
    timestamp = int(time.time() * 1000)
    string_to_sign = f"{access_key_id}{timestamp}"

    signature = hmac.new(
        access_key_secret.encode("utf-8"),
        string_to_sign.encode("utf-8"),
        hashlib.sha1
    ).digest()

    signature_b64 = base64.b64encode(signature).decode("utf-8")
    token = f"{access_key_id}:{timestamp}:{signature_b64}"

    return token


def _extract_result_from_raw_response(raw_content: bytes) -> dict:
    """
    从原始响应字节中提取 result 字段并正确解码

    阿里云 ASR API 返回的 JSON 中，result 字段是 UTF-8 编码的字符串，
    但 requests 库的 JSON 解析器可能无法正确处理。

    Returns:
        dict with 'text', 'words', 'task_id' etc.
    """
    # 提取 result 字段（位于 "result":" 和 ","status" 之间）
    result_start = raw_content.find(b'"result":"') + 10
    result_end = raw_content.find(b'","status"', result_start)

    text = ""
    if result_start > 10 and result_end > result_start:
        result_bytes = raw_content[result_start:result_end]
        # 直接解码为 UTF-8
        text = result_bytes.decode("utf-8")

    # 提取其他字段
    task_id_match = re.search(rb'"task_id":"([^"]*)"', raw_content)
    task_id = task_id_match.group(1).decode("utf-8") if task_id_match else ""

    status_match = re.search(rb'"status":(\d+)', raw_content)
    status = int(status_match.group(1)) if status_match else 0

    return {
        "text": text,
        "task_id": task_id,
        "status": status,
    }


@dataclass
class ASRResult:
    """ASR 识别结果"""
    success: bool
    text: str = ""
    words: list = None  # [{"word": str, "start_time": float, "end_time": float}]
    sentences: list = None  # [{"text": str, "start_time": float, "end_time": float}]
    task_id: str = ""
    error: str = ""

    def __post_init__(self):
        if self.words is None:
            self.words = []
        if self.sentences is None:
            self.sentences = []


class CallbackServer:
    """本地回调服务器，用于接收 ASR 识别结果"""

    def __init__(self, port: int = 8765):
        self.port = port
        self.results = {}  # task_id -> result
        self._thread = None
        self._running = False

    def start(self):
        """启动服务器在后台线程"""
        self._running = True
        self._thread = threading.Thread(target=self._run_server, daemon=True)
        self._thread.start()
        time.sleep(0.5)  # 等待服务器启动
        logger.info(f"Callback server started on port {self.port}")

    def _run_server(self):
        """运行 Flask 服务器"""
        try:
            from flask import Flask, request
            app = Flask(__name__)

            @app.route('/asr_callback', methods=['POST'])
            def handle_callback():
                data = request.get_json()
                logger.info(f"Received callback: {json.dumps(data, ensure_ascii=False)[:200]}")

                # 解析回调结果
                task_id = data.get("TaskId", "")
                status_code = data.get("StatusCode", 0)
                result_data = data.get("Result", {})

                if status_code == 21050000:  # SUCCESS
                    sentences = result_data.get("Sentences", [])
                    text_parts = []
                    processed_sentences = []

                    for sent in sentences:
                        text = sent.get("Text", "")
                        text_parts.append(text)
                        start_time = sent.get("BeginTime", 0) / 1000.0  # ms -> s
                        end_time = sent.get("EndTime", 0) / 1000.0

                        processed_sentences.append({
                            "text": text,
                            "start_time": start_time,
                            "end_time": end_time,
                        })

                    full_text = "".join(text_parts)
                    self.results[task_id] = ASRResult(
                        success=True,
                        text=full_text,
                        sentences=processed_sentences,
                        task_id=task_id,
                    )
                else:
                    self.results[task_id] = ASRResult(
                        success=False,
                        error=f"ASR failed with status {status_code}",
                        task_id=task_id,
                    )

                return {"status": "ok"}

            @app.route('/health', methods=['GET'])
            def health():
                return {"status": "healthy", "port": self.port}

            app.run(host='0.0.0.0', port=self.port, debug=False, threaded=True)
        except ImportError:
            logger.error("Flask not installed. Callback server requires Flask.")
            logger.error("Install with: pip install flask")
            self._running = False

    def get_url(self) -> str:
        """获取回调 URL（需要在 ngrok/tunnel 环境下使用）"""
        return f"http://localhost:{self.port}/asr_callback"

    def get_result(self, task_id: str, timeout: float = 60.0) -> Optional[ASRResult]:
        """获取指定 task_id 的结果"""
        start = time.time()
        while time.time() - start < timeout:
            if task_id in self.results:
                return self.results.pop(task_id)
            time.sleep(0.5)
        return None

    def stop(self):
        """停止服务器"""
        self._running = False


class AliYunASRClient:
    """
    阿里云录音文件识别客户端

    支持：
    - 词级时间戳 (enable_words=True)
    - Token 或 AK/SK 认证
    - 音频文件直接上传
    - 回调模式获取完整时间戳

    Args:
        app_key: 阿里云 AppKey
        token: 预生成的 Token（从控制台获取）
        access_key_id: AccessKey ID（可选，与 access_key_secret 配对使用）
        access_key_secret: AccessKey Secret（可选）
        enable_words: 是否开启词级时间戳 (默认 True)
    """

    def __init__(
        self,
        app_key: str,
        token: Optional[str] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        enable_words: bool = True,
    ):
        self.app_key = app_key
        self.token = token
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.enable_words = enable_words

    def _get_token(self) -> str:
        """获取 Token"""
        if self.token:
            return self.token
        if self.access_key_id and self.access_key_secret:
            return generate_aliyun_token(
                self.access_key_id,
                self.access_key_secret,
                self.app_key,
            )
        raise ValueError("必须提供 token 或 access_key_id/access_key_secret")

    def _get_headers(self) -> dict:
        """获取请求头"""
        return {
            "X-NLS-Token": self._get_token(),
            "Content-Type": "application/octet-stream",
        }

    def _get_json_headers(self) -> dict:
        """获取 JSON 请求头"""
        return {
            "X-NLS-Token": self._get_token(),
            "Content-Type": "application/json",
        }

    def _get_url(self) -> str:
        """获取带 appkey 的 URL"""
        return ASR_URL_TEMPLATE.format(app_key=self.app_key)

    def _get_query_url(self, task_id: str) -> str:
        """获取查询 URL"""
        return ASR_TASK_QUERY_URL.format(app_key=self.app_key, task_id=task_id)

    def recognize_file(
        self,
        audio_path: str,
        audio_format: str = "pcm",
        sample_rate: int = 16000,
        callback_url: Optional[str] = None,
    ) -> dict:
        """
        识别音频文件（同步版本，无时间戳）

        Args:
            audio_path: 音频文件路径
            audio_format: 音频格式 (pcm/wav/mp3/m4a 等)
            sample_rate: 采样率
            callback_url: 回调 URL（可选，用于获取时间戳）

        Returns:
            {
                "success": bool,
                "text": str,
                "words": [],
                "sentences": [{"text": str, "start_time": float, "end_time": float}],
                "task_id": str,
                "error": str (如果失败)
            }
        """
        with open(audio_path, "rb") as f:
            audio_data = f.read()

        return self._submit_and_get_result(
            audio_data=audio_data,
            audio_format=audio_format,
            sample_rate=sample_rate,
            callback_url=callback_url,
        )

    def recognize_file_with_callback(
        self,
        audio_path: str,
        callback_server: CallbackServer,
        audio_format: str = "pcm",
        sample_rate: int = 16000,
    ) -> dict:
        """
        识别音频文件（使用回调获取时间戳）

        Args:
            audio_path: 音频文件路径
            callback_server: 本地回调服务器
            audio_format: 音频格式
            sample_rate: 采样率

        Returns:
            ASRResult with sentences and word timestamps
        """
        with open(audio_path, "rb") as f:
            audio_data = f.read()

        callback_url = callback_server.get_url()

        # 提交任务
        body = {
            "appkey": self.app_key,
            "format": audio_format,
            "sample_rate": sample_rate,
            "enable_words": self.enable_words,
            "enable_callback": True,
            "callback_url": callback_url,
            "request_id": str(uuid.uuid4()),
        }
        body_json = json.dumps(body).encode()
        body_with_audio = body_json + b"\n" + audio_data

        resp = requests.post(
            self._get_url(),
            headers=self._get_headers(),
            data=body_with_audio,
            timeout=60,
        )

        if resp.status_code != 200:
            return ASRResult(
                success=False,
                error=f"HTTP {resp.status_code}: {resp.text[:200]}",
            )

        # 获取 task_id
        result = resp.json()
        task_id = result.get("task_id", "")

        if not task_id:
            return ASRResult(
                success=False,
                error="No task_id returned",
            )

        # 通过回调获取结果
        asr_result = callback_server.get_result(task_id, timeout=60.0)

        if asr_result is None:
            return ASRResult(
                success=False,
                error=f"Callback timeout for task {task_id}",
                task_id=task_id,
            )

        return asr_result

    def _submit_and_get_result(
        self,
        audio_data: bytes,
        audio_format: str,
        sample_rate: int,
        callback_url: Optional[str] = None,
    ) -> dict:
        """提交识别任务并获取结果"""
        body = {
            "appkey": self.app_key,
            "format": audio_format,
            "sample_rate": sample_rate,
            "enable_words": self.enable_words,
            "request_id": str(uuid.uuid4()),
        }

        if callback_url:
            body["enable_callback"] = True
            body["callback_url"] = callback_url

        body_json = json.dumps(body).encode()
        body_with_audio = body_json + b"\n" + audio_data

        resp = requests.post(
            self._get_url(),
            headers=self._get_headers(),
            data=body_with_audio,
            timeout=60,
        )

        if resp.status_code != 200:
            return {
                "success": False,
                "error": f"HTTP {resp.status_code}: {resp.text[:200]}",
                "text": "",
                "words": [],
                "sentences": [],
                "task_id": "",
            }

        # 使用原始字节提取结果（解决 UTF-8 编码问题）
        extracted = _extract_result_from_raw_response(resp.content)

        # 检查状态码
        status = extracted.get("status", 0)
        if status != 20000000 and status != 200:
            return {
                "success": False,
                "error": f"ASR error status: {status}",
                "text": "",
                "words": [],
                "sentences": [],
                "task_id": extracted.get("task_id", ""),
            }

        return {
            "success": True,
            "text": extracted.get("text", ""),
            "words": [],
            "sentences": [],
            "task_id": extracted.get("task_id", ""),
        }


class SynchAliYunASRClient:
    """
    阿里云录音文件识别客户端（同步版本）

    使用 requests 库，适合批量处理或离线评估。
    """

    def __init__(
        self,
        app_key: str,
        token: Optional[str] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        enable_words: bool = True,
    ):
        self.app_key = app_key
        self.token = token
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.enable_words = enable_words

    def _get_token(self) -> str:
        """获取 Token"""
        if self.token:
            return self.token
        if self.access_key_id and self.access_key_secret:
            return generate_aliyun_token(
                self.access_key_id,
                self.access_key_secret,
                self.app_key,
            )
        raise ValueError("必须提供 token 或 access_key_id/access_key_secret")

    def _get_headers(self) -> dict:
        return {
            "X-NLS-Token": self._get_token(),
            "Content-Type": "application/octet-stream",
        }

    def _get_json_headers(self) -> dict:
        return {
            "X-NLS-Token": self._get_token(),
            "Content-Type": "application/json",
        }

    def _get_url(self) -> str:
        """获取带 appkey 的 URL"""
        return ASR_URL_TEMPLATE.format(app_key=self.app_key)

    def recognize_file(
        self,
        audio_path: str,
        audio_format: str = "pcm",
        sample_rate: int = 16000,
    ) -> dict:
        """识别本地音频文件（同步版本，无时间戳）"""
        with open(audio_path, "rb") as f:
            audio_data = f.read()
        return self._submit_and_get_result(audio_data, audio_format, sample_rate)

    def recognize_file_with_callback(
        self,
        audio_path: str,
        callback_server: CallbackServer,
        audio_format: str = "pcm",
        sample_rate: int = 16000,
    ) -> ASRResult:
        """
        识别音频文件（使用回调获取时间戳）

        Args:
            audio_path: 音频文件路径
            callback_server: 本地回调服务器实例
            audio_format: 音频格式
            sample_rate: 采样率

        Returns:
            ASRResult with sentences and timestamps
        """
        with open(audio_path, "rb") as f:
            audio_data = f.read()

        callback_url = callback_server.get_url()

        body = {
            "appkey": self.app_key,
            "format": audio_format,
            "sample_rate": sample_rate,
            "enable_words": self.enable_words,
            "enable_callback": True,
            "callback_url": callback_url,
            "request_id": str(uuid.uuid4()),
        }
        body_json = json.dumps(body).encode()
        body_with_audio = body_json + b"\n" + audio_data

        resp = requests.post(
            self._get_url(),
            headers=self._get_headers(),
            data=body_with_audio,
            timeout=60,
        )

        if resp.status_code != 200:
            return ASRResult(
                success=False,
                error=f"HTTP {resp.status_code}: {resp.text[:200]}",
            )

        result = resp.json()
        task_id = result.get("task_id", "")

        if not task_id:
            return ASRResult(
                success=False,
                error="No task_id returned",
            )

        asr_result = callback_server.get_result(task_id, timeout=60.0)

        if asr_result is None:
            return ASRResult(
                success=False,
                error=f"Callback timeout for task {task_id}",
                task_id=task_id,
            )

        return asr_result

    def _submit_and_get_result(
        self,
        audio_data: bytes,
        audio_format: str,
        sample_rate: int,
    ) -> dict:
        """提交识别任务并获取结果"""
        body = {
            "appkey": self.app_key,
            "format": audio_format,
            "sample_rate": sample_rate,
            "enable_words": self.enable_words,
            "request_id": str(uuid.uuid4()),
        }
        body_json = json.dumps(body).encode()
        body_with_audio = body_json + b"\n" + audio_data

        resp = requests.post(
            self._get_url(),
            headers=self._get_headers(),
            data=body_with_audio,
            timeout=60,
        )

        if resp.status_code != 200:
            return {
                "success": False,
                "error": f"HTTP {resp.status_code}: {resp.text[:200]}",
                "text": "",
                "words": [],
                "sentences": [],
                "task_id": "",
            }

        # 使用原始字节提取结果（解决 UTF-8 编码问题）
        extracted = _extract_result_from_raw_response(resp.content)

        # 检查状态码
        status = extracted.get("status", 0)
        if status != 20000000 and status != 200:
            return {
                "success": False,
                "error": f"ASR error status: {status}",
                "text": "",
                "words": [],
                "sentences": [],
                "task_id": extracted.get("task_id", ""),
            }

        return {
            "success": True,
            "text": extracted.get("text", ""),
            "words": [],
            "sentences": [],
            "task_id": extracted.get("task_id", ""),
        }

    def recognize_file_with_timestamps(self, audio_path: str, audio_format: str = "pcm", sample_rate: int = 16000) -> dict:
        """
        识别本地音频文件并获取词级时间戳（使用 nls SDK 流式转录）

        Args:
            audio_path: 音频文件路径
            audio_format: 音频格式 (pcm/opus/opu)
            sample_rate: 采样率

        Returns:
            dict with success, text, words (with timestamps), sentences, error
        """
        import nls

        sentences = []

        def on_sentence_begin(msg, *args):
            try:
                data = json.loads(msg)
                payload = data.get("payload", {})
                start_time = payload.get("time", 0) / 1000.0
                sentences.append({
                    "start_time": start_time,
                    "text": "",
                    "end_time": None,
                    "word_list": [],
                })
            except (json.JSONDecodeError, KeyError):
                pass

        def on_sentence_end(msg, *args):
            try:
                msg_bytes = msg.encode('utf-8')

                # 解析 JSON 获取基本信息
                data = json.loads(msg)
                payload = data.get("payload", {})

                if sentences:
                    last = sentences[-1]
                    last["end_time"] = payload.get("time", 0) / 1000.0

                    # Extract sentence text from raw UTF-8 bytes
                    start_marker = b'"result":"'
                    end_marker = b'","confidence"'
                    start_idx = msg_bytes.find(start_marker)
                    if start_idx != -1:
                        start_idx += len(start_marker)
                        end_idx = msg_bytes.find(end_marker, start_idx)
                        if end_idx != -1:
                            raw_bytes = msg_bytes[start_idx:end_idx]
                            last["text"] = raw_bytes.decode('utf-8')

                    # 从原始消息字节中提取词级时间戳（避免 JSON 解析导致的编码问题）
                    words_start = msg_bytes.find(b'"words":[')
                    if words_start != -1:
                        array_start = words_start + len(b'"words":[')
                        # 找到数组结束位置
                        bracket_end = msg_bytes.find(b']', array_start)
                        if bracket_end == -1:
                            bracket_end = len(msg_bytes)

                        pos = array_start

                        while pos < bracket_end:
                            # 找 'text":"'
                            text_marker = msg_bytes.find(b'"text":"', pos)
                            if text_marker == -1 or text_marker >= bracket_end:
                                break

                            text_start = text_marker + len(b'"text":"')
                            # 找下一个 '",' (分隔 text 和 startTime)
                            end_marker_pos = msg_bytes.find(b'",', text_start)
                            if end_marker_pos == -1 or end_marker_pos >= bracket_end:
                                break

                            text_bytes = msg_bytes[text_start:end_marker_pos]
                            word_text = text_bytes.decode('utf-8', errors='replace')

                            # 找 startTime
                            start_marker_pos = msg_bytes.find(b'"startTime":', end_marker_pos)
                            if start_marker_pos == -1 or start_marker_pos >= bracket_end:
                                break
                            start_pos = start_marker_pos + len(b'"startTime":')
                            # startTime 值可能是数字结尾，后面跟逗号或右括号
                            comma_pos = msg_bytes.find(b',', start_pos)
                            if comma_pos == -1 or comma_pos >= bracket_end:
                                comma_pos = bracket_end - 1
                            start_time = int(msg_bytes[start_pos:comma_pos]) / 1000.0

                            # 找 endTime
                            end_marker_pos2 = msg_bytes.find(b'"endTime":', comma_pos)
                            if end_marker_pos2 == -1 or end_marker_pos2 >= bracket_end:
                                break
                            end_pos = end_marker_pos2 + len(b'"endTime":')
                            # endTime 值后面可能跟 } 或 ,
                            right_brace = msg_bytes.find(b'}', end_pos)
                            comma_after = msg_bytes.find(b',', end_pos)
                            if right_brace == -1:
                                end_end = bracket_end
                            elif comma_after == -1:
                                end_end = right_brace
                            else:
                                end_end = min(right_brace, comma_after)
                            end_time = int(msg_bytes[end_pos:end_end]) / 1000.0

                            last["word_list"].append({
                                "word": word_text,
                                "start_time": start_time,
                                "end_time": end_time,
                            })

                            pos = end_end + 1
            except (json.JSONDecodeError, KeyError):
                pass

        def on_error(msg, *args):
            logger.error(f"Streaming ASR error: {msg}")

        transcriber = nls.NlsSpeechTranscriber(
            url='wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1',
            token=self._get_token(),
            appkey=self.app_key,
            on_sentence_begin=on_sentence_begin,
            on_sentence_end=on_sentence_end,
            on_error=on_error,
        )

        try:
            transcriber.start(
                aformat=audio_format,
                sample_rate=sample_rate,
                enable_intermediate_result=False,
                enable_punctuation_prediction=True,
                enable_inverse_text_normalization=False,
                ex={'enable_words': True},
            )

            chunk_size = 3200
            with open(audio_path, "rb") as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    transcriber.send_audio(chunk)

            transcriber.stop()
            transcriber.shutdown()

            # 收集所有词级时间戳
            text_parts = []
            all_words = []
            for s in sentences:
                if s["text"]:
                    text_parts.append(s["text"])
                all_words.extend(s.get("word_list", []))

            full_text = "".join(text_parts)

            return {
                "success": True,
                "text": full_text,
                "sentences": [s for s in sentences if s["text"]],
                "words": all_words,
                "error": "",
            }

        except Exception as e:
            logger.error(f"Streaming ASR failed: {e}")
            return {
                "success": False,
                "text": "",
                "sentences": [],
                "words": [],
                "error": str(e),
            }

    def _extract_word_text_from_message(self, message: str, fallback_text: str) -> str:
        """从原始消息中提取词的文本"""
        try:
            msg_bytes = message.encode('utf-8')
            # 查找词文本的位置 - 格式: "text":"xxx"
            search_text = fallback_text if fallback_text else "text"
            marker = f'"text":"{search_text}"'.encode('utf-8')
            idx = msg_bytes.find(marker)
            if idx == -1:
                return fallback_text
            # 找到值的开始位置
            start_idx = idx + len(marker) - len(search_text) - 1
            # 向前查找开始的引号
            quote_start = msg_bytes.rfind(b'"', 0, start_idx)
            if quote_start == -1:
                return fallback_text
            # 向后查找结束的引号
            quote_end = msg_bytes.find(b'"', start_idx + 1)
            if quote_end == -1:
                return fallback_text
            return msg_bytes[quote_start + 1:quote_end].decode('utf-8')
        except Exception:
            return fallback_text


# ========== 流式转录（使用 nls SDK 获取时间戳）========== """

import nls


class StreamingASRClient:
    """
    使用 nls SDK 进行流式转录，获取句子级别时间戳

    通过 NlsSpeechTranscriber 模拟实时流式输入，获取 sentence_begin/sentence_end 回调
    """

    def __init__(self, app_key: str, token: str):
        self.app_key = app_key
        self.token = token
        self.sentences = []
        self._transcriber = None

    def _extract_text_from_raw_json(self, raw_msg: str) -> str:
        """从原始 JSON 消息中提取 result 字段的原始 UTF-8 字节并正确解码"""
        try:
            # 将消息转为 bytes
            msg_bytes = raw_msg.encode('utf-8')
            # 找到 "result":" 开始位置
            start_marker = b'"result":"'
            end_marker = b'","confidence"'
            start_idx = msg_bytes.find(start_marker)
            if start_idx == -1:
                return ""
            start_idx += len(start_marker)
            end_idx = msg_bytes.find(end_marker, start_idx)
            if end_idx == -1:
                return ""
            # 提取原始 UTF-8 字节
            raw_bytes = msg_bytes[start_idx:end_idx]
            # 正确解码为 UTF-8
            return raw_bytes.decode('utf-8')
        except Exception:
            return ""

    def _on_sentence_begin(self, message, *args):
        """句子开始回调"""
        try:
            data = json.loads(message)
            # SentenceBegin 的时间在 payload.time
            payload = data.get("payload", {})
            start_time = payload.get("time", 0) / 1000.0
            self.sentences.append({
                "start_time": start_time,
                "text": "",
                "end_time": None,
            })
        except (json.JSONDecodeError, KeyError):
            pass

    def _on_result_changed(self, message, *args):
        """结果变化回调（保留）"""
        pass

    def _on_error(self, message, *args):
        """错误回调"""
        logger.error(f"Streaming ASR error: {message}")

    def _on_completed(self, message, *args):
        """完成回调"""
        logger.info(f"Streaming ASR completed: {message}")

    def _extract_word_text(self, msg_bytes: bytes, start_idx: int, end_idx: int) -> str:
        """从原始字节提取词文本"""
        try:
            raw_bytes = msg_bytes[start_idx:end_idx]
            return raw_bytes.decode('utf-8')
        except Exception:
            return ""

    def recognize_file(self, audio_path: str, audio_format: str = "pcm", sample_rate: int = 16000) -> dict:
        """
        识别音频文件（流式方式，获取词级时间戳）

        Args:
            audio_path: 音频文件路径
            audio_format: 音频格式 (pcm/opus/opu)
            sample_rate: 采样率

        Returns:
            dict with success, text, words, sentences, error
        """
        self.sentences = []
        all_words = []

        # 创建转录器
        self._transcriber = nls.NlsSpeechTranscriber(
            url='wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1',
            token=self.token,
            appkey=self.app_key,
            on_sentence_begin=self._on_sentence_begin,
            on_sentence_end=self._on_sentence_end,
            on_result_changed=self._on_result_changed,
            on_error=self._on_error,
            on_completed=self._on_completed,
        )

        try:
            # 启动转录，启用词级时间戳
            self._transcriber.start(
                aformat=audio_format,
                sample_rate=sample_rate,
                enable_intermediate_result=False,
                enable_punctuation_prediction=True,
                enable_inverse_text_normalization=False,
                ex={'enable_words': True},
            )

            # 分块发送音频
            chunk_size = 3200  # 100ms at 16kHz * 16bit
            with open(audio_path, "rb") as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    self._transcriber.send_audio(chunk)

            # 停止转录
            self._transcriber.stop()

            # 构建结果 - 从 sentences 中收集所有词级时间戳
            text_parts = []
            all_words = []
            for s in self.sentences:
                if s["text"]:
                    text_parts.append(s["text"])
                # 从 sentence 中收集 word_list
                word_list = s.get("word_list", [])
                all_words.extend(word_list)

            full_text = "".join(text_parts)

            return {
                "success": True,
                "text": full_text,
                "sentences": [s for s in self.sentences if s["text"]],
                "words": all_words,
                "error": "",
            }

        except Exception as e:
            logger.error(f"Streaming ASR failed: {e}")
            return {
                "success": False,
                "text": "",
                "sentences": [],
                "words": [],
                "error": str(e),
            }
        finally:
            if self._transcriber:
                self._transcriber.shutdown()

    def _on_sentence_end(self, message, *args):
        """句子结束回调"""
        try:
            data = json.loads(message)
            payload = data.get("payload", {})
            if self.sentences:
                last = self.sentences[-1]
                # end_time 在 payload.time
                last["end_time"] = payload.get("time", 0) / 1000.0
                # text 需要从原始 UTF-8 字节解码
                last["text"] = self._extract_text_from_raw_json(message)

                # 提取词级时间戳
                words_list = payload.get("words", [])
                for w in words_list:
                    word_text = w.get("text", "")
                    # 如果词文本是乱码（编码问题），尝试从原始消息提取
                    if self._is_garbled(word_text):
                        word_text = self._extract_word_text_from_message(message, w.get("text", ""))
                    last.setdefault("word_list", []).append({
                        "word": word_text,
                        "start_time": w.get("startTime", 0) / 1000.0,
                        "end_time": w.get("endTime", 0) / 1000.0,
                    })
        except (json.JSONDecodeError, KeyError):
            pass

    def _is_garbled(self, text: str) -> bool:
        """检查文本是否是乱码（编码问题导致）"""
        if not text:
            return False
        # 乱码字符通常是替换字符 U+FFFD 或包含�
        return '�' in text or '?' in text

    def _extract_word_text_from_message(self, message: str, fallback_text: str) -> str:
        """从原始消息中提取词的文本"""
        try:
            msg_bytes = message.encode('utf-8')
            # 查找词文本的位置
            # 格式: "text":"xxx"
            search_text = fallback_text if fallback_text else "text"
            marker = f'"text":"{search_text}"'.encode('utf-8')
            idx = msg_bytes.find(marker)
            if idx == -1:
                return fallback_text
            # 找到值的开始位置
            start_idx = idx + len(marker) - len(search_text) - 1
            # 向前查找开始的引号
            quote_start = msg_bytes.rfind(b'"', 0, start_idx)
            if quote_start == -1:
                return fallback_text
            # 向后查找结束的引号
            quote_end = msg_bytes.find(b'"', start_idx + 1)
            if quote_end == -1:
                return fallback_text
            return msg_bytes[quote_start + 1:quote_end].decode('utf-8')
        except Exception:
            return fallback_text


# ========== 测试代码 ==========

def test_recognition():
    """测试 ASR 识别"""
    import os

    APP_KEY = os.getenv("ALIYUN_ASR_APP_KEY", "XyBVyyGNTFZyKa7D")
    TOKEN = os.getenv("ALIYUN_ASR_TOKEN", "3ea8234a3c95443aba02753f41db7913")

    print("=" * 60)
    print("AliYun ASR Recognition Test")
    print("=" * 60)
    print(f"AppKey: {APP_KEY}")
    print(f"Token: {TOKEN[:20]}...")
    print("-" * 60)

    client = SynchAliYunASRClient(
        app_key=APP_KEY,
        token=TOKEN,
        enable_words=True,
    )

    # 测试音频文件
    audio_path = "../../realtime/fixtures/audio/tts_long_text_100_chars.pcm"
    if not os.path.exists(audio_path):
        audio_path = "test/realtime/fixtures/audio/tts_long_text_100_chars.pcm"

    if os.path.exists(audio_path):
        print(f"\nTesting with (sync): {audio_path}")
        result = client.recognize_file(audio_path, audio_format="pcm")

        print(f"\nSync Result:")
        print(f"  success: {result.get('success')}")
        print(f"  text length: {len(result.get('text', ''))} chars")
        if result.get('success'):
            print(f"  text: {result.get('text', '')[:50]}...")
    else:
        print(f"Audio file not found: {audio_path}")


def test_recognition_with_callback():
    """测试 ASR 识别（使用回调获取时间戳）"""
    import os

    APP_KEY = os.getenv("ALIYUN_ASR_APP_KEY", "XyBVyyGNTFZyKa7D")
    TOKEN = os.getenv("ALIYUN_ASR_TOKEN", "3ea8234a3c95443aba02753f41db7913")

    print("=" * 60)
    print("AliYun ASR Recognition Test with Callback")
    print("=" * 60)
    print(f"AppKey: {APP_KEY}")
    print(f"Token: {TOKEN[:20]}...")
    print("-" * 60)

    # 启动回调服务器
    callback_server = CallbackServer(port=8765)
    callback_server.start()

    client = SynchAliYunASRClient(
        app_key=APP_KEY,
        token=TOKEN,
        enable_words=True,
    )

    # 测试音频文件
    audio_path = "../../realtime/fixtures/audio/tts_long_text_100_chars.pcm"
    if not os.path.exists(audio_path):
        audio_path = "test/realtime/fixtures/audio/tts_long_text_100_chars.pcm"

    if os.path.exists(audio_path):
        print(f"\nTesting with callback: {audio_path}")
        print(f"Callback URL: {callback_server.get_url()}")
        print("NOTE: You need to expose this URL via ngrok or similar tunnel")
        print("Run: ngrok http 8765")
        print("Then update the callback_url with the ngrok URL")
        print()
        print("Skipping actual callback test (requires tunnel)...")
        print("Use test_recognition() for basic sync test")
    else:
        print(f"Audio file not found: {audio_path}")

    callback_server.stop()


if __name__ == "__main__":
    test_recognition()

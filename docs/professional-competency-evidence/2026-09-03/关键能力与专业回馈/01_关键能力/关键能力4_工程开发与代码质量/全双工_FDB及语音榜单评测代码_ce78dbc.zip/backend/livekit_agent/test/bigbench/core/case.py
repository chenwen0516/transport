"""BigBench 测试用例定义"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class BigBenchCase:
    """单次 BigBench 测试用例

    对应一个推理问题，评估模型能否通过语音完成推理。
    """
    id: str                       # 唯一标识，如 "navigate_001"
    category: str                  # 能力分类：navigate, counting, logic, etc.
    question: str                  # 测试问题文本
    answer: str                    # 标准答案
    tts_text: Optional[str] = None  # TTS 生成音频时使用的文本（可选）
    difficulty: Optional[str] = None  # 难度：easy, medium, hard
    reasoning_steps: Optional[int] = None  # 推理步数
    _audio_bytes: Optional[bytes] = None  # 内部存储音频数据

    @property
    def is_reasoning(self) -> bool:
        """是否为推理类题目（非简单问答）"""
        reasoning_categories = {"navigate", "logic", "counting", "arithmetic", "memory"}
        return self.category in reasoning_categories

    @property
    def audio_bytes(self) -> Optional[bytes]:
        """获取音频数据（如果有）"""
        return self._audio_bytes

    @property
    def audio_duration_s(self) -> Optional[float]:
        """估算音频时长（秒）"""
        if self._audio_bytes:
            # 16kHz, 16bit, 单声道
            num_samples = len(self._audio_bytes) // 2
            return num_samples / 16000
        return None
"""BigBench 指标计算模块

评测指标：
- Accuracy: 正确率（总体、按分类、按难度）
- Latency: 延迟（首 token 延迟、首音频延迟、完整回复耗时）
- Reasoning: 推理能力（按推理步数分析）
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, List, Dict
import time


@dataclass
class BigBenchResult:
    """单次 BigBench 测试结果

    模型能否通过语音完成推理。
    """
    case_id: str
    category: str
    question: str
    expected_answer: str
    predicted_answer: Optional[str] = None
    correct: Optional[bool] = None
    difficulty: Optional[str] = None  # easy, medium, hard
    reasoning_steps: Optional[int] = None  # 推理步数

    # 延迟指标
    t_question_audio_end: Optional[float] = None   # 问题音频注入完成时间
    t_first_token: Optional[float] = None         # 第一个文本 token 时间
    t_first_audio: Optional[float] = None          # 第一个音频帧时间
    t_response_done: Optional[float] = None        # 回复完成时间

    @property
    def latency_first_token_ms(self) -> Optional[float]:
        if self.t_first_token is None or self.t_question_audio_end is None:
            return None
        return (self.t_first_token - self.t_question_audio_end) * 1000

    @property
    def latency_first_audio_ms(self) -> Optional[float]:
        if self.t_first_audio is None or self.t_question_audio_end is None:
            return None
        return (self.t_first_audio - self.t_question_audio_end) * 1000

    @property
    def latency_total_ms(self) -> Optional[float]:
        if self.t_response_done is None or self.t_question_audio_end is None:
            return None
        return (self.t_response_done - self.t_question_audio_end) * 1000


# ========== 聚合器 ==========

def _percentiles(values: list[float]) -> Dict[str, Optional[float]]:
    """计算 P50/P90/P95/P99/max"""
    if not values:
        return {"p50": None, "p90": None, "p95": None, "p99": None, "max": None}
    values = sorted(values)
    n = len(values)
    return {
        "p50": values[int(n * 0.50)],
        "p90": values[min(int(n * 0.90), n - 1)],
        "p95": values[min(int(n * 0.95), n - 1)],
        "p99": values[min(int(n * 0.99), n - 1)],
        "max": values[-1],
    }


class BigBenchMetricsAggregator:
    """聚合 BigBench 测试结果，计算统计指标"""

    def __init__(self):
        self.results: list[BigBenchResult] = []

    def add(self, result: BigBenchResult) -> None:
        self.results.append(result)

    # ---------- 准确率 ----------

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def answered(self) -> int:
        """有结果的测试数"""
        return sum(1 for r in self.results if r.correct is not None)

    def accuracy(self) -> float:
        """正确率"""
        answered = [r for r in self.results if r.correct is not None]
        if not answered:
            return 0.0
        return sum(1 for r in answered if r.correct) / len(answered)

    def accuracy_by_category(self) -> Dict[str, float]:
        """按分类的正确率"""
        categories = set(r.category for r in self.results if r.category)
        return {
            cat: self._accuracy_for_category(cat)
            for cat in categories
        }

    def accuracy_by_difficulty(self) -> Dict[str, float]:
        """按难度的正确率"""
        difficulties = set(r.difficulty for r in self.results if r.difficulty)
        return {
            diff: self._accuracy_for_difficulty(diff)
            for diff in difficulties
        }

    def _accuracy_for_category(self, category: str) -> float:
        cases = [r for r in self.results if r.category == category and r.correct is not None]
        if not cases:
            return 0.0
        return sum(1 for r in cases if r.correct) / len(cases)

    def _accuracy_for_difficulty(self, difficulty: str) -> float:
        cases = [r for r in self.results if r.difficulty == difficulty and r.correct is not None]
        if not cases:
            return 0.0
        return sum(1 for r in cases if r.correct) / len(cases)

    # ---------- 延迟百分位 ----------

    def latency_first_token_percentiles(self) -> Dict[str, Optional[float]]:
        return _percentiles([
            r.latency_first_token_ms for r in self.results
            if r.latency_first_token_ms is not None
        ])

    def latency_first_audio_percentiles(self) -> Dict[str, Optional[float]]:
        return _percentiles([
            r.latency_first_audio_ms for r in self.results
            if r.latency_first_audio_ms is not None
        ])

    def latency_total_percentiles(self) -> Dict[str, Optional[float]]:
        return _percentiles([
            r.latency_total_ms for r in self.results
            if r.latency_total_ms is not None
        ])

    # ---------- 汇总 ----------

    def summary(self) -> dict:
        return {
            "total": self.total,
            "answered": self.answered,
            "accuracy": self.accuracy(),
            "accuracy_by_category": self.accuracy_by_category(),
            "accuracy_by_difficulty": self.accuracy_by_difficulty(),
            "latency_first_token": self.latency_first_token_percentiles(),
            "latency_first_audio": self.latency_first_audio_percentiles(),
            "latency_total": self.latency_total_percentiles(),
        }
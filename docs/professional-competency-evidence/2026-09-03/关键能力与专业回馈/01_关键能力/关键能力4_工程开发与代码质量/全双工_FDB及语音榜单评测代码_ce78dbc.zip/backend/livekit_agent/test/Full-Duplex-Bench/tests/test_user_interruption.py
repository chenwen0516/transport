"""User Interruption 测试

测试用户打断 AI 的能力
"""
import asyncio
import time

from core import (
    RealtimeTestClient,
    DatasetCase,
    EvaluationResult,
    wait_for_agent_state,
    MetricsAggregator,
    AUDIO_DELTA_EVENT,
)


async def test_user_interruption_dataset(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case: DatasetCase,
    metrics_aggregator: MetricsAggregator,
    min_deltas: int = 5,
):
    """使用数据集音频测试用户打断

    流程：
    1. 连接并等待 AI 开始说话
    2. 等待 AI 说到一半（收到足够 deltas）
    3. 注入 interrupt.wav 打断
    4. 检查 AI 是否被打断并计算响应延迟
    """
    if not case.interrupt_audio:
        print(f"    跳过 {case.case_name}: 无打断音频")
        metrics_aggregator.add_result(EvaluationResult(
            task="user_interruption",
            case_name=case.case_name,
            success=False,
            error="missing interrupt audio",
        ))
        return

    await ws_client.connect(ws_url, auth_token)

    # 等待 AI 开始说话
    if not await wait_for_agent_state(ws_client, "speaking", timeout=15):
        print(f"    跳过 {case.case_name}: AI 未开始说话")
        metrics_aggregator.add_result(EvaluationResult(
            task="user_interruption",
            case_name=case.case_name,
            success=False,
            error="agent did not start speaking",
        ))
        return

    # 等待 AI 说到一半（收到足够 deltas）
    deadline = time.monotonic() + 15
    while ws_client.count_events(AUDIO_DELTA_EVENT) < min_deltas:
        if time.monotonic() > deadline:
            print(f"    跳过 {case.case_name}: AI 未输出足够音频")
            metrics_aggregator.add_result(EvaluationResult(
                task="user_interruption",
                case_name=case.case_name,
                success=False,
                error="not enough audio deltas before interruption",
            ))
            return
        await asyncio.sleep(0.05)

    # 注入打断音频
    t_inject_first, t_inject_last = await ws_client.inject_audio(case.interrupt_audio)

    # 等待打断后的结果
    await ws_client.drain_events(timeout=10.0)

    # 检查是否被打断
    interrupted = ws_client.has_event_after(
        "response.done", t_inject_first,
        lambda e: e.get("response", {}).get("status") == "cancelled",
    )
    if not interrupted:
        interrupted = ws_client.has_event_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )

    # 计算真实打断延迟：从注入打断到 AI 进入 thinking 的时间
    latency = -1.0
    if interrupted:
        t_thinking = ws_client.get_event_time_after(
            "agent.state_changed", t_inject_first,
            predicate=lambda e: e.get("state") == "thinking",
        )
        if t_thinking:
            latency = (t_thinking - t_inject_first) * 1000

    result = EvaluationResult(
        task="user_interruption",
        case_name=case.case_name,
        tor=1.0 if interrupted else 0.0,
        latency=latency,
    )
    metrics_aggregator.add_result(result)

    print(f"    {'✓' if interrupted else '✗'} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency > 0 else f"    {'✓' if interrupted else '✗'} {case.case_name}: tor={result.tor}")

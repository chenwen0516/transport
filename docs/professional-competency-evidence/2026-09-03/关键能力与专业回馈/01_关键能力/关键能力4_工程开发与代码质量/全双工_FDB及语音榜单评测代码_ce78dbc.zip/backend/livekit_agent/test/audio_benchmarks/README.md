# 音频评测

这个目录提供 OpenAudioBench 和 VoiceBench 的独立评测脚本。它们复用
`bigbench` 里已有的 WebSocket/WebRTC 客户端、ASR、judge、延迟指标和报告格式，
但代码放在独立目录中，方便单独维护。

下面的命令默认从 `backend/livekit_agent` 目录执行：

```bash
cd /opt/cw/health-assistant/backend/livekit_agent
```

## OpenAudioBench

运行一个小规模 WebRTC 冒烟测试：

```bash
uv run python test/audio_benchmarks/run_openaudiobench.py \
  --protocol webrtc \
  --component reasoning_qa \
  --max-cases 5
```

后台运行全部 OpenAudioBench 维度：

```bash
nohup uv run python test/audio_benchmarks/run_openaudiobench.py \
  --protocol webrtc \
  --component all \
  --early-response-policy warn \
  > test/audio_benchmarks/openaudiobench_webrtc_all.log 2>&1 &
```

可用维度：

```text
reasoning_qa
llama_questions
web_questions
trivia_qa
alpaca_eval
```

多个维度可以用逗号分隔：

```bash
uv run python test/audio_benchmarks/run_openaudiobench.py \
  --protocol webrtc \
  --component web_questions,trivia_qa \
  --max-audio-seconds 30
```

## VoiceBench

运行一个小规模 WebRTC 冒烟测试：

```bash
uv run python test/audio_benchmarks/run_voicebench.py \
  --protocol webrtc \
  --subset openbookqa \
  --max-cases 5
```

后台运行一个 VoiceBench subset：

```bash
nohup uv run python test/audio_benchmarks/run_voicebench.py \
  --protocol webrtc \
  --subset openbookqa \
  --early-response-policy warn \
  > test/audio_benchmarks/voicebench_openbookqa_webrtc.log 2>&1 &
```

按论文表格的 7 个维度顺序运行。`MAX_CASES` 默认是 20：

```bash
nohup bash test/audio_benchmarks/run_voicebench_each.sh \
  > test/audio_benchmarks/voicebench_20_each.out 2>&1 &
```

修改每个维度的 case 数或其他默认参数：

```bash
MAX_CASES=50 EARLY_RESPONSE_POLICY=retry \
nohup bash test/audio_benchmarks/run_voicebench_each.sh \
  > test/audio_benchmarks/voicebench_50_each.out 2>&1 &
```

运行 7 个维度的全量数据：

```bash
MAX_CASES=all nohup bash test/audio_benchmarks/run_voicebench_each.sh \
  > test/audio_benchmarks/voicebench_all_each.out 2>&1 &
```

常用 subset：

```text
advbench
alpacaeval
alpacaeval_full
alpacaeval_speaker
bbh
commoneval
ifeval
mmsu
mtbench
openbookqa
sd-qa
wildvoice
```

有些 subset 使用的不是 `test` split。例如：

```bash
uv run python test/audio_benchmarks/run_voicebench.py \
  --protocol webrtc \
  --subset mmsu \
  --split health \
  --max-cases 20
```

`alpacaeval_speaker` 使用说话人相关 split，例如
`en_US_Wavenet_A_1.0_0.0_0.0`，不是 `test`。

批量脚本会把每轮运行写入独立报告目录，并生成论文表格风格的结果：

```text
test/audio_benchmarks/test_reports/voicebench_table_YYYYMMDD_HHMMSS/
  voicebench_paper_table_YYYYMMDD_HHMMSS.csv
  voicebench_paper_table_YYYYMMDD_HHMMSS.txt
  voicebench_*.json
```

论文表格维度和评分方式：

```text
AlpacaEval -> G-Eval 分数，表格显示为 1-5 分
CommonEval -> G-Eval 分数，表格显示为 1-5 分
SD-QA -> 准确率百分比
MMSU -> 准确率百分比
OpenBookQA -> 准确率百分比
IFEval -> 准确率百分比
AdvBench -> 安全拒答率百分比
Overall -> 7 个维度百分制原始分的平均值
```

使用 DeepSeek 作为 LLM judge：

```bash
export JUDGE_PROVIDER=deepseek
export DEEPSEEK_API_KEY="sk-..."
export JUDGE_MODEL=deepseek-v4-flash
```

使用其他 OpenAI 兼容的 judge 服务：

```bash
export JUDGE_API_KEY="..."
export JUDGE_API_URL="https://your-provider.example.com/chat/completions"
export JUDGE_MODEL="your-model"
```

## 通用参数

这些评测脚本支持和 BigBench 类似的运行参数：

```bash
--protocol websocket|webrtc
--max-cases N
--per-category N
--min-audio-seconds N
--max-audio-seconds N
--early-response-policy warn|retry|fail
--early-response-retries N
--trailing-silence-ms N
--response-start-timeout N
--response-end-timeout N
--reuse-room
```

报告保存目录：

```text
backend/livekit_agent/test/audio_benchmarks/test_reports/
```

查看最新 VoiceBench 论文表格：

```bash
cat $(ls -t test/audio_benchmarks/test_reports/voicebench_table_*/voicebench_paper_table_*.txt | head -n 1)
```

查看最新详细 JSON 报告：

```bash
cat $(ls -t test/audio_benchmarks/test_reports/voicebench_table_*/voicebench_*.json | head -n 1)
```

每次运行后会刷新一个汇总 CSV：

```text
backend/livekit_agent/test/audio_benchmarks/test_reports/benchmark_table.csv
```

每次运行也会生成一个带时间戳的 CSV 快照：

```text
backend/livekit_agent/test/audio_benchmarks/test_reports/benchmark_table_YYYYMMDD_HHMMSS.csv
```

如果 case 没有 `expected_answer`，报告里的 `correct` 会保留为 `null`，
同时增加 0-100 的 `quality_score` 和 `quality_reason`。这些分数会和准确率分开统计。

汇总指标遵循论文表格风格：

```text
有参考答案 -> accuracy
开放式回答 -> quality_score，0-100
advbench -> refusal_rate
overall_score -> 各顶层任务百分制分数的平均值
```

看论文表格风格结果时，优先看 `summary.score_by_task`。OpenAudioBench 会把细分
category 合并为 5 个顶层任务：`alpaca_eval`、`llama_questions`、
`reasoning_qa`、`trivia_qa`、`web_questions`。

没有 agent 回答的 case 会标记为 `unanswered: true`，并保留 `correct: null`，
因此不会计入准确率、质量分、拒答率或 overall 的分母。

## 注意事项

- 没有单一参考答案的开放式任务也会执行并记录，但 `correct` 字段为 `null`。
- 音频会在注入前转换成 16 kHz 单声道 PCM。
- MP3 解码需要 `pydub` 和可用的 ffmpeg。

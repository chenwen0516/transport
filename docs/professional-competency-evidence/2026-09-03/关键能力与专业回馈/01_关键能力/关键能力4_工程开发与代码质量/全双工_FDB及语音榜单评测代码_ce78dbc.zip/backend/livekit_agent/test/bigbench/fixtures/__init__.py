"""BigBench fixtures"""

from pathlib import Path

# 测试用例目录
CASES_DIR = Path(__file__).parent.parent / "cases"
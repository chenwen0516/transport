"""Pause Handling 测试

测试 AI 对用户停顿的处理能力
"""
import asyncio
import time

from core import (
    RealtimeTestClient,
    DatasetCase,
    EvaluationResult,
    MetricsAggregator,
)


async def test_pause_handling_dataset(
    ws_client: RealtimeTestClient,
    ws_url: str,
    auth_token: str,
    case: DatasetCase,
    metrics_aggregator: MetricsAggregator,
    min_deltas: int = 10,
):
    """使用数据集音频测试停顿处理

    场景：用户在说话中途有停顿，AI 应判断是否接过话轮。
    关键：根据 pause_timestamp 在对应时刻检测 AI 状态变化。

    逻辑：
    1. 边发送音频边检测 AI 状态
    2. 在 pause_timestamp 开始时刻附近检测 AI 是否开始说话
    3. TOR = 1 如果 AI 在停顿期间/后抢话轮
    """
    if not case.input_audio:
        print(f"    跳过 {case.case_name}: 无 input_audio")
        metrics_aggregator.add_result(EvaluationResult(
            task="pause_handling",
            case_name=case.case_name,
            success=False,
            error="missing input audio",
        ))
        return

    await ws_client.connect(ws_url, auth_token)
    ws_client.clear_events()

    t_start = time.monotonic()

    # 边发送音频边检测 AI 状态
    send_task = await ws_client.inject_audio_nonblocking(case.input_audio)

    switched = False
    t_switched = None
    latency = None

    pause_start_s = case.pause_timestamp[0] if case.pause_timestamp else None

    # 监控循环：发送期间持续检测 AI 状态
    while not send_task.done():
        state_changed = ws_client.get_event_time_after(
            "agent.state_changed",
            t_start,
            predicate=lambda e: e.get("state") == "speaking",
        )
        if state_changed:
            t_switched = state_changed
            if pause_start_s is not None:
                real_pause_start = pause_start_s
                real_window_end = (case.pause_timestamp[1] if case.pause_timestamp else pause_start_s + 2.0) + 2.0
                switched_time = t_switched - t_start
                if real_pause_start <= switched_time <= real_window_end:
                    switched = True
                    break
            else:
                switched = True
                break
        await asyncio.sleep(0.05)

    # 等待发送完成
    await send_task

    # 发送完成后额外检测（捕获慢响应）
    if not switched:
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            t_switched = ws_client.get_event_time_after(
                "agent.state_changed",
                t_start,
                predicate=lambda e: e.get("state") == "speaking",
            )
            if t_switched:
                if pause_start_s is None:
                    switched = True
                    break
                switched_time = t_switched - t_start
                real_window_end = (case.pause_timestamp[1] if case.pause_timestamp else pause_start_s + 2.0) + 2.0
                if pause_start_s <= switched_time <= real_window_end:
                    switched = True
                    break
            await asyncio.sleep(0.05)

    if t_switched and pause_start_s is not None:
        latency = ((t_switched - t_start) - pause_start_s) * 1000

    result = EvaluationResult(
        task="pause_handling",
        case_name=case.case_name,
        tor=1.0 if switched else 0.0,
        latency=latency if latency is not None else -1.0,
    )
    metrics_aggregator.add_result(result)

    print(f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}, latency={latency:.1f}ms" if latency and latency > 0 else f"    {'✓' if switched else '✗'} {case.case_name}: tor={result.tor}")

"""pytest fixtures：WS 客户端、音频工具、指标聚合器"""

import asyncio
import os
from pathlib import Path

import pytest
import pytest_asyncio

# 添加 realtime 路径
REALTIME_DIR = Path(__file__).parent.parent / "realtime"
import sys
if str(REALTIME_DIR) not in sys.path:
    sys.path.insert(0, str(REALTIME_DIR))

from core.ws_test_client import RealtimeTestClient
from core.audio_generator import AudioGenerator
from core.metrics import MetricsAggregator


# ========== 环境配置 ==========

def get_ws_url() -> str:
    return os.getenv("WS_URL", "wss://api.health.com/v1/realtime?model=health-assistant")


def get_auth_token() -> str:
    return os.getenv("AUTH_TOKEN", "")


# ========== Fixtures ==========

@pytest_asyncio.fixture(autouse=True)
async def suppress_websockets_rst_noise():
    """静默 websockets 在 TCP RST 时触发的 recv_messages AttributeError"""
    loop = asyncio.get_running_loop()
    original_handler = loop.get_exception_handler()

    def _handler(loop, context):
        exc = context.get("exception")
        if isinstance(exc, AttributeError) and "recv_messages" in str(exc):
            return
        if original_handler is not None:
            original_handler(loop, context)
        else:
            loop.default_exception_handler(context)

    loop.set_exception_handler(_handler)
    yield
    loop.set_exception_handler(original_handler)


@pytest_asyncio.fixture
async def ws_client():
    """创建 WebSocket 测试客户端，测试结束后自动断开"""
    client = RealtimeTestClient()
    yield client
    try:
        await client.disconnect()
    except Exception:
        pass


@pytest.fixture
def audio_gen():
    """音频生成器实例"""
    return AudioGenerator()


@pytest.fixture(scope="session")
def metrics_aggregator():
    """session 级别的指标聚合器，跨测试收集"""
    return MetricsAggregator()


@pytest.fixture
def ws_url():
    return get_ws_url()


@pytest.fixture
def auth_token():
    return get_auth_token()
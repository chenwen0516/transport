"""VoiceBench evaluation runner.

Examples:
    python run_voicebench.py --protocol webrtc --subset openbookqa --max-cases 5
    python run_voicebench.py --protocol webrtc --subset bbh --max-audio-seconds 30
    python run_voicebench.py --protocol webrtc --subset mmsu --split health --max-cases 20
"""

from __future__ import annotations

import argparse
import logging

from common import (
    SimpleBenchmarkDataset,
    add_common_args,
    first_non_empty,
    run_async,
    run_audio_benchmark,
)
from core.case import BigBenchCase  # noqa: E402

logger = logging.getLogger("voicebench.runner")

VOICEBENCH_REPO = "hlt-lab/voicebench"
VOICEBENCH_SUBSETS = [
    "advbench",
    "alpacaeval",
    "alpacaeval_full",
    "alpacaeval_speaker",
    "bbh",
    "commoneval",
    "ifeval",
    "mmsu",
    "mtbench",
    "openbookqa",
    "sd-qa",
    "wildvoice",
]


class VoiceBenchDataset(SimpleBenchmarkDataset):
    @classmethod
    def load(
        cls,
        subset: str,
        split: str,
        category_filter: str | None = None,
        limit: int | None = None,
    ) -> "VoiceBenchDataset":
        from datasets import Audio, load_dataset

        hf_split = f"{split}[:{limit}]" if limit and "[" not in split else split
        logger.info("Loading VoiceBench subset=%s split=%s", subset, hf_split)
        hf_dataset = load_dataset(VOICEBENCH_REPO, subset, split=hf_split)
        for audio_column in ("audio", "audio1"):
            if audio_column in hf_dataset.column_names:
                hf_dataset = hf_dataset.cast_column(audio_column, Audio(decode=False))
        cases: list[BigBenchCase] = []
        for idx, item in enumerate(hf_dataset):
            case = parse_voicebench_item(subset, split, idx, item)
            if not case:
                continue
            if category_filter and category_filter not in case.category:
                continue
            cases.append(case)
        logger.info("Loaded %d VoiceBench cases", len(cases))
        return cls(cases)


def parse_voicebench_item(subset: str, split: str, idx: int, item: dict) -> BigBenchCase | None:
    prompt = first_non_empty(item, ["prompt", "question", "instruction", "turns", "input"])
    if isinstance(prompt, list):
        prompt = "\n".join(str(p) for p in prompt)
    reference = first_non_empty(item, ["reference", "answer", "answers", "target", "output"])
    if isinstance(reference, list):
        reference = "; ".join(str(r) for r in reference)
    if not prompt:
        return None

    case_id = str(
        item.get("id")
        or item.get("question_id")
        or item.get("key")
        or item.get("conversation_hash")
        or f"{subset}_{split}_{idx}"
    )
    category = "/".join(
        str(part)
        for part in [subset, item.get("category") or item.get("src") or split]
        if part
    )
    case = BigBenchCase(
        id=case_id,
        category=category,
        question=str(prompt),
        answer=str(reference or ""),
    )

    audio = item.get("audio") or item.get("audio1")
    if audio is not None:
        case._audio_source = audio
    return case


async def main():
    parser = argparse.ArgumentParser(description="VoiceBench Speech Evaluation")
    parser.add_argument(
        "--subset",
        type=str,
        default="openbookqa",
        help=f"VoiceBench subset/config. Common values: {', '.join(VOICEBENCH_SUBSETS)}",
    )
    parser.add_argument(
        "--split",
        type=str,
        default="test",
        help="Dataset split. Some subsets use non-test splits, e.g. mmsu --split health",
    )
    add_common_args(parser)
    args = parser.parse_args()

    dataset = VoiceBenchDataset.load(
        subset=args.subset,
        split=args.split,
        category_filter=args.category,
        limit=args.max_cases if not args.per_category else None,
    )
    await run_audio_benchmark("VoiceBench", dataset, args)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    run_async(main())
